# Canonical runner reconciliation brief — 2026-09-07

## Exact command count and failures

The `## Regression bundle` block in `docs/game/06_validation_plan.md:322–1138`
contains **652** `run_clean` command lines. The first is the route-control model
smoke at line 454; the last two are the medbay surgery denied smokes at lines 1133–
1134. The final marker at line 1135 is:

```text
echo "SYNAPTIC_SEA REGRESSION PASS commands=${RUN_CLEAN_COUNT} clean_output=true"
```

This agrees with the historical ADR index entry for the Windows validation runtime:
`docs/game/adr/README.md:43` says “652 canonical checks.” The current test is stale at
`tests/test_run_canonical_regression.py:165`, where it asserts 651 commands.

The two observed failures are both caused before count comparison. The marker regexes
in `tools/run_canonical_regression.py:12–19` require decimal digits in `commands=`, and
`extract_bundle()` then requires a matching standalone numeric echo line at lines 73–89.
The document uses the runtime shell variable `${RUN_CLEAN_COUNT}`, so it contains zero
numeric marker matches and raises:

```text
ValueError: expected exactly one canonical regression marker
```

Failures:

| Test | Evidence |
|---|---|
| `test_objectdb_teardown_warning_is_exactly_allowlisted` | `extract_bundle(document_text)` at test lines 131–133 raises the marker error before warning assertions. |
| `test_real_canonical_document_has_consistent_count` | `extract_bundle(document_text)` at test lines 159–162 raises the same error before its stale `== 651` assertion. |

The synthetic tests intentionally exercise numeric markers (`tests/test_run_canonical_regression.py:6–18`), so they do not expose this document mismatch. Earlier focused result was 26 passed, 2 failed in 0.10s; `tools/run_canonical_regression.py --check` exits 2 with the same parser error.

## Minimal bounded reconciliation

Use a literal numeric final marker in the canonical document:

```bash
echo "SYNAPTIC_SEA REGRESSION PASS commands=652 clean_output=true"
```

Retain `RUN_CLEAN_COUNT` for runtime logging if desired, but make the final canonical
marker the parser-owned exact contract. Change the real-document test assertion at line
165 from `651` to `652`. Then the current parser can validate the document and the
count guard will compare 652 parsed `run_clean` lines to 652 claimed commands. This is
smaller and safer than teaching the parser to evaluate shell variables: evaluation
would weaken the fail-closed static extraction boundary and would need shell parsing
semantics that the current tests explicitly reject.

The canonical marker count is therefore 652, not 651. The existing test fixture count
of one remains valid for unit tests; only the real-document assertion is stale.

## P23 allowed-path impact

The generator’s current `P23` allowlist is `tools/build_feature_acceptance.py:673–684`
and is mirrored in `data/validation/feature_completion_cards.json:5083–5174`. It
currently permits the registry, requirements document, 15 build-plan documents, and
the card manifest. It does not permit the canonical validation document or runner
files.

If P23 owns this reconciliation, add these exact paths to the P23 allowlist and card:

| Path | Reason |
|---|---|
| `docs/game/06_validation_plan.md` | canonical bundle marker/count contract |
| `tools/run_canonical_regression.py` | canonical extractor/runner |
| `tests/test_run_canonical_regression.py` | focused parser/count tests |
| `tools/synaptic_sea_gate4_regression.sh` | legacy entry-point delegation |

`docs/game/features/ui_presentation_program.md` should remain excluded from frozen
criteria. It is the parser-admitted proposed UI source causing the 21-row drift, not a
P23 acceptance source to add to the allowlist. If coordinator policy instead records
the proposed document as a governance input, add it explicitly only after the parser
exclusion decision; do not silently admit its 21 leaves.

## Meshy ADR references

The historical Windows ADR remains `docs/game/adr/0060-windows-feature-completion-validation-runtime.md`.
The new Meshy decision is indexed as `0068` at `docs/game/adr/README.md:53`, but its
file header is still `ADR-0060`.

All Meshy references requiring the header/internal-ID correction are:

| Location | Current reference | Required bounded update |
|---|---|---|
| `docs/game/adr/0060-meshy-offline-evidence-rebind.md:1` | `ADR-0060: Offline Meshy Evidence Rebinding` | `ADR-0068: Offline Meshy Evidence Rebinding` |
| `docs/game/adr/0058-meshy-candidates-blender-authority.md:270` | path-only `docs/game/adr/0060-meshy-offline-evidence-rebind.md` | path stays unchanged; no ID text to change |
| `docs/game/features/ai_candidate_asset_pipeline.md:412` | path-only `docs/game/adr/0060-meshy-offline-evidence-rebind.md` | path stays unchanged; no ID text to change |
| `docs/game/06_validation_plan.md:200` | `ADR-0060 offline evidence rebinding` plus path | change prose label to `ADR-0068`; path stays unchanged |

Do not rename the file or historical Windows ADR. README’s 0068 allocation is already
correct and should remain.
