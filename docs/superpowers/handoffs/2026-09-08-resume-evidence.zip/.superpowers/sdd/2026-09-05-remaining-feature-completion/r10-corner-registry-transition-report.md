# R10 corner/T registry transition report

## Reviewed transition

The registry now accepts reviewed one-for-one feature-source supersessions only for `docs/game/features/structural_wrapper_collision.md` under `Acceptance criteria`; requirement-source supersessions retain their existing guard. The three R10 replacements retain their original stable IDs, acceptance kinds, deferred status, metric representative, frozen source leaf-set fingerprint, and denominator: **668 recorded / 657 active / 11 deferred / 622 active metric**.

The reviewed supersession-set fingerprint changed after exact mapping review from `ffe325ef281156711db10d85eb896a4781804ec976944aef4a948bdbe12ad0df` to `54f7c6f782eac4ca7e4a589304b9a74fc754ab3f3384bdf0d5ee3121ec482a8f`. The derived registry records four reviewed mappings, including the existing REQ-SMOD mapping.

The R10 leaves below are reset to `not_verified` with no inherited refs:

- `FEATURE::docs/game/features/structural_wrapper_collision.md::77be1df64944` -> `cbd31fe20bec...`
- `FEATURE::docs/game/features/structural_wrapper_collision.md::3a8fddf3798b` -> `a1d74b54c62f...`
- `REQ-DECAY-002::acceptance-95a1331257bc` -> `37239ecbf322...`

Unchanged criteria keep their historical evidence only when their stable ID and criterion fingerprint still match. Geometry-dependent runtime evidence requires fresh requalification; no completion claim was promoted.

## Reviewed identity correction

The initially supplied proposal-01 mapping declared replacement identities inconsistent with the actual generator digest. The captured expected-failure evidence is in `r10-corner-registry-transition-review-package/initial-proposal-identity-mismatch.log`. Root-approved correction authority: `r10-corner-corrected-criterion-mapping.json`, SHA-256 136b46ee75ff7a466efb48aa94d070f550765bace6d1e1e28bd39d4a8042983b. It changes only replacement IDs and fingerprints; wording and original IDs are unchanged.

## P17 scope

P17 now explicitly permits the half-span source contract, generator/registry outputs, source proposal-02 mapping/spec, structural compiler/serializer, real three corner/T wrapper source/import/manifest/contract paths, and focused validation. Its card states that vertex-owned `(2, 3, 0.2)` rays plus residual half straights provide exact 4 m SOLID-edge coverage without gaps, extra spans, or duplicates. Wrapper metadata paths remain under `scenes/wrappers/structural/ship_structural_v0`.

## Verification and immutable artifacts

- `uv run python -m unittest -v tests.test_feature_acceptance_registry`: 27 tests passed.
- `uv run python tools/build_feature_acceptance.py --write --check`: `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0`.
- No Godot command was run.

The immutable package includes beforeimages, afterimages, a scoped diff generated from those beforeimages, raw output, expected-failure identity evidence, exit metadata, and SHA-256 manifests at `r10-corner-registry-transition-review-package/`.
