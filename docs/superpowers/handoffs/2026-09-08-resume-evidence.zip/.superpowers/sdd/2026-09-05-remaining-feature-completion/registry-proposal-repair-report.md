# Registry proposal repair report

## Outcome

**DONE** — the frozen crafting/derelict acceptance registry visibly catalogs the
single reviewed UI planning proposal while excluding its 21 extracted leaves
from source scope. The frozen source fingerprint and reviewed supersession
fingerprint remain unchanged.

The catalog is deliberately document-specific. It requires the exact current
status of `docs/game/features/ui_presentation_program.md`; promoted, ambiguous,
or missing status and a missing catalogued document fail before scope review can
write output. Other feature documents remain source-accounted, so an unexpected
source or removal of an existing frozen source produces frozen-scope drift.

## Frozen accounting evidence

| Property | Result |
| --- | --- |
| Source fingerprint | `8041e481680152f85fe2d3617491880a5268d89dcb63a59608590711edef48d0` |
| Supersession fingerprint | `ffe325ef281156711db10d85eb896a4781804ec976944aef4a948bdbe12ad0df` |
| Recorded / active / deferred | `668 / 657 / 11` |
| Canonical denominator | `622` |
| Catalogued proposal leaves | `21` |
| Catalogued proposal status | `Proposed for review, 2026-09-05. Planning only; no UI implementation or visual acceptance is claimed.` |

## Changed files and immutable beforeimages

Beforeimages were captured before implementation in
`registry-proposal-repair-beforeimages/`. The immutable review package at
`registry-proposal-repair-review-package/` copies both sides, materializes the
five-file unified diff in `registry-proposal-repair-scoped.diff`, retains fresh
focused test/check stdout/stderr with exit metadata, and hashes every package
file in `SHA256SUMS.txt`. The table gives each exact before and after SHA-256.

| Working path | Beforeimage name | Before SHA-256 | After SHA-256 |
| --- | --- | --- | --- |
| `tools/build_feature_acceptance.py` | `tools__build_feature_acceptance.py` | `89d328225e59b04e1107ec0ffaf857d3ec98ee58b28b5a71838345ac8ed7f7e5` | `b56757de18db7369a7790afbd3d6efd9b965cf5783dd7f1a029245170aa6ec27` |
| `tests/test_feature_acceptance_registry.py` | `tests__test_feature_acceptance_registry.py` | `70a786a9763eef942023d73bb3a379b0a1299dcc613a1f980d5f24d7216b6d8f` | `af2b47142ce837ace966916e3acaf6a3b2b54abe5eb4a7ba257ef0b99462b66f` |
| `docs/game/inventory/feature_acceptance.json` | `docs__game__inventory__feature_acceptance.json` | `345b4844eccfd9bf2c371cb2391fc0874b7e18c8312e3e30a43cf2686659f7bf` | `b1dab1ecd6f7ee796e1334146f0431f2ad7236086621258a84e43ad4f6a35722` |
| `data/validation/feature_completion_cards.json` | `data__validation__feature_completion_cards.json` | `e0216f7214a18d11b7b52417529c5bde6e7d4435b7f8b248f0364ac4765d39f5` | `d49128888e53210ce9ca41d5ad5888594270092e250603fe5bb50d947688f5c8` |
| `docs/game/features/crafting_derelict_feature_completion.md` | `docs__game__features__crafting_derelict_feature_completion.md` | `ddafbe2c0c07b75f8c29aa9fb9c72aadb9d19bc22c273692cd8852a9552838c4` | `0b282550c99e651107bef138b1d9ebae17a1566e36223d4ba554af57f62ed558` |

The implementation adds the explicit catalog, validates it during build and
stored-registry validation, excludes only that catalogued path from source
inventory/fingerprint construction, and records P23 governance. The test suite
adds the real 21-leaf case, accepted/ambiguous/missing status rejections,
unexpected-source rejection, and existing-frozen-source removal rejection.

The regenerated manifest also includes the five root-authorized P23 canonical
regression reconciliation paths and records the 652-call/numeric-marker/runtime
guard and Meshy ADR-0068 ruling. No canonical-regression implementation file was
edited by this repair.

## Source hashes

| Source | SHA-256 |
| --- | --- |
| `docs/game/features/ui_presentation_program.md` | `12f3a5b147104fa9efb2a98bb732cf40063fa6609263baf98b72ed087f8a0899` |
| `docs/game/05_requirements.md` | `83419690cafa7c60f0824e02b544e73e0fa5f0616c38eb74a42c20e0634545aa` |
| `data/validation/reviewed_criterion_supersessions_v1.json` | `9ab825c42402cf4a028d6b5727d82e2b87b0a67465e31f84183a4c376ce8febf` |
| Regenerated registry | `b1dab1ecd6f7ee796e1334146f0431f2ad7236086621258a84e43ad4f6a35722` |
| Regenerated card manifest | `d49128888e53210ce9ca41d5ad5888594270092e250603fe5bb50d947688f5c8` |

## Verification

All commands used `.superpowers/test-runtime/Scripts/python.exe`.

| Command | Exit | Evidence |
| --- | --- | --- |
| `-m pytest -q tests/test_feature_acceptance_registry.py` | 0 | `25 passed` |
| `-c "from tools.build_feature_acceptance import build; ..."` before write | 0 | fingerprint and `668 / 657 / 11 / 622` matched |
| `tools/build_feature_acceptance.py --write` | 0 | `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0` |
| `tools/build_feature_acceptance.py --check` | 0 | same PASS marker |
| `-m pytest -q tests/test_feature_acceptance_registry.py` after write | 0 | `25 passed` |
| `git diff --check -- <owned paths>` | 0 | no whitespace errors |

## Retained evidence and risks

The immutable beforeimages retain all R10 generator, manifest, and feature-spec
content that existed before this repair. The materialized derived-registry diff
contains source-line anchor changes from the incoming merged-base source layout
and generator normalization. `docs/game/05_requirements.md` has no working-tree
diff; no concurrent requirements edit is asserted. Criterion fingerprints and
the frozen source fingerprint remain unchanged, and `--check` validates the
current generated output.

No Godot or runtime validation was run, as required by the brief.

## Round-one review fix

Independent review found that the catalog previously accepted multiple status
declarations because the general parser returned only the first declaration.
The catalogued UI proposal now requires exactly one recognized document-level
status declaration before comparing it to the frozen exact status. This is local
to the reviewed proposal catalog; unrelated feature-source status parsing is
unchanged. Focused tests cover an initial valid declaration followed by
`Accepted`, plus two valid-looking duplicate initial declarations.

The additive immutable package is
`registry-proposal-repair-fix1-review-package/`; it does not overwrite the
initial review package. Its materialized scoped diff is
`registry-proposal-repair-fix1-scoped.diff` with SHA-256
`939fc539dce458c7ed7d46c6f2dc5af3554f4f93a1f9dc1f7e35a1a2560f3ba6`.
It retains fresh focused pytest and registry-check stdout/stderr and exit
metadata; both commands exited 0 with `25 passed` and the registry PASS marker.
