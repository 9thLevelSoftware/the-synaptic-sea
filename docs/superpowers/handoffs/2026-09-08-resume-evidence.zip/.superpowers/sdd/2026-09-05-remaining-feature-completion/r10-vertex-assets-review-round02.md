# R10 vertex assets — round 02 review

## Decision: Approved for the round-02 frozen asset package

Reviewed `task-10a-work-evidence/fix-round-02-vertex-z-axis-01/production-assets-freeze/manifest.json`.
Its SHA-256 is the required
`b40db66c1ca9a7929c95648a885eb38c4df76e0dc86134d6a8a4afd5be0151eb`.
The earlier failed review remains preserved in
`r10-vertex-assets-review.md`; its direct-bounds checker is retained and was
rerun for this review.

This approves the frozen source/GLB asset package.  Godot imported-cache and
materialized runtime behavior remain an integration gate outside this review.

## Independent evidence

- Recomputed SHA-256 and byte size for each of the 27 frozen files: all match
  the round-02 manifest.  The ten intended changes are the recipe, three Blend
  sources, three source records, and three GLBs; the other 17 paths are byte
  identical to the round-01 freeze.  Recomputed every listed evidence hash with
  no mismatch.
- Ran the retained read-only direct GLB checker using the project Python runtime;
  command and raw output are in `r10-vertex-assets-review-round02-evidence/`.
  It decodes actual POSITION accessors, composes glTF scene node transforms, and
  does not use a Blender inverse-axis conversion.  All seven direct world bounds
  now match: north `x=-0.1..0.1,y=0..3,z=-2..0`, east
  `x=0..2,y=0..3,z=-0.1..0.1`, and T west `x=-2..0,y=0..3,z=-0.1..0.1`.
  Wrapper Visual/VisualInstance remain identity, so these are the visible wrapper
  coordinates.
- Inspected the changed recipe.  It preserves canonical saved source and helper
  coordinates as `contract[x,y,z]->blender[x,z,y]`, temporarily moves only the
  selected visual objects via the inverse export mapping
  `contract[x,y,z]->blender[x,-z,y]`, validates direct GLB accessor/node bounds
  on the temporary GLB, atomically publishes only after that validation, and
  restores each saved visual location in `finally`.  Thus the correction is
  export-only and leaves no persistent visual/helper mismatch in the Blend.
- The preserved raw Blender source-alignment inspector reports all seven saved
  source ray locations as canonical Z-up values and `PASS modules=3 rays=7`.
  The reauthor-twice build output independently shows direct validation before
  each temporary-file publish.
- Inspected all three new source records and the recipe provenance constants.
  Each retains the immutable recovered-original GLB hash from before round 01,
  separately records its new current authored GLB hash, and records the three
  coordinate conversion stages.  The preserved reauthor-twice provenance check
  confirms this separation for all modules.
- Compared old and new GLB materials directly.  All retain the sole
  double-sided `SSV0_BULKHEAD` material, color `(0.22,0.25,0.29,1)`, metallic
  `0`, and roughness `0.7`; no texture/image or palette regression was found.

The prior north-ray failure is fixed.  No asset-level finding remains.
