# Task 6 Fix Round 1 — Independent Review

**Verdict: SPEC NOT APPROVED; QUALITY NOT APPROVED.** Two HIGH issues remain: one original acceptance-evidence gap is only partially fixed, and the fix introduces a stale-occupancy authorization regression.

Review scope was the exact frozen fix delta against fix base `0a6a0aa5076acd6c52e06915048f5b832867ae2255e0e364726170bfae34b9f9`, not the inherited HEAD/worktree. Reviewed package:

- `task-6-afterimages/fix-round-01-review-package-01/manifest.json` — SHA-256 `c2028e0740c8214c05921345b95ef9441f4177223a47f0988c2165920a251480`
- `task-6-afterimages/fix-round-01-runtime-freeze-01/manifest.json` — SHA-256 `94eead491457a8ccac12c3503f670eaa1fa737b33626dded3f5ec3389a0f5ad3`

## Original finding verdicts

### 1. Canonical live target range — ADDRESSED

`scripts/procgen/playable_generated_ship.gd:4322-4345,4441-4484,4607-4615,4798-4823,6385-6415`

The production start path now authenticates the target and revision, derives the range point from the authenticated physical slot/module, rejects a caller point that is absent, non-finite, or different from the canonical point, and checks a finite live player position. Active tick and commit derive the canonical point again, so a cached caller point cannot stand in for a moved owner or target. The interactive module callback now supplies the canonical module position rather than the player's position. The focused evidence exercises forged-nearby, non-finite, moved-owner pause, and moved-owner commit cases through production callbacks with protected-state snapshots.

No further remediation is required for this original finding.

### 2. Full protected production sinks and reentrant callback assertions — NOT ADDRESSED

`scripts/validation/fc_p11_smoke.gd:40-79,98-126`; `scripts/validation/fc_p12_smoke.gd:765-818,821-883`

The fix materially improves this area: P12 now drives footprint, socket, and type denials through `_start_transactional_work()` and compares the full authoritative snapshot; it also validates post-reservation target removal, exact escrow retention/recovery, and a real callback-triggered reentrant commit/cancel denial. Those parts of the original finding are addressed.

The required FC13 denial matrix is still not production-authoritative in full. Water/non-component input, unknown item/component, missing/unknown slot or profile, occupied slot, incompatible slot, and wrong-ship cases remain in unchanged P11 pure-model calls. Those checks snapshot only inventory quantities, placement/modification summaries, and power, with no production transaction ledger, receipt, exact lot identity, progression/training XP, threat noise, or completion-audio assertions. Consequently the evidence still cannot detect a production adapter that creates a transaction or emits side effects before/after the model returns one of these denials.

**Why it matters:** FC13 requires every denial to prove no spend and no protected authoritative consequence through the production callback boundary. Pure-model correctness does not establish callback ordering or side-effect isolation.

**Remediation:** extend the production denial table to cover every authored FC13 case, including water/non-component, unknown component/item, missing slot/profile, occupied slot, incompatible slot, and wrong ship. For each case, invoke the real start/panel callback and compare exact inventory lots, physical placement, integrity/modification/system projections, full transaction ledger and receipt count, training/progression XP, threat noise, and completion audio before and after. Keep the newly added post-reservation and live reentrancy cases.

### 3. Fresh direct `ship_mod_run_snapshot_smoke.gd` — ADDRESSED

`task-6-afterimages/fix-round-01-review-package-01/freeze/evidence/direct-ship-mod-run-snapshot-01/summary.json`; `scripts/validation/ship_mod_run_snapshot_smoke.gd:108`

The retained direct run is fresh and clean: exit `0`, exact marker `SHIP MOD RUN SNAPSHOT PASS shipmod=true pillar=true count=true` exactly once, empty diagnostics, no cleanup error, and a passing containment probe. The probe records `APPDATA`, `LOCALAPPDATA`, `GODOT_USER_PATH`, and `XDG_DATA_HOME` under the same owned root.

No further remediation is required for this original finding.

## New fix-delta finding

### HIGH — Start admission uses occupancy captured before recomputation

**Affected component:** `scripts/procgen/playable_generated_ship.gd:4192-4210,4302-4350`

`_start_transactional_work()` constructs `work_context` at line 4319. `_ship_work_context_for()` snapshots `is_occupied` and `is_piloted` from `current_occupancy` and `piloted_ship`. The start path then calls `recompute_occupancy()` at line 4346 but invokes `preflight_physical_mutation()` on the already-created context at lines 4347-4348. Recomputing the playable's fields does not refresh the context's captured booleans.

**Why it matters:** when the player's attendance changes immediately before start, physical authorization can use stale state. A context captured as occupied can admit work and reserve escrow after the player has left the owner ship; a context captured as unoccupied can wrongly deny after the player boards. This violates the start-time physical admission and no-spend-on-denial contract. The shared helper `_physical_work_preflight()` has the correct order—recompute first, then create the context—but the fixed start path bypasses that ordering because it needs the context earlier for target authentication.

**Remediation:** recompute occupancy before constructing `work_context`, or reconstruct/refresh the context after recomputation and use that refreshed instance for all subsequent target, range, and physical admission checks. Add a production test that changes actual player/ship attendance immediately before `_start_transactional_work()` without manually refreshing occupancy and asserts the expected admission result; on denial, assert no active work ID, no transaction/receipt, and unchanged exact inventory lots and protected sinks.

## Evidence assessment

The retained final canonical P10/P11/P12/P13 summaries and the 12 focused P11/P12/P13 cases report exit `0`, each exact PASS marker once, empty diagnostics, clean cleanup, and passing containment probes. The additional P13 authoritative-denial run and the direct snapshot run have the same clean shape. Retained static evidence reports `36 passed`, orphan-smoke membership `PASS` with 211 smokes, and registry `PASS` with 668 criteria and zero unassessed sources. These runs support the addressed portions above but do not cover the stale-occupancy transition or replace the missing production denial cases.

This review does not accept G1/G2, the known-red natural route, natural gameplay acceptance, or the inherited HEAD monolith.
