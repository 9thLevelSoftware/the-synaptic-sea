# R10-A baseline component independent review

Reviewer: `/root/r10_baseline_review` (Sol). Root preserved the returned findings here because the reviewer role prohibits file mutation. This is a condensed transcription; the complete original report is retained in the conversation.

**Spec compliance: FAIL. Task quality: Needs fixes.** Four HIGH findings block baseline acceptance. Scope is the exact accepted-R06-to-qualified 22-source diff, excluding unrelated inherited monolith work.

## Verified package and strengths

- Package manifest SHA-256: `56adde40d6ab1e8492e9bfcb19bf6e605d2bd75d8344d749c08d141f44840f39`.
- Diff SHA-256: `7cfaf55d2393a8a0535704103b291320d149568655b370483828bf81d693b474`.
- Qualified source manifest SHA-256: `9c1c9c85acd0c9b51637579d871af8d20dd6a1343135a17f9564d43147be8d47`.
- All 176 package entries and 22 source/afterimage entries match declared sizes and hashes.
- Materialized projection validates finite binary32 values, hashes, wrapper identity, nonsingular transforms, and live collision content.
- Ceiling collision is 4 x 0.2 x 4, centered at Y=3.9; visual bounds remain separate.
- All 15 Godot cases and 15 separate owned-profile probes have exit 0, one exact marker, clean diagnostics, distinct four-variable environment roots, and matching resolved user paths.
- Production collision/controller traversal covers both directions, the closed barrier, home/away occupancy, and closing behind the player. Zero-volume contact remains legal.

## HIGH 1: Authoring bypasses structural compilation

Affected files under `scripts/procgen/`: `dock_endpoint_authoring.gd:141-150`, `life_boat.gd:178-188`, `ship_layout_generator.gd:189-196`, `ship_generator.gd:409-424`.

`author_layout()` changes a compiled exterior edge and placement from SOLID to DOOR after compilation and validation. It does not supply an explicit exterior portal row for the compiler's one-sided portal rule. Thus `structural_plan_validated` describes a subsequently modified plan. No compiler round-trip proves the endpoint/portal/edge relationship. The lifeboat builder also calls `push_error()` on failure but continues returning/applying the layout.

Required fix: author the endpoint and explicit exterior portal after solved occupancy but before authoritative compilation. Compile and validate that input, then derive or verify registered endpoint identity against the compiled portal, edge, and placement. Lifeboat failure must not publish a layout. Round-trip tests must prove the explicit exterior form succeeds and ordinary one-sided portals still fail.

## HIGH 2: Seam containment is tautological

Affected: `scripts/procgen/dock_endpoint_authoring.gd:723-768`, consumed by `scripts/systems/docking_manager.gd:178-194`.

The predicate merges observed join/join intersections, then tests containment of those same intersections in their union. `join_overlap_outside_seam` is unreachable; any records labeled join may overlap anywhere. The unused `DockingManager._seam_envelope()` near lines 483-502 repeats this method.

A literal union of host/mobile outward-half-space clips is also insufficient: every intersection point lies in one of the complementary half-spaces, hence in one of the clips. Rewriting the code that way would not create an independent permission boundary.

The retained evidence does not establish whether canonical pairs require positive join overlap. The traversal smoke checks only zero non-join overlap and capsule clearance; the logs omit the returned join count. The coordinator assigned a bounded diagnostic.

Required fix: if canonical pairs need no positive join overlap, reject every positive cross-hull intersection, including joins, while preserving zero-volume contact. Otherwise derive permission from independently authenticated canonical connector reference geometry, not the observed boxes being judged. Do not invent a slab thickness or epsilon. Add a negative case proving a displaced or oversized join overlap is rejected.

## HIGH 3: Endpoint, join, and spawn authority are insufficiently validated

Affected: `scripts/procgen/dock_endpoint_authoring.gd:61-86,207-257,266-290`; `scripts/procgen/playable_generated_ship.gd:10650-10679`.

Selection ranks unrelated room roles after dock and airlock instead of failing when neither authorized role provides a candidate. Validation checks keys, an edge, normal, position, two nonempty join IDs, and a fingerprint recomputed from the supplied IDs. It does not bind all endpoint/port/portal/room/deck/cell/direction/module fields to one compiled portal, the first join ID to that edge placement, or the second to the directly incident allowed floor/corridor-floor placement. Navigation identities are not resolved to distinct nodes; clearance points are not fully validated for finiteness, side, or capsule separation.

Because the fingerprint trusts supplied IDs, unrelated placements can be relabeled as joins. Spawn ID, room ID, and navigation ID are similarly opaque present fields; only owner, position, owner bounds, and collision clearance are materially checked.

Required fix: derive and compare every authority field against the compiled structural record. Require a real dock room, otherwise a real airlock room, otherwise fail. Authenticate exact edge and incident floor identities, transforms, modules, portal, and owner cell. Resolve navigation identities and validate clearance geometry. Authenticate the spawn row against the selected lifeboat endpoint/interior anchor. Add mutation tests for spoofed IDs, unrelated floors, wrong room/deck/cell/module/portal, wrong navigation identity, malformed clearance, and absence of authorized room roles.

## HIGH 4: Fresh boot places twice and publishes home occupancy early

Affected: `scripts/procgen/playable_generated_ship.gd:10430-10485,10579-10624,10635-10647,10750-10755`.

`_on_ship_loaded()` calls `_spawn_player()`, which teleports to the home loader start, then assigns home occupancy. Only afterward does `_build_lifeboat_at_home()` validate docking, create the closed barrier, validate the authored spawn, teleport again, and recompute occupancy. Final-state smoke assertions cannot detect these earlier actions.

Required fix: separate construction from placement. Keep the fresh player inert and do not publish home occupancy before pair, barrier, spawn, and capsule validation. Then place exactly once and publish lifeboat ownership. Preserve staged restore/reload behavior. Add an observable ordering test recording teleports and occupancy publication, including failure with no partially published playable state. The coordinator confirmed that synchronous setup does not waive the single-placement contract.

## LOW: Some execution claims lack raw output

The 15 case/probe records are inspectable. The package lacks raw aggregate-runner output proving the aggregate marker and raw output for the claimed 19 Python tests and projection check. Include command, exit code, stdout, and stderr for those executions in the next qualification package.

## Limitations

No Godot suite was rerun; static defects are decisive. Outside-diff inspection was limited to the named docking, spawn-order, and validation paths. The reviewer changed no files or branch state. Current HEAD and unrelated monolith changes were not acceptance scope.
