### Spec Compliance

- ❌ Issues found. The unit correctly stays within the released Unit 5A file boundary and reproduces the fixed home/lifeboat descriptors plus all six supplied fallback/native reference projections exactly. It also implements the required complete-set, no-survivor, divergent-survivor, and equivalent-survivor outcomes in `scripts/systems/world_v6_layout_projection.gd:1735-1789`. It is not yet spec compliant because runtime fallback generation accepts unauthenticated future RNG engines, native parsing can admit incomplete malformed output, and the persisted witness authority does not trace every witness to an exact world-6 producer.
- ⚠️ Cannot verify from this unit: damage/compiler/state projection, schema adapter, current authoring/live capture, save wiring, and staged live placement are explicitly assigned to later units and were not reviewed here.

### Quality Verdict

- **Needs fixes.** The detached/pure boundary, failure vocabulary, exact candidate comparison, and literal independent captures are strong. The three HIGH findings below can produce an incorrect historical projection or allow a later orchestrator to authenticate it from unproven data, so the unit should not be integrated until they are fixed and the focused smoke closes the rejection-path mutation gap.

### Strengths

- `scripts/systems/world_v6_layout_projection.gd:1-18` keeps the projector detached from the scene tree and documents the trusted completeness seam. The diff contains no mutable current generator/endpoint preload, runtime Git access, artifact access, or fixture dependency.
- `scripts/systems/world_v6_layout_projection.gd:1688-1751` builds fallback plus authenticated platform native candidates internally. `scripts/systems/world_v6_layout_projection.gd:1757-1789` rejects incomplete sets before witness selection, distinguishes no survivor from divergent survivors, and preserves all route names for equivalent projections.
- `scripts/systems/world_v6_layout_projection.gd:2048-2140` hashes the platform binary before invoking the registered class and checks generator version 2. Missing platform, binary, class, method, version, malformed JSON, or unusable native projection all remain unavailable rather than selecting fallback.
- `scripts/systems/world_v6_layout_projection.gd:1792-1816` reproduces the c51 docking transform math, including normalized facings and yaw-only rotation. The fixed authority values at `data/migrations/world_v6_geometry_authority_v1.json:43-114` match the pinned home, lifeboat, hangar-slot, and home-docked-lifeboat witnesses.
- Focused c51 symbol check: the embedded `FrozenRoomAssigner` and `FrozenCellLayoutEngine` expose the same 10 and 59 function symbols respectively as blobs `c7738a...` and `cb742f...`; the topology subset omits only unused historical `get_zone`. The derelict archetype matches the pinned JSON semantically, and all 14 template IDs/blob IDs appear in the specified order.
- Frozen file SHA-256 values match the coordinator-provided GREEN-03 set: projector `E1F8130927B597828B4F7184BF79F83658D542D313577A7E67B96FFABD43663C`, authority `E9A45432E4B3A28D3D3DD915C892519AAF24470DD6C5B6F372FCF9DBFE9149E1`, smoke `CB7A6C379B622B4B87C9F63AD698C275D649397961930AB780B8FBF7A61094EB`. The implementer package also matches `DC948FE1A6E7DB835D88EBFB656A767AAB66222440F4D1A2C0C6D136B35B9D73`.
- Evidence inspection (tests not rerun): `artifacts/feature-completion/R10-A-world6-layout-projection-green-03/result.json` records exit 0, 0.532 seconds, one exact PASS marker, empty stderr, no diagnostics, stable source hashes, and a clean P10 containment probe. Its stdout/stderr hashes are `E4B5C86393CFF025BEBF898ABF0240C56D408B8ED889E3FF11F3D447F98D056D` and `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`.
- Independent fallback evidence is at `artifacts/feature-completion/R10-A-world6-layout-reference-capture/historical-green-01/body.stdout.log` (`0D371AD8E948AC698284D0FB71F7B6BD9F0B2C349D4BD89605A03C6525D78995`). Its seed `-73` RoomAssigner warning is isolated in stderr (`7ECB06380AA380BD169BC4D73CF7862F5E183B5724D0D879316A2B94EFBF02D4`) and specifically classified only for the archived reference by `historical_reference_classification.json` (`24DD30D310456B29C0DE76807AFAB1BBCE1356124270CE13C7807930ED558A79`). Production GREEN-03 is clean.
- Independent native evidence is at `artifacts/feature-completion/R10-A-world6-layout-reference-capture/native-green-01/r10a-world6-native-v2-reference.stdout.log` (`EE8672F991B965FEB65783578950650078E79832CF76EF69B66E29D8DAC9A852`), with empty stderr (`E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`). The capture directly authenticates the Windows DLL hash and generator version before calling `export_layout_json`.

### Issues

#### CRITICAL

- None.

#### HIGH

- **Affected:** `scripts/systems/world_v6_layout_projection.gd:1688-1709`, `scripts/systems/world_v6_layout_projection.gd:1819-1828`, and `data/migrations/world_v6_geometry_authority_v1.json:5-9`.
  **Problem:** The fallback path never authenticates the RNG runtime. The authority declares Godot 4.7.1 and says a newer engine is accepted after a focused comparison, but `_load_authority()` checks only schema/source commit and `_generate_fallback_candidate()` runs under any engine build. GREEN-03 ran the explicitly accepted ADR-0060 Windows build `4.7.2.stable.mono.official.ed1daf0bf`, but the production projector has no restriction to that reviewed build or any other conformance authority.
  **Why it matters:** A future Godot RNG change can silently produce a different room order/layout for an untested save and be treated as exact historical geometry. The contract requires unreconstructible/unavailable routes to reject; three captured seeds do not establish unrestricted future-engine equivalence.
  **Remediation:** Keep the accepted ADR-0060 4.7.2 build admitted, but add a closed runtime/conformance table covering the historical 4.7.1 contract and the exact accepted 4.7.2 build fingerprint with its reviewed evidence. Return `legacy_generation_route_unavailable` for every other build. A fully frozen RNG implementation is also sufficient. Add a focused rejection for an unlisted engine fact through a pure authentication seam.

- **Affected:** `scripts/systems/world_v6_layout_projection.gd:2188-2227` (`_candidate_from_native_layout`).
  **Problem:** Native output parsing silently skips malformed topology cells, non-dictionary structural placements, unsupported/malformed placement rows, and invalid positions. It can then build a valid-looking projection from the survivors and `_form_native_candidate()` reports `candidate_set_complete=true` at `scripts/systems/world_v6_layout_projection.gd:2136-2140`.
  **Why it matters:** This converts an incomplete native route into an authenticated candidate. Missing or malformed rows can change the averaged airlock center, hangar slot count/order, and anchors, allowing a wrong historical attachment transform instead of the required `legacy_generation_route_unavailable` failure.
  **Remediation:** Strictly validate the complete native document shape and every row relevant to room/cell and attachment ordering. Reject duplicate/empty room identities, malformed cells, malformed structural-placement arrays/rows, and malformed floor positions rather than continuing. Any incomplete native parse must return `candidate_set_complete=false`. Expose the pure native-document decoder for a focused malformed-output smoke.

- **Affected:** `data/migrations/world_v6_geometry_authority_v1.json:10-42` and `data/migrations/world_v6_geometry_authority_v1.json:159-191`; enforced only generically by `scripts/systems/world_v6_layout_projection.gd:2350-2411`.
  **Problem:** The authority lacks the required exact extracted-symbol manifest and exact historical producer mapping for persisted witnesses. `room_cell_markers.source` is only the phrase “closed world-6 combat/objective records”; it supplies no producer path/blob, enclosing schema, or field path. Focused producer inspection found a concrete world-6 threat witness at `scripts/systems/threat_save_contract.gd:14-18` and `scripts/systems/threat_save_contract.gd:169-170`, while `scripts/systems/derelict_objective_controller.gd:77-82` does not itself persist room/cell geometry. The authority also lacks per-copied-source byte SHA-256 values; all 14 embedded template documents normalize historical `vertical_transition_probability` JSON floats (`0.0`/`1.0`) to integers, so the embedded rows cannot substitute for the required exact byte-source manifest.
  **Why it matters:** The later migration orchestrator has no closed authority for deciding which saved fields may become route-disambiguating evidence. Treating a guessed or regenerated objective coordinate as persisted historical evidence could select the wrong route. Missing symbol/byte provenance also prevents auditing whether this large frozen copy remains the enumerated c51 closure.
  **Remediation:** Add an exact extraction manifest to the authority/source package: source path, full Git blob, byte SHA-256, and exact extracted symbols for each algorithm/data source. For each allowed witness, name the world-6 producer file/blob, envelope schema, exact nested field path, and conversion into the typed witness row. Restrict the orchestrator to those validated producer mappings; remove “objective” provenance unless an actual persisted producer with both identity and topology-local cell is identified.

#### MEDIUM

- **Affected:** `scripts/validation/r10a_world6_layout_projection_smoke.gd:65-108` and `scripts/validation/r10a_world6_layout_projection_smoke.gd:205-269`.
  **Problem:** The smoke checks input immutability only around one successful `project_fallback_candidate()` call. It does not snapshot candidates/witnesses for incomplete-set, no-survivor, ambiguous-survivor, malformed-witness, malformed-candidate, or malformed-transform rejections. It also lacks the one-surviving-real-witness case that proves a persisted room/cell marker can disambiguate differing routes.
  **Why it matters:** “Malformed/unavailable/ambiguous cases reject without input mutation” is an explicit acceptance criterion. The implementation currently duplicates inputs in the relevant paths, but the supplied acceptance evidence does not prove that requirement and will not catch a later regression.
  **Remediation:** Snapshot every candidate/witness/airlock input before the negative calls and assert exact equality afterward. Add a pair of differing authenticated candidates and a real producer-shaped room/cell witness that leaves exactly one survivor, while preserving both the zero-survivor and divergent-survivor cases.

#### LOW

- None.

### Assessment

**Task quality:** Needs fixes

**Reasoning:** The implementation is well bounded and its supplied exact-reference outputs are credible, but it does not yet fail closed for unknown RNG runtimes or partially malformed native documents, and its persisted-witness provenance is not auditable enough to prevent guessed route selection.

### Checks Performed

- Read the frozen 5,174-line three-file diff once in bounded passes; no changed production file was reread separately.
- Compared the released brief section A items 1-3 and 6 plus the final coordinator subdivision against the binding historical projection contract at `docs/game/features/crafting_derelict_feature_completion.md:371-383`.
- Performed focused c51 checks only for named risks: blueprint range behavior, exact DockPorts/DockingManager attachment math, copied room/cell/template symbol closure, and copied archetype/template data. No full-repository review was performed.
- Inspected the current world-6 threat and objective summary producers solely to test the authority's claimed room/cell witness provenance.
- Verified the four frozen SHA-256 values and inspected the supplied GREEN-03, fallback capture, native capture, and warning-classification artifacts. No tests or Git diffs were rerun.
