# R10 corner geometry source-contract transition preflight

Date: 2026-09-08. This is read-only transition preparation for the root-approved
corner/T collision correction. It does not authorize source, registry, manifest,
runtime, or supersession-file edits.

## Current frozen scope

The current registry is frozen at 668 recorded rows, 657 active rows, 11
deferred rows, and a 622 active metric denominator. Its source fingerprint is
`8041e481680152f85fe2d3617491880a5268d89dcb63a59608590711edef48d0`;
its reviewed-supersession fingerprint is
`ffe325ef281156711db10d85eb896a4781804ec976944aef4a948bdbe12ad0df`.

The corrected source contract is narrow: corner and T collision rays become
2 m from a vertex, retaining the complete 4 m outer-edge span through two
half-spans. It retains 3 m height, 0.2 m thickness, and actual corner/T module
instances. It must not alter straight-wall or doorway dimensions, replace
compound wings with a filled AABB, or add/remove acceptance leaves.

## Affected frozen leaves

| Stable current ID | Current fingerprint | Source | Current text / source role | Transition disposition |
| --- | --- | --- | --- | --- |
| `FEATURE::docs/game/features/structural_wrapper_collision.md::77be1df64944` | `77be1df64944335b37ab9851c410c8918c6f9d65f866a5306e032f84fdaffbf4` | `structural_wrapper_collision.md:69` | Inner/outer corner has two `(4, 3, 0.2)` wing slabs. | One-for-one revised feature leaf; reset only this leaf's evidence. |
| `FEATURE::docs/game/features/structural_wrapper_collision.md::3a8fddf3798b` | `3a8fddf3798bfb5801f177ee9863d92adf6f4f19b64b66917457227ad31b59bc` | `structural_wrapper_collision.md:70` | T junction has three wing slabs, without a size in the leaf text. | Revise only if Sol's approved wording adds the 2 m ray/half-span contract; otherwise retain unchanged identity and evidence. |
| `REQ-DECAY-002::acceptance-95a1331257bc` | `1d53a65e3349c1ce72afcabcc0c90ad25df472f6a0a069a34cd749a7d952e0db` | `05_requirements.md:1645` | Corner/T wings, excluding a `4×3×4` AABB. | One-for-one reviewed requirement supersession; reset only this leaf's evidence. |

`remaining_procgen_play_stack.md` has no frozen acceptance leaf that states a
corner/T 4 m ray. Its affected source-contract declarations are non-leaf text:
PR 2b at line 106 and the collision-retune table at lines 344–355. The related
frozen leaf is
`FEATURE::docs/game/features/remaining_procgen_play_stack.md::9a2b2bbf0f8b`
(`9a2b2bbf0f8b5e18bf20bae4cd8a45737681f3a6c72e29fcbaccc14f11fd3cb3`,
line 765): it only states that live collision matches the documented wall slabs
and doorway opening. Leaving that leaf unchanged preserves its identity and
evidence; changing it to state the 2 m corner/T rule requires a separate
one-for-one feature-leaf transition.

## Minimal governed mechanics

1. Preserve the existing accepted `reviewed-criterion-supersessions-v1` record
   unchanged. Add a reviewed one-for-one mapping for the changed
   `REQ-DECAY-002` leaf: stable ID remains the current ID; `original` records
   the exact text, natural ID, and fingerprint above; `replacement` records
   Sol's approved final wording and its computed natural ID/fingerprint.
   Keep acceptance kind `requirement`, active/deferred membership, metric
   representative, and `denominator_delta: 0`. The mapping needs the governing
   accepted ADR path and root review provenance.
2. The current loader deliberately permits reviewed supersessions only for
   requirement-register rows. Do not loosen it globally. Add the smallest
   explicit reviewed feature-source transition form (or a parallel narrowly
   named catalog) for the structural-wrapper feature leaf/leaves, with exact
   allowed paths and headings. It must have the same original/replacement,
   one-for-one accounting, review, and ADR fields; reject unknown feature paths,
   missing targets, duplicate stable/replacement IDs, chains, cycles, changed
   metric fields, and unreviewed wording.
3. Apply any approved mapping before frozen-fingerprint comparison, retain the
   old stable ID in generated criteria, and write replacement text/fingerprint
   plus a transition annotation. The existing evidence carry-forward condition
   compares criterion fingerprints, so a changed replacement fingerprint resets
   that row to `not_verified` with no refs while every unchanged row retains its
   stored evidence. The registry's transition mapping retains original wording
   and fingerprints, not historical evidence payloads: capture the pre-write
   registry as an immutable manifest before regeneration, preserve any existing
   evidence there, and do not copy it onto the replacement row.
4. Scope-fingerprint normalization must use each mapping's original fingerprint
   for only the mapped rows. This keeps the existing source fingerprint and all
   four count values fixed. The reviewed-transition set has different bytes, so
   its set fingerprint and the frozen contract's reviewed-transition fingerprint
   require an explicit root-approved update; regeneration must fail before write
   until both agree.
5. The source edit must preserve exactly the same number of acceptance list
   entries in both feature sources and in `REQ-DECAY-002`. Do not add a broad
   geometry exemption, change the proposal catalog, or suppress unknown source
   documents. Missing source documents and unexpected source leaves remain
   fail-closed.

## Implementation and test surface after Sol supplies the exact source diff

Expected implementation files are `tools/build_feature_acceptance.py`,
`tests/test_feature_acceptance_registry.py`,
`data/validation/reviewed_criterion_supersessions_v1.json`,
`docs/game/inventory/feature_acceptance.json`, and
`data/validation/feature_completion_cards.json`, plus Sol-owned source/ADR
files. The transition work must capture beforeimages before edits and regenerate
only after a pre-write build demonstrates the frozen source fingerprint and
counts above.

Required focused registry tests:

- a reviewed `REQ-DECAY-002` replacement preserves its stable ID, denominator,
  and old original record while resetting only its changed evidence;
- a reviewed structural-wrapper feature replacement has the same behavior;
- if the remaining-stack generic leaf remains text-identical, it remains
  unchanged and retains valid prior evidence; if its wording changes, test its
  independent transition instead;
- all three changed leaves together retain 668/657/11/622 and the frozen source
  fingerprint;
- missing/extra transition targets, unknown source paths, duplicate mappings,
  changed accounting, and a frozen reviewed-transition fingerprint mismatch fail
  before registry write;
- unrelated frozen criteria with valid evidence retain their evidence.

No runtime or Godot check belongs to this source-contract transition preflight.
