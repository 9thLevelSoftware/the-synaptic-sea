# R10-A Run 7 / World 7 Save Transition Preflight

**Status:** Preflight ready; implementation remains gated on the accepted R10-A docking baseline, a post-fix beforeimage, and the rulings in [Open rulings](#open-rulings-before-version-edits). This document describes only the allocated run-7/world-7 transition. It does not absorb R07 V3/history work, change registry counts or fingerprints, or claim the later R04/R09/P17 acceptance.

**Authority:** `.superpowers/sdd/2026-09-05-remaining-feature-completion/task-10a-brief.md`, especially the allocated paired run-7/world-7 transition and validation items 6–9. The linked `r17-hallucination-save-remediation-design.md` supplies the hallucination reset interface only; its earlier save-shape proposals are superseded by the task brief.

**Inspected base:** `D:\the-synaptic-sea-feature-completion`, branch `codex/feature-completion-resume`, inspected at `3a24cde90a1b07e1b94560fbe099a2071c652983` plus the existing reviewed P23/R10 governance and baseline-review WIP. Source is intentionally untouched. The pending baseline fixes may refactor endpoint construction and fresh boot: current endpoint authoring mutates the structural plan after compile/validation, the pure pair predicate has a seam-containment tautology, and fresh boot places the player twice. The save implementation must consume the re-reviewed endpoint/connection and single-placement interfaces; it must not preserve those current defects as compatibility behavior.

## Actual ownership and call-site map

| Concern | Current owner and evidence | R10-A change boundary |
|---|---|---|
| Run schema | `scripts/systems/run_snapshot.gd`: `player_position` at line 33, `hallucination_summary` at 97, summary membership at 147–176, count at 183–187, emission at 189–224, permissive ingestion at 248–321. | Stamp run 7; remove both properties and emitted keys; remove only hallucination from `SUMMARY_FIELDS`, producing count 31; make current run-7 input reject either key even when empty. Preserve a dedicated strict historical run-6 validator for migration rather than routing v6 through the run-7 decoder. |
| Version chain | `scripts/systems/save_migration_service.gd`: run/world version tables and targets at 22–43, run steps at 170–194, world steps at 196–220, pair validation at 223–248. `_migrate_world_v5_to_v6_result()` currently calls `_migrate_world_home_ship(dict, TARGET_VERSION)` at 801–802. | Add explicit run 6→7 and world 6→7 steps and pair `world-7`→run 7. Before changing `TARGET_VERSION`, replace the symbolic v5→v6 target with literal `"gate2-current-run-6"`. Every migration works on a detached copy and returns one stable reason. |
| Standalone-run admission | `scripts/systems/save_load_service.gd`: current run is run 6 at line 25. `_prepare_slot_path()` at 159–242 rejects an unclosed current run only when `source_version == CURRENT_SLICE_VERSION` at 196. `_closed_world_dict_from_run()` at 464–489 currently synthesizes a world from run-global pose. | Add a literal run-6 `unclosed_owner_graph` branch before the new run-7 current check. Keep the existing pre-v6 admission matrix and its closed-world preconditions. Adapt an admitted pre-v6 run into the literal world-6 envelope before the 6→7 pair step; do not first erase its pose into run 7 and then try to fabricate a world owner. Raw run 7 remains an unclosed current run and rejects. |
| World schema | `scripts/systems/world_snapshot.gd`: world 6 at line 19; old pose/edge/open-marker fields at 38–42; emission at 55–89; permissive ingestion at 94–170; nested home is hard-coded to run 6 at 203–205. | Stamp world 7; remove/forbid `dock_edges`, `player_position_in_ship`, and `opened_ports`; add strict connection, owner-pose, and endpoint-state values. Current row validators require exact string keys and uncoerced types. The new top-level legacy-key denial happens before defaults can launder presence. |
| Detached candidate | `scripts/systems/save_restore_candidate.gd`: `build()` at 40, `_materialize()` at 64, hard-coded run 6 at 68, authority normalization at 180. It currently validates inventory/crafting/components/threats but has no connection/endpoint/pose graph. | Materialize run 7 and retain exact accepted pose arrays. Validate unique owners, an acyclic one-parent connection graph, unique connection and endpoint identities, complete endpoint-state coverage, owner==aboard, and threshold references before any scene is staged. Never perform live collision or threshold geometry checks here. |
| Central transaction | `scripts/systems/save_load_service.gd`: sealed prepare at 159–242, candidate re-resolution at 529–560, coherent write at 830–906, capture normalization at 928–943. `scripts/main.gd:26–86` owns disposable staging and the live pointer swap. | Keep the ephemeral accepted-pose receipt on the staged/live instance's `SaveLoadService`, because that is the central save transaction owner and already survives after `Main` publishes the staged instance. Installation occurs only after the staged owner/root and body position pass exact validation. A failed stage never transfers a receipt to the live scene. |
| Live connection | `scripts/systems/docking_manager.gd`: `dock()` at 82–125 writes only `parent_ship`, `docked_ships`, and a loose `docking_ports=[{host_port,mobile_port}]`; `undock()` at 588–598 clears it. `scripts/systems/ship_instance.gd:45–48` has relationship fields but no stable connection record or spatial revision. | After baseline re-review, make the docking manager create and return the strict connection record and make the mobile `ShipInstance` own that exact current record. Add a monotonic owner-root spatial revision to `ShipInstance`; every manager/coordinator transform mutation must increment it. Capture reads records; it does not reconstruct identity from parent markers. |
| Barrier identity/state | `scripts/tools/dock_port_barrier.gd:12–14` already carries `connection_id`, `host_endpoint_id`, and `mobile_endpoint_id`. `playable_generated_ship.gd:2830–2854` currently derives the connection ID and barrier identity locally. | Move canonical connection ID construction to the docking manager/record. Barriers bind to that record. Capture enumerates the defined active endpoint set and emits exactly one `{ship_id, endpoint_id, barrier_open}` row for each; restore requires exact coverage and applies state after connections exist. |
| Capture | `playable_generated_ship.gd:_build_run_snapshot()` at 13033–13183 captures global run pose and hallucination state. `_build_world_snapshot()` at 13863–13954 overwrites the away home pose, captures global `player_position_in_ship`, recomputes marker-based edges in `_current_dock_edges()` at 13960–13985, and captures marker-only opened ports. `_home_player_position` is written at 8908 and consumed only by the obsolete save duplicate at 13879/14161; current travel-home already rides the physical ship. | Remove the run pose/hallucination capture and obsolete home-departure save duplicate. World capture requires non-null explicit `current_occupancy`, its live root, matching `aboard_ship_id`, and a strict interior/threshold classification from the authenticated connection seam. It converts the body through that owner root once and delegates exact-array reuse to the receipt. No nearest-ship or center fallback is permitted. |
| Restore ordering | `playable_generated_ship.gd:_apply_world_snapshot()` at 14129–14270 currently activates/teleports with the global pose at 14235, restores open markers at 14243–14245, later materializes edge owners at 14255–14260, and finally calls permissive `_apply_docking_snapshot()` at 14265. `_apply_docking_snapshot()` at 14277–14311 silently skips missing owners and directly publishes logical occupancy. | Replace this with a reason-returning staged sequence: regenerate every required root → resolve exact registered endpoints → restore every strict connection → bind/apply every endpoint barrier row → project the accepted local pose through its named owner → prove the full live capsule clear and threshold ownership → publish staged occupancy. Any missing/ambiguous step rejects the whole disposable candidate. |
| Stage recapture/publication | `playable_generated_ship.gd:576–617` constructs and validates a hidden, process-disabled stage; `activate_staged_restore()` at 620–645 publishes its local readiness. `_validate_staged_restore()` at 648–721 currently compares old edges/open markers then canonical recapture; `_canonical_restore_world()` at 759–800 has only ADR-0059 oxygen `player_in_breach_zone` as a comparison exception. `scripts/main.gd:65–86` disables the old live scene, activates the ready stage, then swaps the pointer. | Install the pose receipt before exact staged recapture. Compare strict connection/state/pose authority with deterministic row ordering. Preserve the accepted local array verbatim. Keep oxygen as the sole gameplay comparison exception. Activation must not recompute pose, connections, barriers, or occupancy. |
| Hallucination reset | `hallucination_director.gd` exposes configuration at 40 and persisted summaries at 220/245 but no episode-only reset. `hallucination_manager.gd` owns `_ambient_cooldown`/`_prev_hud_active` at 20–21; `clear_all()` at 118–123 clears nodes/FX but not those edges and calls `_free_phantom()`, which also mutates director events. Coordinator status lines are derived from `get_hallucinated_status_lines()` at `playable_generated_ship.gd:11333`. `_apply_run_snapshot()` currently reapplies the saved summary at 13656–13657; reload cleanup only calls `clear_all()` around 14663. | Add `HallucinationDirector.reset_episode()` preserving seed, tuning, pool, and kind schedule while setting step 0, events/timers empty, next ID 1, tier 0. Add manager `reset_projection()` that frees projection nodes without feeding removals back into the already-reset director, zeros FX/cooldown/HUD edge, and therefore clears derived coordinator status. Invoke once, late, while staging remains process-disabled, after sanity/durable state and immediately before receipt installation, exact recapture, readiness, and activation. |
| Historical spatial data | `ThreatSaveContract._validate_threat()` accepts and validates `world_position` plus optional `last_known_position`, but does not require an exact threat-row key set; encounter markers and several receipt dictionaries accept arbitrary JSON. Ship-owned carts, floor drops, corpse drops, and station descriptors already use owner-local positions. | The world-6 adapter must transform only the two admitted combat fields through old-root→new-root and leave established local payload bytes untouched. It needs an explicit recursive spatial-key audit and/or exact historical threat shape; unknown world-space-bearing payloads reject rather than pass through. |
| Runner | `tools/run_r10a_docking_smokes.py` lists 15 cases at 16–32, delegates to `run_feature_completion.execute_isolated_case`, retains raw logs/hashes, and requires one exact marker. `tests/test_r10a_docking_runner.py:57–59` pins the case order/count and unique homes. `tools/run_p10_process_smoke.py` supplies the existing independent three-process persistence proof. | Extend the tracked R10-A runner with the save-transition cases and affected existing smokes. Update its unit tests and exact case count. Keep R04 natural route outside this aggregate and run it last as validation item 9. Run the P10 three-process proof separately with its accepted user-data probe. |

## Strict run-7 and world-7 contracts

The run change is intentionally narrow. `RunSnapshot` no longer owns a pose or a hallucination episode. Run-7 serialization must not emit either key, and run-7 parsing must reject key presence before accessing a value. `SUMMARY_FIELDS` loses `hallucination_summary` and the public count becomes 31. The historical run-6 validator remains capable of validating a present hallucination envelope exactly, including event/timer data, while admitting its historically optional absence. The 6→7 step validates first and erases second.

World 7 owns these strict rows exactly as the brief specifies:

```text
dock connection = connection_id, port_type, slot_index,
                  host{ship_id, endpoint_id, port_id},
                  mobile{ship_id, endpoint_id, port_id}
owner pose       = owner_ship_id, location_kind, local_position,
                   connection_id, endpoint_id
port state       = ship_id, endpoint_id, barrier_open
```

Every row rejects non-string dictionary keys, extra/missing keys, coerced strings/booleans/numbers, duplicate IDs, foreign owners/endpoints, or mixed old/new fields. `local_position` is exactly three finite numeric values; booleans are not numbers. Interior pose requires empty connection/endpoint IDs. Threshold pose requires a live named connection, names its mobile endpoint, and has the mobile ship as both `owner_ship_id` and `aboard_ship_id`. Connection arrays and state arrays are emitted in stable identity order so staged canonical comparison needs no new exception.

Legacy top-level presence is always rejected in world 7, including empty `dock_edges`, empty `opened_ports`, and a zero `player_position_in_ship`. The brief says “current rows require exact keys” but does not explicitly make the entire `WorldSnapshot` top-level dictionary exact, while the existing writer conditionally omits several unrelated fields. The implementation should therefore enforce: exact new nested rows; required presence of the three new top-level authorities plus `aboard_ship_id`; explicit denial of the three legacy keys; and the existing validation rules for unrelated top-level fields. A repository-wide exact top-level set requires a separate ruling because it would change optional historical/current fields outside this slice.

## Version-pinned world-6 geometry authority

The old global pose cannot be inverted through the corrected endpoint graph. It must first be interpreted in the exact graph under which world 6 wrote it.

For the two shipped fixed layouts, the authority comes from the immutable task beforeimages, not current `DockPorts`:

* `.superpowers/.../task-10a-beforeimages/manifest.json` records the pre-R10 `dock_ports.gd` byte hash `d0e6e23988877696e577cd021653aebf0f491601f2774e71039f8ac86c5e3a42` and coherent-home layout hash `3740674ff7e0d51d4df4e969ebf272190e03307dbb6242c06f4006789f76bb89` at historical head `c51bcacbcb5557fd54ccf5a3e2775f0e35c61bad`.
* The historical resolver selected the first matching room's `floor_1x1`/`corridor_floor_1x1` cells. Lifeboat used their average plus `(-2,0,0)`, facing `-X`. Derelict/home used the dock-room average or the airlock-room average, facing `+X`.
* The shipped coherent home's four airlock floors center at `(2,0,2)`, so its old host port was `(2,0,2), +X`. The fixed lifeboat airlock floor centered at `(0,0,0)`, so its old mobile port was `(-2,0,0), -X`. Under identity home root, the historical lifeboat root was translation `(4,0,2)`. Current endpoint geometry must not be substituted for any of these values.
* Historical hangar anchors came from the ordered floor-cell list in the first hangar room, or cargo fallback, with `slot_count=max(1,floor(cell_count/2))` and anchor `cells[(slot_index*2)%cell_count]`. Historical `_place_in_slot()` applied `host_global * Transform3D(identity, anchor)`.

Create `data/migrations/world_v6_docking_geometry_v1.json` as a minimal, immutable copy of these fixed descriptors, old selector constants, supported home profile identities, and provenance hashes. Create `scripts/systems/world_v6_docking_migration.gd` as the detached adapter. The helper must not call `DockPorts.for_lifeboat()`, `DockPorts.for_derelict()`, the corrected pair resolver, or coordinator scene methods while constructing the old graph.

Visited procedural owners are harder: world 6 persists `ShipBlueprint` seed/size/condition and, for supported modern visited ships, exact `generation_context_v1={biome,difficulty}`, but it does not persist `built_layout` or a generator-version ID. Calling the mutable current `ShipGenerator` and merely applying the old room-center selector is not version-pinned. The accepted implementation needs a frozen legacy projection capable of reproducing the historical room/floor order from those persisted inputs, or an equally strong authenticated historical layout source. Missing/invalid generation context, a custom blueprint/layout, or inability to prove the historical projection rejects. This is an explicit root ruling below; the save implementer must not treat “current generator happens to match” as authority.

The helper builds an owner table keyed by exact `ship_id`, then walks old `dock_edges` in topological order. It rejects duplicate/mobile-multiple-parent edges, missing owners/hosts, cycles, illegal slots, ambiguous host marker resolution, and unsupported port types/layouts. For each owner it records the old global transform. Separately, it resolves the corrected registered endpoints and computes the new graph; each old edge must have exactly one new host/mobile endpoint pair. Only after both graphs are complete may it compute pose and combat deltas.

## Literal 5→6→7 chain and standalone denial

Implement and test the ordering explicitly:

1. `_migrate_world_v5_to_v6_result()` calls `_migrate_world_home_ship(dict, "gate2-current-run-6")`. This edit lands before the current constants move.
2. The existing run 5→6 step produces literal run 6 and the existing world step produces literal world 6. Pair validation checks that intermediate pair.
3. The new world 6→7 step validates the complete old pair, including old run schema, all old docking rows, every relevant global coordinate, and the old graph, before erasing anything.
4. Run 6→7 strictly validates a present historical hallucination envelope then drops it; absent remains admitted. It also removes run-global `player_position` only as part of the paired world adapter, after the world pose has been accepted.
5. At home (`current_location == ""`), embedded `home_ship.player_position` must be a finite exact triple and bit/exact-value equal to top-level `player_position_in_ship`. The top-level value is converted through the nonempty explicit `aboard_ship_id`; the embedded duplicate is erased without a second transform.
6. Away (`current_location != ""`), embedded home departure coordinates must still be a finite triple but are obsolete and discarded. They do not imply `ship_start`, do not receive a projection, and absent ownership for that duplicate alone is not a rejection. The top-level global pose still requires a nonempty, uniquely resolved `aboard_ship_id`.
7. Compute `owner_local = old_owner_global.affine_inverse() * legacy_global_position` once with engine numeric precision. Preserve the resulting three-element Array as authority. Build strict new connection/state/pose fields, erase all three old world fields, stamp run 7 then world 7, and validate the new pair.
8. A raw run-6 document hits an explicit literal branch in `_prepare_slot_path()` and returns `unclosed_owner_graph` before any older direct-run adapter. A raw run-7 document is likewise an unclosed current document. Recognized pre-v6 direct runs keep only their existing strict adapter admission; their adapter must form a literal world-6 intermediate while their pose still exists, then use the same 6→7 pair migration.

No rejection writes migration copies, source bytes, slot indexes, backups, sidecars, receipt state, or live state.

## Spatial audit during world-6 migration

For each owner whose global root changes, compute `delta = new_root * old_root.affine_inverse()` after both graphs are proven.

* Preserve cart transforms, floor-drop transforms, corpse-drop positions, physical-station local positions, and all other established ship-local payloads byte-for-byte. Do not parse/re-emit their numbers just to prove equality.
* For each visited owner's validated combat `threats[*].world_position`, apply `delta` to the finite point. For a nonempty `last_known_position`, apply the same delta; preserve an empty Array exactly. Home combat remains byte-identical because its root is unchanged.
* Reject a missing combat owner, a nonfinite point, or a world-space field outside the two admitted threat locations. Run the audit recursively over the migrated visited-ship payload before sealing.

There is a current proof gap: `ThreatSaveContract._validate_threat()` validates known fields but allows extra threat keys, and encounter markers/attack/damage sub-dictionaries permit arbitrary JSON. A recursive key-name denylist can catch additional `world_position`/`last_known_position` fields but cannot prove that an arbitrary unknown key is not another global coordinate. The recommended bounded ruling is to define an exact historical threat-row key set for this migration and reject any extra Array-valued spatial-looking field anywhere under moved-owner combat. Broadly making the current threat contract exact would affect more than R10-A and requires explicit root approval.

## Exact pose receipt and staged restore integration

Add a private, ephemeral receipt to `SaveLoadService`; do not serialize it in either snapshot. Its fields are:

```text
owner_ship_id
owner_spatial_revision
owner_root_instance_id
owner_root_transform_bits
accepted_local_array          # the exact parsed/computed Array retained verbatim
projected_global_body_bits    # exact x/y/z numeric bits at acceptance/capture
location_kind
connection_id
endpoint_id
```

Use exact component bit tokens (for example, three encoded IEEE-754 doubles), not epsilon equality, `is_equal_approx`, rounded strings, or JSON text. Root transform bits cover every basis/origin component; the monotonic revision is still required by the brief and prevents an out-and-back transform from masquerading as unchanged. All root movement paths must go through a revision-bumping seam: `DockingManager.dock()/undock()`, hangar `_place_in_slot()`, bay launch placement, rigid-tree carry/reposition, initial root placement, and staged connection rebuild. The existing `_live_binding_generation` is restoration-handle identity and is not a spatial revision.

Capture requires an explicit live `current_occupancy`. It first determines strict location metadata from the authenticated connection seam. It then asks the central service for a local array:

* If owner ID, revision, root identity, every root-transform bit, every global body-position bit, and location metadata equal the receipt, return `accepted_local_array.duplicate()` without another inverse transform.
* Otherwise compute one `owner_root.affine_inverse() * body_global`, materialize one full-precision three-number Array, and atomically replace the receipt. That newly computed Array is the next authority.

During staged restore, keep the candidate's accepted Array untouched. After roots, connections, and barriers exist, project the Array through the named owner's corrected root and place the body once. Prove the full live player capsule is clear using the corrected physical scene. For `dock_threshold`, also prove the named connection exists, the endpoint is its mobile endpoint, the projected capsule is in the authenticated threshold/seam ownership region, and the occupancy rule selects the mobile owner; for `interior`, connection/endpoint IDs must remain empty and the owner interior proof must pass. Install the receipt from that accepted Array and projected body only after these proofs. Then perform the exact staged recapture; readiness publication is the next state transition. No later activation teleport or recapture is allowed.

This depends on the baseline fresh-boot fix: `_apply_initial_lifeboat_spawn_once()` currently teleports and then recomputes occupancy, while the baseline review found a second placement elsewhere. Save restore must call a single accepted placement seam and must not reuse the double-placement path.

## Hallucination reset integration

The current run model's `hallucination_summary` capture at `playable_generated_ship.gd:13122` and restore at 13656–13657 are removed. The run-6 migration still validates the old envelope before erasing it.

`HallucinationDirector.reset_episode()` preserves `rng_seed`, `health_drain_per_second`, `stamina_recovery_mult`, `pool`, and `_kind_config`; it sets `step=0`, clears `active_events` and `_spawn_timers`, sets `_next_id=1`, and `_current_tier=0`. It must not call `configure()` because that reloads the pool and could change the retained schedule/tuning.

`HallucinationManager.reset_projection()` frees every phantom projection without calling back into director event removal, clears `_phantom_nodes`, zeros the FX meta, `_ambient_cooldown`, and `_prev_hud_active`. With director events empty, `get_hallucinated_status_lines()` returns no coordinator false-status rows. The staged coordinator remains process-disabled through all of this, so no tick can create a new episode between reset and readiness.

Call the two resets once near the end of successful `_apply_world_snapshot()`: after `_apply_run_snapshot()` has restored sanity and all other durable state, after world roots/connections/barriers and the accepted body pose have been proven, and immediately before receipt installation/exact recapture/readiness. A failure before or after reset discards the entire staged instance; it cannot touch the live director/manager.

## Smallest coherent implementation units

Each unit begins with the named focused smoke/assertion and ends with the narrowest validation possible. Do not advance version constants until the accepted docking baseline and new beforeimage are available.

1. **Freeze prerequisites and scope.** Accept the baseline re-review, record the additive post-fix manifest, resolve the open rulings, and add the necessary paths to the P17 allowlist without changing the frozen `668/657/11/622` registry totals or fingerprints. Preserve both existing v7 future fixtures byte-for-byte as historical evidence.
2. **Pin the intermediate before moving constants.** Extend `save_migration_world_smoke.gd` with a chained v5 assertion that proves the intermediate embedded run is literal run 6. Change only `_migrate_world_v5_to_v6_result()` to pass the literal. Run that focused smoke through the hardened isolated seam.
3. **Run-7 model and migration.** Add run-7 malformed/present/absent hallucination and forbidden-pose cases. Update `run_snapshot.gd` and the run migration table/step. Update `save_load_service.gd` with the explicit literal run-6 denial and retained pre-v6 adapter route. Add v8 run sentinel; do not edit the old v7 fixture. Requalify `save_migration_service_smoke.gd`, `save_load_service_smoke.gd`, `ship_mod_run_snapshot_smoke.gd`, and `pillar_persistence_smoke.gd` with count 31/current run 7 while preserving explicit historical run-6 cases.
4. **World-7 detached schema.** Add exact-row, legacy-presence, owner/aboard, topology, state-coverage, and threshold-reference cases. Update `world_snapshot.gd` and `save_restore_candidate.gd`; add v8 world sentinel without editing the old v7 fixture. This unit does not yet admit world 6.
5. **Pinned world-6 adapter.** Add the immutable geometry data and pure adapter. Test home equality, away obsolete-data handling, literal 5→6→7, old home/lifeboat transform, supported procedural transform, missing context/owner, duplicate mobile, ambiguity/cycle, unsupported custom/hangar policy, bad/nonfinite transform, mixed pair, open-marker mapping, moved combat, byte-exact local payloads, unknown world-space field, and detached-source immutability. Only then connect the 6→7 step to `SaveMigrationService`.
6. **Connection records and spatial revision.** Against the accepted baseline interfaces, make `DockingManager`/`ShipInstance` own exact records and root revision. Update airlock and the ruled hangar path, barrier binding, undock, bay placement/launch, and rigid carry. Tests prove stable IDs, one-parent graph, every transform mutation increments revision, and no direct coordinator path bypasses it.
7. **Current capture and receipt.** Add `SaveLoadService` receipt helpers, replace old world capture with exact connection/state/owner-local capture, remove `_home_player_position` persistence use, and add interior/threshold plus moved/rotated/far root tests. Prove two unchanged captures preserve the exact Array bits; body movement, metadata change, root movement, and revision-only change each cause exactly one recomputation and then stabilize.
8. **Strict staged restore.** Replace `_apply_docking_snapshot()` with the reason-returning ordered restore. Add disposable-stage tests for missing/ambiguous endpoint, state omission/duplication, obstruction, wrong threshold owner, source change, injected failure, and activation. Prove disk/index/live pointer and prior receipt remain unchanged on every denial. Keep ADR-0059 oxygen as the only canonical compare exception.
9. **Late hallucination reset.** Add episode/projection reset APIs and the one late coordinator call. A contaminated-stage test proves exact durable sanity; step 0, no events/timers, next ID 1, tier 0; retained seed/tuning/pool/schedule; no phantom/status/FX; cooldown and HUD edge reset; no processing before activation; and first post-activation tick derives only from restored sanity.
10. **Runner and full requalification.** Extend `run_r10a_docking_smokes.py`, update `test_r10a_docking_runner.py` case order/count and exact markers, run all validation 6–8 cases in fresh homes with retained raw logs/hashes, then run the separate P10 three-process proof. Run orphan-smoke classification if membership changed. Finally run unchanged `fc_p09_natural_route_smoke.gd` alone as dependency proof item 9; its result may expose its next real blocker and cannot be replaced by the R10-A aggregate.

## Exact files

### Existing P17-allowed files needed for the save slice

* `scripts/systems/run_snapshot.gd`
* `scripts/systems/world_snapshot.gd`
* `scripts/systems/save_load_service.gd`
* `scripts/systems/save_migration_service.gd`
* `scripts/systems/save_restore_candidate.gd`
* `scripts/systems/hallucination_director.gd`
* `scripts/systems/hallucination_manager.gd`
* `scripts/systems/threat_save_contract.gd` and, only if the ruled audit requires it, `scripts/systems/threat_manager.gd`
* accepted-baseline `scripts/systems/dock_ports.gd`, `scripts/systems/docking_manager.gd`, `scripts/systems/ship_instance.gd`, `scripts/tools/dock_port_barrier.gd`, and `scripts/procgen/playable_generated_ship.gd`
* `scripts/validation/docking_manager_smoke.gd`, `dock_ports_smoke.gd`, `boot_dock_aligned_smoke.gd`, `occupancy_flip_smoke.gd`, `physical_travel_smoke.gd`, `docking_persistence_smoke.gd`, `combat_persistence_smoke.gd`, `save_migration_world_smoke.gd`, `save_migration_service_smoke.gd`, `world_snapshot_smoke.gd`, and `hallucination_director_smoke.gd`
* `tools/run_r10a_docking_smokes.py`, `tests/test_r10a_docking_runner.py`, `docs/game/06_validation_plan.md`, and `tools/classify_orphan_smokes.sh`
* existing historical `tests/fixtures/feature_completion/p10_run_v7_future.json` and `p10_world_v7_future.json` (read/assert bytes only), plus already planned missing `p10_run_v8_future.json` and `p10_world_v8_future.json`

### Necessary additive paths to authorize

* `scripts/systems/world_v6_docking_migration.gd` — detached old/new graph, pose, barrier-marker, and combat-delta adapter.
* `data/migrations/world_v6_docking_geometry_v1.json` — immutable fixed-layout/selector/slot authority and provenance.
* `scripts/validation/r10a_run7_save_transition_smoke.gd` — current run/world strict presence and paired-version contract.
* `scripts/validation/r10a_world6_geometry_migration_smoke.gd` — old graph, at-home/away, rejection, spatial audit, and immutability matrix.
* `scripts/validation/r10a_owner_pose_restore_smoke.gd` — live ordered restore, capsule/threshold proof, and exact receipt behavior.
* `scripts/validation/r10a_hallucination_reset_smoke.gd` — contaminated-stage late reset/fencing proof.

No additive valid-v7 fixture is required if the focused smokes construct strict dictionaries from current model builders. Add one only if the independent three-process proof requires immutable disk input, and authorize its exact path first.

### Existing paths that must be added to the P17 allowlist if updated

* `scripts/main.gd` — only if receipt transfer/publication cannot remain entirely within the staged instance. The recommended design avoids changing it.
* `scripts/validation/save_load_service_smoke.gd` — it currently asserts run pose, hallucination round-trip, and count 32.
* `scripts/validation/ship_mod_run_snapshot_smoke.gd` — it currently writes `player_position` and asserts count 32.
* `scripts/validation/pillar_persistence_smoke.gd` — it embeds `player_position` and asserts at least 32.
* `scripts/validation/fc_p10_smoke.gd` — it pins world 6/run 6 and embedded home pose behavior and therefore must be updated for the current pair and re-run.
* `tools/run_p10_process_smoke.py` needs requalification but no expected source edit unless its marker/fixture protocol embeds old versions.

## Concrete hardened validation matrix

Add the four R10-A save smokes to `CASE_FILENAMES` and update the runner's “fifteen” text/count. Also add affected existing `save_load_service_smoke.gd`, `ship_mod_run_snapshot_smoke.gd`, and `pillar_persistence_smoke.gd`, plus the explicit player-carry and procgen checks `rigid_pair_travel_smoke.gd`, `procgen_golden_parity_smoke.gd`, `ship_layout_generator_smoke.gd`, and `ship_generator_smoke.gd`; retain every existing 15 prerequisite case. This produces 26 aggregate cases. Each case receives its own runner-created `APPDATA`, `LOCALAPPDATA`, `GODOT_USER_PATH`, and `XDG_DATA_HOME`; every positive marker must occur exactly once with exit 0 and no unclassified diagnostics. Negative subcases must assert their exact reason, protected byte/index/live/receipt equality, and absence of the success effect.

The new cases cover:

* `r10a_run7_save_transition_smoke.gd`: run-7 key-presence denial; count 31; world-7 old-key denial; exact new rows; future v8 denial; preserved v7 historical fixture bytes; literal run-6 standalone denial; admitted pre-v6 matrix.
* `r10a_world6_geometry_migration_smoke.gd`: both home and away semantics; present/absent/malformed hallucination; v5 literal intermediate; fixed and generated old graphs; unique mapping; marker-to-endpoint state; every named rejection; moved combat versus byte-identical local payloads; source/candidate immutability.
* `r10a_owner_pose_restore_smoke.gd`: both sides and exact threshold, rotated/far roots, two unchanged recaptures, all receipt invalidators, full capsule obstruction, wrong ownership, ordered connection/barrier/pose restore, disposable rejection, one placement, and no publication before readiness.
* `r10a_hallucination_reset_smoke.gd`: a deliberately contaminated director/manager immediately before a staged load, exact post-reset fields, durable sanity, derived coordinator lines empty, processing fence, and clean first tick.

Requalify the existing docking manager/ports, endpoint contract, traversal, ceiling, canonical opening, boot alignment, occupancy, physical travel, docking persistence, combat persistence, migration, snapshots, hallucination pure model, procgen golden/native parity, `fc_p10_smoke.gd`, and the P10 three-process proof. Validation item 9 is the unchanged R04 natural route run last and separately.

## Open rulings before version edits

1. **Historical procedural layout authority.** `ShipBlueprint` does not persist `built_layout` or a generator version. Approve a frozen world-6 layout projection implementation copied from the accepted historical generator path, or provide another immutable authenticated source. Reject the weaker option of invoking mutable current generation as “version-pinned.”
2. **Hangar contradiction.** World 6 persists `port_type="hangar"`/`slot_index`, but the current registered boarding endpoint contract provides endpoint/port identity for airlock traversal, not hangar slots. World 7 requires both endpoint identities for every connection and one strict barrier-state row for every active registered endpoint. Choose either: (a) authorize registered hangar endpoint/port/barrier identities in R10-A and include them in the connection model, or (b) declare historical/current hangar edges unsupported and reject them with a stable reason until their reserved later transition. Do not fabricate airlock endpoint IDs for a hangar row.
3. **Active endpoint set.** Define whether “every active registered endpoint” means every endpoint on every materialized owner root or only endpoints participating in live connections. The recommended physical interpretation is every registered endpoint on every materialized owner; data-only visited owners become active only when their roots are regenerated for a required connection/current location. Unconnected active endpoints then still require an explicit closed row and physical blocker.
4. **Legacy threshold classification.** World 6 has only global pose plus logical `aboard_ship_id`; it has no saved `location_kind` or threshold connection. Approve classification as `dock_threshold` only when the exact old authenticated seam/occupancy predicate identifies one unique mobile-side connection at the saved point; otherwise require an interior proof under the named aboard owner. Ambiguity rejects.
5. **Unknown combat/spatial fields.** Approve the bounded exact historical threat-row/audit shape described above, or approve a broader current `ThreatSaveContract` exact-key change. Without one, the requirement to reject every other world-space field is not provable.
6. **Baseline interface dependency.** Release save implementation only after the pure pair seam, pre-compile endpoint authoring, and single fresh-boot placement fixes pass independent re-review. The current call-site line numbers are a map, not an interface freeze; implementation must adapt to the accepted refactor.

With those rulings and the accepted baseline, the implementation is bounded: no registry/history absorption, no current endpoint resolver in the old transform, no new gameplay owner, and no comparison exception beyond ADR-0059 oxygen.
