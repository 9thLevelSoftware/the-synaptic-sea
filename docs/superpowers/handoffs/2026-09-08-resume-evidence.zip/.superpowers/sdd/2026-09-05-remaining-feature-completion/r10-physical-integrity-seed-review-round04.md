# R10 physical-integrity seeder — independent review round 04

**Disposition: Approved.** The frozen round-04 smoke repairs the canonical full-edge portal fixture that failed runtime after round 03. No material static finding remains, and the fresh hardened Godot case passed for the reviewed candidate.

## Reviewed scope

- Branch/HEAD: `codex/feature-completion-resume` at `2d29b2bbc398b392d4ef365d671365aba1ec393f`.
- `scripts/systems/module_integrity_consequences.gd`, unchanged SHA-256 `67329c66a2cbe6e9cef2b63d3ab417242d95c994740174358a48f0abe805871f`.
- `scripts/validation/module_integrity_consequences_smoke.gd`, SHA-256 `d36244f47cbabb980b5a91f957c538f28f0a335d89056b461b537265ff00a134`.
- The scoped `git diff --check` reports no whitespace error.

## Canonical portal fixture review

The fixture now supplies the fields required by the production compiler's strict internal-portal path:

- nonempty portal ID `canonical_portal`;
- distinct declared rooms `port_a` and `port_b`, both present on deck `0`;
- `from_cell` `[0, 0, 0]` and `to_cell` `[1, 0, 0]`, each owned by its declared room and cardinally adjacent on the same deck;
- `DOOR` state;
- catalogued `doorway_frame_open_1x1` module with portal-edge sockets;
- matching declared canonical edge `0|v|0|0`.

`StructuralEdgeCompiler._index_portals` independently derives the east boundary from the two cells, producing `0|v|0|0`; it does not rely on the declared edge to establish adjacency. The compiler records the edge as a portal, resolves the `DOOR` kind and doorway module, and emits its `edge:<edge_key>` full-edge placement. `StructuralPlanValidator.validate` independently recompiles the topology, compares the authoritative plan fields, verifies the endpoint ownership/adjacency, and rejects a missing, solid, or nonportal edge. The smoke requires both the compiler error list and validator verdict to be clean before checking integrity identity, and now includes their error details if that fixture fails.

The selected full-edge record is then required to carry `placement_id == edge:<edge_key>`. Seeding must produce `edge/<edge_key>` and must not produce the incorrect `edge/edge:<edge_key>` alias. In this two-cell portal geometry, the internal door is the full-edge placement; the surrounding solid boundary is emitted through the governed vertex/residual-span path.

## Preserved corrective coverage

The earlier reviewed correction remains present:

- the physical source is compiled and must pass the real validator;
- total seeding and map cardinality cover floor, edge, and ceiling records;
- compiler-produced vertex and residual-span records sharing a primary edge retain distinct `edge/<placement_id>` states;
- ownership is compared through the semantic union of `room_id` and `owner_rooms`;
- vertex and span damage produce two independent sparse deltas and round-trip independently;
- deterministic one-record mutator fixtures use exact compiler-produced vertex and span records, stamp the same physical keys, and apply damage through the seeder;
- the false secondary-edge `LayoutMutator` API claim remains removed.

No regression in the legacy noncompiled seed path or the prior shared-room fire path was introduced. The production seeder is unchanged from the previously reviewed hash.

## Findings and limits

No CRITICAL, HIGH, MEDIUM, or LOW finding was identified in the frozen round-04 correction. Live covered-edge resolution through loader wrapper metadata/controller targeting and historical geometry migration remain outside this bounded two-file review.

The round-03 static approval did not correctly anticipate the canonical fixture's strict runtime source contract; the subsequent attempt-02 RED invalidated runtime acceptance for that older hash. This round reviewed the repaired fields directly against `_index_portals`, portal module resolution, full-edge emission, and the validator's authoritative compiler round trip.

## Runtime evidence

Static review is complete and approved for the exact hashes above. Godot was not run by this reviewer. I independently read the retained runtime package under `artifacts/feature-completion/R10-A-fix1-integrity-seed-attempt-03/`; the coordinator separately bound that run to the reviewed seeder and smoke hashes.

`result.json` reports the `r10-integrity-seed` case passed with exit `0` in `1.094` seconds, empty classified diagnostics, no cleanup error, and a passing containment probe. The probe has exit `0`, marker count `1`, empty unexpected stdout/stderr, and all four isolated environment roots under the case-owned user-data directory. `invocation.json` records the accepted Windows feature-completion authority, Godot `4.7.2.stable.mono.official.ed1daf0bf`, the correct checkout path, and `res://scripts/validation/module_integrity_consequences_smoke.gd`. Accepted ADR-0060 supersedes the older general 4.7.1 text for this Windows program.

The raw `r10-integrity-seed.stdout.log` contains exactly one `MODULE INTEGRITY CONSEQUENCES PASS fire=true breach_derived=true scene=true nav=true` body marker, and `r10-integrity-seed.stderr.log` is empty. The retained evidence hashes independently observed in this review are:

- `result.json`: `212496a773cc80cc7a8965281d701079ff915fdfd8bad1d311348f1592d9476e`;
- `invocation.json`: `57c93d18100aee36f4e82aceda58c04d7ac80f91b95a20cddf23118c7f1a58d8`;
- `r10-integrity-seed.stdout.log`: `ae7fb5175ed8477728e8de60718ab21d9dc4c0927cd66b5ad29627f7dea6d3ad`;
- empty `r10-integrity-seed.stderr.log`: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

Together, the static review and retained clean runtime evidence close this bounded seeder correction. They do not accept the separately scoped loader/controller secondary-edge integration or historical geometry migration.
