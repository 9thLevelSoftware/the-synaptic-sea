# R10 physical-integrity seeder — independent review round 02

**Disposition: Needs Fixes.** The frozen round-02 smoke replaces the invalid hand-authored geometry with compiler/validator-produced records and withdraws the nonexistent secondary-edge mutator claim, but its assertions are not correct and its mutator coverage remains nondeterministic. This review applies only to smoke SHA-256 `c0b3e5e1ce4f9baa2a9744c17281f47fae86ea76de226e7c5e951a7a69fe73fc`; later edits require a new frozen review.

## Reviewed scope

- Branch/HEAD: `codex/feature-completion-resume` at `2d29b2bbc398b392d4ef365d671365aba1ec393f`.
- `scripts/systems/module_integrity_consequences.gd`, unchanged SHA-256 `67329c66a2cbe6e9cef2b63d3ab417242d95c994740174358a48f0abe805871f`.
- `scripts/validation/module_integrity_consequences_smoke.gd`, SHA-256 `c0b3e5e1ce4f9baa2a9744c17281f47fae86ea76de226e7c5e951a7a69fe73fc`.
- `artifacts/feature-completion/R10-integrity-seed-fix/review-remediation.md`, SHA-256 `5ea19e768bdaf30e7ca0ad4bb723ee1824d7b112fee488835f2e4978eb857691`.
- The scoped `git diff --check` reports no whitespace error.

## Findings

### HIGH — registration-count assertion counts only one of three seeded layers

**Affected component:** `scripts/validation/module_integrity_consequences_smoke.gd:194`.

**Specific problem:** `seed_map_from_compiled_layout` registers `floor_placements`, edge `placements`, and `ceiling_placements`, but the smoke compares its return value only with `physical_plan.placements.size()`. The two-cell compiler fixture emits nonempty floor and ceiling arrays, so the assertion rejects correct production behavior.

**Why it matters:** The focused smoke cannot reach the new physical-identity checks. The separately owned runtime attempt confirms this exact failure with exit `1` and `MODULE INTEGRITY CONSEQUENCES FAIL: physical placement seed should register every compiler placement`.

**Concrete remediation:** Derive the expected registration count as the sum of `floor_placements.size()`, `placements.size()`, and `ceiling_placements.size()`. Also assert `physical_map.size()` equals that total so duplicate/collapsed identities cannot hide behind the return count.

### HIGH — the single-owner assertions contradict the current integrity ownership representation

**Affected component:** `scripts/validation/module_integrity_consequences_smoke.gd:202-216` and `scripts/systems/module_integrity_consequences.gd:181-194`.

**Specific problem:** The compiler-produced strip fixture has one nonempty owner, `strip`, for both selected records. The seeder stores the primary owner in `room_id` and assigns `owner_rooms` only when more than one owner exists. The smoke nevertheless requires `owner_rooms.size()` to equal the compiler's one-entry `room_ids`, so it will fail after the count assertion is repaired.

**Why it matters:** This is another false negative that blocks the intended identity, damage, and persistence coverage. It also confuses the semantic primary-owner field with the shared-owner collection.

**Concrete remediation:** Compare the semantic owner set formed from nonempty `module.room_id` plus `module.owner_rooms` against the compiler record's unique nonempty `room_ids`. Keep or add a separate compiler-produced shared-room record asserting that all shared owners are retained. If the intended data contract instead requires `owner_rooms` to mirror single ownership, explicitly change and test that production contract rather than embedding the new expectation only in the smoke.

### MEDIUM — random full-plan mutation does not guarantee coverage of vertex/span identity

**Affected component:** `scripts/validation/module_integrity_consequences_smoke.gd:232-258`.

**Specific problem:** `apply_wreck_to_compiled_plan` receives the complete plan and samples floor, edge, and ceiling candidates at a 5% fraction. The smoke expects exactly one row, searches only edge `placements` for the selected placement ID, and never requires the selected record to be a vertex or residual span. A floor/ceiling selection makes `mutator_record` empty, while a full-edge selection can pass without exercising the changed noncanonical placement identity.

**Why it matters:** Even after the two blocking false negatives are corrected, the previous review's core seeder/mutator identity-coverage gap can remain green without testing `edge/<placement_id>` for vertex/span records.

**Concrete remediation:** Compile and validate the complete production fixture first, then construct deterministic one-candidate mutator inputs from exact duplicates of the selected compiler-produced vertex and residual-span records. Assert each emitted `placement_id` and `module_key` matches the seeder's `edge/<placement_id>` target, apply each row through `seed_map_from_compiled_layout`, and verify the corresponding state changes with no primary-edge alias. Do not describe this as an edge-key request test; loader/controller secondary-edge resolution remains a separate integration obligation.

## Resolved part of the prior finding

The physical and canonical fixtures now call the real `StructuralEdgeCompiler` and require a passing `StructuralPlanValidator` result before use. The code selects compiler-produced vertex and half-span records sharing a primary edge, retains the distinct damage/sparse-delta checks, and separately checks a compiler-produced portal's historical `edge/<edge_key>` identity. The remediation note correctly withdraws the former secondary-edge `LayoutMutator` claim. These are the right architectural boundaries, but the findings above prevent acceptance of this frozen implementation.

No new production-seeder correctness defect was found. Historical geometry migration and live loader/controller secondary-edge resolution remain outside this two-file correction.

## Validation state

Static round-02 review is complete. Godot was not run by this reviewer. The separate runtime owner reported the frozen smoke RED at the first registration-count assertion; therefore runtime validation is failed for this candidate, not merely pending. Any corrected smoke must be refrozen and rerun with the required clean `MODULE INTEGRITY CONSEQUENCES PASS fire=true breach_derived=true scene=true nav=true` marker.
