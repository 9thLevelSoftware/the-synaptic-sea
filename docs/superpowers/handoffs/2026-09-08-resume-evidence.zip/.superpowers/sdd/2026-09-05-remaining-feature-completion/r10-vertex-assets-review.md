# R10 vertex asset review

## Decision: Needs Fixes

Reviewed the package frozen at `76bbcc58c7b532c14dfba31c92608a48836e285d`:
`task-10a-work-evidence/fix-round-01-production-assets-01/manifest.json`.
The manifest itself hashes to the required
`d2e6aa3ce1c2d2bd5850515fdb36bd2720a18a932305eb31aa9f3e387e487196`.

This is an asset failure before the later Godot imported-cache/materialized
runtime gate.  The wrapper-visible north geometry points south in the frozen GLBs.

### Superseding world-transform finding

The initial approval was preserved verbatim at
`r10-vertex-assets-review-evidence/initial-review-full.md` before this revision.
It incorrectly relied on Blender's export-then-reimport check for the north sign.
That round trip can reverse Blender's export conversion and does not prove the
coordinate that Godot receives.

The fresh read-only check
`r10-vertex-assets-review-evidence/glb_world_bounds_check.py`, run with
`.superpowers/test-runtime/Scripts/python.exe`, decodes each GLB POSITION
accessor, composes every glTF scene-node TRS, and writes its result in
`r10-vertex-assets-review-evidence/glb_world_bounds_stdout.log`.  All three
`VisualRay_North` nodes have raw translation `(0, 1.5, 1)` and direct world
bounds `x=-0.1..0.1, y=0..3, z=0..2`.

The wrapper scenes leave `Visual`, `VisualInstance`, and their parent root at
identity (the VisualInstance has only `position = Vector3(0, 0, 0)`), so no
wrapper transform corrects the sign.  For Godot's direct glTF Y-up coordinates,
the contract requires north `z=-2..0`; the frozen visible north ray instead
occupies south `z=0..2`.  This affects:

| File | Finding |
| --- | --- |
| `assets/imported/structural/ship_structural_v0/wall_inner_corner/wall_inner_corner.glb`, node `VisualRay_North` | z is `0..2`, must be `-2..0` |
| `assets/imported/structural/ship_structural_v0/wall_outer_corner/wall_outer_corner.glb`, node `VisualRay_North` | z is `0..2`, must be `-2..0` |
| `assets/imported/structural/ship_structural_v0/wall_t_junction/wall_t_junction.glb`, node `VisualRay_North` | z is `0..2`, must be `-2..0` |

The east bounds are correct at `x=0..2, z=-0.1..0.1`, and the T west bounds are
correct at `x=-2..0, z=-0.1..0.1`; only the north visual ray has this sign error.
The wrapper collision north ray remains correctly centered at `(0,1.5,-1)`, so
visual and collision geometry now disagree.  Re-author/re-export the north
visual ray with the correct direct glTF world sign, then refreeze and rerun this
accessor/node/wrapper check.

The implicated recipe conversion is
[`tools/rebuild_vertex_span_modules.py:63-64`](../../../tools/rebuild_vertex_span_modules.py):
`_z_up(value)` returns `(value[0], value[2], value[1])`; its visual construction
at lines 175-180 applies that function to `MODULE_RAYS`, and the subsequent
Blender export at lines 204-208 uses `export_yup=True`.  The former
`_validate_exported_world_bounds` at lines 111-143 then imports the GLB back to
Blender and converts `(x,z,y)` again, which allowed the bad direct GLB Z sign to
pass.

Fix acceptance requires all of the following:

1. Rerun `& '.superpowers/test-runtime/Scripts/python.exe'
   '.superpowers/sdd/2026-09-05-remaining-feature-completion/r10-vertex-assets-review-evidence/glb_world_bounds_check.py'`
   against the newly exported frozen GLBs and retain fresh raw output.
2. Direct exported world bounds must cover all seven required rays: each corner
   north `x=-0.1..0.1, y=0..3, z=-2..0`, east `x=0..2, y=0..3,
   z=-0.1..0.1`; T adds west `x=-2..0, y=0..3, z=-0.1..0.1`.
3. Preserve identity Visual/VisualInstance wrapper placement.  A Blender inverse
   import or inverse-axis conversion alone is not accepted as world-bound proof.

## Independent checks

1. Recomputed SHA-256 and byte counts for all 27 frozen files.  All matched their
   `after_sha256` and `bytes` entries.  Recomputed all six build-evidence hashes,
   both referenced beforeimage-manifest hashes, the recovery-manifest hash, and all
   11 recovery-manifest entries; all matched.  No frozen file drift was found.
2. Inspected `tools/rebuild_vertex_span_modules.py` directly.  `MODULE_RAYS`
   specifies exactly `(0.2, 3.0, 2.0)` at `(0, 1.5, -1)` for north and
   `(2.0, 3.0, 0.2)` at `(1, 1.5, 0)` for east; T adds the same east-west
   slab at `(-1, 1.5, 0)`.  The recipe makes both visible boxes and source
   collision helpers from those same records, exports selected visual objects
   with `export_yup=True`, then reimports the GLB and rejects a bound/sign error.
3. Independently inspected the resulting GLB JSON and the preserved Build 03 raw
   output.  The three GLBs contain two, two, and three visual mesh nodes,
   respectively.  The preserved reimport check reports the contract-coordinate
   bounds exactly:

   | module | verified rays |
   | --- | --- |
   | inner / outer corner | north `x=-0.1..0.1, y=0..3, z=-2..0`; east `x=0..2, y=0..3, z=-0.1..0.1` |
   | T junction | those north/east rays plus west `x=-2..0, y=0..3, z=-0.1..0.1` |

   The source records explicitly preserve the coordinate conversion
   `contract[x,y,z]->blender[x,z,y]`; the raw glTF's Y-up node coordinates are
   therefore not treated as Godot contract axes.  The recipe's GLB reimport
   converts them back before asserting these signed bounds.
4. Read the wrapper scenes.  Inner/outer each have two `BoxShape3D(0.2,3,2)`
   rays at north `(0,1.5,-1)` and, after the documented transform, east
   `(1,1.5,0)`.  T adds the west ray at `(-1,1.5,0)`.  Thus wrapper collision
   covers the specified vertex-owned north/east (and T west) half spans at
   `y=0..3`, thickness `0.2`, rather than the rejected full four-metre wings.
5. Checked kit, JSON contract, `.tres`, wrapper input, wrapper manifest, and
   source record projections for all three modules.  Module id, kit id,
   vertex-center pivot, GLB path, recovered blend path, bounds, socket list, and
   collision-proxy counts agree.  Counts are inner=2, outer=2, T=3.  The kit's
   proxy bounds independently express the same seven rays and are all
   `nav_blocker=true`.
6. Checked provenance against the immutable recovered-source package.  Each
   source record records the exact recovered original GLB hash from the
   beforeimage, then the newly authored GLB hash and the current contract hash.
   The recovered-source provenance says the unavailable historical Mac source
   was not claimed as available.  The recovered evidence hashes verify, so this
   is a traceable recovered-then-self-authored replacement rather than a false
   original-source claim.
7. Compared beforeimage and new GLB material data directly.  Every module retains
   the sole `SSV0_BULKHEAD` material with unchanged double-sided flag, base color
   `(0.22, 0.25, 0.29, 1)`, metallic `0`, and roughness `0.7`; there are no
   textures or images in either version.  Geometry appropriately changes from
   the prior full-box presentation to the required visible 2 m rays.  I found no
   material/palette regression or unrelated visual-quality downgrade.

## Preserved evidence considered, but not accepted on marker alone

`fix-round-01-asset-build-03/command.txt` records the Blender 5.2.1 factory
startup invocation for all three modules.  Its raw stdout contains each exported
bound listed above and the rebuilt-source list; exit code is `0` and stderr is
empty.  The separate preserved projection and asset-verification outputs report
`DOCK COLLISION PROJECTION PASS modules=15 boxes=21` and
`VERTEX_SPAN_ASSET_BATCH PASS modules=3 glb_bounds=7 wrapper_boxes=7`.

Those markers support the result, but approval is based on the independent hash,
GLB/material, recipe, wrapper, projection, and provenance inspections above.

## Scope limits

No Blender or Godot process was run for this review.  The local Python command
is an unavailable Windows Store shim, so I did not rerun the Python checks; this
does not weaken the file-level inspection.  Godot import/cache resolution and
live physics/material behavior must be demonstrated by the runtime owner before
feature completion.
