# Canonical manifest repair report

Base HEAD: `0b90acbad281c22390a5de6f75ea41a89858d539`.

## Scope

Project source changes are limited to:

- `docs/game/06_validation_plan.md`
- `tests/test_run_canonical_regression.py`
- `docs/game/adr/0060-meshy-offline-evidence-rebind.md`

The plan now makes the marker parser-owned and literal:
`echo 'SYNAPTIC_SEA REGRESSION PASS commands=652 clean_output=true'`. It fails closed if
`RUN_CLEAN_COUNT` differs from 652. The real-document assertion expects 652 entries. The Meshy
ADR header and validation-plan prose use ADR-0068, while its historical filename remains unchanged.

The focused parser test also exposed an existing inconsistency: `BASELINE_WARNING` was documented
and defined but omitted from the `FILTERED` allowlist. The filter now includes that declared exact
pattern; no other diagnostics policy changed.

## Beforeimages

| Source file | SHA-256 before |
| --- | --- |
| `docs/game/06_validation_plan.md` | `d54f4c41a95fc33f12ce1e4bef2c7b14b2caafc4cc6ccee5bcb0de2741327b01` |
| `tests/test_run_canonical_regression.py` | `3fd7ed02e76e89913dc58bf36eff3eca50fd88809bdc0afde1774b1030737b84` |
| `docs/game/adr/0060-meshy-offline-evidence-rebind.md` | `b2702043c5b9c1f2b91ad08fc4c3699b602e6d9dc816ecb7fd38eca9cda42007` |

Captured copies: `canonical-manifest-repair-before-06_validation_plan.md`,
`canonical-manifest-repair-before-test_run_canonical_regression.py`, and
`canonical-manifest-repair-before-0060-meshy-offline-evidence-rebind.md`.

## Frozen result

| Source file | SHA-256 after |
| --- | --- |
| `docs/game/06_validation_plan.md` | `682a97856a55948e3a315bce41005ba641bd9787d14dd8f2d45d019fe18f6d02` |
| `tests/test_run_canonical_regression.py` | `e4c2cc7f72e35c5653c120d8255403f8f49a2608c3d2cbc59dca658e7db3589d` |
| `docs/game/adr/0060-meshy-offline-evidence-rebind.md` | `430b18880bbf4a86f6bb48962623daa3f7686499666c1d29ed6c9c6d80a42c23` |

The immutable scoped diff is `canonical-manifest-repair-frozen.diff`:

`sha256=aa0b7af8c5ce9ef2a47a0d338e948e03e48fb49c0700a14756e5ce902b80f354`, 4164 bytes.

## Verification

- `.superpowers/test-runtime/Scripts/python.exe -m pytest -q tests/test_run_canonical_regression.py` — exit 0, `31 passed in 0.07s`.
- `.superpowers/test-runtime/Scripts/python.exe tools/run_canonical_regression.py --check` — exit 0, `CANONICAL REGRESSION MANIFEST PASS`.
- Extracted lines 1135–1139 were piped to Git Bash without Godot. With `RUN_CLEAN_COUNT=652`, exit 0 and the exact PASS marker printed. With `RUN_CLEAN_COUNT=651`, exit 1 and `SYNAPTIC_SEA REGRESSION FAIL commands=651 expected=652` printed.
- `git diff --check` — exit 0.

Raw outputs: `canonical-manifest-repair-pytest.log`, `canonical-manifest-repair-check.log`, and
`canonical-manifest-repair-runtime-tail.log`.
