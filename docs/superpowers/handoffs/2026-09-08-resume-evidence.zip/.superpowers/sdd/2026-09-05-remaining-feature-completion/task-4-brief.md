### Task 4: R04 — Finish natural crafting acquisition and economy closure

**Parent:** P09/FC-10, with FC-04–06 and FC-11. **Owner:** Terra; root owns balance decisions. **Dependencies:** R01; final source pinning waits R03/R11.

**Files:** `tools/check_crafting_economy.py`, `tests/test_crafting_economy.py`; existing material/recipe/item/loot/component catalogs; `scripts/tools/crafting_station.gd`; `scripts/ui/recipe_picker_panel.gd`; `scripts/validation/fc_p09_smoke.gd`; narrow coordinator crafting/interaction seams.

- [ ] Finish graph validation of recipe inputs/outputs, knowledge sources, station tiers, repair BOMs, donor forms, and deconstruction paths. Reject missing IDs, circular mandatory prerequisites, and profitable conversion cycles without an authored sink.
- [ ] Preserve the real existing titanium route: looted thruster nozzle or plasma cutter can be deconstructed at a skill-1 workbench for an ingot. Absence in one sampled route is not proof of unreachability and does not justify arbitrary loot additions.
- [ ] Record a starter route from a new run to mandatory opening repair materials, recipe learning, and usable tools. Follow actual container origin IDs; do not attribute carried inventory to the current container.
- [ ] Record a machinery-donor route: locate compatible donor, dismount through real work, retain lot/condition/origin, transport and install in a real compatible slot, then observe the intended station/system benefit.
- [ ] Record an advanced route through genuine schematic use, XP/skill growth, tier access, and required advanced parts. Confirm `plating` to `plating_plate` conversion and its actual installation/repair use.
- [ ] Fix only demonstrated broken links; each new data edge must have a necessity, balance invariant, and acquisition test. Controlled setup remains useful for negative tests but never satisfies natural acquisition.
- [ ] Pin the economy checker's full production source closure only after reviewed stable integration. Run its existing negative tests, recipe resource/picker checks, and actual timed quality tests.

**Exit:** starter, donor, and advanced routes are reachable through normal gameplay; the economy checker passes against the reviewed production source; no resource injection, force repair, or teleport substitutes for route evidence.

Read r04-cold-start-source-inventory.md as source preparation. Title uses coherent001 and engineer default; selectable low-repair classes have 0/1 versus nav_linkage min_skill2. Verify an ordinary authored progression route before declaring them stranded or altering balance. Positive natural proof must identify actual starter container origin and use production controls, not validation stock or force-repair. If missing route is confirmed, root must resolve minimal authored opening progression/repair adjustment before data changes.
Read r05-g1-validation-inventory.md for the existing injected-fixture boundaries. Existing fc_p09 early force-repair and later quantity/skill injection do not establish the positive cold route. Preserve those useful negative/model cases, but record a separate Title-origin natural path with actual container lot IDs, recipe-use receipt, station owner, paid escrow/job/receipt, collection, and ordinary output consumer. This inventory is source preparation, not proof of runtime failure.
