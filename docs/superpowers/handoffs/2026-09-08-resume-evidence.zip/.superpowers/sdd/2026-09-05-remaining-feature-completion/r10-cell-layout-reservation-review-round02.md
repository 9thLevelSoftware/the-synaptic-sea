# R10 Cell Layout Docking-Reservation Review — Round 02

## Disposition

**Approved**

No material findings remain in the bounded review. The new focused smoke closes the prior MEDIUM test-quality finding without changing production source.

## Frozen review boundary

- Checkout: `D:/the-synaptic-sea-feature-completion`
- Branch/HEAD observed: `codex/feature-completion-resume` / `04e2da8c4bc9c164a7cc9fe1224d90862d088577`
- Production source: `scripts/procgen/cell_layout_engine.gd`
  - SHA-256: `45a2dc1fc7b8bd781e20ec2ba3ee76148017947cf117dfdc828530832646356f`
  - Unchanged from round 01.
- Focused smoke: `scripts/validation/cell_layout_engine_smoke.gd`
  - SHA-256: `d79ce7a9fe6c1887e67e3e958f9a3b86be7999c912be453bd212862770b2b98e`
- Review scope: resolution of the prior MEDIUM finding only. Unrelated active changes were excluded.
- I did not run Godot and did not mutate Git or production/test source.

## Prior finding resolution

The prior finding required direct proof that connector growth avoids the docking reservation and a precise room-area invariant that permits legitimate connector-added cells. Both are now covered.

### Discriminating connector-growth fixture

`_check_connector_growth_avoids_reservation()` constructs two identical connector cases:

- corridor cell at `(-3, 0)`;
- dock cell at `(0, 0)`;
- the exact ten-cell west reservation for the dock at X `-2..-1`, Z `-2..2`.

The unreserved control calls the real `CellLayoutEngine._grow_room_to_touch()` seam and asserts its chosen shortest route crosses the cells that would be reserved. This makes the fixture sensitive to the relevant behavior rather than merely checking a final empty region.

The reserved counterpart passes the ten-cell exclusion map through the same seam and asserts:

- growth succeeds;
- the corridor gains cells;
- no grown cell belongs to the reservation;
- the final corridor footprint equals the exact bounding box of its cells; and
- the corridor and dock share an edge after growth.

The fixture provides an available alternate route within the engine’s 24-step bound. A failure to check the reservation in BFS or path commit would be detected by the no-reserved-cell assertion.

The fixture calls the focused helper directly, but this is adequate in combination with the reviewed production source and prior end-to-end stress evidence. The unchanged source visibly passes each deck’s reservation from `layout()` through `_realize_missing_connectors()`, `_try_grow_pair()`, and then `_grow_room_to_touch()`. The direct fixture tests the complex path-selection seam, while the existing 60-case production run exercises orchestration and endpoint authoring.

### Precise area and shape assertions

For every planned room in the primary compiler-produced fixture, the smoke now asserts:

- the room exists;
- its final role equals the planned role;
- `final_cells.size() >= target_cells`; and
- its stored final footprint equals the bounding box derived from final cells.

The lower-bound check matches the accepted invariant. Initial placement may not shrink the authored area, while connector realization may legitimately append unique path cells and enlarge the bounding box. The smoke therefore detects partial grown rooms without incorrectly requiring universal equality after connector realization.

## Regression coverage retained

The revised smoke retains the prior checks for:

- exact 2-by-5 west reservation anchored at minimum X, then minimum Z;
- no real room occupancy in the reservation;
- no overlap and full planned-room presence;
- room roles, graph connectivity, cardinal adjacency cells, and four-connected room shapes;
- deterministic repeat generation;
- an exact no-dock control with no state leakage;
- late-dock fail-closed behavior and precise failure reason;
- declared entry/spine/side/destination connections; and
- stacked multi-deck connection, vertical-link serialization, and determinism.

Production source remains unchanged, so round-01 static findings remain applicable: reservations are per deck and excluded from returned occupancy/serialization; all rectangle, freeform, aligned, and connector growth paths reject them; late conflicts return an unusable empty result; and collision predicates remain strict.

## Runtime evidence inspected

### Focused GREEN round 02

`artifacts/feature-completion/R10-A-fix1-cell-layout-reservation-green-02/result.json`

- SHA-256: `9c22b2f4cfc977bd081991fc6073bacdd4867d52c1e624a9b0e42cca8114e100`
- Passed: `true`
- Exit code: `0`
- Duration: `1.656` seconds
- Diagnostics: `[]`
- Cleanup error: `null`
- Containment probe: passed, exit 0, marker count 1, no diagnostics.
- Body stderr is empty, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
- Body stdout SHA-256: `9faf3cf3ec4bf510a9d3143335f858d05f477448e17fc2e175f9a3731c2052e4`.
- Raw output contains the new exact reservation marker with `connector_growth_clear=true authored_area_preserved=true`, followed by the legacy cell-layout PASS marker.

### Prior production stress retained

`artifacts/feature-completion/R10-A-fix1-layout-stress-after-reservation-01/result.json`

- SHA-256: `55677a9f8eb754fa6dd47026c1bd1eaea9975c09000f987bf02dfc93ccf0e2c4`
- Passed all 60 production cases, exit 0 in 84.125 seconds, diagnostics empty.
- This run still supplies end-to-end generation, actual fixed-lifeboat paired collision, strict endpoint authoring, determinism, and compiler/validator coverage because production source did not change.

## Evidence limit

The direct growth regression is intentionally a focused helper-level fixture rather than a second full layout template. Source inspection establishes the short reservation-propagation chain, and the existing 60-case production run covers that chain end to end. Extended templates and seeds outside the 60-case matrix remain sampling limits, not material defects in this bounded correction.

