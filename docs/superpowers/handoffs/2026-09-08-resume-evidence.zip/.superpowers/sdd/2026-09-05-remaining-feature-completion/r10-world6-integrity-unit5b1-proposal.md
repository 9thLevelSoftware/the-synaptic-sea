# R10-A Unit 5B1: historical integrity reconstruction proposal

**Status:** Proposed and gated. No production work starts until Unit 5A is
accepted and frozen, the central feature/P17 scope names every path below, and
the coordinator releases one owner.

## Boundary and ownership

Unit 5B1 reconstructs an authenticated world-6 owner's **actual c51 structural
pipeline** result and full historical integrity state. It does not
generate the corrected current plan, map half-spans or vertices, construct a
world-7 candidate, wire `SaveMigrationService`, or apply anything to live state.

One owner has exactly these paths:

- modify `scripts/systems/world_v6_layout_projection.gd` only to expose the
  internally authenticated complete layout candidate needed by B1;
- extend `data/migrations/world_v6_geometry_authority_v1.json` with the pinned
  condition/compiler/integrity closure and exact contract bytes below;
- add `scripts/systems/world_v6_integrity_projection.gd`;
- add `scripts/validation/r10a_world6_integrity_projection_smoke.gd`.

The new smoke path is not in the earlier Unit 5 proposal and therefore requires
an explicit central feature/P17 addition. Unit 5B1 does not edit
`world_v6_docking_migration.gd`, `save_migration_service.gd`, current procgen,
`world_snapshot.gd`, `save_restore_candidate.gd`, or any live loader/apply path.

## Required layout seam

The accepted Unit 5A `project_procedural()` result collapses admitted candidates
to attachment geometry. That is insufficient for damage migration: two routes
can agree on an airlock/hangar projection while disagreeing on physical records.
Add a public `project_authenticated_layout(blueprint: Dictionary, witnesses:
Dictionary = {}) -> Dictionary` seam to `WorldV6LayoutProjection`.

The seam forms every available hash/version-authenticated route internally. No
caller supplies a candidate-completeness Boolean. It returns one detached rooms/
cells candidate only when all surviving candidates are bit-identical for the
attachment projection and the full layout input consumed by the actual c51
structural pipeline. It otherwise preserves the accepted
`legacy_generation_route_unavailable`, `legacy_layout_unreconstructable`, and
`legacy_generation_route_ambiguous` reasons. Persisted input cannot inject a
candidate, route fact, source hash, or completeness decision.

## Public integrity API and result

`WorldV6IntegrityProjection` exposes:

```gdscript
static func project_fixed_integrity(
        owner_kind: String,
        summary_present: bool,
        persisted_summary: Variant) -> Dictionary

static func project_procedural_integrity(
        blueprint: Dictionary,
        witnesses: Dictionary,
        summary_present: bool,
        persisted_summary: Variant) -> Dictionary
```

The later world adapter alone derives `summary_present` with `owner.has(...)`:
`module_integrity_summary` for the home run and `module_integrity` for visited
ship summaries. The Boolean is trusted call-site authority, not persisted data.
When it is false, B1 ignores `persisted_summary` and reconstructs uninitialized
state. When it is true, `null` or a non-Dictionary rejects, while `{}` retains the
accepted uninitialized meaning and reconstructs. Thus absent and explicit `null`
cannot collapse into the same case, while absent and explicit `{}` intentionally
produce the same historical state.

Success returns `ok`, an empty `reason`, c51 source/route provenance, sorted old
physical descriptors, and one full registered-state row per authenticated old
ID, including pristine rows omitted from sparse persistence. Each old solid edge
record includes its canonical `edge_key`, integrity ID `edge/<edge_key>`, and
the exact two coverage keys `<edge_key>@a` and `<edge_key>@b`. It also returns a
canonical sparse recapture for reference comparison. Input Dictionaries remain
byte-equivalent on every result.

Missing state reconstructs the exact c51 order: condition/portal overlays,
structural compile and validation, then compiled-plan wreck generation and
damage application. A present valid envelope initializes the authenticated
registered set as pristine and applies only its explicit rows. Consequently a
present valid envelope with `deltas: []` is explicitly fully repaired and
suppresses generated damage.

## Exact c51 emitted admission

This admission is pinned to what c51 emits; it does not import current summary
strictness by inference.

- `module_integrity_map.gd` blob
  `cce006253918bf83770daf94f4df2efb8a808a10`, `get_summary()`, emits exactly
  `schema`, `deltas`, and `registered`; schema is
  `module_integrity_map_v1`, and `registered` is `_modules.size()`.
- Its `to_sparse_deltas()` emits `ModuleIntegrityState.get_summary()` only for
  non-pristine states. It does not sort rows, so migration validates order
  independently and sorts its own detached output by module ID.
- `module_integrity_state.gd` blob
  `3370bc98e297d81d071e108b79cf4d5733917487`, `get_summary()`, emits exactly
  `module_id`, `kind`, `room_id`, `integrity`, `base_integrity`, `state`,
  `material_composition`, `mounted_components`, and `tool_class`.
- `module_integrity_consequences.gd` blob
  `55feee84141babd7b8f3bc22cdfb997600047d8b` registers compiled floor, edge,
  and ceiling records before applying `module_damage`. The c51 wreck mutator
  derives every generated damage key from those same compiled records. For a
  canonical c51-produced save, `registered` therefore equals the unique union
  of authenticated compiled floor/edge/ceiling IDs, and every emitted delta ID
  belongs to that union.

B1 requires that exact envelope and row shape, unique delta IDs, the exact
authenticated registered count, finite JSON numbers after engine conversion,
`0 < base_integrity`, `0 <= integrity <= base_integrity`, and the exact c51
threshold-derived state. Unknown IDs reject. This deliberately admits canonical
c51 producer output rather than every malformed value that c51's permissive
`apply_summary()` happened to coerce. The stable malformed-input reason is
`invalid_legacy_integrity_summary`.

## Frozen source and data provenance

All sources come from commit
`c51bcacbcb5557fd54ccf5a3e2775f0e35c61bad`.

| Source | Git blob | SHA-256 |
|---|---|---|
| `layout_mutator.gd` | `4381b9c0414cbf386555b442a617609637637359` | `62b0862f220af4c94fccd4022bed68396c698b92eea85d3a2bd9512ede07ef1b` |
| `structural_edge_compiler.gd` | `71167c504b2738ae191288ed90a6419546376f03` | `dad70f0d5a49ee659bad51ea05e8052cee30a37181f9376b5339898a4c2e2d36` |
| `structural_plan_validator.gd` | `e60fcfe6733a9a34a6223638e179fa7f2be9cf4e` | `2b5e2b0dfdc73fd84366550da6bf26d8af1208a5be0a5597218aaa4a3a851d6b` |
| `modular_socket_catalog.gd` | `d7d15f9208402f0c19ea29d514cdf4cae6f8e860` | `c4299764818889c3f768961477cf68eb9b9d9510aa62e98ab445c45cd397ecdb` |
| `walkability_contract.gd` | `8bb48a762ef29dc46682b946b58b268c4c2b2947` | `a827f9d56eceb8976757bdfbfd452226f8be697a7503245448285bc139625e88` |
| `module_integrity_consequences.gd` | `55feee84141babd7b8f3bc22cdfb997600047d8b` | `fbeff7adc79ee9bef3a1e27bfadac9d03cc27f50e9502b5020f1fa5b8463f880` |
| `module_integrity_map.gd` | `cce006253918bf83770daf94f4df2efb8a808a10` | `6e8b024a782e46a7e7f4ca24619749c943cf73cf07de59e683c904eef253e250` |
| `module_integrity_state.gd` | `3370bc98e297d81d071e108b79cf4d5733917487` | `9f787ff2e4849787bd40de958c03dce23c4c83f11ec321e60a34b6cfdbfa4e86` |
| `data/kits/ship_structural_v0.json` | `473f688a078877e4db314cc074933dcc4a9ad3da` | `adde67f7b28d097830662e54475e9ca412ee35a4d459912790b741ea80a43b95` |

The c51 catalog calls `names.sort()` before loading. The exact 16 JSON contract
bytes, in that historical order, are:

| Contract file | Git blob | SHA-256 |
|---|---|---|
| `bulkhead_portal_2x1_contract.json` | `6c54ac573835c3e25a5a658c0f395f4a716de572` | `510e0bd66f609af57a892e33a42dd6a12cc64061ddb737ee9bde9820b82cb75b` |
| `ceiling_cap_1x1_contract.json` | `e914fbaec4246925f817c5735ce477588e9a2c22` | `47667ab20f32692529154299cd2720c49bf1e119ea2a917d5b26b4a7509afb8f` |
| `corridor_floor_1x1_contract.json` | `ff2b74014055d348c1b3024c88614727b5216c69` | `c601a1fcfb40cfbb33bd34d5a631d9eb01c63231f54858eb8b8fb43d65318184` |
| `corridor_floor_1x2_contract.json` | `35c248d2fb327fbcf1a74dfaccd3d34d15873ca2` | `bb0709894acf8d840bd28d4665be4199a57f1d7635bebaca3052f11c56c15a23` |
| `doorway_frame_blocked_1x1_contract.json` | `7ccd8ed1813585d090c1539a44416764e9f9dc14` | `d945225e52afa430b1ce8f1b9aade459e66f9c82e6de31a8946c92400a5d841b` |
| `doorway_frame_open_1x1_contract.json` | `953e35a0ee8e1eaf29b4641d5d569cd900d41be4` | `0d8ade7c150f083ff5cd560bbd1162f0dae82dc074345fe20dac4dab03534765` |
| `floor_1x1_contract.json` | `4e51e781e7d36d96a657698d9727304d0dc029dc` | `c0750fdbe6e3ccb1db800c0887b01d173892877da19c694abd2c00d0caec921e` |
| `floor_2x1_contract.json` | `73c58a34bcdc7f237598828ce21c9cd2bd58959e` | `980a30f8cca801bce0aa7e3813088692e6ead5b298ebc51940a77e47775bfb29` |
| `pillar_support_1x1_contract.json` | `44d8ead38f40e8618d21be6709175c9a7bdf3896` | `326c35eb9f496d3b8b92d891796def87ba909131172b00d18fcc7aadb0306d22` |
| `pressure_door_1x1_contract.json` | `405a76f0bef7b682f375c10990aa4588ecca4967` | `2904e8837f550f1fbb08692a8273f0cba5de7446fdd2034649c8c24852e8e160` |
| `ramp_up_1x2_contract.json` | `735faa938146d728a89abf2aa118a4af3bb0c3dc` | `e10490f999bb4654698aa17ce4fec78ba2fc7cd60d4d34826db41801a56ec01a` |
| `wall_end_cap_contract.json` | `b3643c32141973eb8c6139bdc05c5108195228ab` | `033aa7a6d1afed419ca215b566d40696c918ee7210cee84ac8e001d1952f2caa` |
| `wall_inner_corner_contract.json` | `fc1c08ca27d40f3929cc6074eb5ba0f89593690b` | `3f8129cfe9050c09f5f8e1208732cace9d5e95d2de49f1da418df7b5bddab1af` |
| `wall_outer_corner_contract.json` | `712d13bab91d34715b9683135600456e8132ee54` | `35981d92872bc589d1d3dd292dfb19f52102bd040308b61a64448ee1e5a7df76` |
| `wall_straight_1x1_contract.json` | `ef4abdab74a9ffe7656ded3bf31f653f44bbdaa6` | `fd27d505f72ed855330f087267a247037ba28535fa10f6d1cd4378cc80b46ae2` |
| `wall_t_junction_contract.json` | `1ca35fec9437ef692a902c5fd6692aa00cc5cc11` | `49a0c1bc921fa2c34dfa14095470e0f033e701d8d06939674e5e1555902d0705` |

The authority-source package must retain the full c51 paths, blob IDs, SHA-256,
and original bytes. Runtime authority embeds parsed copies; it never reads Git.

## RED/GREEN and independent reference acceptance

The intended RED is the new smoke failing because the two integrity APIs do not
exist. GREEN must cover fixed, authenticated fallback, and hash/version-gated
native inputs; absent and `{}` reconstruction equivalence; present `null`
rejection; serialized present `deltas: []` fully repaired behavior; serialized
nonempty damage tuples; exact registered/pristine coverage; malformed envelope
and row keys/types, duplicate/unknown IDs, registered mismatch, nonfinite or
fractional invalid values, bounds/state mismatch; route candidates that agree on
attachments but disagree on physical plan/health; and source immutability.

Before acceptance, an artifact-only reference harness built from an exact c51 Git
archive must emit canonical full plan, generated `module_damage`, registered ID
set, and sparse summary for each fixed/fallback fixture. Its manifest records every
source/data hash above. The one already classified c51 RoomAssigner warning remains
historical-reference-only; the production B1 smoke must be clean.

Native reference must use the separately approved direct ClassDB API only after
the exact binary SHA-256 and generator version gate, then feed its detached old
layout through the frozen actual c51 structural closure. The existing three clean
native attachment captures are prerequisites but are not sufficient proof of
physical-plan or damage parity. If a complete native structural reference cannot
be produced on a supported host, native B1 remains a recoverable unavailable route
rather than inheriting fallback results.

Acceptance requires literal expected rows derived from those independent captures,
fresh hardened RED/GREEN evidence with exact markers and clean P10 isolation, an
immutable source/authority package, and independent consequential review. Unit 5B2
may start only after B1 is accepted; it owns current final post-authoring generation
and the ruled uniform half-span/vertex mapping through the accepted public
`compiled_module_id()` seam.
