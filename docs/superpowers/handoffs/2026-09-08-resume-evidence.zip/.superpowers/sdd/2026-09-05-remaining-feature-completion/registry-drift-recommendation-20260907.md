# Registry drift preflight recommendation

The guard is failing for one concrete reason: the new proposed UI feature is parsed as 21 active `FEATURE::...` leaves. The in-memory builder produces 689 criteria versus the frozen 668, with zero removals. The complete row IDs, source lines, criterion text, and fingerprints are in [registry-drift-preflight-20260907.json](registry-drift-preflight-20260907.json).

The UI document is explicitly planning-only (`ui_presentation_program.md:1`), so these 21 rows should not enter the frozen acceptance registry. Preserve the frozen scope fingerprint, 668/657/11 counts, and 622 denominator. A bounded generator fix should exclude this proposed document (or otherwise require accepted status) from feature-leaf extraction; do not weaken the frozen guard or regenerate the registry as a side effect.

The 30 common-row text differences are encoding/mojibake normalization with unchanged criterion fingerprints; they do not account for scope drift. The 12 AI pipeline criteria shifted source line numbers after inserted prose, also without fingerprint changes.

ADR handling is narrower than the prior report recommended: README already allocates row `0068` to the Meshy path. Retain the historical Windows ADR-0060 path and row, retain README's 0068 path, and update only the new Meshy file header/internal references to `ADR-0068`. No historical ID renumbering is needed.
