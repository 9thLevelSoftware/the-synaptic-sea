# R17 accessibility exact source trace (moving WIP)

This report traces the 14 frozen FEATURE leaves for `ui_ux_accessibility.md` from `docs/game/inventory/feature_acceptance.json`. It is source-only and makes no registry promotion, runtime claim, or acceptance claim. The frozen accounting remains 668 source rows and a 622-row canonical denominator.

Six leaves have a concrete implementation and production path without a confirmed source contradiction: main menu, pause menu, text-scale propagation/persistence, codex reachability, item-gated web chart behavior, and settings snapshot round-trip. Seven leaves have a concrete implementation gap: settings submenus, mouse menu reachability, colorblind palette, hold-to-tap, gameplay difficulty propagation, binding-reflective glyphs, and tutorial timing/dismissal. Reduced Motion is dormant/unproven: its stored toggle has no consumer, but the tutorial banner has no animation to disable, so source alone does not establish a contradiction or require new animation.

Every leaf still has a proof gap because no commands were run. Existing PASS strings and validation-only helpers were treated only as named potential checks. They do not prove the full criterion.

## Source-supported leaves

| Leaf | Production trace | Existing assertion / remaining proof gap |
| --- | --- | --- |
| `68058def1241` main menu | `TitleMain._build_title_ui` and `_refresh_continue_enabled` construct the catalog menu and apply `TitleSaveQuery`; title is the project entry path. | `title_screen_flow_smoke.gd` wipes saves then later checks enabled-after-save, but never asserts disabled-without-save or all four labels. |
| `1f2a0585c31d` pause menu | Menu catalog contains required items; `PlayableGeneratedShip._input` delegates to `MenuCoordinator`, which opens pause and dispatches actions. | Title flow tests only the `quit_main` item; it does not enumerate the required list or check Save availability. |
| `bb322ebfa5f6` text scale | `SettingsState` writes the shared a11y object; `MenuCoordinator` reapplies child panels and `PlayableGeneratedShip` reapplies tracker/vitals/hotbar/coordinator; snapshot capture/restore carries `settings_summary`. | Existing title/UI save-load checks cover scale/model handoff, not immediate application to every HUD panel. |
| `8dbd9927d260` codex | Pause confirmation opens `codex`; `_refresh_codex` renders tutorial unlock IDs and registry lines. | UI-shell smoke reaches codex and proves one tutorial unlock only; no exhaustive rendered entry check. |
| `8a6a69a30f75` ChartPanel | Live `ui_open_map` checks `web_chart`, opens/binds ChartPanel, or sets `No web chart`; ChartPanel renders recorded WebChartState rows. | Gate and open/close sources exist, but the focused checks do not assert feedback text or marker rows. |
| `d3b974cb5bb1` settings round trip | `SettingsState.get_summary/apply_summary`; snapshot capture at `PlayableGeneratedShip:13103-13104`, restore at `13631-13633`. | `ui_shell_save_load_smoke.gd` asserts only 4 fields, omitting motion reduction, captions, difficulty, and preset. |

## Concrete implementation gaps

| Leaf | Gap found in source |
| --- | --- |
| `9a22ab4653a0` settings submenus | `settings_menu` is a flat item list. No Accessibility, Gameplay, or Input menus/routes exist. |
| `8ef960684ec2` multi-input menus | `MenuPanel` is `MOUSE_FILTER_IGNORE` and no menu click handler exists. This proves the mouse gap. Gamepad remains unverified: bootstrap-only key bindings do not rule out Godot built-in `ui_*` joypad defaults. |
| `f60dd53fe46d` colorblind palette | Mode is stored only. Objective and hazard palette selection has no mode consumer; tracker palette constants are fixed. |
| `9c9f6c09e1a9` hold-to-tap | Flag is stored only; no interaction/input path reads it to switch press to release. |
| `1723cc64ab27` difficulty | Menu displays a `DifficultyProfile` multiplier, but selected setting does not reach gameplay generation/hazards, codex, tooltip, or a reload boundary. |
| `9273a6019335` glyphs | Bindings are collected but `ControllerGlyphState.glyph_for` uses only static glyph maps. Scheme changes work, actual binding reflection does not. |
| `6d91f1cc1929` tutorials | First trigger, replacement of latest, and model dismissal exist, but no five-second expiry or player-facing dismissal input/control exists. |

## Dormant/unproven behavior

| Leaf | Source finding |
| --- | --- |
| `278d5bffca33` reduced motion | `motion_reduce` is stored and propagated to `AccessibilitySettings`, but no runtime reader uses it. The inspected tutorial overlay has no animation at all, so the source does not prove an animation-disabling failure and does not imply that animation should be added. |

## Focused commands named by current validation plan

`docs/game/06_validation_plan.md:609-624` names the canonical title/menu/settings/tutorial/glyph/UI-shell checks. Focused commands relevant to this report are:

```sh
"$GODOT" --headless --path . --script res://scripts/validation/title_screen_flow_smoke.gd
"$GODOT" --headless --path . --script res://scripts/validation/title_settings_smoke.gd
"$GODOT" --headless --path . --script res://scripts/validation/settings_state_smoke.gd
"$GODOT" --headless --path . --script res://scripts/validation/tutorial_state_smoke.gd
"$GODOT" --headless --path . --script res://scripts/validation/controller_glyph_state_smoke.gd
"$GODOT" --headless --path . --script res://scripts/validation/ui_shell_save_load_smoke.gd
"$GODOT" --headless --path . --script res://scripts/validation/main_playable_ui_shell_smoke.gd
"$GODOT" --headless --path . --script res://scripts/validation/chart_toggle_smoke.gd
```

No command was run for this audit.

## Moving-source limitation

Read revision: `f6250b4eae8dc3e85d7161e5efae9a9c96ee0886`. SHA-256 hashes for all inspected implementation files are recorded in the JSON companion. R10 is concurrently changing docking/boot code in this shared worktree, so source locations and conclusions touching boot/input should be rechecked before runtime validation or registry integration.
