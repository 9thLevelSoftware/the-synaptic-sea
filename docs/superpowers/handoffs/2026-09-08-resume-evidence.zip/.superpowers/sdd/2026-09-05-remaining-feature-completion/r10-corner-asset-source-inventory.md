# R10 corner/T asset source inventory

## Scope and finding

This is a read-only inventory for `wall_inner_corner`, `wall_outer_corner`, and
`wall_t_junction`. Their runtime visual, wrapper collision, placement contract,
projection, and verification records are separate artifacts but share one
structural-source pipeline. A vertex/span correction must preserve the three
module IDs and update the matching records together. No project source was
changed for this report; Godot and Blender were not run.

The current authored-source authority is missing from this checkout. The kit
records point at `/Users/christopherwilloughby/off-the-rails-ai-infra/assets/_source/self_authored/...`
and the contracts point at the corresponding `assets/_processed/...` GLBs, but
there is no `assets/_source` or `assets/_processed` directory here. The tracked
`assets/imported/.../<module>/<module>.glb` is the available canonical runtime
visual artifact, not proof of the original Blender authoring source.

## Per-module source and contract records

| Module | Contract facts observed | Current visual/runtime artifacts |
|---|---|---|
| `wall_inner_corner` | `module_family=corner`, grid `4.0`, footprint `[1,1]`, bounds `[-2,0,-2]..[2,3,2]`, `edge-center`; sockets `outer_corner_vertex_north_01=[2,0,-2]`, `inner_corner_vertex_south_01=[-2,0,2]`; JSON SHA-256 `f4072d99cd9feb526eb1eea75e6eccc155e8ca1d88addcd293374799c6389c1f` | Visual `assets/imported/structural/ship_structural_v0/wall_inner_corner/wall_inner_corner.glb`; textured GLB/PNG beside it; `.input.json` and `.manifest.json` are under `scenes/wrappers/structural/ship_structural_v0/`; wrapper scene has two `(4,3,0.2)` boxes: north at `(0,1.5,-2)` and east rotated/centered `(2,1.5,0)`. |
| `wall_outer_corner` | Same bounds/grid/footprint and two corner sockets as inner corner; JSON SHA-256 `b517ff3e583c4c94959bad02af241afe046f7d7336e601b1242eabc6d96323c5` | Visual `assets/imported/structural/ship_structural_v0/wall_outer_corner/wall_outer_corner.glb`; matching textured GLB/PNG beside it; `.input.json` and `.manifest.json` are under `scenes/wrappers/structural/ship_structural_v0/`; wrapper has the same two wing boxes/poses. |
| `wall_t_junction` | `module_family=junction`, grid `4.0`, footprint `[1,1]`, same bounds and `edge-center`; sockets north `[0,0,-2]`, east `[2,0,0]`, west `[-2,0,0]`; JSON SHA-256 `11bd00b62dce8265a546add015e47e5aa7e979e82f454f7528953e50aa335597` | Visual `assets/imported/structural/ship_structural_v0/wall_t_junction/wall_t_junction.glb`; matching textured GLB/PNG beside it; `.input.json` and `.manifest.json` are under `scenes/wrappers/structural/ship_structural_v0/`; wrapper has three `(4,3,0.2)` wing boxes at north/east/west socket axes. |

The canonical contract pairs are, for each module,
`data/placement/contracts/structural/ship_structural_v0/<module>_contract.json`
and `<module>_contract.tres`. The source contract loader and allowlist are in
`tools/structural_source_contract.py:23-29`; its source-root and imported-GLB
roots are the authority for path/provenance checks.

## Exact bounded change allowlist

Change these together when the vertex/span representation is accepted:

1. **Authored/recovered visual source:** the external self-authored
   `<module>.blend` and `.source.json`, if restored. The tracked runtime visual
   outputs are `assets/imported/structural/ship_structural_v0/<module>/<module>.glb`
   and, only if the material pass changes, the sibling textured GLB/PNG.
2. **Canonical contract:** the three JSON/TRES pairs above. Keep module IDs,
   socket IDs, provenance, and material economics stable unless the design
   explicitly changes them.
3. **Generated wrapper records:**
   `scenes/wrappers/structural/ship_structural_v0/<module>.tscn`,
   `<module>.input.json`, and `<module>.manifest.json` (the latter two are in
   `scenes/wrappers/structural/ship_structural_v0/` in this checkout). The `.tscn` is the direct
   collision authority consumed by projection generation.
4. **Projection/kit:** `data/kits/ship_structural_v0.json` contains the
   generated `dock_collision_projection_v1`; regenerate that projection after
   wrapper changes. If contract/resource hashes are changed, refresh the
   corresponding frozen entries in `tools/check_structural_rebuild_catalog.py`
   through the project’s governed update, then run its checker. Do not change
   the three catalog material-cost rows: inner/outer `12` and T `16`.
5. **Placement semantics only if schema changes:**
   `scripts/procgen/structural_edge_compiler.gd` owns the three module IDs and
   edge compilation constants (`:21-30`). `structural_plan_validator.gd` and
   `layout_serializer.gd` should be added only if the accepted contract adds a
   new vertex/span field that those serializers validate or persist.
6. **Canonical verification:**
   `tools/build_dock_collision_projection.py`,
   `tests/test_dock_collision_projection.py:82-84`,
   `tools/validate_structural_sources.py`,
   `tests/test_validate_structural_sources.py:240-242`,
   `tests/test_structural_source_contract.py:76-100`, and
   `tools/check_structural_rebuild_catalog.py`. The feature contracts also
   require the wrapper collision rows in
   `docs/game/features/structural_wrapper_collision.md:24-30,68-70` and the
   detailed corner/T guidance in
   `docs/game/features/remaining_procgen_play_stack.md:344-350` to be kept in
   sync with the accepted representation.

Do not include tile-generation tools merely for a collision correction.
`tools/batch_generate_tiles.py`, `tools/batch_import_textured_tiles.py`, and
`tools/render_module_passes.py` are optional visual/material regeneration and
preview owners only. Their current generated files are present beside each
GLB; they do not author collision projection.

## Regeneration prerequisites and commands

The original source must first be restored or explicitly accepted as
recoverable. Blender is required for source inspection/export. The documented
recovery command is source-only and imports the existing canonical GLB; it is a
fallback, not original authoring authority:

```text
blender --background --factory-startup --python tools/recover_modules.py -- \
  --project-root . --source-root <external-source-root> \
  --module wall_inner_corner --module wall_outer_corner --module wall_t_junction
```

`tools/promote_structural_sources.py` requires `--project-root`, `--source-root`,
`--staging-root`, one or more `--module` values (or `--all`), and Blender; use
`--dry-run` for planning. It also exposes `--skip-godot`, `--force`, and backup
options. `tools/validate_structural_sources.py` requires
`--project-root`, `--source-root`, and the same module selection, plus Blender.

After wrapper edits, the projection generator’s read-only check is:

```text
<python> tools/build_dock_collision_projection.py --root . \
  --kit data/kits/ship_structural_v0.json --check
```

Its corresponding mutating regeneration is `--write` and must be performed by
the owning implementation workflow. The documented source pipeline uses
`tools/recover_modules.py`, `tools/validate_structural_sources.py`, and the
promotion tool (`docs/game/features/blender_structural_source_pipeline.md:60-76`).

## Missing authority / recommendation

Before changing imported GLBs, obtain the missing self-authored Blender source
and README/asset record, or record an explicit decision that recovered sources
are the new authority. `recover_modules.py` can reconstruct a `.blend` and
`.source.json` from the current GLB, but it cannot recover intended vertex/span
geometry. Sol’s geometry design should therefore land the contract/schema and
wrapper representation first, then regenerate projection and visual artifacts
from a declared source authority. Preserve all historical module IDs and keep
the catalog economics unchanged unless separately approved.

## Windows prerequisite check (2026-09-08)

The conventional local lookup found Blender at:

```text
C:\Program Files\Blender Foundation\Blender 5.2\blender.exe
```

`--version` output: **Blender 5.2.1 LTS**, Windows Release, build hash
`9e2066aef7ef` (2026-08-25). No recovery, import, export, editor, or project
runtime command was run.

Both recovery and promotion accept an owned-worktree source root explicitly;
they do not require the absent macOS path. `recover_modules.py` requires
`--project-root`, `--source-root`, and module selection (`--module` repeated or
`--all`), with optional `--dry-run`/`--overwrite`. `source_output_paths()`
validates that each module output remains below the supplied root and writes
only `<source-root>/<module>/<module>.blend` plus
`<source-root>/<module>/<module>.source.json`. A safe owned-worktree planning
root is therefore, for example,
`D:\the-synaptic-sea-feature-completion\.superpowers\sdd\...\recovered-source`
(use a fresh task-specific directory).

Promotion requires `--project-root`, `--source-root`, `--staging-root`, and
module selection. It resolves the supplied source and staging roots, exports to
a temporary child of the staging module directory, and only later promotes to
`assets/imported/...`; its Blender executable is `BLENDER` or the command
`blender`. `recover_modules.py` itself is invoked by Blender and has no profile
path option. It uses `--factory-startup` in the documented invocation and the
script only writes the explicit source-root outputs; no repository or external
default profile path is selected by the tool. Promotion’s optional Godot smoke
uses a temporary overlay; `--skip-godot` is available for a source/export-only
plan. The installed 5.2.1 executable is newer than the project’s accepted
Godot version and must not be substituted for the requested Godot runtime.
