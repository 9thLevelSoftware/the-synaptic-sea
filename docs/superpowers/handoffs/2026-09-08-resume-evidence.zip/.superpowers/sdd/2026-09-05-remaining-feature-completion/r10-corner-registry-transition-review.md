# R10 corner registry transition — independent scope review

**Disposition: spec PASS / quality approved.** Reviewed the frozen package `r10-corner-registry-transition-review-package/` against source proposal-02 (manifest SHA-256 `cc22d4b8ddae102eb2a9675dea17952f2f537cc6435d29f9d673bcf3ef87dacf`) and the root-corrected mapping `r10-corner-corrected-criterion-mapping.json` (SHA-256 `136b46ee75ff7a466efb48aa94d070f550765bace6d1e1e28bd39d4a8042983b`). This is a registry/scope review only; it does not accept current geometry or runtime behavior.

## Frozen evidence integrity

The scoped diff hash is `cdb8d2e9c37e485ddbcc5067188a88104ae4a10f978ad50e5a4bb1a0b283e27e`. All ten frozen before/after images independently match the exact path, byte-count, and SHA-256 entries in additive `artifact-manifest-v2.json` (manifest SHA-256 `21e3c091b26ce9df567959ebf6a441e4c8bf0e6208b3a954adaae4c7749cc97e`): five beforeimages and five afterimages, with zero mismatches. This repairs the older abbreviated image manifests without replacing them and binds the review to frozen copies rather than the moving working tree.

The recorded commands are internally consistent: the final focused unittest log reports 27 passing tests, and the final write/check log reports `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0` with zero exit metadata. These logs support registry validation only.

## Scope, identity, and accounting

The afterimage of `tools/build_feature_acceptance.py` narrowly allowlists feature-source supersession solely for `docs/game/features/structural_wrapper_collision.md` under `Acceptance criteria`. It retains the separate requirement-source path, natural-ID and fingerprint recomputation, stable-ID, accounting, cycle, duplicate, unknown source, proposal, and frozen-scope guards. Its frozen source fingerprint is `8041e481680152f85fe2d3617491880a5268d89dcb63a59608590711edef48d0`; its reviewed-supersession-set fingerprint moves exactly from `ffe325ef281156711db10d85eb896a4781804ec976944aef4a948bdbe12ad0df` to `54f7c6f782eac4ca7e4a589304b9a74fc754ab3f3384bdf0d5ee3121ec482a8f`.

Exactly the three R10 stable leaves are superseded, retaining their original stable IDs and acceptance/history accounting while using the corrected replacement identities:

- `FEATURE::docs/game/features/structural_wrapper_collision.md::77be1df64944` -> `cbd31fe20bec...`
- `FEATURE::docs/game/features/structural_wrapper_collision.md::3a8fddf3798b` -> `a1d74b54c62f...`
- `REQ-DECAY-002::acceptance-95a1331257bc` -> `3c2770736202...`

All three afterimage records have empty references and `not_verified` evidence. Their counts remain **668 recorded / 657 active / 11 deferred / 622 active metric**. A record-by-record comparison found zero evidence changes on every other stable criterion, so historical evidence is preserved and no current runtime acceptance is promoted.

## P17 card review

The P17 card is additive: its allowlist grows from 103 to 137 paths, has no removed allowlist path or scope decision, and has no unrelated scalar-field change. The added decision describes the vertex-owned geometry and residual half-straight coverage, while added paths cover the stated geometry/compiler, serializer, wrapper/source/contract, and focused-validation scope. No unrelated P17 fields were lost.

No findings require a registry/package repair. Runtime implementation and its separate source/scene validations remain required before any geometry-dependent criterion can be accepted.
