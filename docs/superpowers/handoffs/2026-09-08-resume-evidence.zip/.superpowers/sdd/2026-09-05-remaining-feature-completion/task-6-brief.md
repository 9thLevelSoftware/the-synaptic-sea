# Task 6 / R06 physical-work and selected-ship closure brief

Date: 2026-09-06 (America/New_York)  
Workspace: `D:\the-synaptic-sea-feature-completion`  
Branch: `codex/feature-completion`  
Parent: P11-P13 / FC-13 through FC-15; dependency: accepted R03

## Frozen acceptance and authority

The frozen acceptance rows remain unchanged:

- FC-13: Only compatible catalogued parts install into physical slots.
- FC-14: Physical repair/install is timed, interruptible and exactly-once.
- FC-15: Selected derelict edits never modify the home ship accidentally.

The program remains frozen at 668 source rows, 657 active rows, 11 deferrals and
622 distinct active criteria after reviewed aliases. This package does not
promote any completion percentage or player acceptance state.

ADR-0059 decisions 5, 10, 15, 21, 25, 26, 28 and 31 govern R06. One
`ComponentPlacementState` owns durable slot occupancy; `ShipModificationState`
is derived. One ship-owned `ShipWorkTransaction` owns escrow and receipts. One
session-local `ShipWorkContext` binds the selected ship and live generation.
Permanent install/remove requires access; ordinary attended repair/salvage keeps
its existing action-specific policy.

## Provenance and source boundary

The initial exact disk-byte snapshot is
`task-6-beforeimages/manifest.json` (SHA-256
`ef83165b7788aa7f8f732d27f0ebcb63443832e957877a694ca29b5958322fcd`).
It records 41 paths at HEAD `17d9d3b11177b8c7d70d07d113ce5e9c038a513b`,
including inherited modified and untracked sources. The Task 6 brief, report and
the superseded plan-local focused-suite runner path were absent. Its scoped status
and working-tree patch are retained beside the manifest. Additive manifest
`task-6-beforeimages/scope-addendum-01/manifest.json` (SHA-256
`3f833f394108ca35f0b782f0d9236efb43e915cfb22267fb76eadbf086d1ff11`)
records the tracked `tools/run_physical_work_smokes.py` and its meaningful test
`tests/test_physical_work_runner.py` as absent before either is created.

This is the governance boundary, not the final runtime baseline. Runtime and
test candidates must receive a new additive beforeimage manifest immediately
after the coordinator releases the exclusive runtime window. Earlier snapshots
remain immutable and attributed.

R03 accepts the exact tested persistence source and its 17-file companion diff.
The playable coordinator and six persistence files still carry inherited
whole-file hunks outside the narrow R02/R03 implementation patches. R06 may
review and close only the P11-P13 owner/transaction families in the coordinator;
root retains the final whole-file commit boundary and Git index.

## Already-covered behavior to preserve and reuse

- P11 already rejects water, unknown components, incompatible slots, wrong ship
  and missing/unknown physical profiles in model coverage. It restores saved
  mounted data against current authored slot policy and quarantines incompatible
  or removed-slot content.
- P12 already reserves exact lots, pauses/resumes without progress loss, refunds
  exact lots on explicit cancellation, retains escrow on stale commit, stores one
  receipt for duplicate commits and blocks a reentrant commit latch. Its live path
  proves no early install/remove mutation and a committed component source lot.
- P13 already checks access, attachment, occupancy, selected owner, work-ledger
  identity, binding generation, stale callbacks, foreign home ownership, and
  untouched home state during away work.
- R03's accepted `fc_p10_smoke.gd` production path dismounts/remounts one exact
  component lot on the away ship, reloads twice, moves the same lot to the home
  ship, reloads twice, revisits the away owner, and proves exact origin, quantity,
  one mounted copy, and both owner projections. `ship_mod_run_snapshot_smoke.gd`
  separately proves direct model/RunSnapshot restoration. R06 reuses both at
  their existing strength and does not duplicate the transfer implementation.

## Missing obligations and planned implementation

1. Split FC-13 negatives into distinct authored identity/profile,
   footprint/size, socket/type, occupied-slot, water, unknown-item and wrong-ship
   cases. Every denial snapshots inventory lots, placement, derived power/effects,
   transaction ledger, receipt count and XP/noise observables.
2. Require a nonempty explicit target ship at physical-work start. Remove the
   selected/current/home fallback from the transaction admission path. Existing
   production callers already carry the owner; missing-owner validation must fail
   before work ID allocation or escrow.
3. Add start-time spatial admission before reservation. Keep commit-time range,
   selected owner, access, occupancy, tool, target existence and exact revision
   revalidation. A pre-escrow out-of-range request spends nothing; leaving range
   after admission pauses with exact escrow and progress until resume or explicit
   cancel.
4. Exercise target removal and same-generation revision drift after reservation
   through the production coordinator. Prove no effect, receipt, XP or completion
   noise on denial, followed by exact explicit-cancel recovery.
5. Count model mutation, scene/effect application, completion noise, receipt and
   XP independently across first, duplicate and reentrant completion. Each work
   ID may apply and award once.
6. Audit every production panel/interact call into the physical-work transaction.
   Validation-only direct driver helpers may remain clearly scoped, but no player
   path may reach the legacy direct component resolver branch or infer a home owner.

The expected first edit set is `scripts/procgen/playable_generated_ship.gd`,
`scripts/validation/fc_p11_smoke.gd`, `fc_p12_smoke.gd`, and
`fc_p13_smoke.gd`, plus tracked `tools/run_physical_work_smokes.py` and
`tests/test_physical_work_runner.py`. The runner is a thin adapter over the
existing hardened `execute_isolated_case` contract; it may group focused cases
but may not weaken containment, marker, diagnostic, timeout, cleanup, or retained
output checks. The existing
`ship_work_context.gd`, `ship_work_transaction.gd`,
`component_placement_state.gd`, `component_mount_resolver.gd`,
`ship_modification_state.gd`, and `ship_modification_panel.gd` are scoped only
if the RED reproduction proves their authority is incomplete. Any additional
file needs a card update and additive beforeimage before editing.

## Non-goals

P09 economy or natural-route work, ADR-0066/P14 condition and health policy, P15
selected repair, P17-P20 structural replacement/claim behavior, multiplayer
authority, synthetic slots, freeform construction, a replacement interaction
framework, a second component authority, save-schema changes, default-profile
recovery, editor/import/plugin work, or unrelated cleanup.

## Verification contract

Use Godot 4.7.2 accepted by ADR-0060 and
`.superpowers/test-runtime/Scripts/python.exe`. Every Godot body gets a fresh
task-owned home with exact `APPDATA`, `LOCALAPPDATA`, `GODOT_USER_PATH`, and
`XDG_DATA_HOME`, and a separate P10 containment probe before the body. Never use
the default profile.

- Canonical isolated cases: P11, P12 and P13 through
  `tools/run_feature_completion.py`.
- Focused isolated groups through `tools/run_physical_work_smokes.py`: P11 component slot,
  system-link, panel and modification smokes; P12 repair-unification,
  blocked-consume, work-driver and mount/dismount smokes; P13 away interact,
  away inventory sync, away remount SFX and revisit persistence smokes.
- Canonical P10 rerun for the accepted same/cross-ship exact-lot and two-reload
  predicate, plus direct `ship_mod_run_snapshot_smoke.gd` in retained evidence.
- Generator checks: `tools/build_feature_acceptance.py --write --check` followed
  by `--check`; criteria must remain 668 with denominator 622.
- Runner tests: `python -m pytest -q tests/test_physical_work_runner.py`.

Every positive case requires exit 0, its exact marker once, no unexpected
diagnostic, no timeout/cleanup failure and retained raw output. Every negative
also requires its exact denial plus unchanged protected state and no success
effect/receipt/XP/noise marker. Ownership and transaction changes require an
independent review on one frozen source manifest.

External `synaptic-sea-stage-gate` synchronization remains pending because no
connector is available. The generated local card manifest is the reviewable
stage-gate authority for this checkpoint.
