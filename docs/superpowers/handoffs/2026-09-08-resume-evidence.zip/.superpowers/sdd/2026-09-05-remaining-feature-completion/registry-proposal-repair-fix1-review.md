### Scoped Re-review

- ✅ ADDRESSED: `tools/build_feature_acceptance.py:1188-1203` collects every recognized inline or section-style status declaration. The catalogue now requires exactly one declaration before comparing it to the approved exact value (`tools/build_feature_acceptance.py:1263-1269`), so both a later Accepted declaration and a duplicated approved declaration fail closed.
- ✅ Regression coverage: `tests/test_feature_acceptance_registry.py:456-468` adds `initial_then_accepted` and `duplicate_initial` cases while preserving the prior accepted, ambiguous, changed-phrase, and missing-source cases.
- ✅ New breakage in this fix diff: none found. The new helper is used only by the proposal catalogue; the pre-existing general `_document_status()` path is unchanged.
- ✅ Retained fresh evidence: focused registry tests passed (`25 passed in 1.08s`, exit 0) and `tools/build_feature_acceptance.py --check` passed with `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0` (exit 0). Package SHA-256 matches the supplied `939fc539dce458c7ed7d46c6f2dc5af3554f4f93a1f9dc1f7e35a1a2560f3ba6`.

**Verdict:** all scoped findings addressed; task quality Approved.

**Limitations:** read-only scoped re-review of the additive fix package. No tests, Godot, or broader audit were run.
