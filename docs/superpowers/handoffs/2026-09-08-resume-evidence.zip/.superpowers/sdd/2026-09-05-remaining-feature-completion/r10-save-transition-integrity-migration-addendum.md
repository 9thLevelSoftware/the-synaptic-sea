# R10-A historical integrity identity migration addendum

Date: 2026-09-08. Preparation only. This is additive to the frozen save-transition
reports. It does not authorize runtime, schema-version, fixture, constant, or
governance edits, and it binds current half-span behavior only after the baseline
implementation is accepted and captured in the post-fix manifest.

## Proven identity change

The frozen world-6 implementation at `c51bcacb` emitted one structural placement per
materialized canonical edge. `structural_edge_compiler.gd:284` assigned
`placement_id = "edge:<edge_key>"`; `module_integrity_consequences.gd:181` derived
`<layer>/<key_part>`, where the edge key part was always the canonical `edge_key`.
Historical sparse damage therefore names `edge/<edge_key>`. The old compiler could
change that full-edge record's visual module to a corner or T junction, but it never
created a vertex or half-span integrity identity.

The pending physical compiler instead partitions each solid four-metre edge into the
canonical tokens `<edge_key>@a` and `<edge_key>@b`. A current placement declares
`edge_keys` and `covered_half_spans`; the validator requires each solid half-span to
have exactly one placement owner. Current producer/consumer identity is:

- A canonical full-edge or portal record with
  `placement_id == "edge:<primary_edge_key>"` retains
  `edge/<primary_edge_key>`.
- A vertex or residual half-span record uses `edge/<placement_id>`, for example
  `edge/vertex:0|0|0` or `edge/span:0|h|-1|0@b`.

That rule is visible in the pending `ModuleIntegrityConsequences._compiled_module_id`,
`GeneratedShipLoader._structural_target_id`, and `LayoutMutator` record collection.
Those three must agree byte-for-byte after baseline acceptance; migration must call a
single accepted identity function or prove exact parity rather than copy a fourth
slightly different rule.

Concrete examples:

| Frozen world-6 authority | Corrected physical authority | Result |
| --- | --- | --- |
| Placement `edge:0|v|0|0`, integrity `edge/0|v|0|0`, retained as a canonical full edge or portal | Placement `edge:0|v|0|0` | Integrity remains exactly `edge/0|v|0|0`; never emit `edge/edge:0|v|0|0`. |
| Full edge `0|h|-1|0`, integrity `edge/0|h|-1|0` | Vertex `vertex:0|0|0` covers `0|h|-1|0@a` and `0|v|0|-1@a`; residual `span:0|h|-1|0@b` covers the other half | Candidate target IDs are `edge/vertex:0|0|0` and `edge/span:0|h|-1|0@b`. The vertex also depends on the historical health of `edge/0|v|0|-1`. |
| Three historical edges incident at one T vertex | One `vertex:<deck>|<x>|<z>` placement covering three half-spans, plus any residual spans | The vertex has one health state. Differing incident historical states cannot be merged losslessly and reject. |

## Detached migration projection

For every recognized world-6 owner, the version-pinned
`world_v6_layout_projection.gd` first reconstructs and authenticates the frozen old
plan. The accepted current generator/compiler independently produces the corrected
plan from the same authenticated owner inputs. Neither current spatial proximity nor
visual module labels participate.

1. Strictly validate the historical `module_integrity_map_v1` envelope and its sparse
   rows before mutation. Missing/empty integrity means uninitialized: reconstruct
   frozen condition overlays and generated `module_damage` before mapping health.
   A nonempty valid summary with `deltas: []` means explicitly fully repaired and
   suppresses generated damage. A present envelope
   must have the known emitted keys `schema`, `deltas`, and `registered`; delta module
   IDs are unique and each known emitted row has exactly `module_id`, `kind`,
   `room_id`, `integrity`, `base_integrity`, `state`, `material_composition`,
   `mounted_components`, and `tool_class`. Numbers are finite after engine conversion,
   `base_integrity > 0`, `0 <= integrity <= base_integrity`, and `state` exactly agrees
   with the historical thresholds. Booleans/strings do not coerce.
2. Authenticate each historical `edge/<edge_key>` row against exactly one materialized
   frozen placement. Unknown edges, duplicate rows, a row for an old OPEN/no-wrapper
   edge, or kind/owner data inconsistent with the frozen placement reject. Non-edge
   floor/ceiling identities remain unchanged after the same strict validation.
3. Expand every frozen materialized SOLID edge into two logical source spans,
   `<edge_key>@a` and `<edge_key>@b`. Each inherits the edge's complete historical
   health tuple `(integrity, base_integrity, state)`; omission supplies the authenticated
   pristine tuple. This expansion is a detached interpretation, not a source rewrite.
4. Validate the corrected plan and build its physical placement table. Every current
   solid half-span must be claimed exactly once, every claimed token must name one
   frozen edge span, placement IDs and resulting integrity IDs must be unique, and the
   reverse map must account for both halves of every frozen damaged solid edge.
   Missing, extra, multiply claimed, topology-changed, or unauthenticated coverage
   rejects as `legacy_integrity_projection_unavailable`.
5. For a canonical full-edge/portal target, select the one historical edge by exact
   canonical key. For a vertex/span target, collect the historical tuple for every
   edge named by its `covered_half_spans`. If those tuples differ in any bit, reject
   the complete world candidate as `legacy_integrity_projection_ambiguous`; do not use
   minimum, maximum, average, sum, first-row, room order, or primary-edge preference.
6. After the product ruling below, emit at most one current sparse row per physical
   placement, sorted by current integrity ID. Current identity, structural kind, and
   room ownership come from the authenticated current placement. Only the approved
   historical health projection supplies health. Validate and exact-recapture this
   candidate before live publication. Source dictionaries/bytes, indices, live maps,
   sidecars, and backups remain unchanged on every rejection.

Pristine source spans do not produce sparse target rows. A current shared vertex whose
incident source spans are all pristine remains pristine. If all incident source spans
carry bit-identical non-pristine health, one vertex row is sufficient because the
current vertex is one physical integrity unit; duplicate target rows are forbidden.

Historical non-health mutable payload is a separate ambiguity. A one-to-one retained
identity can preserve `material_composition`, `mounted_components`, and `tool_class`
after validation. A one-to-many split or many-to-one vertex with any non-default
value cannot prove which new physical unit owns it and rejects as
`legacy_integrity_payload_projection_ambiguous`. Component/work/rebuild payloads that
refer to an old edge ID must use the same exact mapping; any reference with more than
one possible current target rejects rather than choosing one.

## Product ruling required: scalar HP or uniform extent state

A damaged old full edge has one scalar health record but may become two or more
independently damageable current placements. The historical save contains no damage
location within the four-metre edge. Copying its tuple to every claimed placement
assumes uniform health over the old edge; splitting the numeric loss chooses an
unrecorded distribution and changes threshold states; assigning it to one placement
loses damage on the other half. Absolute-health conservation and pointwise health
preservation cannot both be inferred from this schema.

Recommended ruling: define historical edge integrity as an intensive, uniform state
over its physical extent for this migration only. Copy the exact health tuple to every
current placement that owns one of its half-spans, subject to the identical-tuple rule
for shared vertices. This preserves damaged/breached/destroyed coverage and does no
rounding or arithmetic. If product authority instead treats integrity as a conserved
per-module scalar, split historical damaged edges are not reconstructible and must
reject `legacy_integrity_projection_ambiguous`; no allocation formula is supported by
the old save.

## Minimal implementation seams after acceptance

- Planned additive `scripts/systems/world_v6_layout_projection.gd`: expose the
  authenticated frozen old edge/placement table and old `edge/<edge_key>` identity.
- Existing `scripts/systems/save_migration_service.gd`: run the detached world-6 to
  world-7 integrity projection and return stable recoverable reasons.
- Existing `scripts/systems/save_restore_candidate.gd` and
  `scripts/systems/ship_instance.gd`: reject malformed current integrity summaries
  before they can be stored as opaque dictionaries or applied later.
- Pending accepted `scripts/systems/module_integrity_consequences.gd`: provide the
  single current placement-to-integrity-ID rule consumed by seeder, loader, mutator,
  and migration. If baseline does not expose this seam, adding it is an explicit
  allowed-file decision; migration must not depend on a private duplicated formula.
- Existing `scripts/procgen/playable_generated_ship.gd`: apply only the already sealed
  candidate summary after current geometry and descriptors exist. It owns no mapping
  policy.
- Already planned additive
  `scripts/validation/r10a_world6_geometry_migration_smoke.gd`: own this migration
  matrix. No fifth R10-A save smoke or new fixture path is proposed.

Meaningful acceptance fixtures within that smoke are:

- exact one-to-one full-edge and portal retention, including the absence of the
  erroneous `edge/edge:<edge_key>` ID;
- one old damaged edge projected across a vertex half and residual half under the
  approved uniform-state ruling, with exact health bits and current IDs/kinds/owners;
- two and three incident old edges with identical non-pristine tuples producing one
  shared vertex row plus the correct residual rows;
- damaged-versus-pristine and two different damaged tuples at a shared vertex reject
  `legacy_integrity_projection_ambiguous` without partially migrating residual spans;
- missing, duplicate, unknown, multiply claimed, and unaccounted span mappings reject
  `legacy_integrity_projection_unavailable`;
- non-default mounted/material/tool payload on a split/shared mapping rejects
  `legacy_integrity_payload_projection_ambiguous`;
- unaffected floor/ceiling rows remain byte-identical, source/current candidate/live
  state remains exact on every denial, and accepted current IDs survive staged exact
  recapture, save/reload, owner unloading, and revisit;
- requalification of `module_integrity_consequences_smoke.gd`,
  `pillar_persistence_smoke.gd`, `pillar_revisit_persistence_smoke.gd`, and the P10
  process persistence proof through the hardened runner after baseline acceptance.
