# R10-A Save Transition Preflight Addendum

**Status:** Preflight needs two narrow coordinator rulings before implementation release: historical native-route support and the exact hangar attachment/launch contract. The remaining requested decisions are concrete below. This addendum refines `r10-save-transition-preflight.md`; it does not change the allocated run-7/world-7 pair, absorb R07/history, or change source, governance, fixtures, constants, or registry evidence.

**Evidence base:** historical behavior is pinned to commit `c51bcacbcb5557fd54ccf5a3e2775f0e35c61bad` and `task-10a-beforeimages/runtime-after-r06-manifest.json`. The baseline is concurrently repairing four HIGH findings in compiler/endpoint/fresh-boot owners. Current `playable_generated_ship.gd`, `dock_ports.gd`, and `docking_manager.gd` names below identify semantic owners only; their current line numbers and signatures are not an interface freeze.

## 1. Smallest frozen world-6 procedural projection

World 6 persists `ShipBlueprint.to_dict()` (`size`, `condition`, `seed_value`, room-count range, and optional exact `generation_context_v1`) but not `ShipInstance.built_layout`, generator route, generator version, or originating platform. At c51, `ShipGenerator.generate_from_seed()` selected native generation solely when `ClassDB.class_exists("DerelictGenerator")`; otherwise it selected the GDScript fallback. Revisit repeated that runtime choice. A current endpoint resolver therefore cannot prove the old root, and a frozen fallback alone cannot prove a save made by the native route.

The fallback projection does not need the full historical generation stack. The closed dependency set needed to recover the first dock/airlock floor center and ordered hangar/cargo slot anchors is:

| Frozen input | Required portion | c51 Git blob |
|---|---|---|
| `ship_generator.gd` | Route evidence, default derelict archetype selection, and nonempty-difficulty extended-template choice | `5b61d7f906d967975291de9c8605a316d1a7dc40` |
| `ship_blueprint.gd` | Size/condition/seed/context validation and size-to-room-count range | `112458a7e9fa0b547c9b86b60f66897d43a5304b` |
| `template_selector.gd` + `topology_template.gd` | Exact extended-pool order and template decoding | `145a90a0f4e944a36b9b06829271b01704c753ea`, `13623b059a96bd345f20b5801d5ba8cb42211267` |
| `room_assigner.gd` | Zone order, RNG consumption, role aliases/guarantees, room order, and footprints | `c7738a8f47368d2de0518873456692ea0ecbada6` |
| `cell_layout_engine.gd` | Complete cell placement and adjacency realization | `cb742f3725b587e22e4bcb151560d86074a85ec2` |
| `ship_layout_generator.gd` | Four-attempt policy, retry salt `base_seed ^ (attempt * 0x9E3779B9)`, and first-connected/best-effort choice | `0799708c7a836634a8adfd0966ba2da92860c743` |
| `derelict.json` | Role weights and guarantees | `04024f7c6d3ca32b9bd0a5ed87d9a417c589ad6` |

The 14 historical template blobs, in exact selectable-pool order, are `spine=435b727323eb400e1f2bc6ba281eba2986f4339d`, `bifurcated=42a0ff4b4b04640d11b85859a604e2959e45786a`, `stacked=896b6fa47c53eb06f319cc916f0f57c8a6b26c04`, `stacked_v2=97e16735f6228cbf73177b32c7001b40ff764b00`, `compact=0abd9fea02cde84a06dc32d60d2fee76cab77a17`, `dispersed=1807af5a2a7cd0cdd298110446a843825e9d8b07`, `derelict_a=3c1c1327fe8a0c8286ef99d0830f6a9ad796d3f6`, `derelict_b=8668ff62c3b27de67d0341cc4ec666b645561a8d`, `ring=505d3c2e95ffb25995bbfb39c8bfa95fcf761203`, `radial=1d758e0a2f53df6e39e60fb88d618a8d178ab323`, `double_spine=16139a3b9627b957f1a2475af4e09d228a2f3a52`, `hangar_wing=29cfdf7405a52f2e4ae603677ad1bf0dde5ede07`, `vault=c64c20e39aa2318e4c99f3d83f26c2584f783a4f`, and `hive=fa23ac9cd98eb994d4fd1f57b52c2c1c6f24ad51`.

After `CellLayoutEngine`, old `DockPorts` needs only ordered rooms and ordered cells. Historical serialization maps every cell to `[x * 4.0, deck * 4.0, z * 4.0]`; wall resolution, structural compilation, module loading, variants, encounters, biome profiles, hazards, and scene construction cannot affect these poses. Variant selection uses its own deterministic calculation and does not consume `RoomAssigner.rng`. Connectivity retry can be decided from the placed-room adjacency graph, so the migration helper need not call the historical serializer.

Fixed authority can be data, not copied runtime generators. The c51 home layout blob `8f96dfb451a5e36b55db4033cfffe1e918093dc1` gives airlock floor cells `[0,0,0]`, `[4,0,0]`, `[0,0,4]`, `[4,0,4]`, hence old host port center `[2,0,2]`; its cargo cells yield two old hangar anchors `[20,4,-4]` and `[20,4,-8]`, size class 2. The c51 lifeboat source blob `f7ff672933a6a5cb57e9c3a812dbd81b3efaa058` has one airlock cell at zero; old `DockPorts.for_lifeboat()` therefore gives `[-2,0,0]`, and the old home-docked lifeboat root is `[4,0,2]` with identity basis. The old derivation and transform math are pinned by `dock_ports.gd` blob `195546f8855251163785f4a1d7e33fe2714886d9` and `docking_manager.gd` blob `ec49a728e0d798f01d1e72b93bd94139149ec651`.

The native route is an independent historical candidate. Its exact authority is `DerelictGenerator.generator_version()==2`, size map `{0:shuttle,1:corvette,2:freighter}`, condition intactness `{0:9500,1:6000,2:2000}`, kit `ship_structural_v0`, Windows DLL blob `b3e91392...` / SHA-256 `3279db6338e7af6b54cb4e8c8886d39bdffec73549a25149a05a87d9ebdb8798`, macOS dylib blob `fb99158e...` / SHA-256 `a17fbcaf4834d51ac8ddc05becbe0a762d07ab83e043f215532eccb40040cec1`, and kit blob `473f688a...`. There is no checked-in Linux library, Web has no native route, and native source is absent.

For each procedural owner, the adapter should form every available historical candidate and authenticate it against closed persisted witnesses: blueprint/context, old connection role, exact hangar slot count/size/occupancy, and exact known local room/cell marker identities. One surviving candidate is usable. Multiple survivors are usable only when every required old attachment/slot transform is bit-identical; otherwise reject `legacy_generation_route_ambiguous`. Zero survivors reject `legacy_layout_unreconstructable`. This never selects a route from the corrected current endpoint result.

Proposed additive paths are:

* `scripts/systems/world_v6_layout_projection.gd`: self-contained frozen fallback subset plus native candidate adapter and historical-candidate authentication.
* `data/migrations/world_v6_geometry_authority_v1.json`: exact source/blob provenance, copied archetype/template data, fixed home/lifeboat projections, old dock/slot constants, native version/hash/parameter table, and Godot 4.7.1 RNG dependency.

The previously proposed `scripts/systems/world_v6_docking_migration.gd` remains the detached graph/pose/combat orchestrator and consumes this projection. It must not preload the mutable current generator files. All export presets use `export_filter="all_resources"`, so the new `.gd` and `.json` ship automatically. The tracked `.gdextension` ships only the Windows/macOS libraries listed above; a runtime hash/version gate is required before using them.

**Ruling H1 required:** authorize platform-bounded native reconstruction using the exact checked-in binary after SHA/version verification. On Linux/Web the historical candidate set is incomplete because route/platform was not persisted; reject `legacy_generation_route_unavailable` unless an authority-defined route-exclusive witness proves fallback. If recognized native-origin saves must migrate there or after those binaries change, R10 needs a portable frozen native-v2 projection that the repository does not currently contain. Copying the binaries to a new path does not solve this by itself because both libraries register the same `DerelictGenerator` class.

## 2. Hangar attachment behavior and identity

The current behavior is narrower than an airlock connection:

* `DockPorts.for_hangar()` picks the first hangar room, else first cargo room; allocates `max(1, floor(cell_count / 2))` slots; takes ordered cell `i * 2` as each anchor; and admits size class 2 only at four or more floor cells.
* `HangarBay.free_slot_for()/dock()` checks only mobile size class and first-free occupancy. The requested UI slot is advisory; `_on_bay_dock_requested()` selects the first airlock-docked child that fits, clears its airlock relationship, installs it in the first free slot, and `_place_in_slot()` writes `host_root * Transform3D(identity, anchor)`.
* Current placement has no hull-volume, collision-shape, or capsule fit query. Launch clears the slot/parent edge and parks the root at host-local `[0,0,-8]`, also without a collision query. `_redock_bayed()` silently substitutes another slot when the saved index is invalid; run 7 must reject instead.
* A bayed root has no hangar `DockPortBarrier` and no traversable hangar doorway. It is physically nested at a slot. Occupancy gives the piloted/mobile interior priority; a host with no unrelated airlock barrier is boardable through the defensive no-barrier branch. A hangar attachment is therefore not a boarding endpoint and receives no `boarding_port_states_v1` row.

The smallest honest row model is a strict `port_type` tagged union:

```json
{
  "connection_id": "<derived>",
  "port_type": "hangar",
  "slot_index": 0,
  "host": {"ship_id": "carrier", "attachment_id": "hangar-slot:0"},
  "mobile": {"ship_id": "child", "attachment_id": "ship-root"}
}
```

Airlock rows retain the brief's exact host/mobile `{ship_id, endpoint_id, port_id}` shape and `slot_index:-1`. A current hangar attachment registry derives the host identity from the exact current ordered slot descriptor and the mobile identity from that ship's root and size class. Restore requires exact slot identity/index equality, unique empty allocation, size fit, one-parent acyclic ownership, and the exact root-to-anchor transform; it never calls airlock alignment, creates endpoint IDs, creates a barrier, or chooses another slot.

The identity alone cannot repair the current missing physical-fit authority. The smallest safe behavior is to apply the accepted baseline's broad-phase plus authoritative cross-ship collision-shape query to the proposed root transform, allowing only zero-volume contact, before both live baying and staged redock. This is a hangar placement predicate; it does not weaken the airlock pair predicate or exempt host geometry. If existing authored slot anchors cannot pass that query, new slot geometry/fit metadata is required rather than an identity exception.

Launch exposes a separate persistence hole: once parked at `[0,0,-8]`, the mobile has no parent connection and no saved root transform. World 7 cannot reconstruct a save made in that free state from `dock_connections_v1`.

**Ruling H2 required:** authorize the tagged hangar row above and the exact-fit precondition. Also rule the launch state: either launch must end in another authenticated connection before saving, or the allocated world-7 contract must gain explicit free-root authority. Silently accepting the current unrooted `[0,0,-8]` state is not exact; rejecting every bayed hangar edge would contradict the instruction to preserve hangar save/travel behavior.

## 3. Durable inactive boarding-port coverage

The smallest complete rule is one durable per-owner endpoint-state map in the detached candidate/runtime model and one flattened disk authority in `WorldSnapshot.boarding_port_states_v1`. `ShipInstance.built_layout` is not serialized, and current `opened_ports` is collected from live barrier nodes, so live-node enumeration cannot preserve an unloaded visited owner.

For every known boarding owner (`ship_start`, `lifeboat`, and every visited `ShipInstance`), candidate materialization uses the accepted **current** pure endpoint authorizer to produce an endpoint manifest from that owner's persisted layout inputs. The state invariant is exact set equality: each manifest endpoint has exactly one Boolean row and no row names an endpoint outside the manifest. Active roots additionally require exact equality with their materialized endpoint registry and barrier projection. Inactive owners retain the authenticated map when their scene root unloads; activation regenerates the manifest and proves equality before creating barriers. Missing, duplicate, extra, or unprovable rows reject rather than defaulting false.

Barrier transitions update the owner map; teardown first snapshots every live barrier into it; capture flattens all owner maps, including inactive owners. Staged restore installs the candidate maps before any owner activation, binds barriers from those values, and exact recapture flattens the same maps. Hangar attachment IDs are held by the connection registry and are never inserted into this Boolean map.

World-6 migration constructs a corrected-current manifest for every known owner, initializes every endpoint false, then maps each legacy opened marker to exactly one corrected endpoint. Ambiguous or unmatched markers reject. This satisfies inactive revisit and exact staged recapture without adding a second serialized copy inside each ship summary.

No additional policy ruling is needed if the coordinator accepts detached current endpoint-manifest generation for all known owners during candidate materialization. The save implementation must bind to the re-reviewed pure authorizer interface, not today's moving compiler call sites.

## 4. Corrected-current legacy pose classification

The prior preflight's historical-seam wording is superseded. `world-6.aboard_ship_id` is the sole owner. The pinned old graph computes exactly one value:

```text
owner_local = old_owner_global.affine_inverse() * legacy_global_position
```

The adapter then projects that unchanged local value through the same explicit owner's corrected current root. It runs the accepted current threshold classifier only against current connections whose **mobile owner** is that ship. Exactly one containing authenticated threshold yields `dock_threshold` with that connection and mobile endpoint. With zero threshold matches, the same owner's current interior/capsule proof must pass to yield `interior` and empty IDs. Multiple threshold matches or failure of both proofs rejects. Historical proximity, old port tags, another owner's volume, clamping, and endpoint snapping have no role. Final live capsule clearance remains a staged prepublication check. No further ruling is needed beyond consuming the accepted baseline classifier.

## 5. Closed moved-owner combat schema

World 6 has two known emitted envelopes. The c51 envelope has exactly seven top-level keys (`encounter_markers`, `threats`, `detection`, `awareness_indicator`, `combat_engaged`, `last_attack_result`, `damage_pipeline`) and 40-key threat rows without `structure_damage`. The R06 envelope adds exact `schema:"threat-manager-2"` and `structure_damage`, giving eight top-level and 41 threat keys. The migration-only validator accepts these two variants, applies the existing legacy structure-damage table to the first, and then validates current values. It does not loosen or edit `ThreatSaveContract`.

The closed nested variants are:

| Envelope | Exact known variants |
|---|---|
| Threat row | `instance_id, archetype_id, display_name, room_id, cell, world_position, state, previous_state, max_health, health, attack_damage, [structure_damage], attack_type, attack_noise, attack_interval, attack_cooldown, noise_sensitivity, light_sensitivity, sight_sensitivity, memory_seconds, memory_remaining, flee_threshold, stunned_remaining, awareness_score, last_known_room, status_on_hit, armor_profile, tags, move_speed, hunt_speed_mult, flee_speed_mult, investigate_speed_mult, attack_range, last_known_position, ambush_hold, stalk_range, swarm_split, anchored, telegraph_seconds, telegraph_remaining, player_verb`. Only `world_position` and a nonempty `last_known_position` are global. `cell` is topology-local. |
| Threat `armor_profile` | Exact authored 3-key `{flat_reduction,resistance,durability}` or exact normalized 5-key form adding `max_durability,wear_factor`; the two damage-type maps have string keys and finite numeric values. |
| Encounter marker | Exact fallback/validation 5-key `{id,room_id,cell,encounter_kind,count}` or exact injected 14-key `{id,room_id,deck,cell,local_position,encounter_kind,count,difficulty_tier,encounter_table_id,seed_offset,tension_progress,branch_depth,patrol_crosses_critical,spike}`. `cell` and `local_position` are ship-local and remain byte-identical. |
| Detection | Exact 13 keys: `noise_level,light_level,sight_level,crouching,room_id,detect_threshold,memory_seconds,memory_remaining,awareness_score,detected,heard,seen,last_reason`. |
| `last_attack_result` | `{}`; exact 11-key incoming result `{damage_type,incoming,flat_reduction,resistance,absorbed,final_damage,durability,profile,source_id,status_effect_id,noise}`; or exact 17-key weapon result adding `stun_seconds,ok,weapon_id,target_id,ammo_item_id,ammo_remaining`. `profile` is the exact normalized 5-key armor form. |
| Damage pipeline | Exact keys `processed_hits,total_damage_applied,total_noise_generated,last_result,armor_resolver`. `last_result` is `{}`, the exact 11-key incoming form, or the 12-key threat-hit form adding `stun_seconds`. `armor_resolver` is exact `{armor_profile,last_resolution}`; its profile is exact normalized 5-key, and `last_resolution` is `{}` or exact `{damage_type,incoming,flat_reduction,resistance,absorbed,final_damage,durability,profile}`. |

For a visited owner whose root transform changes, reject any additional key at any of these levels with `unsupported_moved_combat_payload:<path>` before changing a point. Then transform only the two declared threat fields through `new_root * old_root.affine_inverse()` and preserve every other value exactly. Home combat remains under its existing validator because the home frame does not move. There is no spatial-looking-name/array heuristic and no remaining opaque nested dictionary after the exact armor/result variants above are enforced.

Add focused cases to `r10a_world6_geometry_migration_smoke.gd` for both c51/R06 envelopes; all three attack-result forms; all three damage `last_result` forms; both marker and threat-armor variants; an unknown key at top, threat, marker, detection, result, pipeline, resolver, resolution, and armor levels; exact preservation of local cells/positions/maps/tags; and transformation of only world/last-known points. These refine the existing validation-7 matrix and do not add unrelated owners or another aggregate suite.

## Remaining coordinator decisions

1. **H1:** platform-bounded exact native-v2 binary use plus stable unavailable/ambiguous rejection, or provision of a portable native-v2 projection.
2. **H2:** exact hangar tagged-union row and collision-shape fit predicate, plus the authority for a launched free root.

After those rulings and baseline re-review, the save implementation can proceed in the preflight's existing order. Historical projection remains pinned to c51 inputs; current endpoint classification/coverage binds only to the newly accepted pure interface.
