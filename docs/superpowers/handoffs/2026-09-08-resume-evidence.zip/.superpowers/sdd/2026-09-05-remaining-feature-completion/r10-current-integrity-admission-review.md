### Spec Compliance

- ❌ Issues found. Current run-7/world-7 raw admission, exact envelope/row shape, Boolean and non-finite rejection, threshold-consistent state, recursive JSON payload checks, explicit empty-delta initialization, descriptor count/ID/kind/room authentication, atomic staging, room-owner preservation, exact sparse recapture, and historical-version isolation are implemented at `scripts/systems/module_integrity_map.gd:201-316`, `scripts/systems/run_snapshot.gd:250-258`, and `scripts/systems/world_snapshot.gd:140-142,209-231`. However, the implementation does not preserve every admitted numeric health value as required by `docs/game/features/crafting_derelict_feature_completion.md:409-411`; see the HIGH finding below.
- ⚠️ Cannot verify from this unit: live staged-restore wiring and geometry closure are explicitly deferred by the binding scope (`docs/game/features/crafting_derelict_feature_completion.md:413-416`) and are not claimed by this package.

### Strengths

- `scripts/systems/module_integrity_map.gd:201-253` validates raw `Variant` input before decoding, rejects non-dictionaries and malformed exact-key envelopes/rows, distinguishes `{}` from an initialized empty-delta envelope, rejects duplicate IDs and invalid health/state tuples, and deep-copies accepted syntax.
- `scripts/systems/module_integrity_map.gd:259-316` completes descriptor and row validation into temporary state before assigning `_modules` or current-mode metadata. Rejected applications therefore leave both live module state and rebuild authority unchanged.
- `scripts/systems/module_integrity_map.gd:125-151,311-315` plus `scripts/systems/module_integrity_state.gd:157-165` recapture explicit rows in accepted order from live models rather than replaying a cached receipt, while current-mode exact pristine checks retain sub-epsilon damage.
- `scripts/systems/run_snapshot.gd:250-258` and `scripts/systems/world_snapshot.gd:140-142,209-231` restrict strict raw admission to run-7/world-7 and validate home and visited values before permissive nested decoders can normalize them.
- `scripts/validation/r10a_integrity_admission_smoke.gd:28-352` exercises malformed syntax, current run/home/visited admission, historical run-6 isolation, descriptor mismatches with unchanged state, explicit row order/value recapture, room owners, pristine reconstruction, empty deltas, sub-epsilon damage, and detached authority denial against real models.

### Issues

#### CRITICAL

- None.

#### HIGH

- `scripts/systems/module_integrity_map.gd:230-240`; `scripts/systems/module_integrity_state.gd:145-165`; `scripts/validation/r10a_integrity_admission_smoke.gd:93-108,291-309` — The validator accepts every finite `int` health/base value, immediately converts it to `float`, and validates only the rounded tuple. The destination model then explicitly casts both fields to `float`. For example, integer `9007199254740993` becomes `9007199254740992.0`; a row with that value for both integrity and base is admitted as intact and later recaptured with a different numeric value. This violates the binding requirement to preserve accepted health without coercion and can silently corrupt a syntactically accepted current save. The smoke covers large unsafe integers only for `registered` (`r10a_integrity_admission_smoke.gd:70-77`) and uses small float health values, so it does not expose this path. Remediate by rejecting integer health/base values that cannot be represented exactly by the model's float storage (or by changing storage to preserve the admitted numeric representation), and add validator plus descriptor-application assertions using an unrepresentable integer to prove rejection or exact recapture.

#### MEDIUM

- None.

#### LOW

- None.

### Focused Checks Outside the Diff

- Current-mode reset risk: searched production call sites for `ModuleIntegrityMap.apply_summary` and `apply_sparse_deltas`. Production callers use `apply_summary`, whose successful historical path clears all current-mode metadata at `scripts/systems/module_integrity_map.gd:176-194`; no production direct `apply_sparse_deltas` caller was found.
- Descriptor-authority typing risk: inspected `scripts/systems/structural_rebuild_state.gd:49-57,333-348`. Registration is the sole source for `get_original_descriptors`; strict application independently validates the descriptor fields it relies on and stages failure before commit.

### Tests Inspected

- Inspected the new smoke assertions in `scripts/validation/r10a_integrity_admission_smoke.gd:16-352`; no test was rerun because the code established the remaining defect and the execution lane is serialized.
- Inspected packaged RED `evidence/red/result.json`: exit 1, zero exact PASS markers, intended missing-validator parse errors, and a passing clean containment probe.
- Inspected packaged final `evidence/final/result.json`: all six focused smokes report exit 0, one exact marker each, empty diagnostics, clean containment probes, and stable hashes for all five owned sources.

### Assessment

**Task quality:** Needs fixes

**Reasoning:** The architecture and ordinary-value behavior are strong, and the current-only/raw/atomic requirements are well covered. Admission of integer health values that the float-backed model cannot preserve is a direct strict-contract violation, so this unit should not pass until the validator and smoke close that boundary.
