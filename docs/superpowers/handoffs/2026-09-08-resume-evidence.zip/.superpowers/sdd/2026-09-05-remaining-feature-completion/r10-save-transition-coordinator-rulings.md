# R10 save-transition coordinator rulings and remaining preflight

Date: 2026-09-08. This is preparation only. No version or runtime edits are released until the baseline fix passes independent re-review.

## Historical procedural geometry

A version-pinned legacy projection is authorized in principle. It should reproduce only the historical room/floor ordering and attachment poses required for world-6 transforms, using the smallest closed set of historical algorithms and data. It must not call mutable current generation and assume compatibility. Before implementation, identify the transitive generator/data/native dependencies, exact historical source provenance, proposed new paths, and how exported builds retain this authority. Intentional versioned migration code is justified; copying an entire generation stack without identifying the necessary subset is not.

Cost if wrong: recognized procedural saves may reject safely or require additional migration compatibility work. Existing fixed-layout provenance remains valid preparation.

## Hangar attachments

Do not drop supported hangar save/travel behavior merely to simplify this transition. Do not invent airlock identities for hangar slots. Before the final contract ruling, trace the actual current slot allocation, placement, launch, owner graph, collision/fit checks, and whether stored ship roots have a traversable boarding barrier. A type-specific registered attachment identity may be appropriate because connection rows already distinguish port_type, but it must represent existing authored slot/root attachment authority and must not imply a new doorway or collision exemption. Return the smallest concrete model and exact call sites. Baseline airlock collision rules must not be weakened for this purpose.

## Endpoint state must survive unloading

The interpretation 'only currently materialized roots matter' is insufficient if it drops opened/closed state from visited owners when their roots unload. Preserve durable state for every known endpoint owner across unloading and revisiting. Every active boarding endpoint requires exactly one explicit Boolean state; retained inactive-owner state also needs authenticated owner/endpoint identity. Do not fabricate a barrier for a non-boarding attachment. Before implementation, identify the smallest complete coverage rule that preserves exact staged recapture and prior visited-port state without treating omission as a reset. Explicitly distinguish boarding endpoints from attachment endpoints in the proposed contract.

Cost if wrong: older or revisited ships could silently reopen/reseal. That is unacceptable; reject incomplete state instead of normalizing it invisibly.

## Legacy player classification

The explicit historical aboard_ship_id remains the owner authority. Use the pinned old graph only to interpret the old global position into that owner's local coordinates. Then classify the preserved local point under the corrected current registered endpoint geometry: threshold only when one unique current connection identifies it as its mobile-owned threshold; otherwise interior only when the same explicit owner passes its interior proof. Final live capsule validation still occurs before publication. Do not carry a historical threshold tag into a different current endpoint, infer another owner, clamp, or move the point to make migration succeed.

Cost if wrong: a valid legacy point may reject rather than load. Adjust the explicit geometry classifier from evidence; never relax exact ownership or recapture.

## Unknown moved-owner spatial payloads

Use a bounded, closed historical migration schema for the movement-relevant combat payload and its nested envelopes, covering all known emitted legacy variants. Do not rely on a 'spatial-looking array' heuristic: it neither proves unknown coordinates absent nor distinguishes harmless numeric arrays. Known nonspatial fields may be preserved unchanged when their schema/consumers establish that role. Unknown fields in a moved owner's spatially authoritative payload reject with a stable unsupported-payload reason before mutation. Do not broaden current ThreatSaveContract strictness as an incidental change. Return the exact known field/variant inventory and identify unresolved opaque envelopes.

Cost if wrong: unsupported historical metadata may require another explicit compatibility variant. Silent misprojection is not an acceptable fallback.

## Other accepted preparation

The central ephemeral exact-pose receipt, literal v5-to-v6 target, standalone run-6 denial after the constant bump, strict run7/world7 nested rows, and late hallucination reset match the existing brief. Do not allocate another schema transition or absorb R07. The proposed 26-case aggregate is a starting validation inventory, not permission to omit affected P10/R06 checks or to rerun redundant suites indefinitely.

## Addendum adjudication, 2026-09-08

Reviewed r10-save-transition-preflight-addendum.md, SHA-256 65d4595bc13c34c77e84433057a382e34e67723238a6147bf276ca699e5c33cd.

H1: accept historical native-v2 reconstruction only after exact binary hash and generator-version verification. An unavailable native route does not establish fallback provenance. Incomplete candidate sets reject legacy_generation_route_unavailable; incompatible surviving candidates reject legacy_generation_route_ambiguous. This explicitly leaves cross-platform historical compatibility limited where no complete projection exists; it does not establish universal migration support. Preserve the minimal frozen fallback closure and exact data provenance described in the addendum.

H2: accept the strict hangar attachment tagged union and full pre-placement collision-shape fit, with no positive-volume overlap exemption. Preserve launch as a real free-root state through explicit world-7 spatial authority rather than requiring another connection. Before implementation, specify the exact free-root row and coverage: fixed roots, attached roots, detached materialized roots, and inactive visited owners must have unambiguous authority, with no duplicate transform authority. The existing fixed launch offset is not evidence of safe placement. A failed live launch or staged placement must leave state unchanged. Save preparation owner is producing the bounded schema and source inventory; no runtime/schema edits are released yet.

Accept the addendum's durable endpoint-map coverage for all known owners and closed historical combat variants as preparation. These still require tests and independent implementation review. Cost if wrong: explicit compatibility variants or attachment geometry/schema revision, never silent owner reassignment, overlap admission, or loss of visited-door state.

## Historical physical integrity projection ruling (2026-09-08)

Accept the uniform-state interpretation proposed in r10-save-transition-integrity-migration-addendum.md (SHA-256 1ccaefc75936a9dc51585ba8c97746fd42c292fd84ae434496a148ebb7cf8a55). This is an explicit migration policy, not a claim that old saves recorded localized damage. Preserve the exact historical integrity/base_integrity/state tuple on each authenticated current physical claimant. Do not divide or sum hit points: the existing module model derives damage states from integrity/base_integrity, and arithmetic redistribution would change breach/destruction behavior. Shared vertices require bit-identical source tuples across every covered historical edge, including pristine omissions. Conflicting tuples reject the entire candidate atomically. Non-health payload and ambiguous old-target references follow the separately documented rejection rules.

A positive split-edge fixture must include matching source state on every incident edge contributing to a shared vertex; a lone damaged edge beside pristine edges must reject. Keep both cases explicit. This ruling permits the migration specification/acceptance update; it does not release schema/runtime implementation before baseline acceptance. The final allowed-file scope must include the shared identity helper seam if needed. Root retains the full legacy compatibility obligation and requires explicit recoverable reasons for unsupported historical projections.
