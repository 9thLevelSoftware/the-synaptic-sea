# Task 7 / R07 governance-preparation report

Date: 2026-09-06 (America/New_York)  
Workspace: `D:\the-synaptic-sea-feature-completion`  
Branch: `codex/feature-completion`

## Checkpoint result

R07 remains unreleased and unimplemented. This checkpoint produced only
`task-7-brief.md` and this report. No shared governance, runtime, validation,
runner, Godot profile, save, generated manifest, board, Git index or commit was
changed. No Godot or test command was run.

The brief now records:

- the exact ADR-0066 condition, effective-health, damage, repair, power, tier,
  plating and restore contracts;
- a bounded file/function implementation scope that preserves R06 owner and
  exactly-once work boundaries;
- proposed placement and manager interfaces with stable provider ordering and
  atomic condition-mirror updates;
- an acceptance matrix covering multi-provider, disconnection, replacement,
  paid/forced repair, two-ship isolation, power drift, tier threshold, weighted
  plating, detached initialization, two disk reloads and ten timed cycles;
- a release-time beforeimage and hardened evidence plan using a unique owned home,
  all four user-data variables and the exact P10 process-smoke probe for every
  engine body;
- the coordinator's release, quality, runner and full-membership rulings;
- source-backed stable-target and nested ship-mod persistence recommendations.

## Source-backed findings

The current placement owner already preserves strict source lots, detached
condition-lot allocation, dismount identity and incoming lot condition, but it
has no stable provider aggregation or atomic condition mutation API.
`ShipSystemsManager` currently persists only intrinsic health and has no
placement binding/effective query; its `restore_subcomponent_on_remount` floor
and coordinator install/dismount calls implement the superseded behavior.

Production bypasses remain in power rebalance, repair-point construction and
revision, fire selection, compatibility/HUD summaries, objective helpers and
lifeboat initialization. Plating install still repairs module integrity, station
tier ignores condition, and restore replays effect writes. Those are the exact
R07 migration sites. The accepted durable association history and changed
projection semantics justify a new paired outer transition after R10-A; they do
not justify a catalog change or reuse of R10-A's pair.

The current P14 CARD set contains four cases, but the source-backed impacted set
contains eighteen. The current P14 source allowlist omits its own documented
`ship_mod_overbudget_power_smoke.gd` verification case. It also omits the
inventory-named `component_system_link_smoke.gd` and
`ship_mod_overbudget_power_away_smoke.gd`. Five legacy smoke families still
assert install healing, dismount damage, restore healing or plating repair and
must receive meaningful condition/disconnection/resilience assertions and new
markers. Their old PASS strings cannot qualify R07.

## Source-backed recommendations

### Stable mapped-target universe

Current placement links live on component rows. `get_summary()` deliberately
clears soft links, `restore_from_layout()` reconstructs current rows, and
`mount_by_slot_id()` replaces the old row with the incoming component's catalog
link. The catalog confirms that one `wall_console_mount_v1` slot can accept
`reactor_console`, `nav_console`, `thruster_control`, or `sensor_rack`, each
pointing at a different system target. Therefore, deriving `mapped` only from
current/dismounted rows would let an explicit replacement erase the old target's
mapping and expose its intrinsic health as effective health.

R07 should persist versioned association history separately from providers under
`mapped_target_authority_version: 1` and `mapped_targets_v1`. Each canonical row
records the target, source kind, authored slot and catalog component where
applicable. Validation derives an allowed set from this ship's exact systems,
authored physical slots, catalog links/fit, and deterministic soft-link rerun.
Every saved row must belong to that set, and every current placement association
must be covered. Version must be JSON integer `1`; history must be an array; each
row has exactly five string keys, with catalog component required and soft-link
component empty. Unknown/cross-ship targets, a real target without an authorized
slot association, removed slots, forged soft links, catalog/fit mismatches,
extra keys, wrong types, noncanonical order and duplicates reject; saved strings
never create authority by themselves.

Initial linking and replacement prepare history beside the placement row. Commit
rechecks a complete base fingerprint and atomically swaps placement plus the
monotonic history union. Dismount/replacement never erase old history. Failed,
cancelled, repeated or stale prepare changes neither owner nor mapping revision
derived from history and appends no provisional record or counter allocation.
Provider aggregation still reads mounted rows only, so an explicit relink leaves
the old target mapped/disconnected without a phantom provider.

### Strict ship-mod projection handling

The model boundary is permissive: `RunSnapshot` copies
`ship_modification_summary` without requiring or structurally validating it,
`SaveRestoreCandidate` does not independently materialize it, and
`ShipModificationState.apply_summary()` coerces configuration, accepts the saved
bonus, clears installed rows, and relies on a later bind whose return is ignored.

The end-to-end P10 boundary is stronger than that local trace suggested.
`_validate_staged_restore()` captures the fully applied disposable sibling,
builds another detached candidate from it, and compares the complete canonical
world against the expected candidate. Its exclusions are save metadata and one
oxygen cache flag; `ship_modification_summary` remains in the comparison. A bad
bonus or installed claim corrected by a successful bind rejects, and a failed
bind that changes the recaptured summary also rejects with
`staged_world_authority_mismatch`. The source does not demonstrate a malformed
ship-mod summary that passes this full comparison. The proven weaknesses are
late validation, coercion and an unchecked bind result, not a demonstrated
end-to-end P10 acceptance hole.

Use nested `ship_modification_v3` with R07's subsequent paired outer transition.
Current V3 must be present and strictly typed. Detached restore
recomputes installed rows, full P05 quality-adjusted draw, power status and
condition-weighted plating from validated placement/catalog state and requires
canonical equality before staging. Keep P10's later full recapture comparison as
the final backstop and check the bind return explicitly.

Legacy recognition must use central migration provenance, never the nested
discriminator. R10-A pair 7 remains valid V2/pre-mapped input and migrates only
through R07's central literal 7-to-8 run/world step. Older pairs traverse every
explicit prior boundary, including governed 6-to-7. R07's new current pair,
provisionally `world-8` with home `gate2-current-run-8`, requires V3 and mapped
authority v1 from its first capture. V2, missing authority, nested schema
switching, and saved migration flags under that current pair reject. Mixed pairs
and provisional future sentinel 9/9 reject. Trusted provenance remains the
pre-mutation `from_version`, `WORLD_HOME_RUN_PAIRS` validation and executed
ordered step.

This requires narrow post-R10-A scope for `save_load_service.gd`,
`run_snapshot.gd`, `world_snapshot.gd`, `save_migration_service.gd`,
`save_restore_candidate.gd`; the reviewed post-R10-A versions of
`save_migration_service_smoke.gd`, `save_migration_world_smoke.gd`,
`world_snapshot_smoke.gd`, `fc_p10_smoke.gd`, and
`fc_p10_process_smoke.gd`; and the active future plus new valid pair-7 migration
fixtures. Exact run 8/world 8 and sentinel 9 literals/fixture names are allocated
only after R10-A review confirms availability. Existing R10-A artifacts remain
history rather than being overwritten into valid migration inputs.

## Applied coordinator rulings and release gate

R07 owns manager-to-placement binding after accepted R06. Reviewed R10-A lands
before R07 runtime. Power expectations use current authored P05
`ItemQualityEffects` unchanged. The existing tracked physical-work runner is
extended to P14, all eighteen meaningful affected cases form the full membership,
and retired markers change atomically with governance. The hardened isolation
probe is `fc_p10_process_smoke.gd --mode=probe`, requiring exactly one
`FC P10 USER DATA PROBE PASS` marker.

The coordinator accepted provenance-bearing
`mapped_target_authority_version: 1`/`mapped_targets_v1` history in principle,
including exact ship/system/slot/catalog validation, atomic monotonic updates and
rejection-with-no-history tests. The coordinator also selected a subsequent
paired outer R07 transition rather than retrofitting R10-A pair 7. The remaining
preparation item is to allocate exact current/sentinel literals and fixture names
against reviewed R10-A's afterimage. No runtime work begins before that review,
the R06 gate, and explicit R07 release.

The next valid R07 action is the coordinator's explicit release of an exclusive
baseline after R06 and R10-A meet those gates. At that point the
implementer should capture the planned additive beforeimages before editing and
establish the specified RED cases. This report makes no implementation,
validation, feature-completion or player-acceptance claim.
