# R10-A fix1 independent review

Reviewer: `/root/r10_baseline_review` (Sol). Root preserves this condensed report
from the completed read-only review; the full report remains in the conversation.

**Spec compliance: FAIL. Task quality: Needs fixes. Exactly two HIGH findings.**

Authority: package `88c3f83a8604726230fbd9d4c39e2b521c839512218ae5c90622e2dd6cf441e3`,
source manifest `5771a376f85aa3aef5ff4b3ee1b5c1e1413e797b6d698f95eb84b2cbb550bd47`,
full component diff `808bd44a3280485e3463eae67e196f057d5a3ce960266a3c7544677b2bc18d87`.

## Closed original findings

- Exterior portal/navigation authoring precedes authoritative compilation; final
  validation recompiles and exactly compares the result.
- Every positive cross-hull intersection rejects, including join pieces; exact
  zero-volume contact remains legal.
- Fresh player construction is inert until pair/barrier/spawn/capsule validation,
  followed by one placement and occupancy publication. Restore remains separate.
  The defensive post-teleport occupancy mismatch is unreachable under the accepted
  synchronous validation/alignment/ownership invariants and is not a blocker.
- Half-span reconstruction, shared physical identity, and the bounded docking
  reservation have no additional blocking finding. All 60 stress cases are retained.

## HIGH 1 — loader publication lacks complete authentication

`scripts/procgen/generated_ship_loader.gd:181-185,246-260,289-290,420-469`
validates only StructuralPlanValidator and wrapper loadability. It can emit
`ship_loaded` and expose a layout whose endpoint/spawn is missing or spoofed, or
whose mapped wrapper collision differs from the authored projection.

Before runtime root creation/publication, authenticate endpoint/spawn using the
projection, including the fixed lifeboat spawn requirement. Reuse or extract the
existing exact materialized-wrapper validator to compare collision paths,
transforms, dimensions and fingerprint. Actual loader negatives must cover missing
and spoofed endpoint/spawn, unrelated navigation/floor identities, and collision
mismatch. Later DockPorts/DockingManager rejection does not close this boundary.

## HIGH 2 — endpoint geometry accepts lossy coercion

`scripts/procgen/dock_endpoint_authoring.gd:338-340,349-383,427-444,525-531,1024-1029`
coerces cells/deck/size via int and vectors via float. Cell arrays accept length >=2
and ignore their third deck component. Fractional, boolean or string inputs can
normalize into canonical values. Existing obvious-invalid mutations miss these.

Require exactly three cell elements, exact third-component/deck agreement, finite
numeric values and integral in-range coordinates/deck/size. Preserve mathematically
integral JSON floats; reject fractions, booleans, strings and extra/missing elements.
Use strict finite numeric vector parsing. Test direct validation and actual loading.

## Evidence and scope

The 15 runtime cases and 15 contained probes have exact markers, exit 0, clean
diagnostics and cleanup. Supplemental manifest
`847f8b2d0f9a86d936f0f2761a41d38cdb11b43e522f2907ca6aa7b68136c5ed`
records 19 Python tests passing in 1.02s and projection PASS modules=15 boxes=21.
The original LOW evidence concern is substantively resolved. A single aggregate
process transcript is absent, but individual logs suffice for the claims made.
No critical, medium, or actionable low findings remain. No tests were rerun by the
reviewer; the two HIGHs concern unexercised paths found by static inspection.

Run7/world7, historical migration, R10-B, R14 and natural R04 remain outside this
component acceptance. Fix2 must close both HIGHs before releasing migration work.
