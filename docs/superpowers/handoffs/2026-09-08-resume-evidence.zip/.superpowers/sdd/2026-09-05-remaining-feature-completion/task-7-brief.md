# Task 7 / R07 durable machinery condition and effective-health brief

Date: 2026-09-06 (America/New_York)  
Workspace: `D:\the-synaptic-sea-feature-completion`  
Branch: `codex/feature-completion`  
Parent: P14 / FC-16; dependencies: accepted R06 owner boundary, reviewed R10-A, and the retained P05 quality curve

## Checkpoint status

This is governance preparation only. The R07 implementation window is not
released. No runtime, shared governance, validation source, card manifest,
runner, save format, or default Godot profile was changed or executed while
preparing this brief. The exact implementation baseline must be captured only
after R06 review fixes are accepted, R10-A is implemented and independently
reviewed, and the coordinator grants R07 its exclusive runtime window.

The source authorities read for this checkpoint are Task 7 of
`docs/superpowers/plans/2026-09-05-remaining-feature-completion.md`,
`docs/game/adr/0066-durable-machinery-condition-and-effective-system-health.md`,
`docs/game/features/crafting_derelict_feature_completion.md`, and
`r07-condition-source-inventory.md`. The original P14 section in the repository
plan, current P14 card metadata, current validation markers, and current runtime
call sites were inspected to resolve scope. The ADR-linked brief in the sibling
2026-09-04 SDD workspace was deliberately not read.

## Frozen outcome and non-goals

FC-16 remains: `Power/tier/system effects match installed condition and reverse once`.
REQ-SMOD-001 retains its reviewed stable identity and accepted replacement text.
R07 must implement the following behavior without changing the frozen 622 active
criterion denominator:

- `source_lot.condition` is canonical for installed machinery; the placement
  entry's `condition` is an atomically updated mirror.
- `ShipSubcomponent.health` is intrinsic ship-side damage and persists separately.
- A mapped target with providers has effective health
  `min(intrinsic_health, max(mounted_provider_conditions))`.
- A mapped target with no mounted provider is disconnected with effective health
  zero. An unmapped target retains intrinsic health.
- Damage changes exactly one authority class: every mounted provider for a mapped
  connected target, otherwise intrinsic health. Removed inventory lots are not
  ship-side damage targets.
- Paid and forced repair of a mapped connected target set intrinsic health and
  the first provider in stable instance-ID order to `1.0` in one synchronous
  commit. A mapped disconnected target returns `disconnected_component` and
  creates or spends nothing.
- Installed condition does not discount the retained P05 quality-adjusted power
  draw. Tier bonus requires condition at least the configured
  `min_operational_ratio` (`0.5` currently). Plating resistance is
  `clamp(2 * sum(0.05 * mounted_plating_condition), 0, 0.5)`.
- Install, dismount, rollback, and restore never write intrinsic health or module
  integrity and never replay an incremental effect.

R07 does not authorize catalog/BOM/balance changes, new capacity values, a second
condition store, reuse of R10-A's outer version for changed R07 semantics,
structural patch/rebuild policy, new selected-repair product policy, component
fabrication, singleton owner fallbacks, or changes to reviewed R10-A
docking/player-pose behavior. R08 owns the broader selected paid-repair UX and
G2; R07 supplies the connected-target authority it must call.

## Exact implementation scope

The following is the proposed runtime and focused-test boundary after release.
Line numbers are those in the 2026-09-06 source inventory and are locators, not a
claim that the pending R06/R10-A sources are frozen.

| File | Exact R07 responsibility | Behavior preserved |
| --- | --- | --- |
| `scripts/systems/component_placement_state.gd` | Add a stable mapped-target universe separate from current mounted providers; seed/validate it from authored/catalog associations, retain old targets across explicit reassignment, and persist it in stable order; preserve an existing slot's soft link when a replacement definition has no explicit link; add validated batch condition mutation that updates entry and `source_lot` together; expose a combined target revision/fingerprint without scene access. | Detached lot allocation/commit, strict summary validation, exact lot dismount/remount, physical slot and fit authority. |
| `scripts/systems/component_mount_resolver.gd` | Carry the exact source lot and condition through existing resolver results; do not apply system effects. | Resolver remains placement-only; inventory and scene consequences remain caller-owned. |
| `scripts/systems/ship_subcomponent.gd` | Label current APIs as intrinsic and split repair eligibility/timing from mutation so the manager can preflight both owners before an atomic commit. | Existing BOM, tools, skill threshold, duration formula, intrinsic summary shape, and isolated intrinsic-model behavior. |
| `scripts/systems/ship_system.gd` | Keep `health()` and `is_self_functional()` intrinsic-only; update comments/tests so production use through the manager is enforceable. | Persistence/configuration and isolated model tests. |
| `scripts/systems/ship_systems_manager.gd` | Bind non-owningly to one placement owner; provide effective subcomponent/system health and functionality; route dependency resolution, status and `advance()` through effective state; own mapped damage, repair, force repair, combined revision, and the explicit lifeboat intrinsic initializer. | System definitions/order, intrinsic summaries, deterministic authored initial damage, BOMs, dependency graph. |
| `scripts/systems/ship_modification_state.gd` | Derive installed draw and condition-weighted plating from current placement; keep full P05 quality-adjusted draw independent of condition; treat summary projection fields as diagnostics rather than mutation authority. | Physical slot binding, catalog fit, current power supply/baseline and full preflight/commit budget rules. |
| `scripts/systems/crafting_state.gd` | Gate the existing max/affinity station-tier projection on mounted provider condition meeting the supplied/current `min_operational_ratio`. | Existing integer bonus, maximum selection, station affinity and owner-scoped station update rules. |
| `scripts/tools/repair_point.gd` | Use manager repair eligibility, requirements, effective target revision, and commit APIs; reject `disconnected_component` before escrow; create/retain points according to effective functionality. | Timed range/tool pause, exact lot escrow, explicit cancellation, XP/noise/receipt transaction behavior. |
| `scripts/procgen/playable_generated_ship.gd` | Bind each ship's manager to the same owner-authenticated placement used by its `ShipWorkContext`; replace raw power/fire/repair/HUD/objective/travel decisions with manager queries; replace direct lifeboat health writes with the manager initializer; remove `_apply_ship_mod_system_link`, `_apply_ship_mod_plating_repair`, and health-writing restore replay; refresh only derived projections after mount/dismount/restore. | R06 explicit selected-ship, generation, range, access, escrow and exactly-once boundaries; P10 detached restore and P13 per-ship owner isolation; R10-A code outside the approved overlap. |
| `tests/test_p14_health_authority.py` | Add source-policy and regression-inventory tests that reject retired health/integrity effect calls and raw production decision patterns, and require every named P14 case to be assigned a retained or replacement marker. | Existing registry accounting tests remain separate. |
| `scripts/validation/fc_p14_smoke.gd` | Add the integrated ten-cycle, multi-provider, repair, projection, rollback, detached initialization and two-reload scene proof with exactly one `FC P14 PASS` marker. | Uses production mount/work/save paths; fixture setup remains clearly separate from final player acceptance. |
| Named P14/adjacent smokes listed below | Rewrite retired semantic assertions and strengthen retained cases without weakening marker/diagnostic rules. | File names may remain stable; marker text must state the new observable meaning. |

The durable association authority and changed projection semantics require a
paired outer transition after R10-A, not a nested change inside R10-A's pair.
After reviewed R10-A confirms literal availability, governance must add:

- `scripts/systems/save_load_service.gd` for the new current run literal and
  explicit preservation of version-pinned direct-run rejection/closure rules;
- `scripts/systems/run_snapshot.gd` for current strict V3/mapped-authority shape;
- `scripts/systems/world_snapshot.gd` for the paired current world literal and
  exact current home-run pairing;
- `scripts/systems/save_migration_service.gd` for explicit ordered prior-to-new
  run/world steps, target constants, known-version tables and pair table;
- `scripts/systems/save_restore_candidate.gd` for detached mapped-authority and
  exact ship-mod projection validation against the validated placement; and
- the reviewed post-R10-A versions of
  `scripts/validation/save_migration_service_smoke.gd`,
  `save_migration_world_smoke.gd`, `world_snapshot_smoke.gd`,
  `fc_p10_smoke.gd`, and `fc_p10_process_smoke.gd`, limited to paired-version,
  nested downgrade, detached candidate, full-recapture and future-rejection
  assertions; plus the active P10 future fixtures and new valid pair-7 migration
  fixtures without overwriting R10-A evidence/history. Provisionally, R07 allocates
  `gate2-current-run-8`/`world-8` and moves the active future sentinels to
  run 9/world 9; none of these literals is allocated until R10-A review confirms
  that 8/8 and 9/9 remain available.

No `ship_instance.gd`, catalog, requirements, or unrelated R10-A behavior enters
scope merely because it is nearby. The final allowlist must use the reviewed
post-R10-A filenames rather than guessing renamed fixtures now.

## Proposed interfaces and invariants

Names below are the narrow implementation contract proposed for review. They can
be adjusted before release, but implementations must retain the stated ownership
and return semantics.

### Placement owner

- Maintain mapped-target association history separately from `placed`. Persist
  it under additive `mapped_target_authority_version: 1` and
  `mapped_targets_v1`. Each canonical history row contains
  `{system_id, subcomponent_id, source_kind, slot_id, component_id}`.
  `source_kind` is exactly `catalog_explicit` or `authored_soft`; `component_id`
  is required for a catalog row and empty for a soft row. Sort and deduplicate by
  all five fields. The public mapped universe is the unique pair projection of
  those rows. History establishes that a target needs physical machinery; it
  never counts as a provider.
- Build the allowed association set from this ship's three live authorities,
  never from saved target strings. First enumerate exact
  `system_id/subcomponent_id` pairs in this ship's validated `systems.json`
  projection. Then enumerate this ship's authored physical slot IDs and profiles.
  A `catalog_explicit` row is allowed only when the component exists, its catalog
  definition names that exact valid ship target, the slot exists in this authored
  layout, and `validate_component_fit(component_id, slot)` succeeds. An
  `authored_soft` row is allowed only when a detached rerun of the existing
  layout/seed/catalog/system deterministic linker assigns that exact slot to that
  exact valid ship target. A saved pair, component ID, or slot ID that lacks this
  complete authority chain rejects; merely naming a real system target is not
  enough to disable it.
- Current summary validation requires exact field types, canonical ordering,
  uniqueness, every history row in the derived allowed set, and coverage of every
  association on the restored current placement. The version is a JSON integer
  exactly `1`; the history is an array; every row has exactly the five named
  string keys with nonempty system, subcomponent, source kind and slot IDs.
  Catalog rows require a nonempty component ID and soft rows require an empty
  one. Unknown systems/subcomponents, cross-ship targets, removed slots,
  catalog-link mismatches, incompatible components, forged soft assignments,
  extra keys, wrong types, noncanonical order, and duplicate rows reject
  detached. This keeps an old catalog association valid after same-slot
  replacement because its recorded component still exists in the catalog and
  still fits that authored slot, without treating it as mounted.
- Initial populate/link prepares the deterministic authored/catalog rows.
  `mount_by_slot_id` prepares the replacement placement row and, when needed, its
  validated catalog association in one candidate. Commit rechecks one complete
  base fingerprint covering placement rows, condition authority, physical-slot
  policy and mapping history, then atomically swaps the placement and monotonic
  history union. Dismount never removes history. Failed validation, cancelled or
  repeated prepare, and stale commit mutate neither placement nor history and
  change no revision derived from that history and append no entry; there is no
  provisional history mutation or counter allocation.
- `get_mapped_targets() -> Array[Dictionary]` returns unique
  `{system_id, subcomponent_id}` rows in lexical pair order from that stable
  universe.
- `get_mounted_providers(system_id: String, subcomponent_id: String) -> Array[Dictionary]`
  returns deep copies sorted by `component_instance_id` and never exposes mutable
  internal rows.
- `is_target_mapped(system_id: String, subcomponent_id: String) -> bool` observes
  the stable universe. An explicitly relinked slot can therefore leave its old
  target disconnected without fabricating a mounted provider or exposing the old
  target's intrinsic health as effective health.
- `prepare_condition_updates(updates: Dictionary) -> Dictionary` validates the
  base fingerprint, every mounted instance ID, finite `[0,1]` values, strict lot
  identity and mirror consistency without mutation.
- `commit_condition_updates(prepared: Dictionary) -> bool` rechecks the base
  fingerprint and replaces all affected placement rows in one call. Every row's
  `condition` and `source_lot.condition` receive the same value. Stale or malformed
  batches change nothing.
- `target_condition_revision(system_id: String, subcomponent_id: String) -> String`
  includes mapped state, mounted instance IDs, lot IDs and full-precision
  conditions in stable order.

The same-slot replacement rule is applied in `mount_by_slot_id`: an incoming
component's nonempty explicit catalog link wins; otherwise the dismounted row's
soft-link pair and `soft_linked` flag survive. The incoming lot identity,
quality, condition and origin remain the incoming lot's values. When an explicit
replacement points elsewhere, its validated association joins the history in the
same placement commit, the old pair stays mapped/disconnected, and only the
mounted replacement appears in provider aggregation.

### Systems manager

- `bind_component_placement(placement: RefCounted) -> bool` accepts only an owner
  exposing the required query/mutation contract, stores a non-owning reference,
  and never copies or persists derived health.
- `get_effective_subcomponent_health(system_id: String, subcomponent_id: String) -> float`
  implements the ADR formula and returns zero for unknown targets.
- `is_effective_subcomponent_functional(system_id: String, subcomponent_id: String) -> bool`
  compares effective health to the authored intrinsic subcomponent threshold.
- `get_effective_system_health(system_id: String) -> float` returns the weakest
  effective subcomponent, retaining the existing empty-system value of `1.0`.
- `is_operational(system_id: String) -> bool` and its cycle-safe dependency walk
  use effective self-functionality. `get_status_summary()` and `advance()` use the
  same projection.
- `get_repair_precheck(system_id: String, subcomponent_id: String,
  available_parts: Array, available_tools: Array, skill_level: int) -> Dictionary`
  is pure and returns the existing reasons plus `disconnected_component`.
- `repair(...) -> Dictionary` prechecks first, prepares the stable first-provider
  condition update where mapped, commits it, then sets intrinsic health to `1.0`
  before returning. Because both RefCounted owners are mutated synchronously and
  no later fallible action exists, callers cannot observe a half repair.
- `force_repair(system_id: String, subcomponent_id: String) -> bool` follows the
  same mapped/unmapped authority and returns false when mapped/disconnected.
- `damage_subcomponent(...)` and `damage_system(...)` prepare all affected
  provider mutations before committing; connected mapped targets do not change
  intrinsic health, while mapped/disconnected and unmapped targets retain the
  ADR-defined intrinsic path.
- `get_target_revision(system_id: String, subcomponent_id: String) -> String`
  combines intrinsic full-precision health with the placement target revision.
- `initialize_intrinsic_health(system_id: String, health_by_subcomponent: Dictionary) -> bool`
  validates the complete requested ID/value set before writing and is the only
  new coordinator-facing direct intrinsic initializer. Lifeboat setup supplies
  explicit values for every propulsion subcomponent, with `nav_linkage` at
  `DAMAGED_HEALTH` and the others at `1.0`.

`get_system()`, `ShipSystem.health()` and `ShipSubcomponent.is_functional()`
remain available for intrinsic configuration, serialization and isolated model
tests. The new Python guard must reject production decisions in the coordinator
and repair point that call those raw health/functionality methods.

### Ship-modification persistence projection

The current model boundary is permissive, while the complete P10 staging boundary
is stricter:

- `RunSnapshot.to_dict()` and `from_dict()` copy the field, but current v5/v6
  structural validation neither requires nor validates it.
- `SaveRestoreCandidate._materialize()` validates and normalizes component
  placement but does not independently materialize ship-modification state.
- `ShipModificationState.apply_summary()` does not check `schema`, presence or
  field types. It coerces/clamps configuration, temporarily accepts saved
  `hull_plating_bonus`, clears saved `installed`, and relies on the later placement
  bind to recompute both projections. `_apply_run_snapshot()` also ignores that
  bind's boolean result.
- This is not evidence that an ordinary bad derived claim is accepted end to end.
  `_validate_staged_restore()` captures the fully applied disposable sibling,
  rebuilds a detached candidate from that capture, and compares
  `_canonical_restore_world(captured)` with the expected candidate world. The
  canonicalizer does not exclude `ship_modification_summary`. A forged bonus or
  installed row that a successful bind corrects, and a failed bind that changes
  the recaptured summary, therefore fails with `staged_world_authority_mismatch`.
  The source does not demonstrate a corrupted ship-mod summary that survives this
  full comparison. The proven issue is missing early strict model validation and
  an unchecked bind result; P10's full recapture remains the final backstop.
- Current capture writes `installed`, `power_draw`, `power_ok`, and
  `hull_plating_bonus`; restore subsequently invokes the retired effect replay.

Use nested `ship_modification_v3` together with R07's subsequent paired outer
transition. Durable configuration fields remain `ship_id`, finite nonnegative
`power_supply`, finite nonnegative `power_demand_baseline`, and finite
`min_operational_ratio` in `[0,1]`. The `installed` rows, `power_draw`,
`power_ok`, and `hull_plating_bonus` are derived claims. V3 current input must be
present, structurally exact, and canonically equal to a detached recomputation
from the validated placement, component catalog, and unchanged P05
`ItemQualityEffects`. `hull_plating_bonus` becomes the weighted sum
`sum(0.05 * mounted_plating_condition)`; resistance remains its clamped doubled
projection. Any current mismatch rejects the whole candidate without sidecar or
live mutation.

Legacy admission belongs only to `SaveMigrationService`, keyed by the original
outer version pair before mutation. The following provisional matrix becomes
literal only after reviewed R10-A confirms that run 8/world 8 and future
sentinels 9 are free:

| Original source pair | Nested/component input | Result |
| --- | --- | --- |
| R07 current `world-8` + home `gate2-current-run-8` | exact `ship_modification_v3` plus mapped-target authority v1 | Validate strictly and continue to detached exact projection comparison. |
| R07 current `world-8` + home `gate2-current-run-8` | V2, missing/empty/unknown ship-mod schema, or missing/malformed mapped authority | Reject. Changing a sibling discriminator cannot invoke legacy normalization. |
| Recognized R10-A `world-7` + home `gate2-current-run-7` | exact V2 and pre-R07 placement without mapped authority | Only the central literal 7-to-8 run/world step may validate those legacy shapes, retain durable ship/power/ratio configuration, rebuild mapping history from authored authority plus valid saved explicit associations, discard/recompute all derived ship-mod claims, and emit current V3/authority v1. |
| Older recognized pair | exact shape required at every historical boundary | Walk the existing literal chain, including governed 6-to-7 and new 7-to-8 steps; each world/home pair must validate before its step. No skipped or inferred boundary is accepted. |
| Recognized historical standalone run admitted by P10 closure | exact historical run version reaching the same central 7-to-8 step | Apply the same normalization while closing the world; no nested schema grants admission by itself, and existing explicit direct-run rejection rules remain. |
| Mismatched world/home pair, any outer source carrying saved migration flags, or unknown/current-future `world-9`/run 9 | any nested shape | Reject before nested legacy handling. Saved provenance is never trusted. |

The central migration result's pre-mutation `from_version`, the validated
`WORLD_HOME_RUN_PAIRS` entry, and the actual ordered migration step are the trusted
provenance. A boolean `migrated` flag or a persisted `migration_origin` string is
insufficient. The version-pinned 7-to-8 step validates every present V2 type
without coercion, retains only durable configuration, and discards/recomputes
`installed`, `power_draw`, `power_ok`, and old unweighted
`hull_plating_bonus`. Older sources reach it only through every explicit literal
step. The new 8/8 pair requires V3 and mapped authority from its first valid
capture. Future sentinel 9/9 rejects. Exact literals and fixture names are filled
in only after R10-A review confirms availability. Normalized current bytes are
published only after the detached P10 candidate commits.

## Dependency-aware implementation sequence after release

1. Record a release-time additive beforeimage manifest after R06 is accepted and
   the implemented R10-A source passes independent review.
2. Amend only the P14 governance/runner and nested ship-mod persistence scope
   accepted by the coordinator. Run
   Python generator/runner tests; do not start Godot during the governance edit.
3. Add the Python authority test and rewritten pure-manager/placement cases first.
   Establish RED on missing effective queries, atomic condition mutation, mapped
   disconnection, and retired effect strings.
4. Implement placement provider queries, soft-link retention, condition batching,
   and stable target revisions.
5. Implement intrinsic repair precheck and the manager's binding, effective query,
   damage, repair, force-repair, initializer and status/dependency paths.
6. Change ship-modification, crafting-tier and plating projections. Preserve full
   quality-adjusted draw at both admission and commit.
7. Change repair-point queries/revision/commit, then migrate the enumerated
   coordinator consumers in the exclusive shared-file window.
8. Rewrite the legacy semantic smokes and add `fc_p14_smoke.gd`. Extend the
   existing tracked physical-work runner to the accepted eighteen-case P14 set
   and use the hardened
   runner for every engine body, each with a new owned four-variable home and a
   successful separate containment probe.
9. Run the full P14 set, P10/P13 owner/save regressions required by the final
   overlap, Python tests, registry/orphan checks, diff inspection, and independent
   Sol review on one frozen source/evidence manifest.

## Acceptance matrix

| Obligation | Positive proof | Required negative/invariant proof |
| --- | --- | --- |
| Canonical/mirror condition | Damage/repair changes both placement condition and exact source lot condition to the same full-precision value. | Malformed, stale, missing-lot, mismatched-mirror or nonfinite batch changes no row or sequence. |
| Stable mapping authority and aggregation | Two providers use max condition; deterministic first-ID repair restores only that provider; removing one retains connection; explicit relink commits its catalog-valid association with placement and preserves the old association. | Unknown/cross-ship IDs, real-but-unauthorized target pairs, forged soft links, catalog/slot/fit mismatches, duplicate history, failed prepare and stale commit add no mapping history or revision; removing the last provider yields effective zero without a phantom provider. |
| Replacement semantics | A distinct healthy lot restores component-side effectiveness when intrinsic health permits. | Remounting the same damaged lot remains limited; healthy replacement cannot erase seeded/disconnected intrinsic damage. |
| Damage authority | Connected mapped damage lowers every mounted provider once and leaves intrinsic unchanged; unmapped damage remains intrinsic. | Dismounted inventory lot never changes; whole-system damage does not hit both provider and intrinsic authority. |
| Paid/forced repair | Exact existing BOM/tool/skill/duration succeeds and sets intrinsic plus first stable provider to `1.0`; other redundant providers remain unchanged. | Mapped disconnected target returns `disconnected_component` before escrow; unknown/insufficient/already-effective cases preserve both owners and inventory. |
| Effective dependencies/status/tick | Power, dependency cascade, status percentages and `advance()` respond to effective manager state for the correct ship. | Raw intrinsic health cannot keep a disconnected/damaged-provider system operational; another ship's placement cannot influence the selected owner. |
| Quality/full power | Two qualities retain the P05 divisor and full draw regardless of condition; mounted draw appears once and dismount returns to baseline. | Power change between start and commit rejects with unchanged escrow/placement/tier/system/inventory and no receipt/XP/noise. |
| Tier projection | Mounted condition `0.5` grants the full authored integer bonus; max and affinity rules remain. | Condition below `0.5` grants zero; dismounted/foreign/duplicate projection rows grant nothing. |
| Plating projection | Resistance equals the accepted weighted formula, clamps at `0.5`, and reverses exactly on removal. | Install/remove/restore leaves every module integrity byte-equivalent and does not resurrect destroyed structure. |
| Restore | Disk save/load twice preserves intrinsic health, exact provider lot metadata, effective health, draw, tier and plating projection. | Restore performs no health/integrity writes, consumes no sequence, produces no duplicate provider/effect, and rejects malformed current lots through P10 authority. |
| Ship-mod projection contract | R07's new paired current capture carries V3 and mapped authority and exactly matches detached recomputation; R10-A pair-7 V2 migrates only through the central literal 7-to-8 step. | Missing/malformed/unknown current V3 or any current derived mismatch rejects atomically; changing only V3 to V2 or adding saved migration flags under the R07 current pair cannot invoke legacy handling; future sentinel 9 rejects; P10 full recapture remains an exact final backstop. |
| Detached initialization | Repeated prepare on one base yields identical IDs; commit advances sequence by exactly the committed allocation count and binds effective state after both owners exist. | Cancel/stale/reject consumes no sequence and mutates no live owner; current missing lot never falls into legacy initialization. |
| Ten-cycle reversibility | Ten real timed dismount/install cycles return exact item quantity/lot ID/quality/condition/origin, intrinsic health, draw, tier, plating projection and once-only receipt counts. | No install floor, dismount damage, plating patch, effect replay, resource mint, duplicate XP/noise or cross-ship mutation occurs. |
| Lifeboat initializer | Manager initializer sets the intended propulsion intrinsic values before play and the later placement bind derives connection state. | Coordinator contains no direct subcomponent health writes; initializer rejects unknown IDs/nonfinite values without partial mutation. |

## Full P14 regression inventory and marker disposition

`CARD_SMOKES["P14"]` currently contains only four files:
`fc_p14_smoke.gd` (missing), `ship_mod_overbudget_power_smoke.gd`,
`ship_mod_station_tier_away_smoke.gd`, and
`ship_mod_run_snapshot_smoke.gd`.

The complete source-backed impacted set is eighteen cases. It is the union of
the accepted P14 source allowlist, current P14 card commands, the original P14
run list, and the two adjacent cases named by the R07 source inventory. Every
case below must run through hardened isolation after its assertions are reviewed.

| Case | Current relation | R07 disposition |
| --- | --- | --- |
| `fc_p14_smoke.gd` | CARD; planned/missing | Create integrated ADR-0066 proof; keep `FC P14 PASS`. |
| `ship_mod_overbudget_power_smoke.gd` | CARD and original run; absent from P14 source allowlist | Retain, replace synthetic installed-row setup with current placement/full quality draw where needed, and cover commit-time power drift. |
| `ship_mod_station_tier_away_smoke.gd` | CARD/source allowlist | Rewrite to prove condition threshold and away-owner isolation; change marker to include `condition_gate=true`. |
| `ship_mod_run_snapshot_smoke.gd` | CARD/source allowlist | Retain exact-lot/RunSnapshot proof, add intrinsic/effective no-replay predicates; this does not replace two disk reloads in `fc_p14`. |
| `ship_systems_manager_smoke.gd` | Source allowlist beyond CARD | Extend intrinsic/effective aggregation, dependency, status, advance, damage and paid repair cases. |
| `ship_systems_manager_force_repair_smoke.gd` | Source allowlist beyond CARD | Add connected deterministic provider repair, unmapped intrinsic repair and mapped-disconnected denial. |
| `component_mount_dismount_smoke.gd` | Source allowlist beyond CARD | Strengthen exact lot identity/quality/condition/origin and no intrinsic mutation. |
| `dismount_system_damage_smoke.gd` | Source allowlist beyond CARD; retired semantics | Rewrite as last-provider disconnect with unchanged intrinsic and returned lot; replace marker with `DISMOUNT SYSTEM CONNECTION PASS disconnected=true intrinsic_unchanged=true lot_unchanged=true`. |
| `remount_system_restore_smoke.gd` | Source allowlist beyond CARD; retired floor semantics | Rewrite as damaged-lot remount preservation with no floor; replace marker with `REMOUNT CONDITION PRESERVATION PASS damaged_lot=true effective_limited=true no_floor=true`. |
| `ship_mod_system_effect_smoke.gd` | Source allowlist beyond CARD; retired heal/damage semantics | Prove connection, full quality draw, reversible removal and unchanged intrinsic; replace marker fields with `connection=true power=true intrinsic_unchanged=true`. |
| `ship_mod_system_effect_away_smoke.gd` | Source allowlist beyond CARD; retired heal/damage semantics | Same replacement for away owner plus exact home noninterference. |
| `ship_mod_restore_effects_smoke.gd` | Source allowlist and original run beyond CARD; current assertions replay healing | Rewrite as projection recomputation with no effect write; proposed marker `SHIP MOD RESTORE PROJECTION PASS replay_free=true tier=true effective=true`. |
| `ship_mod_restore_effects_away_smoke.gd` | Source allowlist beyond CARD; current assertions replay healing | Same replacement for away owner plus exact home noninterference. |
| `ship_mod_plating_repair_smoke.gd` | Source allowlist beyond CARD; retired install repair | Rewrite as weighted/reversible plating resistance with unchanged module integrity; proposed marker `SHIP MOD PLATING RESILIENCE PASS integrity_unchanged=true weighted=true reversible=true`. |
| `ship_mod_plating_repair_away_smoke.gd` | Source allowlist beyond CARD; retired install repair | Same replacement for away owner plus exact home noninterference. P15 may later extend this file for explicit paid patching without restoring install healing. |
| `ship_mod_station_tier_smoke.gd` | Source allowlist beyond CARD | Rewrite to prove threshold `0.5`, below-threshold zero, full integer bonus and removal reversal. |
| `component_system_link_smoke.gd` | Adjacent inventory case; outside current P14 allowlist | Retain and add stable multi-provider ordering plus soft-link preservation/replacement coverage, or move those assertions into the P14 manager smoke if the coordinator declines the allowlist addition. |
| `ship_mod_overbudget_power_away_smoke.gd` | Adjacent inventory/validation case; outside current P14 allowlist | Retain and migrate synthetic installed-row setup; prove away-owner commit rollback and exact home noninterference. |

The existing marker strings containing `uninstall_damage=true`, `floor=true`,
or plating `repair=true` are invalid after ADR-0066. The restore-effect markers
also need replacement because their current bodies explicitly require health
restoration on bind. Validation-plan commands, marker constants, P14 card source
references, and requirement verification references must move in the same
governance change; a legacy PASS string cannot be retained as an alias.

## Beforeimage and evidence plan

No Task 7 beforeimage directory is created at this checkpoint because the
runtime baseline is moving. Immediately after release, create
`task-7-beforeimages/runtime-release-01/` with an immutable manifest containing:

- current branch, HEAD, tracked/untracked status limited to every proposed R07
  file, and attribution of inherited changes;
- full bytes and SHA-256 for all runtime/model/coordinator files above;
- full bytes and SHA-256 for all existing members of the eighteen-smoke set,
  absent/present state for `fc_p14_smoke.gd` and the new Python test, the runner
  and its tests, P14 card/case generator inputs,
  validation plan, requirement verification row, and current generated manifests;
- the accepted R06 and reviewed R10-A afterimage/review identifiers;
- an additive manifest before any later file is admitted.

The RED and final evidence roots must be new and initially absent. Every Godot
case runs through `tools/run_feature_completion.py`'s
`execute_isolated_case` contract, or a reviewed adapter over that exact contract.
Each case receives a distinct owned user-data directory, all four variables
`APPDATA`, `LOCALAPPDATA`, `GODOT_USER_PATH`, and `XDG_DATA_HOME`, and a separate
successful `scripts/validation/fc_p10_process_smoke.gd --mode=probe` execution
with exactly one `FC P10 USER DATA PROBE PASS` marker. Retain command/environment/
stdout/stderr/Godot log/result JSON, exit zero, exactly one expected body marker, no
timeout/cleanup failure, and no unexpected `ERROR:`, `WARNING:`, or
`SCRIPT ERROR:`. Never execute a bare Godot command or reuse an evidence/home
directory.

The final source freeze must hash the exact implementation, rewritten markers,
runner constants and all retained raw evidence. P10 and P13 reruns are required
after coordinator/binding/restore changes; the exact R10-A overlap regression is
set by its owner after serialization. Independent Sol review must inspect the
frozen source and evidence rather than a later moving checkout.

## Proposed narrow governance amendments

These are proposals for coordinator review; none is applied here.

1. Update Task 7/P14 local card scope to remove the sibling SDD brief as a runtime
   dependency, add the current `task-7-brief.md` and eventual report/review
   artifacts, and explicitly record accepted R06 plus reviewed R10-A as release
   gates. R07 owns manager-to-placement binding after those gates.
2. Add `ship_mod_overbudget_power_smoke.gd` to the P14 source allowlist, because
   it is already a P14 verification command but is absent from the allowlist.
   Add `component_system_link_smoke.gd` and
   `ship_mod_overbudget_power_away_smoke.gd` because R07 changes their link/power
   authorities and the current inventory names both as affected coverage.
3. Expand the authoritative P14 focused list from four cases to the accepted
   eighteen-case inventory above. Do not let the old four-case CARD subset stand
   in for the plan's required full P14 regression set.
4. Extend the reviewed tracked `tools/run_physical_work_smokes.py` adapter and
   `tests/test_physical_work_runner.py` to admit P14 through
   `execute_isolated_case`. Add those runner files to the P14 allowlist before
   editing them; do not create a duplicate harness.
5. Replace every retired marker and corresponding validation-plan/card/reference
   string atomically. Reset changed semantic evidence to `not_verified`; retain
   stable criterion identity and denominator 622.
6. Add a card note that `ship_mod_run_snapshot_smoke.gd` is a direct model/
   RunSnapshot regression only; the integrated P14 case owns two real disk reloads
   and no-replay proof.
7. Add versioned, provenance-bearing stable mapped-target association history to
   the placement summary. Validate each row against this ship's system pairs,
   authored slot, catalog link/fit or deterministic soft assignment. Placement
   and monotonic history update in one commit; failed/stale prepare changes
   neither. Providers remain mounted-row-only, and arbitrary saved target IDs
   reject.
8. Add nested `ship_modification_v3`, the paired outer R07 transition, and the
   narrow P10 files/fixtures identified above to the R07 allowlist. Provisionally
   allocate run 8/world 8 and move future sentinels to 9/9 after reviewed R10-A
   confirms availability. Pair-7 V2 is recognized only inside the central
   literal 7-to-8 step, then type-checked, discarded and recomputed. Current R07
   nested downgrade or saved migration flags reject.

## Coordinator rulings applied

- R07 owns manager-to-placement binding after accepted R06; R06 does not add it.
- R10-A implements and passes review before R07 receives a runtime window.
- R07 pins power expectations to the current authored P05
  `ItemQualityEffects`; final R05 economy pinning follows R11 and creates no R07
  dependency cycle.
- The existing tracked physical-work runner is extended to P14; no duplicate
  harness is added.
- All eighteen meaningful affected cases form the full P14 membership, and their
  retired markers move atomically with governance.
- The hardened probe is `fc_p10_process_smoke.gd --mode=probe` with
  `FC P10 USER DATA PROBE PASS`, not a separately named containment smoke.
- Typed validated mapped-target history and atomic monotonic placement/history
  updates are accepted in principle, including rejection-with-no-history tests.
- R07 receives a new paired outer transition after R10-A. The provisional
  allocation is run 8/world 8 with future sentinels 9/9; exact literals wait for
  reviewed R10-A availability confirmation.

No question remains about R10-A's governed 6-to-7 seam. The remaining preparation
item is mechanical allocation of the exact R07 current and future-sentinel
literals/files against reviewed R10-A's afterimage. This brief still grants no
runtime or shared-governance edit authority until R06 and R10-A satisfy their
release gates and root explicitly releases R07.
