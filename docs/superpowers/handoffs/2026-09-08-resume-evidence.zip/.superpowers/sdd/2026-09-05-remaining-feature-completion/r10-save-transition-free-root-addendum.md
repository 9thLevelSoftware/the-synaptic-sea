# R10-A free-root spatial-authority addendum

Date: 2026-09-08. Preparation only. This file is additive to the accepted
`r10-save-transition-preflight-addendum.md`; it does not revise that file. Runtime,
schema-version, fixture, constant, and governance edits remain gated on acceptance of
the baseline re-review.

## Exact world-7 row

Add `ship_root_authorities_v1`, an array with exactly one strict tagged-union row for
every ship returned by the coordinator's deduplicated all-known-owner set. The set is
home, lifeboat, current, and every retained visited ship. Rows sort by `ship_id`; all
strings are nonempty except where a variant explicitly says otherwise; keys are exact.

```json
{"ship_id":"ship_start","authority_kind":"world_anchor","location_id":"home","anchor_id":"home-origin-v1"}
{"ship_id":"ship:visited","authority_kind":"world_anchor","location_id":"marker-id","anchor_id":"visited-host-v1"}
{"ship_id":"ship:mobile","authority_kind":"connection","connection_id":"connection-id"}
{"ship_id":"ship:free","authority_kind":"free","frame_ship_id":"ship:anchor","local_transform":[1,0,0,0,1,0,0,0,1,12,0,-4]}
```

The variants and their exact key sets are:

- `world_anchor`: `ship_id`, `authority_kind`, `location_id`, `anchor_id`.
  `ship_start` alone uses `home` / `home-origin-v1`. A retained visited host uses its
  exact nonempty `marker_id` / `visited-host-v1`. Anchor IDs resolve through a
  versioned world-root resolver fixed after the baseline review; the current
  `DERELICT_DOCK_OFFSET` implementation is evidence of present behavior, not that
  resolver's accepted value.
- `connection`: `ship_id`, `authority_kind`, `connection_id`. The ID names exactly
  one strict `dock_connections_v1` airlock or hangar row whose mobile owner is this
  ship. The connection supplies the transform; the root row stores no second pose.
- `free`: `ship_id`, `authority_kind`, `frame_ship_id`, `local_transform`.
  `frame_ship_id` must name an explicit `world_anchor` row. It may not name an
  attached/free ship, so free-frame cycles and moving-frame reinterpretation are
  impossible. The ship's world root is exactly
  `frame_root.global_transform * transform_from_summary(local_transform)`.

Authority kind is state, never inferred from numerical pose. An explicit dock makes
the mobile `connection`; an accepted hangar launch makes it `free`; new/revisited
fixed hosts are explicitly initialized as `world_anchor`. A free root that happens to
equal an anchor or connection pose remains free. Capture may not normalize it into a
different variant.

## Coverage and materialization

`inactive` is materialization status, not a fourth transform authority. Making it a
row variant would discard the connection or free pose needed on revisit. Resolve every
authority chain to one world anchor, then derive materialization from that anchor's
location:

| Runtime case | Sole spatial authority | Materialization rule |
| --- | --- | --- |
| Fixed home root | `world_anchor(home)` | Always materialized. |
| Current visited host root | `world_anchor(current_location)` | Materialized while that location is current. |
| Attached root, including hangar | `connection` | Materialized iff the host chain's anchor is materialized. |
| Detached free root | `free` in an explicit anchor frame | Materialized iff that frame anchor is materialized. |
| Inactive visited root/subtree | Its retained `world_anchor`, `connection`, or `free` row | No live `scene_root`; retain the exact row and subordinate state unchanged. |

The graph rejects unless every known ship has exactly one row, every connection mobile
has exactly one matching `connection` row, no non-connection row is a connection
mobile, every chain is acyclic and reaches one anchor, and each non-home anchor's
`location_id` equals its owner's retained marker. An inactive owner must have no live
root; every materialized owner must have one. `player_owner_pose`, floor drops, carts,
corpse drops, and endpoint state remain owner-local payloads and are not additional
ship-root authority. Known retained threat `world_position` and
`last_known_position` fields remain world-space; migration rebases them when their
owner root moves, as specified by the accepted closed historical combat schema.

The 12 transform elements retain `ShipInstance.transform_to_summary` column order.
They must be numeric (never Boolean/string) and finite in the input. After conversion
to engine numeric representation, reconstruct the `Transform3D` and require every
basis/origin component and the derived world transform to remain finite; an input that
overflows during conversion rejects. The basis must be exactly one supported
right-handed cardinal Y-up basis: yaw 0, 90, 180, or 270 degrees, determinant `+1`.
Scale, shear, reflection, pitch/roll, singular bases, and approximate/cardinalized
inputs reject as `unsupported_free_root_transform`. Restore does not orthonormalize,
round, remove signed zero, clamp, or otherwise rewrite accepted numbers. This is the
full transform class currently produced by registered endpoint alignment and hangar
placement; broadening it requires a later explicit schema variant.

## Exact recapture

The central save transaction owns a per-free-ship ephemeral receipt:
`ship_id`, authority revision, ship root instance/revision and exact world-transform
bits, frame ship/root instance/revision and exact world-transform bits, and the exact
accepted `local_transform` array. Unchanged capture emits that retained array. Any
root/frame/authority revision or exact-bit change computes
`frame_global.affine_inverse() * ship_global` once, validates the supported transform,
and makes that new full-precision array and receipt authoritative.

An inactive free ship has no root to invert: capture emits its retained array exactly.
Staged restore retains the parsed array, installs `frame_global * local_transform`
once when materializing, and installs the matching receipt; the mandatory staged exact
recapture therefore emits the accepted array without a second inverse round trip.
Transition failure discards the candidate and receipts with no live publication.

## Safe live launch transaction

The current handler clears the slot via `bay.launch(idx)` before ship/root validation
and then assigns carrier-local `[0,0,-8]`; it has no placement proof. Replace that
ordering with prepare, prove, then publish:

1. Resolve the exact carrier, occupied slot, mobile owner, strict hangar connection,
   materialized roots, root-authority graph, registered endpoint layouts, and full
   launched subtree without mutation. A nonnegative requested slot remains exact and
   may not fall through to another slot; only request `-1` selects the stable first
   occupied slot.
2. Enumerate unoccupied authenticated exterior endpoint pairs in stable
   `(carrier endpoint_id, mobile endpoint_id)` order. For each pair, use the accepted
   post-review pure registered-endpoint alignment only as a candidate transform; do
   not create an airlock connection or boarding barrier.
3. Test the candidate's complete mobile subtree collision-shape projection against
   the carrier and every other materialized root. Internal pre-existing subtree
   contacts are excluded by owner identity; every new positive-volume cross-owner
   intersection rejects, while exact zero-volume contact follows the baseline rule.
   If the player is aboard the moving subtree, carry the exact owner-local capsule and
   require its candidate world pose to remain valid. Derive the `free` row in the
   ultimate world-anchor frame and validate it before selection.
4. Select the first fully valid candidate. If none exists, return
   `hangar_launch_no_clear_candidate`; do not clear the bay, erase the hangar
   connection, change parent/child fields, move a root/player, revise authority,
   recompute occupancy, or alter a save receipt. A denial signal/SFX may follow the
   unchanged-state result.
5. Under one transition guard, publish the prepared root/subtree transform, replace
   the hangar connection with the prepared free authority, clear the exact slot and
   parent/child relationship, advance revisions, install receipts, verify graph/slot/
   transform postconditions, then recompute occupancy. Capture prior exact values for
   rollback if a postcondition fails before the guard releases.

This uses authored exterior geometry as the initial deterministic launch-placement
source while preserving launch as an actual free root: there is no new connection,
endpoint state, barrier, doorway, overlap exemption, fixed offset, or search-distance
constant. Failure to find a candidate leaves the attempted transition unchanged, but
is not sufficient product completion. The supported authored carrier/hangar path must
prove a normal bay-to-launch transition succeeds. If its endpoint candidates or slot
geometry cannot provide one valid fit, escalate for explicit authored launch/slot
geometry and revise this preparation before implementation acceptance; do not remove
launch functionality or satisfy acceptance with denial-only tests. Staged free-root
placement uses the same all-materialized-root fit predicate and also rejects the
complete candidate before publication.

## Minimal source inventory after the baseline gate

- Existing allowed `scripts/systems/world_snapshot.gd`: strict field/row syntax and
  serialization; no transform inference.
- Existing allowed `scripts/systems/save_restore_candidate.gd`: complete owner/row/
  connection coverage, graph resolution, transform support, inactive retention, and
  pre-publication fit verdicts.
- Existing allowed `scripts/systems/save_load_service.gd`: per-ship exact receipts,
  staged exact recapture, transactional discard/reset.
- Existing allowed `scripts/systems/ship_instance.gd`: retained authority row/revision
  plus the existing transform summary order; no parallel root pose.
- Existing allowed `scripts/systems/docking_manager.gd`: additive pure free-placement
  candidate/all-materialized collision predicate. Its endpoint/compiler dependencies
  bind to the accepted post-review interface, not today's moving call sites.
- Existing allowed `scripts/procgen/playable_generated_ship.gd`: initialize/capture/
  materialize authority rows and replace `_on_bay_launch_requested`'s mutate-first
  flow with the guarded transaction.
- Planned additive allowed `scripts/validation/r10a_owner_pose_restore_smoke.gd`:
  own the strict row/graph, free recapture, inactive revisit, safe-launch, staged-fit,
  and unchanged-on-denial cases. Existing allowed
  `scripts/validation/docking_persistence_smoke.gd` is requalified unchanged unless
  the new contract exposes a real expectation change. Requalify affected P10/R06
  owner/travel/hangar smokes through the hardened runner.

The validation file above is one of the four additive R10-A save-smoke paths already
proposed by the preflight; this addendum proposes no fifth validation path. No additive
runtime helper is necessary: the pure graph parser belongs in the existing candidate
owner and the live fit math belongs in the existing docking owner. No edit
is proposed to endpoint authoring/compiler, `HangarBay`, fixed geometry, registries,
fingerprints, history, fixtures, constants, or governance for this bounded addition.

Required focused proofs are: strict union/key/coverage rejection; duplicate or cyclic
authority denial; all four cardinal free transforms plus input-nonfinite,
engine-overflow, singular, scale, shear, and reflection denial; materialized and
inactive exact recapture; inactive free-root revisit; the supported authored normal
bay-to-launch-to-save-to-reload-to-revisit flow succeeds with the exact requested slot
and no connection/barrier fabricated; an occupied first candidate is followed by the
deterministic safe candidate; no candidate leaves all exact state unchanged; and staged
overlap rejects before publication. Denial cases cannot substitute for the positive
authored launch flow. The post-baseline manifest must pin the final endpoint/docking
source bytes before implementation.
