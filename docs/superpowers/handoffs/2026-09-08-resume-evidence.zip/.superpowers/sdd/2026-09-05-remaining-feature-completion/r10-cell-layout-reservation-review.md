# R10 Cell Layout Docking-Reservation Review

## Disposition

**Needs Fixes**

The frozen `CellLayoutEngine` implementation is structurally sound for the reviewed reservation behavior: it creates a per-deck exclusion dictionary, keeps that dictionary outside room occupancy and serialized output, checks it in rectangular placement, freeform growth, and connector realization, and rejects a late dock conflict by returning an empty layout with a precise failure reason. The production `ShipLayoutGenerator` path passes generated layouts through endpoint authoring against the fixed-lifeboat counterpart and the shared strict positive-volume cross-hull intersection predicate. The supplied focused GREEN and 60-case stress results are clean.

One material acceptance-test gap remains. The governing requirement explicitly preserves room area and requires connector growth to respect the reservation, but the focused smoke does not directly prove either invariant.

## Frozen review boundary

- Checkout: `D:/the-synaptic-sea-feature-completion`
- Branch/HEAD observed: `codex/feature-completion-resume` / `04e2da8c4bc9c164a7cc9fe1224d90862d088577`
- Reviewed implementation: `scripts/procgen/cell_layout_engine.gd`
  - SHA-256: `45a2dc1fc7b8bd781e20ec2ba3ee76148017947cf117dfdc828530832646356f`
- Reviewed focused smoke: `scripts/validation/cell_layout_engine_smoke.gd`
  - SHA-256: `00762ca545fc0320d31c35205d4b02cae6b22808e72d00680196e102e3a35813`
- Governing committed specification: `docs/game/features/crafting_derelict_feature_completion.md`, lines 380-389, introduced by `04e2da8c`.
- Comparison: current two-file working-tree diff against `04e2da8c`, plus production callers and supplied runtime evidence. Unrelated concurrent working-tree changes were excluded.
- I did not run Godot and did not mutate Git or reviewed source.

## Material finding

### MEDIUM — Reservation-specific connector growth and room-area preservation are not behaviorally asserted

**Affected component**

- `scripts/validation/cell_layout_engine_smoke.gd`
- Acceptance behavior implemented in `scripts/procgen/cell_layout_engine.gd`:
  - target-area placement at lines 299-375 and 712-749
  - reservation-aware connector realization at lines 885-944 and 962-1037

**Specific problem**

The focused smoke proves that the final rooms do not occupy a derived 2-by-5 west envelope, verifies room existence and role, checks deterministic output, and proves a late dock conflict returns an empty layout. It does not create a case where `_realize_missing_connectors()` must find a path near the docking envelope, so the newly added `reserved.has(...)` checks in connector BFS and path commit are covered only by source inspection.

The smoke also never compares final room cell cardinality with each room-plan `target_cells`. The 60-case stress accepts any output with at least three rooms and nonempty structural placements. Its exact five-cell `corridor_04` assertion exercises an existing connector-grown shape, but does not establish that this growth encountered or avoided the docking reservation. Consequently, both explicit claims can regress while the recorded focused and stress assertions still pass.

The applicable area invariant should account for legitimate connector-added cells:

- Every planned room must remain present with its assigned role.
- Every final room must own **at least** its planned `target_cells`; connector realization may add unique path cells, so equality is not a universal final-state requirement.
- The stored final `footprint` must equal the bounding box derived from its final cells. Connector additions may enlarge that box.
- Reservation cells must remain absent from every final room even when a declared same-deck connection requires connector realization.

**Why it matters**

The reservation is a new obstacle in both placement and connector search. A future missed call-site argument or path-commit check could grow a corridor through the boarding envelope. A placement constrained by the reservation could also return fewer cells than planned: `_grow_from_seed()` stops when no next cell exists but returns the nonempty partial cell list. The current tests would not distinguish those failures from a valid topology. Either regression can reintroduce paired hull collision or silently reduce authored room capacity while still emitting a successful layout.

**Concrete remediation**

Add a deterministic layout fixture in the existing focused smoke with an early dock/airlock and a declared same-deck connection whose connector realization would use a reserved cell on the old path. Assert that:

1. the declared rooms are connected after realization;
2. none of the ten deck-local reserved cells belongs to any room;
3. the declared connector routes around the envelope in a fixture that guarantees an alternate path within `MAX_GROW_STEPS`;
4. every planned room remains present with the same role and `final_cells.size() >= target_cells`; and
5. each final footprint equals the exact bounding box of its final cells.

Apply the same lower-bound area check to the existing primary fixture. Do not require universal equality with `target_cells`, because connector realization legitimately appends cells.

## Static correctness observations

- The reservation is exactly two outward columns by five tangent rows, anchored at minimum X and then minimum Z on the docking room’s west boundary.
- `_docking_reservations_per_deck` is cleared at the start of every `layout()` call and keyed by deck, preventing cross-call and cross-deck leakage.
- Reservation cells are never inserted into `occupied_per_deck`, `placed`, the returned room map, or adjacency serialization.
- Rectangle candidates, freeform seeds and growth, aligned placement, connector BFS, and connector path commit all reject reserved cells.
- Dock/airlock rooms are not enlarged during connector realization, preserving the reservation anchor after it is calculated.
- A docking-envelope collision with an already occupied cell sets `last_failure_reason`; `layout()` then returns `{}`, which the production layout generator rejects.
- With an empty reservation dictionary, the placement decision logic remains equivalent to the prior implementation. The no-dock smoke also compares a reused engine with a fresh engine and pins its two-room topology.
- The reviewed patch does not modify collision predicates. Current endpoint authoring rejects every positive-volume cross-hull intersection and allows only zero-volume contact.

## Runtime evidence inspected

### Intended RED

`artifacts/feature-completion/R10-A-fix1-cell-layout-reservation-red-02/result.json`

- SHA-256: `b8f00003d99a5a91bfbed934d3aab8c6a68df78abbc07921f4ea9f8dcb152d71`
- Exit 1 with the intended diagnostic: late docking conflict returned a usable partial layout.
- No PASS marker in body output; containment probe passed.

### Focused GREEN

`artifacts/feature-completion/R10-A-fix1-cell-layout-reservation-green-01/result.json`

- SHA-256: `5c0dcdb33ef670a7a176627958d2c4cfe4fb2916415bc0ade5e228b276353dc0`
- Exit 0 in 1.657 seconds, diagnostics empty, stderr empty, containment probe passed.
- Raw stdout contains the reservation marker and the legacy cell-layout marker exactly once each.

### Historical six-case diagnostic

`artifacts/feature-completion/R10-A-fix1-endpoint-failed-cases-diagnostic-02/result.json`

- SHA-256: `f3123bbf92718725fb9af4748137a0fcb4299e6cfaaa0e8661bad2efb82689ba`
- Exit 0 in 6.921 seconds, diagnostics empty.
- Each historical case—bifurcated seeds 2, 7, 8, 9, and 12, plus spine seed 19—now produces a nonempty first-attempt layout.

### 60-case production stress

`artifacts/feature-completion/R10-A-fix1-layout-stress-after-reservation-01/result.json`

- SHA-256: `55677a9f8eb754fa6dd47026c1bd1eaea9975c09000f987bf02dfc93ccf0e2c4`
- Exit 0 in 84.125 seconds, diagnostics empty, stderr empty, containment probe passed.
- Exact marker: `PROCGEN LAYOUT STRESS PASS total=60/60 rooms=[9,12] golden=deterministic`.
- Seed-17 compiler/validator summary also passed with 11 rooms, 53 occupied cells, 13 portals, and zero compiler errors.
- This production path performs endpoint authoring against the actual fixed-lifeboat layout and collision projection, so the result supports paired clearance without weakening the strict intersection predicate.

## Evidence limits

The 60 cases cover seeds 1-20 for `spine`, `bifurcated`, and `stacked`. Extended templates and seeds outside that matrix are not exhaustive. Static inspection supports the implementation beyond the sampled set, but the missing reservation-specific connector-growth and area assertions prevent closing the full scoped acceptance claim.


