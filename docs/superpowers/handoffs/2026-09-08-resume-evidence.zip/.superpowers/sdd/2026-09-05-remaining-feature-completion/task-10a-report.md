# Task 10A / R10-A governance and baseline qualification report

Date: 2026-09-07 (America/New_York)  
Workspace: `D:\the-synaptic-sea-feature-completion`  
Qualification branch / HEAD: `codex/feature-completion-resume` / `0b90acbad281c22390a5de6f75ea41a89858d539`  
Status: docking/ceiling baseline freshly qualified and frozen for independent component review; run7/world7 persistence is not started and full P17 remains open

## Outcome

R10 is split into a baseline prerequisite and the existing candidate-result
safety integration. R10-A now precedes the R04 natural-route runtime and R09
live-scene acceptance. R10-B retains full rebuild egress/support work and remains
required for `FC P17 PASS`.

The source-backed P17 card, feature spec, original/remaining plans and accepted
ADR amendments agree on these contracts:

- All production home, native, fallback and fixed-lifeboat layouts precompile
  exact `boarding_endpoints_v1` rows from real occupancy and explicit one-sided
  exterior portals. Its plane is the canonical doorway frame's projected outer
  collision face. A non-join shape is subject to the inward support predicate
  when its tangent/up projection intersects the finite aperture, and all shapes
  remain subject to strict cross-ship pair checks. Only separately
  authenticated bounded join-box portions may cross that plane. The fixed lifeboat's
  west airlock/engine seam is forbidden; no diagnostic coordinate is frozen.
- Dock pose comes only from opposing authenticated descriptors. Actual wrapper
  evidence rules out a universal zero-overlap constraint: the open frame uses
  0.2 m-deep boxes and the floor reaches the cell edge. Only authenticated open-
  frame/directly-incident-floor join boxes may intersect, and their exact
  intersection must be contained in a finite envelope derived by clipping those
  contract-selected wrapper boxes to both outward half-spaces. Walls, ceilings,
  opaque portals, interiors, unrelated floors and dynamics never qualify; no
  epsilon/global margin is allowed. The mobile endpoint owns the threshold and
  instantiates one separate physical barrier. Full-capsule clearance is an
  independent condition. Rejection occurs before root/connection state changes.
- The projection stores binary32-normalized readable basis/origin/dimension
  components beside their exact bit strings and rejects either representation
  when the pair disagrees. Author-time selection and live preflight call the
  same pure projected pair predicate. Baseline pairing authority covers the
  canonical lifeboat against production home, fallback and native hosts;
  arbitrary claimed-ship pairing remains R14.
- The docking transaction moves all established owner state coherently. Existing
  ship-local carts, floor drops, corpse drops and station positions inherit the
  root. Active/stored combat world and last-known positions receive the same
  old-root to new-root delta. Unknown world-space ownership rejects.
- `ceiling_cap_1x1` keeps its floor-origin wrapper and visual. Canonical physical
  bounds become `[-2,3.8,-2]..[2,4.0,2]`, yielding a 4x0.2x4 proxy centered at
  `(0,3.9,0)`. Transform-aware visual bounds remain separate and retain the
  decorative underside near Y 3.6875.
- The allocated `gate2-current-run-7`/`world-7` pair combines registered connection
  identity, endpoint-keyed barrier state, owner-local player pose and ADR-0042
  ephemeral hallucination removal. Runtime constants remain unchanged.
  Historical run-6/world-6 stays admitted and v5-to-v6 targets literal run-6.
  Legacy migration needs an explicit aboard owner and version-pinned old geometry;
  every ambiguity rejects recoverably.
- The accepted full-precision owner-local pose remains authoritative. An exact
  central restore receipt preserves unchanged recapture without epsilon, numeric
  rounding or a second inverse transform. Restore creates roots, connections and
  barriers before projecting the body and proving its real capsule clear.
- ADR-0017's canonical opening remains aboard the lifeboat. The fixed layout owns
  one strict lifeboat-local initial spawn, distinct from the threshold and
  permitted to reuse its capsule-clear interior clearance anchor. New Game
  applies it once after corrected pair/barrier construction and
  publishes only when the capsule is clear, occupancy identifies the lifeboat,
  and the closed barrier excludes home. It is never a load/migration fallback.
- Home and away traversal use ordinary production `PlayerController` input and
  remain grounded in both directions. Overlapping room AABBs resolve only after
  the current connection, barrier and both endpoint IDs authenticate the
  registered plane. Exact tie is mobile, and closing behind either cleared side
  does not rewrite ownership.
- Run 7 removes `RunSnapshot.player_position` without adding another run-pose
  field. World 7's `player_owner_pose_v1` is the sole current player-pose
  authority. At-home world-6 migration requires exact embedded/top-level
  position equality and uses explicit `aboard_ship_id`; away migration validates
  and discards the finite obsolete home-departure value without inferring
  `ship_start` or rejecting solely for its missing owner.

## Run-6/world-6 player-position source trace

`RunSnapshot.player_position` is an ownerless raw global coordinate. The producer
copies `player.global_position` in
`scripts/procgen/playable_generated_ship.gd:12858-12876`; the model reads the
three numeric values without an owner in `scripts/systems/run_snapshot.gd:288-291`;
and the run applier writes them directly back to `player.global_position` in
`scripts/procgen/playable_generated_ship.gd:13591-13598`.

Production user saves are coherent world envelopes. The live menu receives
`_build_world_snapshot` at `playable_generated_ship.gd:9155-9159`; objective
autosave, rotating autosave, quicksave and manual save build a WorldSnapshot at
`:13048-13064`, `:13077-13099`, `:13172-13197`, and `:13207-13231`.
`SaveLoadService.save_to_slot` normalizes every accepted write to a world
envelope at `scripts/systems/save_load_service.gd:783-826,830-906`. The
`save_current_run` entry point at `:130-136` is a legacy alias; when handed a
RunSnapshot it wraps it into a closed world, copies the run coordinate to the
top-level position and sets `aboard_ship_id="ship_start"` at `:464-489`. A raw
standalone current run-6 payload is already rejected as `unclosed_owner_graph`
at `:193-207`; only recognized older run schemas reach the historical adapter.
Because that branch currently compares against `CURRENT_SLICE_VERSION`, the
run7 change must add an explicit run-6 literal rejection before older-run
adaptation; advancing the constant alone would accidentally admit run6.

World capture has two embedded-home cases. At home, the embedded run retains the
same live global coordinate later copied to top-level world position, and the
world stores explicit `aboard_ship_id` at
`playable_generated_ship.gd:13684-13735`. Away from home, the builder overwrites
the embedded run coordinate with `_home_player_position` at `:13703-13707`.
That value was captured at departure at `:8819-8823`, after travel recomputed
occupancy and required `current_occupancy == piloted_ship` at `:8729-8747`.
Consequently the field role cannot prove occupied owner `ship_start`; a normal
lifeboat departure proves the player occupied the piloted lifeboat.

The away-world loader copies that embedded coordinate back into
`_home_player_position` before applying the home run at `:13983-13994`.
Phase-5b `travel_home` instead preserves the current mobile-local carry and never
reads `_home_player_position` (`:8875-8965`). The regression itself records that
the old exact home-position behavior was superseded in
`scripts/validation/world_save_anywhere_smoke.gd:140-146`. Repository search
finds no other runtime reader. The away embedded value is therefore validated
legacy residue, not a second current pose or a reason to reject an otherwise
provable world migration.

The migration admission matrix is therefore:

| Source | R10-A result |
|---|---|
| Raw `gate2-current-run-6` | Reject `unclosed_owner_graph` by an explicit literal branch before older-run adaptation, even after the current constant becomes run7. |
| Recognized pre-v6 direct run | Retain only the existing strict closed-world adapter preconditions. |
| `world-6`, `current_location == ""` | Require finite exact embedded/top-level position equality and explicit `aboard_ship_id`; migrate one pose, discard the embedded duplicate. |
| `world-6`, `current_location != ""` | Require a finite embedded legacy coordinate, discard it as obsolete, and migrate only the top-level pose through explicit `aboard_ship_id`. |

## Governance and provenance

The initial beforeimage manifest contains 66 paths, including absent planned
files. After R06 reported canonical P10-P13, 12 focused Godot and 36 Python checks
green but before independent review, a second 56-path runtime/test manifest
captured the then-current WIP. Both are historical provenance. R06 review has
three HIGH fixes underway, so runtime implementation requires a new additive
post-fix manifest after root accepts the R06 re-review handoff.

The requirements source was deliberately unchanged at SHA-256
`ddcfa8934eae874901edc4313072b5d875b763c0ddb9d7521e1faa79212b462c`.
Frozen acceptance remains 668 recorded, 657 active, 11 deferred and 622 distinct
active criteria. R10-A adds rationale and acceptance detail under existing
FC-18/FC-19; it creates no requirement row and changes no completion evidence.

Governance files changed or created:

- `task-10a-brief.md`, `task-10a-report.md`, and both task beforeimage manifests;
- the remaining-feature plan and original P17/P19 plan;
- ADR-0017's accepted opening amendment, ADR-0059's accepted decisions 44-49,
  and ADR-0065's accepted section-4 amendment;
- the crafting/derelict feature spec;
- `tools/build_feature_acceptance.py` and its generated card/register JSON.

No GDScript, scene, catalog, canonical asset, save fixture, runtime version,
Godot project/import state or global configuration was edited by this task.

## Verification

- Python source compile: pass for `tools/build_feature_acceptance.py`.
- Source generator write/check: `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0`.
- Frozen accounting: 668 / 657 / 11 / 622.
- Requirements hash: unchanged against the initial beforeimage.
- Focused governance diff check: no whitespace errors.
- P11-P13 source constants, smoke lists, marker lookup and verification branches
  were not edited; R06's reported-green pre-review generated deltas remain
  present while its review fixes proceed.

Godot and gameplay Python tests were intentionally not run because this
checkpoint contains governance and beforeimages only. The generated P17 card now
contains the future tracked command
`tools/run_r10a_docking_smokes.py` with marker
`R10-A DOCKING PREREQUISITE PASS`; that runner is planned missing and cannot be
used until implementation.

## Version allocation and runtime entry conditions

1. Governance allocates `gate2-current-run-7` and `world-7` as one production
   pair. R06/P10 still uses those literals as strict future-rejection sentinels
   in generated governance, `combat_persistence_smoke.gd`, and two fixtures.
   During implementation, retain those old artifacts as historical evidence,
   move the active sentinel/fixtures to `gate2-current-run-8`/`world-8`, then
   make run7/world7 current. No runtime constant or fixture changed here.
2. Wait for R06's independent review and any accepted shared-owner fixes, then
   capture a new additive post-fix accepted-handoff manifest before editing any
   shared path; preserve both historical manifests and all inherited WIP.
3. Implement R10-A through the tracked hardened runner, Godot 4.7.2, fresh
   four-variable process homes and a separate accepted P10 containment probe.
   R04's unchanged natural route runs last and remains the authority for R04.

The main implementation risks are exact legacy geometry reconstruction for
world-6, full-shape hull preflight across nested/rotated roots, transactional
rebasing of world-space combat state, and ensuring the ceiling pipeline keeps
physical and visual bounds separate. Each risk has a required rejection case in
the brief's validation matrix.

## Runtime recovery checkpoint 1

The interrupted runtime work was recovered at HEAD `3a6675d7` without reset.
`task-10a-beforeimages/runtime-recovery-02/manifest.json` (SHA-256
`28b560f10189dbc4c5df5cb9e3d90e3fc3b0c29132993752f1aa2946a6cbd64d`)
captures all 101 accepted-handoff entries and the 17 partial runtime/test deltas.
The reviewed R10-A runner remains byte-identical at SHA-256
`3c768a07c8505715662dffe382a8fd6813e3f4ef672c3102a065cd71a978a5ac`.

A fresh complete hardened aggregate at
`task-10a-work-evidence/recovery-aggregate-01` ran all 15 cases with separate
contained homes: 8 passed and 7 failed. Endpoint schema and ceiling clearance
passed. The first causal failure is five positive-volume non-join overlaps from
the selected fixed-lifeboat connector; boot, occupancy, physical travel and
docking persistence then fail downstream. The old dock-port smoke also asserts
the superseded west-facing lifeboat port. Summary SHA-256 is
`4872aefc7df2edad8cd1c11dbd0c6a0debf24df4ad4eb9a0c4c7a777c2c84031`.

The coordinator accepted an additive `dock_collision_projection_v1` in the
existing kit. It is generated from contract-selected canonical wrapper trees and
records stable shape paths, exact composed transforms/dimensions and build-time
wrapper source hashes. The pure authorizer consumes that validated projection;
the live loader independently rejects missing, unexpected or stale materialized
collision content without requiring exported source `.tscn` bytes. Hardcoded
doorway depth and GLB input-sidecar proxy bounds are forbidden. The narrow new
generator/test paths are authorized and must receive absent-file beforeimages
before creation. Save run7/world7, live traversal/spawn, migration, final
qualification, R04-last dependency proof and independent review remain pending.

## Runtime recovery checkpoint 3

The projection is now published in `data/kits/ship_structural_v0.json` for all
15 selected modules and 21 enabled boxes. Its numeric authority pairs readable
binary32-normalized values with exact component bit strings; the canonical
`dock-collision-content-v1` byte format hashes stable paths and those bits. The
Python generator rounds parsed and composed operations to binary32, transposes
Godot text-resource matrix rows into `Basis` columns, rejects out-of-range finite
values with a controlled `ProjectionError`, and passes 9/9 focused tests.

`DockingManager` now validates exact catalog coverage and instantiates every
selected wrapper through `ResourceLoader`. It compares the complete live enabled
box inventory, stable paths, composed transform bits, dimensions and normalized
content SHA before projected geometry enters preflight. This never reads source
scene bytes at runtime. A nested fractional parent/child fixture written inside
the isolated `user://` root reproduced generator fingerprint
`3c12acd22cb6a29b4a2897ee67eafbb5946658b2884f8bf8b5cd2d30b18d6abf`.
The earlier canonical rotated corner mismatch exposed and fixed the row/column
conversion rather than weakening comparison.

The authorizer no longer embeds doorway/floor boxes. It consumes the validated
projection, derives the endpoint from the doorway's outer collision face, and
applies the inward support predicate only to non-join boxes intersecting the
finite aperture projection. Preflight retains strict all-pairs positive-volume
rejection and uses exact quarter-turn placement bases. Hardened evidence
`task-10a-work-evidence/character-traversal-dev-01` proves the selected home and
fixed-lifeboat pair has zero non-join overlaps, exact live projection agreement,
closed-barrier denial, bidirectional direct capsule casts, and ordinary grounded
`CharacterBody3D` traversal in both directions across the 0.2 m floor seam with
the barrier open. The complete case result and separate containment probe are
clean. Full runtime aggregate, live owner occupancy/spawn and paired save schema
remain pending.

## Runtime recovery checkpoint 2

The accepted derivative-schema correction is implemented in
`tools/build_dock_collision_projection.py` with focused coverage in
`tests/test_dock_collision_projection.py`. The data-only parser accepts the
strict wrapper forms used by the selected catalog, composes parent and shape
transforms, records exact enabled box paths/bases/origins/dimensions, preserves
finite non-cardinal bases for non-join geometry, and rejects unsupported shapes,
ambiguous paths/properties, singular transforms and stale source provenance.
The real catalog test proves all 15 current selected wrappers and their current
identity/cardinal composed bases, including the corrected ceiling box.

Governance now limits the supporting inward-plane predicate to non-join shapes
whose tangent/up projection intersects the finite aperture, while preserving the
strict all-pairs collision rule. It defines the mating plane as the projected
doorway frame's exact outer collision face. Source-byte hashes are build
provenance checked by the generator; exported runtime validation must reproduce
the normalized collision-content fingerprint from the loaded wrapper tree and
has no missing-source bypass. Focused projection tests pass 8/8 and the generated
feature-acceptance registry still reports 668 criteria with zero unassessed
sources. Projection publication into the kit and runtime consumption remain the
next milestone.

## Runtime implementation stopping checkpoint 4

Work stopped on the coordinator's request at a quiescent, parseable baseline;
no Godot or Python process remains. No run7/world7 persistence source, migration
fixture, future-version sentinel or runtime constant was changed in this resumed
cycle. The current checkpoint is development evidence, not accepted R10-A
completion.

The collision projection pipeline now publishes 15 canonical wrapper modules
and 21 enabled `BoxShape3D` rows. The generator and runtime agree through exact
binary32 component bits, while readable numeric fields are mutually validated.
Build-time source hashes remain provenance; exported runtime validation reloads
the materialized wrapper tree and rejects missing, extra, stale or malformed
collision content. The focused Python suite last passed 9/9. The current
authorizer consumes this projection, derives the exterior plane from the full
doorway-frame collision face, and uses the same strict projected cross-hull
predicate as live preflight.

Deterministic fixed-lifeboat counterpart selection evaluates complete compatible
pairs. For seed 42 it rejects host endpoint `0|h|7|8` because the lifeboat
`wall_outer_corner` WingEast box has two positive-volume non-join intersections,
then selects host endpoint `0|v|3|3`. The diagnostic is retained in
`pair-selection-diagnostic-03`; the exact regression passes in
`pair-selection-contract-dev-02` (result SHA-256
`b6d57fc2aa817fc0c04974454ee4746b17bb318350df31fefab5115b578529ac`).
The retired room-center/west-port test was replaced by the authenticated
north-facing lifeboat endpoint contract and passes in
`dock-ports-retired-contract-dev-01` (result SHA-256
`d3cf9e8a7225609d8df050b02bf8cc84ccf6f96531a9269330fd46588c97b42e`).

Fresh boot now fails before `playable_ready` when dock construction, barrier
registration or initial spawn validation fails. The independently identified
lifeboat-local initial spawn is the capsule-clear interior anchor
`(4, 0.55, -1.1)`, remains distinct from the threshold, and is applied only once
after dock/barrier construction. Missing, malformed, foreign-owner and blocked
spawn cases are covered by `spawn-clearance-contract-dev-01` (result SHA-256
`5f7a6451310efc148051d49e47c8c851e99390a41d24255f16714075a2ad5bb5`).
ADR-0065 and the P17 card still say the spawn must also be distinct from both
clearance anchors; resume work must amend that obsolete self-imposed constraint
and state that later separation costs an authored spawn change plus opening
requalification.

Production traversal uses the real `PlayerController` input path,
`move_and_slide`, production capsule and grounding settings. At home and away,
the closed barrier denies passage; the opened barrier permits grounded travel in
both directions. Occupancy authenticates the live connection, barrier and both
endpoint IDs, classifies the exact plane tie to the mobile owner, and remains
geometrically stable when the barrier closes behind a player on either side.
The latest focused home result is `production-traversal-dev-04` (SHA-256
`195f7b272213014b3f60dc4a7c77bf47a01a80fdad16c1af0eb460f48fb25aaa`), and the
away/return result is `away-production-traversal-dev-01` (SHA-256
`d18aeee0b5578b1fbab6300ca13a59f6deb68420fc479a3a10311754f1a7cd19`).

`baseline-aggregate-dev-01` completed all 15 hardened cases with marker
`R10-A DOCKING PREREQUISITE PASS cases=15`; its summary SHA-256 is
`bd5d422e116d4f128242a2f2efe7ed23831a5b9e001e210529bdfd2079a018be`.
It predates the final focused occupancy/marker refinements, so it is retained as
development evidence and must not be presented as final qualification. Those
later focused cases passed cleanly with their own containment probes. A fresh
full aggregate is still required after governance is reconciled.

The exact checkpoint source list and byte hashes are in
`task-10a-work-evidence/runtime-checkpoint-handoff-01/source_manifest.json`
(SHA-256 `7f9be8d323474cd532884a538edbea61198f2f586ed076a7a2d80fbe1b029f43`).
Resume by reconciling ADR-0065, the R10-A brief, P17 generator/card projection
fields, pair-selection baseline scope, spawn rule and authenticated occupancy
tie rule. Regenerate/check the registry, run the 9 projection tests, then run a
new hardened 15-case aggregate without editing while it executes. Only after
that baseline review should the paired run7/world7 migration begin. Remaining
R10-A work includes strict connection/barrier/owner-local receipt persistence,
literal v5-to-v6-to-v7 migration, standalone current run-6
`unclosed_owner_graph` rejection, pinned old geometry, coordinated future-8
sentinels, transactional rejection, affected P10/R06 requalification and an
independent final review.

## Resume baseline closure — 2026-09-07

The merged checkpoint reproduced all 22 runtime source hashes from
`runtime-checkpoint-handoff-01`. Governance now records the final projection
fields, shared pair predicate, canonical-lifeboat/R14 boundary, initial-spawn
anchor reuse, authenticated connection-plane tie, close-behind ownership, and
real grounded home/away controller traversal. Two runtime files changed only in
comments: `DockingManager` now describes the projection-derived finite seam, and
the canonical-opening smoke removes the stale duplicated opening wording. The
accepted behavior and exact pass marker did not change.

The final runtime source freeze is
`task-10a-work-evidence/baseline-qualification-01-source-freeze/source_manifest.json`
(22 files, SHA-256
`9c1c9c85acd0c9b51637579d871af8d20dd6a1343135a17f9564d43147be8d47`).
All hashes remained exact after qualification. It records the accepted R06
handoff manifest and the prior WIP checkpoint as provenance. Run7/world7 source,
fixtures, constants and sentinels remain untouched.

The one fresh hardened aggregate is
`task-10a-work-evidence/baseline-qualification-01`. It passed all 15 mandatory
cases with exit 0 and exactly one
`R10-A DOCKING PREREQUISITE PASS cases=15` marker. Its summary SHA-256 is
`629be83b36f19da4ba92a9ed56edb8308b8bb232fc1a5e669663ee1de32b9334`;
the retained artifact-hash manifest SHA-256 is
`3e066260333b5d6146b1a4cc86045e8c39e815f976b9e936cf2dc32635410b6e`.
All 15 case results have exit 0, one exact case marker, no diagnostics and no
cleanup failure. Their 15 separate no-save containment probes each have exit 0,
one exact marker, no timeout or diagnostics, prove actual `user://` equals the
OS user directory, and keep it beneath the corresponding fresh four-variable
owned root. A raw-log scan found no `ERROR:`, `WARNING:` or `SCRIPT ERROR:`.

Fresh focused checks after the aggregate passed 19 tests across collision
projection and the reviewed R10-A runner. The projection check reports exactly
15 modules and 21 boxes. The P17 generator/card R10 fields match through a
targeted projection check. The whole acceptance-registry check was separately
red on merged incoming planning/UI source drift before these edits; that bounded
P23 classification repair is coordinator-owned and is excluded from the R10
runtime hash surface and review package.

The independent review package is
`task-10a-review-packages/baseline-geometry-component-01`. Its full accepted-R06
handoff-to-qualified component diff includes every one of the 22 source paths;
the diff SHA-256 is
`7cfaf55d2393a8a0535704103b291320d149568655b370483828bf81d693b474`.
Exact afterimages and the complete fresh evidence are bundled beside it. The
large `playable_generated_ship.gd` diff intentionally exposes inherited
non-R10 monolith changes for reviewer visibility, but those accepted R03/R06 and
other feature hunks remain outside this component review. Independent review is
still required before any run7/world7 migration starts; this baseline result does
not emit `FC P17 PASS` or close R10-A persistence.

## Baseline independent-review fix round 1 — 2026-09-08

The four HIGH findings in `r10-baseline-component-review.md` are implemented.
Exterior portals are authored before the authoritative compile; only that final
compile can publish structural validation and endpoint/navigation authority, and
lifeboat failure returns no usable layout. Endpoint validation binds the portal,
room, edge, placement, incident floor, navigation, clearance and spawn identities
to the compiled plan. Fresh boot keeps the player unplaced and occupancy
unpublished until the pair, barrier and spawn pass, then performs one observable
placement/publication transaction. Every positive cross-hull intersection now
rejects, including joins; zero-volume contact remains legal and the old seam
waiver/helper are gone.

The review exposed a pre-existing corner/T wrapper anchor mismatch. Under the
approved replacement contract, vertex-owned two-metre rays cover exact half-edge
spans and residual straights fill the other half. The three visual GLBs, wrapper
colliders, JSON/TRES contracts, kit projection, compiler, validator, loader,
mutator and physical-integrity identity consumers now agree. The recovered source
authority and direct GLB-axis review are frozen by asset manifest
`b40db66c1ca9a7929c95648a885eb38c4df76e0dc86134d6a8a4afd5be0151eb`.

Six retained stress cases had no valid endpoint because occupancy surrounded the
airlock. `CellLayoutEngine` now reserves a real deck-local 2x5 west docking
envelope during placement and connector growth, rejects late conflicts atomically,
and preserves roles, minimum authored room areas, graph, vertical links and
determinism. Its focused review is approved at
`ec64d1a62d5741bda8e759796bb06b9a03d00e1ff9f7d2a3581bf3b3da9db923`;
all 60 retained seed/template cases pass.

The additive seed-17 fixture contains 57 physical placements and 80 exact half
spans. Its edge-map SHA-256 is
`8802e6dfea01370af2f233c800a99f61ab13efae7ce847a75c3263f959863361`;
provenance is
`311380f0f09401b2398b0a66dcd7a6418249aa60b844118cd3032de5f1b10129`.
Fresh structural compiler qualification passes 291 placements/55 portals.
Loader/playable and current-topology parity pass at 8 objectives, 245 collision
shapes, 85 edge wrappers, 52 floor wrappers and 57/57/9 parity. The physical
integrity component is independently approved at report hash
`dd0267259c6d24ce6c2e787568d23e6ffd3564f1f2ab5f32c488e3a399fdbbca`.

The final fresh aggregate is
`artifacts/feature-completion/R10-A-fix1-final-qualification-02`. All 15 bodies
and 15 separate containment probes pass with exit 0, exact markers, empty
diagnostics, no cleanup failure and isolated four-variable homes. Its summary
SHA-256 is
`9edb409f0cd7ef4195bb4878820820c75c77bd136aa18c5eee2e5e9a2091c8f3`.
The before/after 56-file source manifests are identical; the before manifest
SHA-256 is
`5771a376f85aa3aef5ff4b3ee1b5c1e1413e797b6d698f95eb84b2cbb550bd47`.
Run7/world7 remains unstarted. The replacement component requires independent
review before migration work resumes.
