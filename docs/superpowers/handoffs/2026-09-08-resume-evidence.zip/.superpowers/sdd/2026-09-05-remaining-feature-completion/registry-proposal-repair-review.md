### Spec Compliance

- ❌ Issues found: the required ambiguous-status fail-closed behavior is incomplete. `tools/build_feature_acceptance.py:1175-1185` returns the first status declaration it encounters. A proposal containing the approved top-level status followed by a second `Status: Accepted.` declaration (or a `## Status` section) is ambiguous, yet `_reviewed_out_of_scope_proposals()` accepts the first value at `tools/build_feature_acceptance.py:1248-1251`. The test coverage at `tests/test_feature_acceptance_registry.py:456-468` covers changed single declarations, but not conflicting duplicate declarations. Require exactly one recognized status declaration, or otherwise reject the document, and add a focused regression test.

### Strengths

- The named proposal is the only excluded path, and it is visibly emitted with path, disposition, actual status, reason, and the independently extracted count of 21 leaves (`tools/build_feature_acceptance.py:1242-1265`; `docs/game/inventory/feature_acceptance.json:73-81`).
- Build and stored-registry validation invoke the proposal review before source extraction and require exact catalog equality. Source accounting derives the expected set from every feature document except the catalogued path, so unexpected sources and removed existing sources remain detectable (`tools/build_feature_acceptance.py:1480-1482`, `tools/build_feature_acceptance.py:1950-1963`).
- Before/after package comparison shows no criterion identity, fingerprint, deferred state, evidence state, or evidence payload change; it preserves 668 recorded, 657 active, 11 deferred, and denominator 622. The frozen source fingerprint remains `8041e481680152f85fe2d3617491880a5268d89dcb63a59608590711edef48d0`, and the supersession fingerprint remains `ffe325ef281156711db10d85eb896a4781804ec976944aef4a948bdbe12ad0df`.
- P17 is byte-for-byte unchanged in the before/after card manifests. The P23 additions include the root-authorized canonical paths and the proposal-scope decision (`data/validation/feature_completion_cards.json:5175-5202`), and the append-only governance paragraph creates no acceptance heading or leaves (`docs/game/features/crafting_derelict_feature_completion.md:346-350`).
- The retained fresh evidence is clean: `25 passed in 0.90s` for `tests/test_feature_acceptance_registry.py`, and `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0` for `--check`, both exit 0. The immutable diff SHA-256 matches the supplied `6ee6d8160f4666600b0ceacaf563b7eee070ae0a9d13f1389d071f8ff931e15d`.

### Issues

#### Critical (Must Fix)

- None.

#### Important (Should Fix)

- `tools/build_feature_acceptance.py:1175-1185,1248-1251`; `tests/test_feature_acceptance_registry.py:456-468`: reject documents with multiple or conflicting recognized status declarations. Returning only the first declaration permits an ambiguous document whose later declaration promotes it to Accepted, violating the proposal-status fail-closed requirement.

#### Minor (Nice to Have)

- None.

### Assessment

**Spec verdict:** ❌ Not compliant until the duplicate/conflicting-status ambiguity is rejected.

**Task quality:** Needs fixes.

**Reasoning:** The document-specific catalog, source accounting, preserved frozen contract, generated outputs, governance, and retained focused evidence are otherwise well scoped and internally consistent. This is a narrow but load-bearing status-guard gap, so the fresh suite was not re-run during this read-only review; the existing evidence remains sufficient for all reviewed behavior apart from the identified missing case.

### Limitations

- Read-only review of the immutable package only. The scoped diff was read once and the packaged afterimages were consulted only because the diff output cut off inside the validation function. No Godot, runtime, or test suite command was run.
