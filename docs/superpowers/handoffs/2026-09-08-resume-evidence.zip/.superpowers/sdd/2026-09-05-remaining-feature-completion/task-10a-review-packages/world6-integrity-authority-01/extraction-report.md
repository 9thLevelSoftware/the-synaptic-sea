# World 6 historical integrity authority package

- Historical commit: `c51bcacbcb5557fd54ccf5a3e2775f0e35c61bad`
- Extraction: read-only `git ls-tree -r` path resolution and `git cat-file blob` byte extraction.
- Records extracted: 25 (9 authority sources and 16 structural contract files).
- Tree resolution: all 25 proposal blob IDs resolve uniquely to the full paths recorded in `manifest.json`.
- Byte verification: 24/25 proposal SHA-256 values match the extracted bytes.
- Frozen-source mismatch: `wall_t_junction_contract.json` blob `1ca35fec9437ef692a902c5fd6692aa00cc5cc11` is 3937 bytes; actual SHA-256 is `49a0c1bc921fa2c34dfa14095470e0f033e701d8d06939674e5e1555902d0705`, while the proposal records `49a0c1bc921fa2c34dfa14095470e0f033e701d8d06974e5e1555902d0705`. The proposal value is preserved verbatim and is not silently corrected.
- Catalog ordering proof: historical `scripts/procgen/modular_socket_catalog.gd` appends `_contract.json` names and calls `names.sort()` before `_load_contract`; the package preserves the resulting lexicographic 16-name set.
- Acceptance status: blocked pending coordinator disposition of the single frozen SHA-256 mismatch; no production files were changed.
