# R10-A current integrity admission unit 5 fix 1

This immutable scoped package addresses the sole HIGH finding in
`r10-current-integrity-admission-review.md` against
`current-integrity-admission-unit5-01`. The original package is retained
unchanged; its `package_manifest.json` still hashes to
`1204f11943a581d7569e024191d34bc511cd7403124def822d9518cb814f70cb`.

Review scope is exactly:

- `scripts/systems/module_integrity_map.gd`
- `scripts/validation/r10a_integrity_admission_smoke.gd`

`before/` contains the original review package's after-images. `after/`
contains the fix-1 source bytes. `fix1.diff` is the complete difference between
those trees. The reviewed state/run/world sources are unchanged by this fix.

The current validator now rejects integer integrity and base values that the
destination float fields cannot preserve exactly. It tests integer low bits
before conversion, including at the int64 upper boundary, and continues to
accept finite floats and large integers that are exactly representable. Bounds
and threshold-state checks still run on the admitted float value.

The smoke adds independent validator cases for inexact health, inexact base,
and the int64 upper boundary. Descriptor-authenticated application repeats the
health and base cases and proves denial leaves live modules and rebuild
descriptors unchanged. `9007199254740994` is the large exactly representable
positive control through validation, application, and recapture.

The binding contract is
`docs/game/features/crafting_derelict_feature_completion.md:409-416`; the
version-specific boundary is also described in
`.superpowers/sdd/2026-09-05-remaining-feature-completion/r10-save-transition-integrity-migration-addendum.md`.
This fix does not change historical permissive APIs or expand the staged restore
integration claim.

Meaningful RED evidence is in `evidence/red`: the focused smoke exited 1 with
zero exact PASS markers because integer health `9007199254740993` was admitted;
the isolated P10 probe passed cleanly. GREEN evidence is in `evidence/green`:
the focused smoke exited 0 with one exact marker, empty diagnostics and stderr,
and a clean P10 probe. Declared source hashes matched and remained stable in
both runs.
