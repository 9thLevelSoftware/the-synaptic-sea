# Correction addendum (manifest02)

The prior `extraction-report.md` and `manifest.json` incorrectly reported a SHA-256 mismatch because the expected proposal token was manually transcribed incorrectly.

Programmatic re-read of the frozen proposal row for `wall_t_junction_contract.json` gives:

- proposal SHA-256: `49a0c1bc921fa2c34dfa14095470e0f033e701d8d06939674e5e1555902d0705`
- blob: `1ca35fec9437ef692a902c5fd6692aa00cc5cc11`
- extracted/package SHA-256: `49a0c1bc921fa2c34dfa14095470e0f033e701d8d06939674e5e1555902d0705`
- size: `3937` bytes

The values are equal. The earlier mismatch claim is retracted. `manifest02.json` is the corrected full manifest; its SHA-256 is `2f8c4d34b128ce627bb641529b107d1e3dd222f472c1be3de924534b552cebac`.

All 25 extracted package source files were rechecked against the proposal’s 25 blob IDs and SHA-256 values: 25/25 pass. The 16 contract names remain lexicographically sorted under historical `names.sort()` order.
