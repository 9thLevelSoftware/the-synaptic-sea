# R10-A current integrity admission unit 5

This immutable package freezes the bounded run-7/world-7 integrity admission
prerequisite from HEAD `14eb80714b6a2dacce6fe0db1b156b5b27214fb6`.

Review scope is exactly:

- `scripts/systems/module_integrity_map.gd`
- `scripts/systems/module_integrity_state.gd`
- `scripts/systems/run_snapshot.gd`
- `scripts/systems/world_snapshot.gd`
- `scripts/validation/r10a_integrity_admission_smoke.gd`

The current-only pure validator rejects malformed integrity dictionaries before
RunSnapshot or ShipInstance can launder them. The descriptor-authenticated
`apply_current_summary` path validates completely before replacing live modules,
rebuilds pristine descriptor omissions, preserves room owners, and assigns exact
health without historical configure/clamp coercion. Current initialized maps retain
explicit row order and use exact health sparsity for later runtime changes. The old
permissive `apply_summary` APIs and historical run-6 decode behavior remain intact.

Detached validation proves syntax only. Geometry identity closure requires the new
strict application API after original descriptors are registered. This package does
not claim live staged restore integration or historical migration completion.

`tracked-files.diff` is the Git diff from HEAD for the four tracked sources.
`new-smoke.diff` records the new smoke against an absent baseline. `before/` and
`after/` contain exact source bytes. RED evidence is from
`R10-A-integrity-admission-red-01`: exit 1, zero PASS markers, the intended missing
validator errors, and a clean P10 probe. Final evidence is from
`R10-A-integrity-admission-final-01`: all six focused smokes exited 0 with one exact
marker, empty diagnostics/stderr, clean P10 probes, and stable source hashes.

