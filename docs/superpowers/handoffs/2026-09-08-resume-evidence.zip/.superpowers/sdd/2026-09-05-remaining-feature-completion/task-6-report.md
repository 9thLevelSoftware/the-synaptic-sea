# Task 6 / R06 implementation report

Date: 2026-09-06 (America/New_York)  
Workspace: `D:\the-synaptic-sea-feature-completion`  
Branch: `codex/feature-completion`  
Implementation base: `c51bcacbcb5557fd54ccf5a3e2775f0e35c61bad`

## Result

R06's bounded FC-13 through FC-15 closure passes its canonical and focused
verification on Windows Godot 4.7.2. The coordinator now rejects an omitted
ship owner, missing target position, out-of-range start, absent/mismatched
physical slot, stale target revision, occupied slot, incompatible physical fit,
and invalid selected component lot before work allocation or escrow. Commit
revalidates binding, selection, attachment, occupancy, access, range, tool,
target revision, actual current slot policy, component identity, destination
capacity, exact paid lot, power/effect authority, and the owner-specific state.

A completed component transaction produces one stored ledger receipt, one
physical placement effect, one completion-noise sink, one routed completion SFX,
and one real training/progression XP delivery. Duplicate commit returns the same
receipt without repeating inventory, placement, noise, audio, event-log, XP, or
progression effects. A component WorkAction without its explicit owner-bound
transaction fails closed before stamina, progress noise, resolver mutation, or
completion consequences.

The existing R03 P10 production journey remains the transfer authority: the
final P10 rerun proves the same immutable component lot across the away ship and
home ship, with two reloads after each move and the owner/count/provenance
predicates intact. R06 did not add a second transfer implementation.

## Implementation and focused fixture changes

- `scripts/procgen/playable_generated_ship.gd`
  - Removed active/current-owner inference from transaction start; a nonempty
    `target_ship_id` is mandatory.
  - Added start-time spatial and exact target-revision admission before work-ID
    allocation and escrow.
  - Added actual physical-slot, fit, occupancy, component, destination, and exact
    source-lot preflight at start and again during commit staging.
  - Bound interactive remount transaction identity to the actual physical slot
    ID. Room/kind/index remain commit payload fields for the resolver.
  - Added fail-closed handling for an untransactioned component driver.
  - Counted effect/noise/XP at their actual application seams for independent
    validation while retaining checks against the authoritative sinks.
- `scripts/validation/fc_p11_smoke.gd`
  - Added distinct footprint/size, socket, type, slot, missing-profile,
    unknown-slot, and occupied-slot denials.
  - Corrected the panel test to its request-only contract and checked explicit
    owner, binding generation, slot/component/item payload, and unchanged
    placement.
  - Updated current-policy restore fixtures to valid strict condition lots.
- `scripts/validation/fc_p12_smoke.gd`
  - Added missing-owner, out-of-range, stale-start-revision, no-spend snapshots.
  - Added authoritative exactly-once checks for inventory/placement, ledger
    receipt, completion audio, threat noise, training log/XP, and progression.
  - Added a direct untransactioned-component regression proving no resolver or
    consequence fallback.
- `scripts/validation/fc_p13_smoke.gd` initially passed byte-for-byte from its
  inherited untracked runtime-release base. Review fix round 1 later extended
  its two-owner, access, binding-generation, stale-target, escrow, and
  no-fallback assertions as recorded below.
- Conditional focused fixtures now use current-layout restore with valid strict
  condition authority:
  `component_slot_population_smoke.gd`, `ship_modification_smoke.gd`, and
  `pillar_revisit_persistence_smoke.gd`. The component-slot marker now exactly
  matches its declared marker.
- Terra's tracked `tools/run_physical_work_smokes.py` and
  `tests/test_physical_work_runner.py` are included unchanged from their handoff
  hashes. Sol did not edit these files.

## Owner-fallback audit

All three production `_start_transactional_work` call sites pass an explicit
ship ID. Panel install/uninstall and live interact enter the same transaction
path. Component completion without an active transaction returns
`missing_work_transaction`; it cannot resolve against the coordinator's current
placement. Transaction staging and application fetch the context from the
record's `ship_id`, require that owner's live binding and work-ledger identity,
and pass that owner's placement, modification, systems, and integrity objects.
The component effect calls disable their legacy current-owner fallback. No R06
component mutation uses the home/current placement alias.

## RED and final verification

The first isolated P12 RED was the intended missing-owner failure:

```text
FC P12 FAIL: missing owner admitted or spent: { "ok": true, "reason": "active", "work_id": "ship_start/dismount_component:1" }
```

It had no P12 PASS marker and exited 1 after the separate containment probe
passed. After implementation, every engine body below ran through the hardened
runner with a new four-variable home and separate P10 probe. Raw stdout, stderr,
Godot logs, probe environment and summaries are retained.

| Gate | Result | Evidence |
| --- | --- | --- |
| Canonical P10 transfer/reload | `FC P10 PASS` | `artifacts/feature-completion/R06-P10-transfer-reload-final-20260906-01` |
| Canonical P11 | `FC P11 PASS` | `artifacts/feature-completion/R06-P11-canonical-final-20260906-01` |
| Canonical P12 | `FC P12 PASS` | `artifacts/feature-completion/R06-P12-canonical-final-20260906-01` |
| Canonical P13 | `FC P13 PASS` | `artifacts/feature-completion/R06-P13-canonical-final-20260906-01` |
| Focused P11 | `R06 P11 FOCUSED PASS cases=4` | `artifacts/feature-completion/R06-P11-focused-final-20260906-03` |
| Focused P12 | `R06 P12 FOCUSED PASS cases=4` | `artifacts/feature-completion/R06-P12-focused-final-20260906-01` |
| Focused P13 | `R06 P13 FOCUSED PASS cases=4` | `artifacts/feature-completion/R06-P13-focused-final-20260906-02` |
| Runner tests | `36 passed in 1.32s` | `tests/test_physical_work_runner.py tests/test_feature_completion_runner.py` |
| Orphan classification | `ORPHAN CLASSIFICATION CHECK PASS orphans=211` | `bash tools/classify_orphan_smokes.sh --check` |
| Scoped diff whitespace | pass | `git diff --check -- <R06 GDScript paths>` |

## Source freeze and provenance

The review freeze is
`task-6-afterimages/runtime-freeze-02/manifest.json`, SHA-256
`538f8f747a6e2119870fc0c662bdf60da790b84134a20637cde265a886d58dfb`.
It contains nine full source afterimages, exact unified deltas against the
recorded pre-edit bases, Terra's full runner report, and per-file SHA-256 indexes
for 178 retained files across the RED and seven final evidence directories.
`runtime-freeze-01` is explicitly marked incomplete because its generator
stopped before producing a manifest; it is not a review source.

The exact coordinator delta is against the additive runtime-release snapshot,
whose base already contained inherited coordinator WIP. FC P12 likewise had an
inherited modified base; FC P13 was inherited untracked and has a zero-byte exact
R06 delta. The three conditional fixture deltas use the original 41-file
beforeimage. The runner and runner test use their recorded absent beforeimages
and retain Terra attribution. Root owns staging and commits.

## Integration state and limits

The first post-runtime `tools/build_feature_acceptance.py --check` was RED
because concurrent R10-A generator changes were temporarily ahead of the two
generated manifests. R06 did not regenerate or overwrite that work. After the
R10 owner completed its generator write/check and confirmed the P11-P13
constants, focused groups, and commands were unchanged, the R06 registry
recheck passed:

```text
FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0
```

A later fix-round recheck became transiently RED again while the R10 governance
owner updated approved pose rules. The stored registry's first observed
difference was `criteria[100].source.line` (`257` stored, `259` computed), and
the generated card manifest also differed. R06 recorded that raw result and did
not regenerate either artifact. After the R10 governance owner regenerated its
approved changes, R06's final read-only recheck again passed at 668 criteria and
zero unassessed sources. Both raw results are retained.

This is bounded focused-fixture acceptance. R04's actual new-game physical route
remains RED on the known lifeboat/ceiling geometry prerequisite, so this report
makes no natural-route claim and does not change physics. R10-A will later change
geometry and the paired save version; the R06 physical-work paths require an
explicit post-integration requalification. R06 made no R07/P14 condition-policy,
selected-repair, reconstruction, multiplayer, or new-save-schema change.

## Independent review fix round 1

The coordinator transcription of the three HIGH findings is frozen in
`task-6-review.md`. The additive pre-fix base is
`task-6-beforeimages/fix-round-01/manifest.json`, SHA-256
`0a6a0aa5076acd6c52e06915048f5b832867ae2255e0e364726170bfae34b9f9`.
It preserves the original packages and records inherited/shared WIP before any
fix edit.

The coordinator now authenticates owner, target identity, and revision before
deriving the target's live world position from the owner's actual component
slot or module. It rejects non-finite positions and caller coordinates that do
not match that canonical point. Only the canonical value is cached. Tick and
commit recompute it from the live owner, so moving the ship or target cannot
reuse a stale start point for range admission.

P12 covers a forged nearby point for a distant valid slot, a non-finite point,
a stale caller point, a moved owner at start, a moved owner during work, and a
moved owner immediately before commit. P13 covers the same forged-point attack
for a real damaged module. These checks enter the production coordinator and
prove no active transaction or protected-state change on denial.

The shared authoritative snapshot includes exact inventory lots, component
placement, module integrity, ship modification and systems state, ledger and
receipt count, actual work-effect counters, threat noise, completion audio,
training events, delivered XP, progression, active work ID, and driver status.
Production tests use it for footprint/socket/type denials, missing/foreign
ledger, missing systems authority, stale binding callback, reserved target
removal, and same-generation revision drift. Target removal and revision drift
retain the exact escrow lots while paused, then explicit cancel returns those
lots exactly, empties escrow, creates no receipt, and restores the original lot
summary. Reentrant completion is invoked from the real training-event
consequence callback; the nested commit returns `commit_in_flight`, and the
outer commit changes actual placement/modification plus receipt, noise, audio,
training, XP, and progression exactly once. A later duplicate commit returns
the original receipt and leaves the entire authoritative snapshot unchanged.

Every final engine body used the hardened isolated runner with a new
four-variable home and a separate P10 containment probe:

| Fix-round gate | Result | Evidence |
| --- | --- | --- |
| Canonical P10 | `FC P10 PASS` | `task-6-fix1-evidence/final-canonical-p10-01` |
| Canonical P11 | `FC P11 PASS` | `task-6-fix1-evidence/final-canonical-p11-01` |
| Canonical P12 | `FC P12 PASS` | `task-6-fix1-evidence/final-canonical-p12-01` |
| Canonical P13 | `FC P13 PASS` | `task-6-fix1-evidence/final-canonical-p13-01` |
| Focused P11 | `R06 P11 FOCUSED PASS cases=4` | `task-6-fix1-evidence/final-focused-p11-01` |
| Focused P12 | `R06 P12 FOCUSED PASS cases=4` | `task-6-fix1-evidence/final-focused-p12-01` |
| Focused P13 | `R06 P13 FOCUSED PASS cases=4` | `task-6-fix1-evidence/final-focused-p13-01` |
| Direct ship-mod run snapshot | `SHIP MOD RUN SNAPSHOT PASS shipmod=true pillar=true count=true` | `task-6-fix1-evidence/direct-ship-mod-run-snapshot-01` |
| Runner tests | `36 passed in 1.26s` | `tests/test_physical_work_runner.py tests/test_feature_completion_runner.py` |
| Orphan classification | `ORPHAN CLASSIFICATION CHECK PASS orphans=211` | `bash tools/classify_orphan_smokes.sh --check` |
| Scoped diff whitespace | pass | `git diff --check -- <R06 GDScript paths>` |
| Final registry recheck | `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0` | `tools/build_feature_acceptance.py --check` |

The direct snapshot result has one exact PASS marker, empty stderr, no runtime
diagnostics, and a passing containment probe whose four environment roots all
resolve under its unique owned directory. Its smoke source remained unchanged
from the fix-round base. Natural-route and R10 requalification limits remain as
stated above.

## Independent review fix round 2

The independent fix-1 review is `task-6-fix1-review.md`, SHA-256
`177ee7d5d1c5f4bbee41fc0413ab841c15eb613161ae6271a95fbcec21662dd2`.
It closed the canonical-position and direct-snapshot findings and retained two
HIGH items: the remaining pure-model FC13 denial evidence and a stale occupancy
snapshot introduced at transactional start. The additive pre-edit base is
`task-6-beforeimages/fix-round-02/manifest.json`, SHA-256
`879ad1d24368854f94b6216ac9cd144cacf1071162071ac773856237e8dbb453`.

Transactional start now calls `recompute_occupancy()` before constructing its
owner-bound `ShipWorkContext`. Target identity/revision, canonical range,
physical fit, effect authority, transaction activation, and reservation all use
that one freshly constructed context. A production P12 fixture moves the real
lifeboat AABB around the home target without refreshing occupancy immediately
before start. When actual attendance changes from lifeboat to home, paid work is
admitted and explicit cancel returns the exact escrow lot. When attendance
changes from home to lifeboat at the same in-range point, start returns
`not_attending_target` before a work ID or escrow and the complete authoritative
snapshot remains byte-equal.

The production denial matrix now invokes the real panel callback or
`_start_transactional_work()` for all authored FC13 cases: missing item,
missing/unknown slot, water/non-component input, unknown component,
incompatible item form, missing/unknown slot profile, incompatible slot,
footprint, socket, and type, occupied slot, and wrong selected ship. Every
denial compares the shared snapshot byte-for-byte, including exact lots,
placement, integrity, modification, systems, the full ledger and receipt count,
effect counters, threat noise, completion audio, training events, delivered XP,
progression, active ID, and driver state. Catalog/slot fixture mutations are
restored immediately and never enter the transaction ledger.

The first covering P12 run was RED because the selected production component
authored `slot: any`, so changing only the slot kind was not an incompatible
case. The corrected fixture temporarily sets a distinct required slot on that
same live catalog component and restores the definition after the denial. This
tests the intended production boundary rather than assuming a stricter contract
than the selected component authors.

| Fix-round-2 gate | Result | Evidence |
| --- | --- | --- |
| Canonical P10 | `FC P10 PASS` | `task-6-fix2-evidence/final-canonical-p10-01` |
| Canonical P11 | `FC P11 PASS` | `task-6-fix2-evidence/final-canonical-p11-01` |
| Canonical P12 | `FC P12 PASS` | `task-6-fix2-evidence/final-canonical-p12-01` |
| Canonical P13 | `FC P13 PASS` | `task-6-fix2-evidence/final-canonical-p13-01` |
| Focused P11 | `R06 P11 FOCUSED PASS cases=4` | `task-6-fix2-evidence/final-focused-p11-01` |
| Focused P12 | `R06 P12 FOCUSED PASS cases=4` | `task-6-fix2-evidence/final-focused-p12-01` |
| Focused P13 | `R06 P13 FOCUSED PASS cases=4` | `task-6-fix2-evidence/final-focused-p13-01` |
| Runner tests | `36 passed in 1.71s` | `tests/test_physical_work_runner.py tests/test_feature_completion_runner.py` |
| Orphan classification | `ORPHAN CLASSIFICATION CHECK PASS orphans=211` | `bash tools/classify_orphan_smokes.sh --check` |
| Scoped diff whitespace | pass | `git diff --check -- <R06 GDScript paths>` |
| Final registry recheck | `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0` | `tools/build_feature_acceptance.py --check` |

The fix-round registry build matched, but its card-manifest comparison was
transiently RED while another governance owner changed the generated card
inputs. The raw `stored_cards == cards` assertion is retained in
`task-6-fix2-evidence/final-static-checks-01/transient-registry-check-red.log`.
After that owner regenerated the two newly present R10-A runner/test path states,
R06's final read-only check passed at 668 criteria and zero unassessed sources.
R06 did not regenerate or edit shared governance artifacts. The
canonical-position and direct-snapshot implementation remained unchanged in
this round.
