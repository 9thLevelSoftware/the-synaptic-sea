# R18 runner reconciliation after resumed manifest repair

Read-only coordinator check, 2026-09-08. No implementation or runtime acceptance.

The existing reviewed `tools/run_feature_completion.py` already supports the repaired single-quoted numeric marker: `REGRESSION_MARKER` accepts that form as well as the older dynamic form. `_prepared_bundle()` derives its final count at runtime and injects distinct per-Godot-case homes, all four owned environment variables, and a separate P10 containment probe. `_verified_bash()` locates Git Bash on Windows; `_canonical_python_shim()` binds the runner's actual Python executable.

Therefore the newly merged convenience entry point's hardcoded `/bin/bash` does not block running the full canonical program through the established feature-completion runner. R18 should reuse the reviewed `--profile baseline` path and verify current integration before proposing a new runner. The convenience wrapper can be reconciled if its own supported entry-point contract requires it; it must not cause duplicate validation infrastructure or be used for unsafe local runtime execution.

The canonical document remains the command-list authority. The resumed manifest repair preserves the exact ordered 652 commands and adds a fail-closed runtime count guard. No full canonical bundle was run by this check; all R18 product and runtime evidence remains pending.
