# R10 physical-integrity seeder — independent review

**Disposition: Needs Fixes.** The production seeder change is correct for current compiler records, but the focused smoke does not prove the required compiler-valid secondary-edge behavior. Runtime validation is separately pending and was not run in this review.

## Reviewed scope

- Branch/HEAD: `codex/feature-completion-resume` at `2d29b2bbc398b392d4ef365d671365aba1ec393f`.
- `scripts/systems/module_integrity_consequences.gd`, SHA-256 `67329c66a2cbe6e9cef2b63d3ab417242d95c994740174358a48f0abe805871f`.
- `scripts/validation/module_integrity_consequences_smoke.gd`, SHA-256 `9efdf99b1b9237af9b8f26690c10410e7d279a021893e8444cc4fe8fbfc65024`.
- The scoped diff is 16 additions/3 deletions in the seeder and 110 additions in the smoke. `git diff --check` reports no whitespace error.

## Finding

### MEDIUM — the new smoke uses invalid compiler fixtures and does not exercise secondary-edge resolution

**Affected component:** `scripts/validation/module_integrity_consequences_smoke.gd`, especially the `physical_layout` block at lines 148-186 and `secondary_lookup_layout` block at lines 227-252.

**Specific problem:** The added records are hand-authored and are not valid output from `StructuralEdgeCompiler`. For `vertex:0|0|0`, the first fixture lists `edge_keys` as `0|h|0|0` and `0|v|0|0` but declares `0|v|0|0` as its primary `edge_key`; the compiler sorts incident keys and uses the first key as primary. More fundamentally, neither listed edge is an incident ray for vertex `0|0|0` according to `_edge_key_for_vertex_ray`. The second fixture also labels a hand-authored record as a secondary-edge lookup, but `LayoutMutator.apply_wreck_to_compiled_plan` has no edge-key request API. `_collect_compiled_records` reads only the record's primary `edge_key` and `placement_id`; it never reads `edge_keys` or `covered_half_spans`. Removing or corrupting the alleged secondary edge would leave the new assertion green.

**Why it matters:** The scoped seeder acceptance must at least prove identity consistency from real compiler output through seeding and mutator damage rows. This smoke can pass for records the compiler cannot produce, so it does not protect that boundary. Its stronger secondary-edge claim is also misleading: live resolution from a covered edge to the same physical target belongs to the loader wrapper metadata and controller target-resolution integration, not to `LayoutMutator`. The static source review shows the seeder key rule is correct, but the scoped acceptance evidence remains incomplete and the broader secondary-edge acceptance must stay pending.

**Concrete remediation:** Build the test input with `StructuralEdgeCompiler.compile` and require a passing `StructuralPlanValidator` verdict. Select compiler-produced full-edge, vertex, and residual-span records, including two physical placements sharing one primary edge when available. Seed that compiled plan and assert the map contains exactly the expected full-edge or `edge/<placement_id>` key for each physical record, with no primary-edge alias for a vertex/span. Feed exact duplicates of compiler-produced records to deterministic one-candidate mutator fixtures and assert each damage row uses the same physical key as the seeder. Keep the distinct damage and sparse-delta round-trip assertions against these compiler-produced identities, and remove the false secondary-edge request claim. Separately, the loader/controller integration acceptance should select a materialized wrapper reached through a covered secondary edge and prove that its `structural_edge_keys` all bind to its single `structural_placement_id`, `module_key`, original descriptor, and health state. That broader proof is outside this two-file repair and must remain pending rather than being inferred from the mutator test.

## Correctness assessment

`ModuleIntegrityConsequences._compiled_module_id` correctly preserves `edge/<edge_key>` for a current full-edge record whose placement identity is `edge:<edge_key>`, and uses `edge/<placement_id>` for current vertex and residual-span records. This agrees with `GeneratedShipLoader._structural_target_id` and `LayoutMutator._collect_compiled_records` for valid current compiler output. Two records sharing a primary edge therefore receive separate health states, and the existing owner collection retains all unique room IDs. The damage and sparse-delta round-trip checks are meaningful for the keys they exercise, including the absence of a collapsed primary-edge alias in the three-entry map.

The pre-existing noncompiled `seed_map_from_layout` path is unchanged and remains exercised earlier in the smoke. The helper also retains the prior edge-key behavior for older compiled records with no placement identity, which preserves the existing canonical-ID smoke cases. That compatibility differs from the current loader/mutator fail-closed behavior for such malformed records; the governing specification assigns historical geometry interpretation to the later explicit R10 save transition, so this review does not treat it as authorization for migration or guessing.

No correctness, architecture, maintainability, error-handling, security, concurrency, or performance defect was found in the production seeder hunk itself. No CRITICAL or HIGH findings were identified.

## Validation state

Static review is complete. I independently verified the two frozen candidate hashes and ran the scoped diff/whitespace checks. I did not run Godot by assignment. The focused `module_integrity_consequences_smoke.gd` runtime result and required clean `MODULE INTEGRITY CONSEQUENCES PASS fire=true breach_derived=true scene=true nav=true` marker remain pending with the separate runtime owner. A green runtime result for the current smoke would establish parse/execution health but would not close the fixture/coverage finding above.
