# Merged-base impact audit — 2026-09-07

Scope: read-only comparison of checkpoint `0d4518a0` through the observed working
HEAD, limited to the incoming requirements/validation/ADR/UI/asset-pipeline and
canonical-regression files requested by the coordinator. No Godot, import/editor,
source, or registry mutation was performed.

## Observed revision and source fingerprints

The requested starting branch description named `2f9c69132ca2b4badd81e0865aad9c32a8121739`.
The shared worktree had advanced by audit time: observed `HEAD` was
`0b90acbad281c22390a5de6f75ea41a89858d539` (`2026-09-07T23:33:29-04:00`), with
parent `2f9c69132ca2b4badd81e0865aad9c32a8121739`. The audit therefore reports the
observed source state and does not reset or alter it.

SHA-256 (observed files):

| File | SHA-256 |
|---|---|
| `docs/game/05_requirements.md` | `83419690cafa7c60f0824e02b544e73e0fa5f0616c38eb74a42c20e0634545aa` |
| `docs/game/06_validation_plan.md` | `d54f4c41a95fc33f12ce1e4bef2c7b14b2caafc4cc6ccee5bcb0de2741327b01` |
| `docs/game/adr/0060-meshy-offline-evidence-rebind.md` | `b2702043c5b9c1f2b91ad08fc4c3699b602e6d9dc816ecb7fd38eca9cda42007` |
| `docs/game/adr/README.md` | `512560b1bed606bbfff9084043d8fe4da9cf483287ca72e4f7b011f4b466058b` |
| `docs/game/features/ui_presentation_program.md` | `12f3a5b147104fa9efb2a98bb732cf40063fa6609263baf98b72ed087f8a0899` |
| `docs/game/features/ai_candidate_asset_pipeline.md` | `f35e241383bde21de48f318e39dbdc906efd267cb387d1b9705f0194684e1d68` |
| `tools/run_canonical_regression.py` | `2ba85010a1ad316d0ed7f23bf4903f49555dd72848c1fd477855e3d63ba6454a` |
| `tests/test_run_canonical_regression.py` | `3fd7ed02e76e89913dc58bf36eff3eca50fd88809bdc0afde1774b1030737b84` |
| `tools/synaptic_sea_gate4_regression.sh` | `655af1956275081297626c193af181a58cf66499195d9977415b5c65f8526aa8` |
| `docs/game/inventory/feature_acceptance.json` | `345b4844eccfd9bf2c371cb2391fc0874b7e18c8312e3e30a43cf2686659f7bf` |

The handoff's frozen fingerprints remain present in the registry:
scope `8041e481680152f85fe2d3617491880a5268d89dcb63a59608590711edef48d0` and
reviewed supersessions `ffe325ef281156711db10d85eb896a4781804ec976944aef4a948bdbe12ad0df`.

## Impact on frozen criteria and existing contract

`docs/game/05_requirements.md` changes only five verification/provenance paragraphs
under the pre-existing Meshy requirements (`REQ-AIAP-001..010`, diff hunks around
lines 1669–1828). The set of requirement headings is unchanged: 130 at the
checkpoint and 130 at HEAD; no `REQ-*` IDs were added or removed. The edits describe
the integrated `loot_container_derelict_v1` evidence and retain proposal-only
promotion boundaries. They do not constitute new product-scope criteria.

The new `docs/game/features/ui_presentation_program.md` is explicitly **Proposed**
(line 1) and says its decisions are reviewable proposals, not accepted ADRs. It is
planning scope, not an addition to the frozen feature-acceptance registry. The
associated repository audit and execution plan likewise recommend a future allowed-
files card and scoped implementation evidence; they do not supersede frozen rows.

The registry check currently fails closed before comparison can complete:

```text
AssertionError: frozen scope drift; coordinator review is required before regeneration
BUILD_FEATURE_ACCEPTANCE_EXIT=1
```

This is expected from the changed source-document content being hashed into the
frozen scope contract; no registry file was regenerated. The frozen denominator in
the handoff remains authoritative (668 source rows, 657 active, 11 deferred, 622
distinct active criteria). Do not update the fingerprint or denominator solely to
absorb these prose/UI/asset evidence changes; require coordinator scope review if a
new source leaf is intentionally admitted.

ADR ambiguity is concrete: `docs/game/adr/README.md:43` already maps ID `0060` to
`0060-windows-feature-completion-validation-runtime.md` (Windows 4.7.2 baseline,
652 canonical checks), while the new row at README line 53 maps ID `0068` to the
path `docs/game/adr/0060-meshy-offline-evidence-rebind.md`. The file itself is titled
“ADR-0060”. This is a dual-ID/path collision. Preserve historical IDs and paths;
coordinator should choose a new unused historical ID for the Meshy ADR and update
only its title/index references, without renumbering old records.

## Canonical runner audit

`tools/run_canonical_regression.py:60–119` extracts the sole `## Regression bundle`
and validates count/marker structure. The documented bundle's final marker at
`docs/game/06_validation_plan.md:1135` is:

```text
echo "SYNAPTIC_SEA REGRESSION PASS commands=${RUN_CLEAN_COUNT} clean_output=true"
```

The runner requires decimal digits (`tools/run_canonical_regression.py:12–19`), so it
cannot parse the current canonical document's shell-variable marker. It therefore
does not yet replace the older manual/adapted runner. Focused verification was:

```text
26 passed, 2 failed in 0.10s
```

The two failures are `test_objectdb_teardown_warning_is_exactly_allowlisted` and
`test_real_canonical_document_has_consistent_count`; both fail with
`ValueError: expected exactly one canonical regression marker`. The other 26 tests
pass. `tools/run_canonical_regression.py --check` exits 2 with the same parse error.

The runner also does not implement the accepted Windows 4.7.2/isolation/diagnostics
contract: it invokes `/bin/bash` at line 139, requires a caller `GODOT` but only
describes 4.7.1 at line 138, sets no isolated home/APPDATA/LOCALAPPDATA/
`GODOT_USER_PATH`/`XDG_DATA_HOME`, emits no raw-log/source-hash evidence, and has no
native no-save `user://` containment probe. The validation plan still names Godot
4.7.1 at lines 182, 204, and 327. The legacy shell entry point is now only a thin
wrapper (`tools/synaptic_sea_gate4_regression.sh`), so it inherits this incomplete
manifest/runner behavior. README's accepted ADR-0060 statement (“652 canonical
checks”) also has no demonstrated correspondence to the current variable marker.

## Bounded next actions

1. Coordinator reviews the changed Meshy verification prose against the frozen scope;
   keep the 622 denominator and fingerprints unless a deliberate source-scope decision
   is recorded.
2. Resolve the ADR collision by assigning the new Meshy decision an unused ID while
   preserving the historical Windows ADR-0060 file and index row.
3. Make the canonical document and runner agree on one exact marker/count contract
   (the current tests expect a numeric marker and 651 `run_clean` entries), then rerun
   the focused test file and `--check` before considering canonical replacement.
4. Separately adapt the canonical execution lane to the accepted Windows 4.7.2
   binary, hardened isolation, no-save probe, diagnostics policy, raw logs, and source
   hashes. This audit did not run Godot or alter that lane.

