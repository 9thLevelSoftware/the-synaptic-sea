# Task 4 / R04 governance checkpoint

Date: 2026-09-05 (America/New_York)  
Workspace: `D:\the-synaptic-sea-feature-completion`  
Branch: `codex/feature-completion`  
Checkpoint HEAD: `4590a4058f631fdfd316d276d116b1ec8001df17`

## Scope and provenance

The required exact disk-byte beforeimages are stored in
`task-4-beforeimages/`, with a 32-entry manifest, full status capture, and
working/index binary diffs. Its manifest hash is
`6d636184a7b6e76f4a5af0b021f348c13f5109ac5cf2f84394cb887f287a8cc2`.
It captures tracked and untracked scoped paths, including the pre-existing
untracked economy checker, its tests, and `fc_p09_smoke.gd`; the intended new
natural-route smoke and unique evidence roots are explicitly absent.

The original manifest is immutable. A correction addendum captures the newly
scoped generated-card authority at
`task-4-scope-addendum-beforeimages/manifest.json` (SHA-256
`9405dad6926bf60e0f4b485196b53b72d25bb03b7ac886ca6bd96f1497c95149`):
`tools/build_feature_acceptance.py` is preserved byte-for-byte before its P09
scope/card changes.

R03 was frozen at `ed70d37198000529cb8baa5217414f74a0372090`. The current
checkpoint advances only through `4590a405`, a documentation-only R03 outcome
commit; the manifest records that runtime/data source remains frozen relative
to that earlier head. No runtime/data source or test was executed by R04.

The local P09 card on generated board `synaptic-sea-stage-gate` is generated
from `tools/build_feature_acceptance.py`, never hand-edited. It records the
natural-route smoke as `planned_missing`, scope decisions, non-goals, and the
hardened runner verification. `--write --check` and a second `--check` both
reported `criteria=668 unassessed_sources=0`; the registry's frozen active
metric denominator remains 622. External board synchronization remains
`pending`: no connector is available and no external write is claimed.

## R04 governing facts and implementation approach

The current cold-opening fixture force-repairs unrelated systems and later
injects ingredients/skill. It remains valuable for negative and model coverage
but cannot prove a natural route. The positive route will instead begin from
Title New Game on `coherent_ship_001`, record the searched `start_supply_*`
container and actual lot origin, use the inventory-book interaction for
knowledge, and use ordinary station interaction/picker, escrowed timed work,
collection, and an actual output consumer.

The existing titanium route is preserved: `thruster_nozzle` or `plasma_cutter`
deconstructs at the skill-1 salvage workbench to `titanium_ingot`. A missing
roll in a sampled run will be recorded as such, never converted into arbitrary
loot. The advanced route must include `plating` -> `plating_plate` and its
real component installation or repair consumer. The economy checker will cover
recipe inputs/outputs, item/material IDs, book knowledge, station tiers, repair
BOMs, component/donor forms, deconstruction, mandatory dependency cycles, and
sinkless profitable cycles; its production-source pin waits for reviewed R03/R11
integration.

Default Engineer starts with repair 3 and satisfies nav-linkage's repair-2
opening gate. The selectable repair-0/1 classes need an authored-progression
audit before anyone calls them softlocked or changes balance. Machinery-donor
proof must observe current station/system effects only; it cannot count retired
donor healing from pending ADR-0066/R07 work.

## Root decision requested before runtime window

No policy ambiguity blocks the governance checkpoint. The only prospective
runtime decision is conditional: if normal-control evidence demonstrates a
missing deterministic opening, recipe-book, donor, or advanced edge, root must
rule the smallest authored progression or balance change before it is added.
Until that ruling and explicit runtime release, R04 will make no runtime/data
edits or execute Godot/Python tests.

## Governance correction

The FC-10 acceptance-register table text is restored byte-for-byte to its
frozen criterion. The R04 detail is adjacent rationale only, so it does not
alter the 622-denominator source contract. The original P09 plan and generator
now explicitly list `fc_p09_natural_route_smoke.gd` before it exists. The card
does not carry a standalone process-probe command: every Godot body uses the
hardened feature-completion runner, whose accepted first marker prefix is
`FC P10 USER DATA PROBE PASS`.

## Runtime window: provisional evidence (2026-09-06)

Root accepted the corrected governance in `a8f7d9653bd00c3d6b7b3221dc577277d0a46aec` and released the exclusive R04 runtime window. The original 32-path manifest remains frozen; the later orphan-registration beforeimage is at `task-4-orphan-registration-beforeimages/manifest.json` (SHA-256 `c9bbd213c065e0f76c767a380c127717a4022441e437696ad004908f4a115752`). It captures `tools/classify_orphan_smokes.sh` and `docs/game/06_validation_plan.md` before their approved standalone-feature-completion registration. `bash tools/classify_orphan_smokes.sh --check` now passes (`orphans=211`), and the generated registry was updated only with `tools/build_feature_acceptance.py --write --check`; it reports `criteria=668 unassessed_sources=0` with frozen denominator 622.

`tests/test_crafting_economy.py` had a stale unit assertion that treated historical non-null reviewed hashes as current-source pins while the coordinator hash is intentionally pending R11 review. It now asserts that canonical guard remains pending and retains the existing synthetic copied-fixture approval and drift tests. `python -m unittest tests.test_crafting_economy` passed all 54 tests. The canonical production checker remains intentionally blocked, without a bypass or rebinding: `CRAFTING ECONOMY BLOCKED source_error=runtime scripts/procgen/playable_generated_ship.gd: compatible tool action proof pin pending review`. The final source pin is explicitly pending R05/G1 after reviewed R11; any graph diagnostic before then is provisional only.

The new `fc_p09_natural_route_smoke.gd` starts via a real Title `ui_accept` input, opens the live dock barrier with the player interaction signal, drives the real `PlayerController.move_and_slide` path, and never uses inventory injection, direct skill mutation, force repair, teleport, or snapshot seeding. A task-local runner helper (`r04_run_natural_case.py`) invokes `run_feature_completion.execute_isolated_case` with a distinct evidence root and four-home containment probe. Every body invocation first recorded the accepted `FC P10 USER DATA PROBE PASS` containment marker.

The initial natural route located two physical blockers. First, the home interaction branch did not dispatch `AuthoredPortalRuntime`, unlike the away branch, so a live closed `PortalBlocker` at `edge:0|v|0|1` was solid. The narrow coordinator dispatch now calls the existing `_try_authored_portal_interact` after home pickups. Fresh evidence then proves ordinary input acquires the overlapping oxygen pump and, on the following interaction, opens that exact portal. No door state was forced. Second, after the door opens, movement is blocked before either starter container by the generated floor collision: fresh evidence `artifacts/feature-completion/P09-R04-natural-20260906T040404Z` ends at `(3.149058, 0.125933, 1.908347)` with collider path `/root/TitleMain/Main/PlayableCoherentShip/LifeBoat/ShipStructure/airlock_01/floor_0_0_0/CollisionRoot`. It also logged `META PAYOUT reason=death payout=0 meta_currency=0 runs_completed=0` during the timeout. This prevents actual container access in the current probe and requires fresh Sol traversal diagnosis before any physical topology or player-collision conclusion. R04 does not bypass it in the smoke.

The strict runner records the existing exact voice warning `WARNING: AudioManager: stream file missing, path='res://data/audio/voice/log_beacon_01.ogg'`. Root classified it under ADR-0044 and the validation-plan authored six-file warn-once fallback: raw strict runner results remain failures when it occurs; a future task-local accepted-diagnostic verdict may accept only that precise set with raw logs retained, clean containment, exit 0, exactly one body marker, no timeout/cleanup failure, and no other diagnostic. R04 adds no audio assets, disables no voice behavior, and makes no general runner change.

The natural smoke currently treats the two start containers only as the starter checkpoint. It will not infer a missing advanced book or titanium donor from that checkpoint: those are later ordinary repair/boarding/exploration legs. The companion source-only `r04-low-repair-opening-source-table.md` records that repair-1 progression is conditional and repair-0 remains unproven, without asserting a softlock or authorizing balance changes.

Read-only wrapper inspection records a hypothesis only: `scenes/wrappers/structural/ship_structural_v0/floor_1x1.tscn` and `corridor_floor_1x1.tscn` place a `(4, 0.25, 4)` static box centered at local `y=0`, while the observed player origin is `y≈0.125`. That co-planarity may contribute to the observed collision, but the final floor contact alone does not prove its cause or a lateral vertical-face collision. Fresh Sol traversal diagnosis is pending; no structural collision/spawn correction is authorized or was changed by R04.


## Provisional graph closure update (2026-09-06)

R04 extends only the economy checker and isolated synthetic-test coverage. The checker now reports unseeded mandatory prerequisite SCCs explicitly and validates the two authored titanium donor routes: `deconstruct_thruster` requires loot-capable `thruster_nozzle` and `deconstruct_plasma_cutter` requires loot-capable `plasma_cutter`; each must be a skill-1 `workbench` deconstruction recipe with a one-unit `titanium_ingot` output. This is catalog/route evidence, not a claim that either donor must appear in a particular sampled container.

The test-local reviewed-hash fixture (used only in the Python process) produced a provisional actual-source graph result with no unknown IDs, unreachable recipe input/output IDs, unreachable repair BOM/tool IDs, mandatory prerequisite cycles, titanium donor-route gaps, or zero-power cycle groups. It records donor source tables `loot:generic_locker` for `plasma_cutter` and `loot:salvage_engineering` for `thruster_nozzle`. The production command remains fail-closed because the coordinator hash is still `None`: no pin was changed, persisted, or rebound.

The remaining-plan dependency ruling is explicit in commit `17d9d3b1`: R04 exits only with natural-route evidence, provisional graph diagnostics, and negative checks; R05/G1 owns the canonical full source pin after reviewed R11. R04 must not claim the canonical checker passes before that dependency completes.

## Frozen economy package evidence (2026-09-06)

The exact afterimages for independent R04 review are frozen at `task-4-economy-afterimages/manifest.json` (manifest SHA-256 `6896b4b304ad3b4b968af5a3779ae9626affcef34dfbb9d819e5973a6fd11c58`) from HEAD `17d9d3b11177b8c7d70d07d113ce5e9c038a513b`. `tools/check_crafting_economy.py` is SHA-256 `d2ca55e11a5d35ae8c1740bd34eb03c5eea18625e82df7074d622235e038ece7` (110296 bytes) and `tests/test_crafting_economy.py` is SHA-256 `e69c9b29d9cf37592a4ac5745ad9109cb14224277bc0ec7646b88b2c78fa239a` (64404 bytes). The manifest and raw command records are retained alongside those byte copies.

` .superpowers\\test-runtime\\Scripts\\python.exe -m unittest tests.test_crafting_economy` exited 0; raw stdout is the zero-byte `unittest.stdout.log`, while raw stderr `unittest.stderr.log` reports 56 tests and `OK`. ` .superpowers\\test-runtime\\Scripts\\python.exe tools\\check_crafting_economy.py --root .` exited 1 as expected; raw stdout is `canonical.stdout.log`, stderr is `canonical.stderr.log`, and the exact stdout is `CRAFTING ECONOMY BLOCKED source_error=runtime scripts/procgen/playable_generated_ship.gd: compatible tool action proof pin pending review`.

`provisional_diagnostic.py` and its raw logs retain the separate actual-source graph diagnostic. It patches `REVIEWED_TOOL_ACTION_FILE_HASHES` **in memory only in that evidence process**, exited 0, and explicitly prints its provenance as `test-only in-memory hash fixture; never canonical approval`. It is not a production bypass, does not persist approved hashes, and cannot satisfy the R05/G1 reviewed-R11 canonical pin. Its raw result records no graph findings and the two live donor table sources.


## Economy review remediation round 1 (2026-09-06; re-review pending)

The scoped independent review at `r04-economy-review.md` found two defects in
R04's checker/test package. The immutable pre-fix snapshot is
`task-4-economy-fix1-beforeimages/manifest.json` (SHA-256
`93aea87771d929def3691c5f1e253f2e8679178a7e84fd26062a2449004df3a9`) at
HEAD `c51bcacbcb5557fd54ccf5a3e2775f0e35c61bad`. The additive afterimage
manifest is `task-4-economy-fix1-afterimages/manifest.json` (SHA-256
`c6b05c37a6fd57f89e6f6b307974e3000deddeea0fe771a27324a6e2cf3823a8`). It
records `tools/check_crafting_economy.py` SHA-256
`2b9f4642c955b486099e5cbd85210782c9d844656dd31680fab6f4650edbae22`
(110543 bytes) and `tests/test_crafting_economy.py` SHA-256
`23f61e6b7cebe44e713315bccaaed2234593c9c1ca48dca37b57f66795c70b8b`
(65336 bytes). The exact source diff is retained as
`task-4-economy-fix1-afterimages/fix1.diff` (SHA-256
`a938bdeac5faa943dfd524da7b9009f177688a29528374d45a9028901bf2e45f`,
4363 bytes).

The checker now reads each titanium donor recipe's `required_skill_level` once
and accepts only a non-boolean Python integer. `True`, `1.9`, `"1"`, `"one"`,
and `null` now produce the deterministic source error `required_skill_level
must be an integer`; a well-typed but incorrect integer such as `0` remains a
route blocker (`invalid_skill_level`), while authored integer `1` remains the
positive route. The focused synthetic test also now proves the exact
`mandatory_prerequisite_cycles` blocker is present for the isolated unseeded
cycle and absent after seeding its entry item, rather than relying only on a
non-success result that could have another cause.

Fresh raw verification is retained in `task-4-economy-fix1-afterimages/`:

- `.superpowers\\test-runtime\\Scripts\\python.exe -m unittest tests.test_crafting_economy`
  exited 0. `unittest.stdout.log` is empty; `unittest.stderr.log` reports 56
  tests and `OK`.
- `.superpowers\\test-runtime\\Scripts\\python.exe -m unittest
  tests.test_crafting_economy.GraphAnalysisTests` exited 0; raw stderr reports
  16 tests and `OK`.
- `.superpowers\\test-runtime\\Scripts\\python.exe
  tools\\check_crafting_economy.py --root .` exited 1 as required for the
  fail-closed canonical guard. Its exact stdout remains `CRAFTING ECONOMY
  BLOCKED source_error=runtime scripts/procgen/playable_generated_ship.gd:
  compatible tool action proof pin pending review`.
- The separate `provisional_diagnostic.py` exited 0 with no mandatory-cycle,
  donor-gap, unknown-ID, unreachable, or zero-power-cycle findings. It reports
  the two authored donor rows: `deconstruct_plasma_cutter` from
  `loot:generic_locker` and `deconstruct_thruster` from
  `loot:salvage_engineering`, both skill-1 workbench routes. Its SHA-256 is
  `d3df8b925b48022eb6818fb7131781a594f8f9411bb089c33b69e5c8009eab3e`.

That provisional program patches reviewed action hashes only in its own
in-memory evidence process. It neither writes nor approves production source
pins, and does not change the canonical R05/G1-after-reviewed-R11 dependency.
This remediation package requires a new scoped independent review; it is not
an R04 completion or canonical-checker pass claim.
