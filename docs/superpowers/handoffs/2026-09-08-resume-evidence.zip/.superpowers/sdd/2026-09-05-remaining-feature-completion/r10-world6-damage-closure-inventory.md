# Historical damage reconstruction dependency inventory

Read-only discovery by `/root/world6_damage_closure_scan` (Luna), against Git
authority `c51bcacb`. This inventory scopes later migration work; it neither
implements reconstruction nor replaces the existing native/fallback route rulings.

Required historical source paths:

- `scripts/procgen/ship_layout_generator.gd`: condition overlays, compile/validate,
  then wreck damage stamping in that order.
- `scripts/procgen/layout_mutator.gd`: branch/portal overlays, wreck stamping and
  damage-map seeding.
- `scripts/procgen/structural_edge_compiler.gd` and
  `scripts/procgen/structural_plan_validator.gd`: historical placement identity and
  authenticated edge/floor/ceiling topology.
- `scripts/procgen/modular_socket_catalog.gd` and `walkability_contract.gd`:
  contract loading and validator passability.
- `scripts/systems/module_integrity_consequences.gd`, `module_integrity_map.gd`
  and `module_integrity_state.gd`: registration, generated damage application,
  threshold and sparse-summary semantics.
- `scripts/procgen/ship_blueprint.gd`: historical condition enum/input authority.

Pin `data/kits/ship_structural_v0.json` and all 16 historical contract JSON files
under `data/placement/contracts/structural/ship_structural_v0/`; catalog loading
discovers that directory dynamically. Instantiating the real historical integrity
map additionally creates `structural_rebuild_state.gd`, loads
`structural_rebuild_catalog.gd`, and reads
`data/construction/structural_rebuild_catalog.json`. A pure health reconstruction
may exclude rebuild behavior only after proving equivalent registered health.

Historical damage IDs are `edge/<edge_key>`, `floor/<cell_key>` and
`ceiling/<cell_key>`. Never prepend `edge/` to the historical `edge:` placement ID.
Visual wrappers, GLBs, live loader and visual resolver are not needed solely to
derive registered health. Upstream seed-only layout reconstruction still requires
the separately governed frozen generation closure; this inventory assumes its
authenticated historical layout or plan is available.
