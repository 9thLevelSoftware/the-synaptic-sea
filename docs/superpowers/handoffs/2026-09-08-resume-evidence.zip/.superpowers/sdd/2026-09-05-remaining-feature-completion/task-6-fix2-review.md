# Task 6 Fix Round 2 — Independent Review

**Verdict: SPEC PASS; QUALITY APPROVED for the scoped R06 fix-round-2 delta.** Both open HIGH findings are addressed. No material breakage was introduced by this fix delta.

Review scope was limited to the two findings retained in `task-6-fix1-review.md` and breakage introduced by their fixes. I reviewed the exact frozen delta against the fix-round-2 base, not the inherited HEAD/worktree:

- Review package `task-6-afterimages/fix-round-02-review-package-01/manifest.json` — SHA-256 `398c00c357d012757d3a5d4bee43f5cb2ae28ed9d395771450d5f8d58abc4c44`
- Runtime freeze `task-6-afterimages/fix-round-02-runtime-freeze-01/manifest.json` — SHA-256 `c9ff8d346e00b9f9154e46465875c778284d573dd96e7ae586e1250b9ef38632`
- Fix base `task-6-beforeimages/fix-round-02/manifest.json` — SHA-256 `879ad1d24368854f94b6216ac9cd144cacf1071162071ac773856237e8dbb453`

## Open finding verdicts

### 1. Complete production denial table with all protected sinks — ADDRESSED

**Affected component:** `scripts/validation/fc_p12_smoke.gd:767-969`; authoritative snapshot in `scripts/procgen/playable_generated_ship.gd:4931-4974`

`_validate_production_denial_matrix()` now covers the previously missing FC13 cases through a production boundary:

- The real panel signal callback covers missing item and missing/unknown slot.
- `_start_transactional_work()` covers water/non-component input, unknown component, incompatible item form, missing/unknown slot profile, incompatible slot, footprint, socket, type, occupied slot, and wrong selected ship.

Every helper captures the shared authoritative snapshot immediately before and after the denial and requires byte-equality plus no active work. That snapshot contains exact inventory lots, placement, integrity, modification, systems, the full work ledger and receipt count, effect counters, threat noise, completion audio, training log, delivered XP, progression, active work ID, and driver status. Catalog, profile, slot, selection, and temporary lot fixture changes are restored outside each denial assertion. The panel-only failure SFX is correctly excluded from completion-audio authority.

The retained covering P12 run passes with one exact `FC P12 PASS` marker, exit `0`, empty stderr and diagnostics, and clean containment. The retained intended RED has no PASS marker, exits `1`, and reports that the first incompatible-slot fixture was incorrectly admitted because its component authored `slot: any`; the corrected fixture changes the live component's required slot and restores it afterward.

No further remediation is required for this finding.

### 2. Refresh attendance before constructing the admission context — ADDRESSED

**Affected component:** `scripts/procgen/playable_generated_ship.gd:4312-4353`; regression coverage in `scripts/validation/fc_p12_smoke.gd:972-1072`

Transactional start now calls `recompute_occupancy()` before `_ship_work_context_for()`. The context used for target authentication, canonical range, physical admission, effect authority, transaction activation, and reservation therefore contains current `is_occupied`/`is_piloted` values. The former recomputation after context construction was removed, so the stale captured booleans cannot authorize or deny start.

The production fixture exercises both directions without manually refreshing occupancy immediately before start. It first leaves a stale away-ship occupancy value while actual attendance changes to the target ship and requires successful admission plus exact escrow recovery on cancel. It then leaves a stale target-ship occupancy value while actual attendance changes to the other ship and requires `not_attending_target`, no active work or escrow, an updated live occupancy owner, and a byte-identical authoritative snapshot. This directly covers the prior regression.

No further remediation is required for this finding.

## New fix-delta findings

None.

## Evidence assessment

The frozen package contains 13 scoped source afterimages/deltas and 192 indexed evidence files. I independently checked every copied source/delta hash and every evidence hash/size against the frozen manifests and found no mismatch.

The four canonical runs and all 12 focused cases each have exit `0`, exactly one declared body marker, empty stderr, empty classified diagnostics, no cleanup error, and a passing containment probe. For all 16 positive cases, plus the covering GREEN and intended RED, the four environment variables resolve to the same case-owned root and match the probe's expected root. Static evidence reports `36 passed in 1.71s`, orphan classification `PASS` with 211 smokes, and the final registry `PASS` with 668 criteria and zero unassessed sources. The transient card-manifest RED is retained and the later final registry check is green.

This approval is limited to the exact R06 fix-round-2 delta. It does not approve G1/G2, the known-RED natural route, natural gameplay acceptance, R10/P14 changes, or the inherited HEAD monolith. The previously addressed canonical-position and direct-snapshot findings were unchanged and were not reopened.
