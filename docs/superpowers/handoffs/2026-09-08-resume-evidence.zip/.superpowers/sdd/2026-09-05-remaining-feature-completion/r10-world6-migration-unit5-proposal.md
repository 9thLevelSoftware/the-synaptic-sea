# R10-A unit 5: world-6 to world-7 detached migration proposal

**Status:** Proposed scope only. Do not implement until the coordinator annotates the
exact frozen projection/data closure, updates the P17 allowlist, and releases the
unit. This unit consumes the approved run-7 migration from commit `581aec07`, the
approved public `ModuleIntegrityConsequences.compiled_module_id()` seam from commit
`c3bdf40b`, and the independently accepted final world-7 model/candidate interface.

**Coordinator annotation, 2026-09-08:** Unit 5A is released to the separate
`/root/world6_attachment_projection` owner for only
`world_v6_layout_projection.gd`, `world_v6_geometry_authority_v1.json`, and
`r10a_world6_layout_projection_smoke.gd`. That release covers attachment/layout
projection only and excludes damage, candidate validation, and save wiring. All
remaining paths below stay proposed until separately released.

## Result and boundary

The unit admits a strictly validated world-6/run-6 pair and produces a detached,
strict world-7/run-7 candidate. It reconstructs historical geometry before resolving
corrected current endpoints, migrates player pose, connections, durable endpoint
state, root authority, known combat coordinates, and physical integrity, then exact-
recaptures and validates the candidate. Every failure returns one stable recoverable
reason without changing source dictionaries/bytes, save index, backup/sidecars, or
live state.

This unit does not implement current world-7 capture, staged scene publication,
receipts, free-root live launch, hangar live placement, hallucination reset, or the
final save/load integration qualification. `save_load_service_smoke.gd` remains RED
until current capture supplies complete world-7 authority.

## Proposed file ownership

Add exactly:

- `scripts/systems/world_v6_layout_projection.gd`
- `data/migrations/world_v6_geometry_authority_v1.json`
- `scripts/validation/r10a_world6_layout_projection_smoke.gd`
- `scripts/systems/world_v6_docking_migration.gd`
- `scripts/validation/r10a_world6_geometry_migration_smoke.gd`

Modify exactly for the core unit:

- `scripts/systems/save_migration_service.gd`
- `scripts/validation/save_migration_world_smoke.gd`
- `scripts/validation/save_migration_service_smoke.gd`
- `scripts/validation/module_integrity_consequences_smoke.gd`
- `scripts/validation/pillar_persistence_smoke.gd`
- `scripts/validation/pillar_revisit_persistence_smoke.gd`

The already accepted `scripts/systems/module_integrity_consequences.gd` public ID
function is consumed without another edit. Add
`scripts/systems/save_restore_candidate.gd` and `scripts/systems/ship_instance.gd`
only if the final accepted world-7 unit still admits malformed current integrity
envelopes; that strict-admission correction must be a separately frozen seam before
the migration service wiring. Do not edit world-7 model/candidate files while their
current review is open.

No existing future fixture may change. The focused smoke constructs its fixtures in
memory from model builders and the frozen authority resource, so this proposal adds
no fixture path.

## A. Frozen historical projection and authority package

`world_v6_layout_projection.gd` is a pure, version-named implementation. It may copy
only the function-level historical behavior listed below. It must not preload or call
the mutable current generator, current endpoint authorizer, or current structural
compiler while computing old geometry.

The projection closure is:

1. Blueprint input checks and size-to-room-count mapping from c51
   `ship_blueprint.gd` blob `112458a7e9fa0b547c9b86b60f66897d43a5304b`.
2. Fallback route/archetype/template selection from `ship_generator.gd` blob
   `5b61d7f906d967975291de9c8605a316d1a7dc40`, `template_selector.gd` blob
   `145a90a0f4e944a36b9b06829271b01704c753ea`, and `topology_template.gd` blob
   `13623b059a96bd345f20b5801d5ba8cb42211267`.
3. Room assignment and RNG consumption from `room_assigner.gd` blob
   `c7738a8f47368d2de0518873456692ea0ecbada6`, complete cell placement/adjacency
   from `cell_layout_engine.gd` blob `cb742f3725b587e22e4bcb151560d86074a85ec2`,
   and the four-attempt salt/selection policy from `ship_layout_generator.gd` blob
   `0799708c7a836634a8adfd0966ba2da92860c743`.
4. Historical final post-authoring order from that same layout-generator blob:
   `_apply_condition_mutators`, then `_stamp_structural_plan`, then
   `_apply_wreck_to_compiled_plan`. Copy only the called condition/portal/wreck
   branches from `layout_mutator.gd` blob `4381b9c0414cbf386555b442a617609637637359`, the exact historical compile
   behavior from `structural_edge_compiler.gd` blob `71167c504b2738ae191288ed90a6419546376f03`, its validation
   predicates from `structural_plan_validator.gd` blob `e60fcfe6733a9a34a6223638e179fa7f2be9cf4e`, catalog lookup
   behavior from `modular_socket_catalog.gd` blob `d7d15f9208402f0c19ea29d514cdf4cae6f8e860`, and the used flood-
   fill predicate from `walkability_contract.gd` blob `8bb48a762ef29dc46682b946b58b268c4c2b2947`. The coordinator
   must replace each abbreviated blob with its full object ID before release.
5. Historical integrity health creation and sparse-envelope semantics from c51
   `module_integrity_consequences.gd` blob `55feee84141babd7b8f3bc22cdfb997600047d8b`,
   `module_integrity_map.gd` blob `cce006253918bf83770daf94f4df2efb8a808a10`, and
   `module_integrity_state.gd` blob `3370bc98e297d81d071e108b79cf4d5733917487`. The projection should compute the
   exact registered health tuples directly. It must not instantiate the historical
   rebuild catalog/state unless coordinator review proves the byte-faithful map
   object is required; those are not needed to derive health.
6. Old fixed home/lifeboat/airlock/hangar transforms from c51 `dock_ports.gd` blob
   `195546f8855251163785f4a1d7e33fe2714886d9` and `docking_manager.gd` blob
   `ec49a728e0d798f01d1e72b93bd94139149ec651`.

`world_v6_geometry_authority_v1.json` contains data and provenance, never executable
source. Its exact schema must be fixed before coding and contain:

- schema/version ID and Godot 4.7.1 RNG dependency;
- every full source blob/hash and the exact extracted symbol list used by the helper;
- the derelict archetype data (`04024f7c...`) and all 14 templates in their historical
  selectable order with full blob IDs and copied data;
- `ship_structural_v0.json` blob `473f688a...` plus the 16 historical structural
  contract JSON documents in the exact old dynamic-directory order, each with path,
  blob/hash, and copied data;
- fixed c51 home layout blob `8f96dfb...`, lifeboat source blob `f7ff672...`, old port
  center/slot derivation constants, and the derived fixed transforms with their
  source witnesses;
- Windows native-v2 DLL SHA-256
  `3279db6338e7af6b54cb4e8c8886d39bdffec73549a25149a05a87d9ebdb8798`, macOS
  dylib SHA-256 `a17fbcaf4834d51ac8ddc05becbe0a762d07ab83e043f215532eccb40040cec1`,
  generator version `2`, size/condition parameter maps, and kit binding.

Before release, produce an immutable authority-source package containing every full
historical blob ID, every copied JSON byte source and its SHA-256, the proposed
authority JSON, and an extraction manifest. Review must prove the helper contains
only the enumerated closed algorithms. It must not absorb whole historical files by
convenience.

For each procedural owner, build every available authenticated historical candidate.
Exact hash/version-gated native reconstruction is supported on Windows/macOS. Native
unavailability never implies fallback origin. An incomplete route set rejects
`legacy_generation_route_unavailable`; incompatible surviving candidates reject
`legacy_generation_route_ambiguous`; zero reconstructible candidates reject
`legacy_layout_unreconstructable`. Multiple candidates may proceed only when every
required old attachment, slot, physical placement, and damage witness is bit-identical.

## B. Current descriptor binding and integrity projection

Generate the corrected current final post-authoring plan independently from the same
authenticated owner inputs. Validate it through the accepted current plan validator
and bind every physical placement through the public
`ModuleIntegrityConsequences.compiled_module_id(record, layer)` function. The
migration must not duplicate that formula. Canonical full edges/portals retain
`edge/<edge_key>`; vertex/span placements use `edge/<placement_id>`. Historical IDs
are always `edge/<edge_key>`, never `edge/edge:<edge_key>`.

Strictly validate the historical `module_integrity_map_v1` before projection.
Missing or `{}` means uninitialized: reconstruct the frozen condition overlays and
generated `module_damage` before mapping. A present valid nonempty envelope with
`deltas: []` means explicitly fully repaired and suppresses generated damage.
Present rows require the exact known envelope/row keys, unique IDs, finite engine
values, valid bounds, and threshold-consistent state.

Apply the accepted uniform-state policy after old damage reconstruction. Each old
solid edge expands to two authenticated half-spans. Copy the exact
`(integrity, base_integrity, state)` tuple to every current physical claimant; never
sum, divide, average, or round. A shared vertex requires bit-identical tuples from
all incident contributors, including pristine omissions. Any difference rejects the
entire candidate as `legacy_integrity_projection_ambiguous`. Missing/extra/duplicate/
multiply-claimed spans reject `legacy_integrity_projection_unavailable`. Ambiguous
non-health payload or old-ID references reject
`legacy_integrity_payload_projection_ambiguous`.

## C. Detached world adapter and service wiring

`world_v6_docking_migration.gd` executes in this order:

1. Strictly validate and deep-copy the complete world-6/run-6 pair, old dock rows,
   every required finite position, known owners, generation witnesses, hangar slots,
   combat envelopes, and integrity envelopes.
2. Reconstruct the old owner/root graph using only section A. Reject missing owners,
   multiple parents, cycles, invalid exact hangar slots, or unprovable roots.
3. Build corrected current owner plans/endpoints. Map every old airlock row to exactly
   one current endpoint pair. Emit strict hangar tagged-union rows with the exact old
   occupied slot. Map each old opened marker to exactly one current endpoint and emit
   explicit false rows for every other durable known-owner endpoint.
4. Emit one `ship_root_authorities_v1` row per known owner: fixed home/current visited
   hosts are `world_anchor`; airlock/hangar mobiles are `connection`. World-6 does not
   contain enough authority to invent a `free` row for an unconnected mobile, so that
   shape rejects instead of using the former `[0,0,-8]` launch offset.
5. Use world-6 `aboard_ship_id` as the sole owner. At home, require embedded home pose
   to equal the top-level pose exactly; away, validate and discard the obsolete home
   duplicate. Compute `owner_local = old_owner_global.affine_inverse() *
   legacy_global_position` once, then classify that explicit owner/local point only
   against corrected current endpoint geometry.
6. For roots whose transform changes, rebase only the closed historical combat
   variants' `world_position` and `last_known_position`. Keep carts, floor/corpse
   drops, station positions, maps, cells, tags, and other owner-local payload bytes
   unchanged. Unknown fields in a movement-authoritative combat envelope reject.
7. Apply section B's integrity projection after the old condition/damage state exists.
8. Migrate the nested run through the approved run-6 to run-7 step, erase all three
   legacy world fields, stamp world-7, then require `WorldSnapshot.from_dict()` and
   `SaveRestoreCandidate.validate_world_authority_graph()` to accept the detached
   result. Exact recapture must equal it before return.

Only after the pure adapter passes does `save_migration_service.gd` add `world-7` to
the known/target/pair tables and dispatch an explicit world-6 to world-7 step. The
existing world-5 step stays pinned to literal run-6, and raw standalone run-6 denial
continues through the approved named closure API.

## RED and GREEN acceptance

The new smoke first records an intended RED at the missing world-6 step. Its GREEN
matrix then proves:

- fixed home/lifeboat and authenticated fallback/native procedural positives;
- literal world-5 to world-6 to world-7 chaining and exact final pair;
- at-home duplicate-pose equality, away duplicate validation/discard, explicit owner
  classification, and source immutability;
- strict airlock and exact-slot hangar rows, complete root authority, durable endpoint
  coverage, and unique legacy marker mapping;
- missing context/owner, duplicate parent, cycle, unsupported layout, unavailable or
  ambiguous generation route, endpoint/marker ambiguity, nonfinite transform, and
  unprovable old free root rejection without partial output;
- every accepted historical combat envelope/variant, exact rebasing of only known
  world-space positions, unknown-field rejection, and byte-identical local payloads;
- integrity missing and `{}` reconstruction; valid nonempty empty-deltas repair;
  one-to-one full edge/portal; split edge with matching incident neighbors; two/three
  incident identical tuples yielding one vertex row; damaged-versus-pristine and
  unequal tuples rejecting atomically; missing/duplicate/unaccounted spans and
  ambiguous non-health payload rejecting with their stable reasons;
- final strict world-7 decode, authority-graph validation, exact recapture, and
  unchanged historical run/world-v7 fixture hashes.

Requalify the listed existing smokes through the hardened isolated runner with fresh
four-variable homes, exact markers, clean diagnostics, and the separate P10 probe.
Retain `save_load_service_smoke.gd`'s exact `invalid_world_snapshot` RED as the next
capture-unit dependency rather than weakening world-7 validation.

## Dependency-safe execution slices

- **A1, independent:** build and review the immutable historical source/data package;
  no project runtime edit.
- **A2, released to the separate Unit 5A owner:** add the authority JSON, pure frozen
  attachment/layout projection, and `r10a_world6_layout_projection_smoke.gd`; no
  unit-3/world-7 file edit and no damage/candidate/save behavior.
- **B, already complete:** the shared typed physical-ID seam is accepted at
  `c3bdf40b`.
- **C1, after world-7 review:** add strict current integrity admission only if the
  accepted candidate/ShipInstance interface still needs it; freeze separately.
- **C2, after A2 + world-7 + B:** implement the detached docking/combat/integrity
  orchestrator and focused smoke.
- **D, last:** wire the explicit world migration step in `SaveMigrationService` and
  requalify existing migration/persistence smokes.

One owner assembles `r10a_world6_geometry_migration_smoke.gd`; independent slices
must not edit that file concurrently.

## Coordinator release subdivision (2026-09-08)

Unit5A is released to world6_attachment_projection for the attachment-only subset (items1-3 and6), authority JSON, and r10a_world6_layout_projection_smoke.gd. Historical condition/compiler/health reconstruction (items4-5) is a separate remaining implementation, not part of that worker's ownership. The shared current integrity-ID seam is already accepted. Full historical object IDs above were resolved from c51 by root; this provenance resolution does not release the remaining damage or save-wiring scope. Current target identity always uses the corrected final post-authoring plan; historical reconstruction follows only the actual frozen historical pipeline, never retroactively applying current endpoint authoring.
