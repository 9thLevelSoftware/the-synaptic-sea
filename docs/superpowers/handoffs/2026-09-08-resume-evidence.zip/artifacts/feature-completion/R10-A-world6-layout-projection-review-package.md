# R10-A world-6 layout projection review package

Frozen: 2026-09-08

## Scope

This package covers the bounded Unit 5A historical attachment projection prerequisite only. It adds a pure, detached world-6 layout projector, its pinned geometry authority, and one focused smoke. It does not implement damage projection, the structural historical compiler, world-save or schema wiring, capture/restore, live clearance, or new endpoint behavior.

## Frozen files

All three files are new whole-file additions, so each Git blob ID identifies the complete review diff for that file.

| File | SHA-256 | Git blob ID |
| --- | --- | --- |
| `scripts/systems/world_v6_layout_projection.gd` | `E1F8130927B597828B4F7184BF79F83658D542D313577A7E67B96FFABD43663C` | `1544ef111e85f979ea177c7ff00ce341b88914da` |
| `data/migrations/world_v6_geometry_authority_v1.json` | `E9A45432E4B3A28D3D3DD915C892519AAF24470DD6C5B6F372FCF9DBFE9149E1` | `8d269b439d5218adaf96871ab828f8b799f3b517` |
| `scripts/validation/r10a_world6_layout_projection_smoke.gd` | `CB7A6C379B622B4B87C9F63AD698C275D649397961930AB780B8FBF7A61094EB` | `58650af96c8b53285ef745c06935e03aff6956f8` |

GREEN-03 independently recorded matching before/after SHA-256 values for all three files, with `declared_hashes_match=true` and `source_hashes_stable=true`.

## Source authority and capture provenance

The geometry authority pins source commit `c51bcacbcb5557fd54ccf5a3e2775f0e35c61bad`, the needed source blob IDs, the copied derelict archetype, all 14 ordered templates, fixed attachment descriptors, historical dock and slot constants, fallback retry/RNG parameters, native-v2 parameter mappings, and platform binary hashes. Runtime projection reads this checked-in authority. It does not read Git, artifacts, or test fixtures.

The independent fallback oracle was built from an exact `git archive` of c51. The archive SHA-256 is `FBFBBC0AAD30EFAC3D3544265A1E50B73AFF6D36358E0016FBA2434ECF3DB43D`; the additive historical capture script SHA-256 is `B7D93C7901A9C44FB2A93E8DAE730EC3D7A205788C13BA2870CB97F0CCC9B7C1`. Its raw stdout is `artifacts/feature-completion/R10-A-world6-layout-reference-capture/historical-green-01/body.stdout.log`, SHA-256 `0D371AD8E948AC698284D0FB71F7B6BD9F0B2C349D4BD89605A03C6525D78995`. Its stderr SHA-256 is `7ECB06380AA380BD169BC4D73CF7862F5E183B5724D0D879316A2B94EFBF02D4`.

That archived run emitted one c51 diagnostic for seed -73: `RoomAssigner: guaranteed role 'dock' has no eligible zone in this template; guarantee skipped`. The coordinator accepted it only as a historical-reference diagnostic. The classification file is `historical-green-01/historical_reference_classification.json`, SHA-256 `24DD30D310456B29C0DE76807AFAB1BBCE1356124270CE13C7807930ED558A79`. It is not a waiver for production validation.

The direct native-v2 oracle uses only the registered `DerelictGenerator` API after validating generator version 2 and Windows binary SHA-256 `3279db6338e7af6b54cb4e8c8886d39bdffec73549a25149a05a87d9ebdb8798`. It does not call mutable current generation or endpoint code. Capture script SHA-256 is `70AE862EDE1D5BD801ACD7DAC36DFA06F89332D0EE08E10B8DE92D417417726C`; raw stdout is `native-green-01/r10a-world6-native-v2-reference.stdout.log`, SHA-256 `EE8672F991B965FEB65783578950650078E79832CF76EF69B66E29D8DAC9A852`; stderr is empty, SHA-256 `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`.

## Exact reference comparisons

The focused smoke compares current projector output to these literal independent reference rows.

| Input | c51 fallback capture | Current fallback assertion | Pinned native-v2 capture | Current native assertion |
| --- | --- | --- | --- | --- |
| seed `17`, size `1`, condition `2`, no context | template `bifurcated`; airlock `[2,0,2]`, broken; no hangar | Exact match | airlock `[26,0,34]`, broken; no hangar | Exact match |
| seed `104729`, size `2`, condition `1`, biome `dead_fleet`, difficulty `normal` | template `hangar_wing`; airlock `[4,0,2]`, intact; ordered hangar anchors `[[12,0,0],[12,0,8],[16,0,4]]`, count 3, size 2 | Exact match | airlock `[46,0,42]`, intact; ordered hangar anchors `[[68,0,20],[76,0,20],[72,0,24],[68,0,28]]`, count 4, size 2 | Exact match |
| seed `-73`, size `0`, condition `0`, biome `breach_field`, difficulty `hard` | template `compact`; airlock `[2,0,2]`, intact; ordered hangar anchors `[[8,0,4],[12,0,4]]`, count 2, size 2 | Exact match | airlock `[38,0,26]`, intact; ordered hangar anchors `[[12,0,16],[20,0,16],[16,0,20],[12,0,24]]`, count 4, size 2 | Exact match |

The fallback and native projections differ for every captured input. The production smoke therefore also exercises a real Windows `project_procedural()` call and requires `legacy_generation_route_ambiguous`; seed alone never authenticates one route.

Fixed authority assertions are exact: home airlock center `[2,0,2]`, lifeboat airlock `[-2,0,0]`, home ordered hangar anchors `[[20,4,-4],[20,4,-8]]`, and the docked lifeboat root transform translation `[4,0,2]` with identity basis.

## Route completeness and witness policy

`project_procedural()` establishes route completeness internally after authenticating the platform-bounded native path. The public `resolve_authenticated_candidates(candidates, witnesses, candidate_set_complete)` Boolean is a trusted orchestration seam and must never come from persisted save data.

An incomplete possible route set returns `legacy_generation_route_unavailable`. A complete set with no witness survivors returns `legacy_layout_unreconstructable`. Differing surviving projections return `legacy_generation_route_ambiguous`. Equivalent surviving projections return `origin_resolution=equivalent_projection` and list every source in `admitted_routes`; they do not claim one route was proven.

Persisted witnesses accept only the closed top-level keys `dock_edges`, `hangar_summary`, and `room_cell_markers`, each with exact nested row keys and validated finite integer/numeric fields. Their provenance is documented in the authority JSON. Unknown or malformed keys reject. No route hint or corrected-current geometry can be inferred or supplied as a witness.

The native route is available only when the current platform is listed, the checked-in binary exists at the exact authority path, its SHA-256 matches, the existing class is registered, and `generator_version()` returns 2. Missing class/binary/platform, hash mismatch, version mismatch, malformed native output, or an incomplete potential route returns `legacy_generation_route_unavailable`. Runtime code never installs or loads a duplicate extension.

## Verification evidence

Focused GREEN-03: `artifacts/feature-completion/R10-A-world6-layout-projection-green-03/result.json`.

- body exit `0`, timeout false
- exact marker count `1`: `R10-A WORLD6 LAYOUT PROJECTION PASS fixed=true fallback=true routes=true`
- diagnostics `[]`; stderr empty
- P10 containment probe passed clean
- raw stdout SHA-256 `E4B5C86393CFF025BEBF898ABF0240C56D408B8ED889E3FF11F3D447F98D056D`
- raw stderr SHA-256 `E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855`
- result SHA-256 `E27CEC537105B8BBC3AF1A258ABE38D6CA2C8C8D17660E2830E0578A165D5D7A`
- artifact manifest SHA-256 `51F37CD2130257D8BAA11AA18997D13313E0A1E2980FFBA41FAEC1AE35AEBC18`

The smoke also covers strict fixed-role selection, identical multi-route reporting, incomplete/unavailable and ambiguity failures, native hash/version gates, malformed/nonfinite inputs, exact witness/candidate schemas, source immutability, and malformed mobile transforms.

Static checks after GREEN-03: authority JSON parsed successfully, `git diff --check` passed, and searches found no mutable generation/endpoint preload, runtime Git invocation, fixture dependency, or residual literal patch artifact.

## Compatibility boundary

Fallback parity is established for the independently captured varied rows and for the frozen c51 closure and authority copied into production. Native parity is bounded to authenticated generator version 2 and exact platform hashes. The projector does not claim universal historical compatibility when a possible source binary or route cannot be authenticated; it rejects that state.
