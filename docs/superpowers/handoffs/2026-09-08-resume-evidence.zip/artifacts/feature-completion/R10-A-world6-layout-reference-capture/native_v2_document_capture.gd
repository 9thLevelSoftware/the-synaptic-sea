extends SceneTree

## Exact native-v2 document-shape capture for the Unit 5A strict decoder.
## Uses only the authenticated, already-registered historical native API.

const BINARY_PATH: String = "res://addons/derelict/bin/win64/derelict_godot.dll"
const BINARY_SHA256: String = "3279db6338e7af6b54cb4e8c8886d39bdffec73549a25149a05a87d9ebdb8798"


func _initialize() -> void:
    if OS.get_name() != "Windows" \
            or not FileAccess.file_exists(BINARY_PATH) \
            or FileAccess.get_sha256(BINARY_PATH).to_lower() != BINARY_SHA256 \
            or not ClassDB.class_exists("DerelictGenerator"):
        _fail("native binary/class authentication failed")
        return
    var generator = ClassDB.instantiate("DerelictGenerator")
    if generator == null or not generator.has_method("generator_version") \
            or int(generator.generator_version()) != 2 \
            or not generator.has_method("export_layout_json"):
        _fail("native generator version/export authentication failed")
        return
    var text: String = str(generator.export_layout_json(17, {
        "archetype_id": "corvette",
        "intactness_override": 2000,
    }, "ship_structural_v0"))
    var parser := JSON.new()
    if parser.parse(text) != OK or not parser.data is Dictionary:
        _fail("native document was not valid JSON object")
        return
    print("HISTORICAL_NATIVE_V2_DOCUMENT %s" % text)
    print("R10-A WORLD6 NATIVE V2 DOCUMENT CAPTURE PASS hash=%s" % BINARY_SHA256)
    quit(0)


func _fail(message: String) -> void:
    push_error("R10-A WORLD6 NATIVE V2 DOCUMENT CAPTURE FAIL: %s" % message)
    quit(1)
