extends SceneTree

## Direct reference capture of the c51 native-v2 route. This script runs in the
## current execution project only so the already-registered extension is
## available. It does not call mutable GDScript generation or endpoint code.

const SOURCE_COMMIT: String = "c51bcacbcb5557fd54ccf5a3e2775f0e35c61bad"
const BINARY_PATH: String = "res://addons/derelict/bin/win64/derelict_godot.dll"
const BINARY_SHA256: String = "3279db6338e7af6b54cb4e8c8886d39bdffec73549a25149a05a87d9ebdb8798"
const FLOOR_MODULES: Array[String] = ["floor_1x1", "corridor_floor_1x1"]


func _initialize() -> void:
    if OS.get_name() != "Windows" \
            or not FileAccess.file_exists(BINARY_PATH) \
            or FileAccess.get_sha256(BINARY_PATH).to_lower() != BINARY_SHA256 \
            or not ClassDB.class_exists("DerelictGenerator"):
        _fail("native binary/class authentication failed")
        return
    var generator = ClassDB.instantiate("DerelictGenerator")
    if generator == null or not generator.has_method("generator_version") \
            or int(generator.generator_version()) != 2 \
            or not generator.has_method("export_layout_json"):
        _fail("native generator version/export authentication failed")
        return
    var cases: Array[Dictionary] = [
        {"seed": 17, "size": 1, "condition": 2},
        {"seed": 104729, "size": 2, "condition": 1},
        {"seed": -73, "size": 0, "condition": 0},
    ]
    var archetypes: Dictionary = {0: "shuttle", 1: "corvette", 2: "freighter"}
    var intactness: Dictionary = {0: 9500, 1: 6000, 2: 2000}
    for case_v in cases:
        var case: Dictionary = case_v
        var params: Dictionary = {
            "archetype_id": archetypes[int(case.size)],
            "intactness_override": intactness[int(case.condition)],
        }
        var parser := JSON.new()
        var text: String = str(generator.export_layout_json(
            int(case.seed), params, "ship_structural_v0"))
        if parser.parse(text) != OK or not parser.data is Dictionary:
            _fail("native layout export was malformed")
            return
        var projection: Dictionary = _projection(
            parser.data, int(case.seed), int(case.condition))
        if projection.is_empty():
            _fail("native layout had no historical attachment projection")
            return
        print("HISTORICAL_NATIVE_V2_CAPTURE %s" % JSON.stringify({
            "commit": SOURCE_COMMIT,
            "binary_sha256": BINARY_SHA256,
            "generator_version": 2,
            "params": params,
            "input": case,
            "projection": projection,
        }, "", true, true))
    print("R10-A WORLD6 NATIVE V2 REFERENCE CAPTURE PASS commit=%s hash=%s" % [
        SOURCE_COMMIT, BINARY_SHA256])
    quit(0)


func _projection(layout: Dictionary, seed_value: int, condition: int) -> Dictionary:
    var dock_cells: Array = _room_floor_cells(layout, "dock", "dock")
    if dock_cells.is_empty():
        dock_cells = _room_floor_cells(layout, "airlock", "airlock")
    if dock_cells.is_empty():
        return {}
    var hangar_cells: Array = _room_floor_cells(layout, "hangar", "hangar")
    if hangar_cells.is_empty():
        hangar_cells = _room_floor_cells(layout, "cargo", "cargo")
    var hangar: Dictionary = {}
    if not hangar_cells.is_empty():
        var slot_count: int = maxi(1, int(hangar_cells.size() / 2))
        var anchors: Array = []
        for index in range(slot_count):
            anchors.append((hangar_cells[index * 2] as Array).duplicate())
        hangar = {
            "type": "hangar",
            "slot_count": slot_count,
            "slot_size_class": 2 if hangar_cells.size() >= 4 else 1,
            "slot_anchors": anchors,
        }
    return {
        "airlock": {
            "position": _average(dock_cells),
            "facing": [1.0, 0.0, 0.0],
            "type": "airlock",
            "size_class": 1,
            "condition": _condition(seed_value, condition),
        },
        "hangar": hangar,
    }


func _room_floor_cells(
        layout: Dictionary, role_match: String, id_prefix: String) -> Array:
    for room_v in layout.get("rooms", []) as Array:
        if not room_v is Dictionary:
            continue
        var room: Dictionary = room_v
        if str(room.get("room_role", "")) != role_match \
                and not str(room.get("id", "")).begins_with(id_prefix):
            continue
        var cells: Array = []
        for placement_v in room.get("structural_placements", []) as Array:
            if not placement_v is Dictionary:
                continue
            var placement: Dictionary = placement_v
            var module_id: String = str(placement.get(
                "module_id", placement.get("module", "")))
            if module_id not in FLOOR_MODULES:
                continue
            var position_v: Variant = placement.get(
                "world_position", placement.get("position", null))
            if position_v is Array and (position_v as Array).size() >= 3:
                cells.append([
                    float((position_v as Array)[0]),
                    float((position_v as Array)[1]),
                    float((position_v as Array)[2]),
                ])
        if not cells.is_empty():
            return cells
    return []


func _average(cells: Array) -> Array:
    var total := Vector3.ZERO
    for cell_v in cells:
        var cell: Array = cell_v
        total += Vector3(float(cell[0]), float(cell[1]), float(cell[2]))
    var center: Vector3 = total / float(cells.size())
    return [center.x, center.y, center.z]


func _condition(seed_value: int, condition: int) -> String:
    if condition <= 0:
        return "intact"
    if condition >= 3:
        return "broken"
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    return "broken" if rng.randf() < 0.25 * float(condition) else "intact"


func _fail(message: String) -> void:
    push_error("R10-A WORLD6 NATIVE V2 REFERENCE CAPTURE FAIL: %s" % message)
    quit(1)
