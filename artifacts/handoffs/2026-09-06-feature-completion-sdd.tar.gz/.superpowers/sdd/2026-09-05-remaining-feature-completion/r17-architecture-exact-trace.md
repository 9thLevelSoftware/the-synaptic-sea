# R17 Architecture Exact Trace

- Generated: `2026-09-05T22:09:54.5029999-04:00`
- Source revision: `d850c26ab596b8130be57c8ba4024ef92617f61d`
- Moving WIP: `true`
- Scope: source-only trace; no runtime/test execution, evidence promotion, registry/index changes, or complete-game acceptance
- Registry selection: `domain == "arch" && deferred == false`
- Expected / actual leaves: `16 / 16`
- Result: `9 traced`, `7 source_mapped_partial`, `0 unresolved`, `0 fresh executions`

The active registry and `REQ-ARCH-001` through `REQ-ARCH-006` are the current authority. `docs/game/features/ship_runtime.md:3-5` still says only A1a landed and `:35-40` still calls tick bands a non-goal. That status is stale relative to the active requirements at `docs/game/05_requirements.md:1385-1424` and the current A1b/A1c/A3 source. No active ADR found in the bounded search retires or supersedes these criteria.

`traced` means current source plus the appropriate predicate cover the full leaf; it does not mean a test was freshly run. For negative architectural constraints, reviewed source structure and bounded reference absence are the appropriate predicates. Tests that mirror call names or assert code absence are not required. `source_mapped_partial` identifies a real missing behavioral predicate or unresolved authority wording.

## Exact leaf traces

### `REQ-ARCH-001::acceptance-958a663577c2`

**Criterion:** Vitals hot-path context keys are defined once in `SimKeys`.

- Production route: `VitalsState.tick` consumes the hot path at `scripts/systems/vitals_state.gd:141-199`; it imports `SimKeys` at `:8`.
- Implementation: the 12 canonical keys are declared once at `scripts/systems/sim_keys.gd:14-26` and returned by `vitals_hot_path_keys` at `:86-101`.
- Predicate: `scripts/validation/sim_keys_smoke.gd:12-39` requires exactly 12 entries and removes each expected wire key, failing on missing or unexpected values.
- Status: `traced`.

### `REQ-ARCH-001::acceptance-5c7579ece792`

**Criterion:** Pure vitals consumers use `SimKeys` constants; wire strings remain stable.

- Production route: every VitalsState context lookup at `scripts/systems/vitals_state.gd:146-194` uses `SimKeysScript.*`.
- Implementation: historical wire values remain in `scripts/systems/sim_keys.gd:15-26`.
- Predicate: `scripts/validation/sim_keys_smoke.gd:41-47` checks representative literal wire values; `:49-66` builds a SimKeys-keyed context and asserts health near 90 and thirst near 98. The complete wire-name set is checked at `:17-39`.
- Status: `traced`.

### `REQ-ARCH-002::acceptance-22616a332c0d`

**Criterion:** `TuningCatalog` loads `data/balance/*.json` with const fallbacks for missing keys.

- Production route: `TuningCatalog.load_directory` enumerates the balance directory at `scripts/systems/tuning_catalog.gd:53-71`; `load_defaults` is the export-safe entry at `:44-50`.
- Implementation: `load_file` parses and flattens JSON at `:27-41,116-124`; typed getters return caller-supplied defaults at `:78-105`, permitting callers to supply constants. The catalog-owned constants at `:10-14` describe its balance directory/file list.
- Predicate/gap: `scripts/validation/tuning_catalog_smoke.gd:11-23` checks missing-key defaults, `:25-41` checks shell loading, and `:53-61` checks directory loading. Authority clarification is needed: “const fallbacks” can mean caller-supplied constants accepted by these getters, but the requirement does not say whether TuningCatalog must own key-specific fallback constants. This audit does not invent the stronger interpretation.
- Status: `source_mapped_partial`.

### `REQ-ARCH-002::acceptance-2ddee78336a8`

**Criterion:** Shell fixture proves load/override without mass-migrating coordinator literals.

- Production route: the fixture uses `TuningCatalog.load_file/load_directory` at `scripts/systems/tuning_catalog.gd:27-71`; no `PlayableGeneratedShip` call site references the catalog.
- Implementation: `_merge_dict` overwrites an existing flattened key on a later load at `scripts/systems/tuning_catalog.gd:116-124`. A bounded source search finds catalog references only in the class and its smoke, consistent with the non-migration comment at `:6-8`.
- Predicate: `scripts/validation/tuning_catalog_smoke.gd:63-76` loads 9.25 after the shell fixture and asserts the override wins. The reviewed bounded reference search finds no PlayableGeneratedShip/runtime caller importing or invoking TuningCatalog, which is the appropriate static evidence for no mass migration.
- Status: `traced`.

### `REQ-ARCH-003::acceptance-1cdeb94bc259`

**Criterion:** Per-ship systems manager advance and web→hull damage run through \ShipRuntime\.

- Production route: `_tick_present_ships` calls `_advance_ship` at `scripts/procgen/playable_generated_ship.gd:11094-11100`; `_advance_ship` calls `_runtime_for(ship).advance` at `:1990-1993`.
- Implementation: `ShipRuntime.advance` calls `ship.systems_manager.advance` at `scripts/systems/ship_runtime.gd:121-129`, then calls `web.tick` and damages hull compartments at `:130-144`.
- Predicate/gap: `scripts/validation/ship_runtime_smoke.gd:31-45` asserts time stamping plus web/hull movement. `scripts/validation/ship_catchup_smoke.gd:58-79` asserts the coordinator wrapper grows web and degrades hull. Neither observes `systems_manager.advance`, so that conjunct is source-only.
- Status: `source_mapped_partial`.

### `REQ-ARCH-003::acceptance-a38cc7c03471`

**Criterion:** Absent derelicts catch up in capped sub-steps; home ships skip catch-up.

- Production route: `_catch_up_ship` rejects null/home and delegates absent instances at `scripts/procgen/playable_generated_ship.gd:2020-2023`.
- Implementation: `ShipRuntime.catch_up` rejects home, caps elapsed time to 1800 seconds, and advances in `min(5, 3)` second steps at `scripts/systems/ship_runtime.gd:16-21,179-192`.
- Predicate/gap: `scripts/validation/ship_runtime_smoke.gd:47-74` checks catch-up change/idempotence and `:76-86` checks home skip. No test gives a gap above 1800 or asserts step count/maximum step size. `ship_catchup_smoke.gd:87-91` calls zero-delta idempotence “bounded”; it does not test the cap.
- Status: `source_mapped_partial`.

### `REQ-ARCH-003::acceptance-9b27f3ff9cdb`

**Criterion:** Coordinator wrappers preserve existing catch-up smoke contracts.

- Production route: `_catch_up_ship` remains at `scripts/procgen/playable_generated_ship.gd:2020-2031`; `_runtime_for` constructs/configures its ShipRuntime at `:1998-2017`.
- Implementation: the wrapper delegates catch-up at `:2023` and drains craft completion receipts at `:2024-2031`.
- Predicate: `scripts/validation/ship_catchup_smoke.gd:39-59` calls `playable._catch_up_ship` directly; `:61-79` asserts web growth, hull degradation, and timestamp stamping; `:81-92` asserts no second-call mutation.
- Status: `traced`.

### `REQ-ARCH-004::acceptance-7e1cc4ef63f2`

**Criterion:** ShipRuntime to_snapshot/from_snapshot round-trips last_sim_time and ship summary.

- Production route: `ShipRuntime.to_snapshot/from_snapshot` are the per-ship persistence entries at `scripts/systems/ship_runtime.gd:198-264`.
- Implementation: `to_snapshot` emits `last_sim_time` and `ship.get_summary` at `:201-212`; `from_snapshot` restores time and calls `ship.apply_summary` at `:243-248`.
- Predicate/gap: `scripts/validation/ship_runtime_smoke.gd:88-94` checks ship ID/schema and `:96-110` restores into another instance, but asserts only `last_sim_time`. Despite the test comment, no restored ship-summary field is compared.
- Status: `source_mapped_partial`.

### `REQ-ARCH-004::acceptance-299e409b44f3`

**Criterion:** Two independent ShipRuntimes advance without cross-mutation.

- Production route: `_advance_ship` creates/configures a runtime for the supplied ship at `scripts/procgen/playable_generated_ship.gd:1990-2017`.
- Implementation: each runtime holds per-instance ship/hull/web references at `scripts/systems/ship_runtime.gd:27-39` and mutates only those references in `advance` at `:121-144`.
- Predicate: `scripts/validation/ship_runtime_smoke.gd:112-125` asserts the second runtime's web advances; `:126-131` advances it again and asserts the first runtime's web is unchanged.
- Status: `traced`.

### `REQ-ARCH-004::acceptance-5afe45cb549e`

**Criterion:** compose_runtime_snapshots bundles multiple runtimes under a stable schema.

- Production route: `ShipRuntime.compose_runtime_snapshots` is the explicit composition entry at `scripts/systems/ship_runtime.gd:320-326`.
- Implementation: it calls `to_snapshot` per valid runtime and returns `{"schema":"ship_runtime_bundle_v1","ships":...}`.
- Predicate: `scripts/validation/ship_runtime_smoke.gd:133-140` composes two runtimes, asserts the exact schema, and asserts two ship entries.
- Status: `traced`.

### `REQ-ARCH-005::acceptance-b312bb9d3961`

**Criterion:** Present ships advance through _tick_present_ships (ShipRuntime) on both branches.

- Production route: away `_process` calls `_tick_present_ships` at `scripts/procgen/playable_generated_ship.gd:11041-11067`; home `_process` calls it at `:11068-11087`.
- Implementation: `_tick_present_ships` advances home and, while away, the current ship at `:11094-11100`; `_advance_ship` delegates to ShipRuntime at `:1990-1993`.
- Predicate/gap: `scripts/validation/generated_seed_boarded_slice_smoke.gd:199-218` drives away `_process` and observes exact cooldown decrement done only by `_tick_present_ships`; `ship_runtime_smoke.gd:31-45` tests ShipRuntime directly. No existing assertion found drives home `_process` and observes this route.
- Status: `source_mapped_partial`.

### `REQ-ARCH-005::acceptance-0b35305896d8`

**Criterion:** Sanity, arc, ammo/consumable decay, audio, and food helpers are shared — no home-only reimplementation for those systems.

- Production route: away `_process` calls the helpers at `scripts/procgen/playable_generated_ship.gd:11049,11055,11061-11063`; home calls the same helper names at `:11078-11084`.
- Implementation: the single definitions are `_tick_sanity_and_hallucinations` at `:11146-11161`, `_tick_electrical_arc` at `:11164-11168`, `_tick_ammo_and_consumable_decay` at `:11171-11177`, `_tick_audio_runtime` at `:11197`, and `_tick_food_runtime` at `:11372`.
- Predicate: away consequences are asserted by `main_playable_hallucination_smoke.gd:129-139`, `derelict_arc_smoke.gd:141-161`, `consumables_away_tick_smoke.gd:49-58`, `audio_pipeline_smoke.gd:125-140`, and `food_away_tick_smoke.gd:73-85`. Reviewing both `_process` bodies and the single shared helper definitions establishes the no-home-only-reimplementation constraint; a test mirroring helper call names is not required.
- Status: `traced`.

### `REQ-ARCH-005::acceptance-c95b7789a3de`

**Criterion:** Away survival smoke still PASSes with away_ticks.

- Production route: the smoke's `_pump` drives live away `_process` at `scripts/validation/main_playable_survival_away_smoke.gd:106-111`; away survival runs at `scripts/procgen/playable_generated_ship.gd:11041-11067`.
- Predicate: `main_playable_survival_away_smoke.gd:49-57` asserts radiation drain, `:59-65` temperature rise, `:67-89` O2 effects, and `:91-100` death without extraction. `:102-104` prints the `away_ticks=true` marker only afterward.
- Execution limit: this is a predicate trace only; no fresh PASS is claimed.
- Status: `traced`.

### `REQ-ARCH-006::acceptance-c53361640f00`

**Criterion:** ShipRuntime exposes FRAME/SLOW/LAZY band polling with fixed intervals.

- Production route: `ShipRuntime.poll_bands` is public at `scripts/systems/ship_runtime.gd:147-172`.
- Implementation: FRAME is true for each positive delta; SLOW and LAZY use fixed 0.35 and 3.0 second constants at `:19-21,149-172`.
- Predicate: `scripts/validation/tick_bands_smoke.gd:19-43` checks many FRAME hits, at least four SLOW hits, and zero LAZY hits over 2 seconds; `:45-53` checks LAZY by 3.5 seconds. Stable constants plus these behavioral distinctions cover the stated fixed-band contract. The criterion does not bind exact numeric values, so direct 0.35/3.0 equality assertions are not required. The registry verification source misspells the filename as `ick_bands_smoke.gd`.
- Status: `traced`.

### `REQ-ARCH-006::acceptance-b1ce11560455`

**Criterion:** Present-ship systems advance every frame; hub expanded recompute is SLOW-banded.

- Production route: every eligible home/away `_process` call reaches `_tick_present_ships` at `scripts/procgen/playable_generated_ship.gd:11041-11087`.
- Implementation: `_tick_present_ships` calls `_advance_ship` before any gate at `:11094-11100`, then calls `_recompute_expanded_ship_systems` only when `_hub_slow_acc` reaches the SLOW interval at `:11107-11111`.
- Predicate/gap: `tick_bands_smoke.gd:22-43` validates generic ShipRuntime cadence, while `generated_seed_boarded_slice_smoke.gd:199-218` observes away per-frame `_tick_present_ships` work. Neither observes systems-manager advance per coordinator frame nor counts hub recomputes below/at the threshold; the band smoke never enters the coordinator.
- Status: `source_mapped_partial`.

### `REQ-ARCH-006::acceptance-20996f1e9789`

**Criterion:** Catch-up uses LAZY-aligned quanta and is still bounded.

- Production route: `_catch_up_ship` delegates an absent ship to `ShipRuntime.catch_up` at `scripts/procgen/playable_generated_ship.gd:2020-2023`.
- Implementation: catch-up caps elapsed time to 1800 seconds, selects `min(5, 3)` seconds as the quantum, and advances in steps no larger than it at `scripts/systems/ship_runtime.gd:16-21,179-192`.
- Predicate/gap: `scripts/validation/tick_bands_smoke.gd:55-61` only asserts `catch_up(30)` increases `lazy_band_fires`; `ship_catchup_smoke.gd:81-91` asserts fixed-time idempotence. Neither asserts ten 3-second steps, any individual step size, or an above-1800 cap. The smoke variable named `bounded` proves idempotence, not the maximum bound.
- Status: `source_mapped_partial`.

## Review gaps

- Add a systems-manager observable to the ShipRuntime advance test.
- Assert catch-up step sizes/count and a gap exceeding the 1800-second cap.
- Compare restored ShipInstance summary fields after `from_snapshot`.
- Drive and observe `_tick_present_ships` on the home branch.
- Count coordinator hub recomputes before and at the SLOW boundary.
- Clarify whether REQ-ARCH-002's “const fallbacks” means caller-supplied constants or catalog-owned key-specific constants before changing the catalog contract.
