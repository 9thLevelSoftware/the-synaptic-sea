# R17 authored audio bus config brief

This is a source-only preparation brief based on the reviewed R17 audio trace.
No runtime, Godot, smoke, registry, specification, or governance change was
made.

## Established finding

The reviewed audit at
`r17-audio-feature-leaf-trace-reviewed.md` records AU002's root cause as
`canonical_bus_resource_bypass`: the authored resource
`res://data/audio/audio_bus_config.tres` exists with the seven specified buses,
but production `AudioManager` initializes `bus_config` with
`AudioBusConfig.make_default()` at `scripts/audio/audio_manager.gd:49`.
`PlayableGeneratedShip` constructs the manager at
`scripts/procgen/playable_generated_ship.gd:1736-1749`.

This proves the authored resource is bypassed. It does not prove that current
factory constants differ from the authored values, that an end user currently
hears an incorrect level, or that save/load overrides are broken: the existing
defaults happen to mirror the seven `.tres` values, and override persistence is
covered separately.

## Exact design requirement

`docs/game/features/audio-music-spatial.md:29-32` defines REQ-AU-002:

> Given the canonical bus config `res://data/audio/audio_bus_config.tres`, when
> the playable loads, the master, sfx, music, voice, ui, ambient, and meta buses
> exist with default dB values matching the spec.

The same feature's stop condition at lines 102–105 says a missing bus config
cannot be defaulted in code without losing schema validation. Therefore the
production default must load and validate the authored `AudioBusConfig`
resource, with an explicit failure path if it is missing or invalid. Factory
construction may remain a narrow fallback only where an existing detached test
contract explicitly requires it; it must not be the playable production source
of truth. Because Godot `ResourceLoader` caches loaded `Resource` instances,
the loaded authored resource must be duplicated/detached into each manager's
validated mutable `AudioBusConfig` state before settings setters or
`apply_summary` can mutate it. A manager must never mutate the cached authored
resource or share mutable bus arrays with another manager.

## Current construction and override order

The relevant current order is:

1. Project settings register `res://data/audio/default_bus_layout.tres` as the
   engine `AudioServer` bus layout (`project.godot:[audio]`). That resource
   contains the seven engine buses and matching dB values.
2. Main playable setup reaches
   `scripts/procgen/playable_generated_ship.gd:1736-1749`, constructs and adds
   `AudioManager` after hazard setup, and currently receives a factory model from
   `scripts/audio/audio_manager.gd:49`.
3. `AudioManager._apply_bus_volumes()` at
   `scripts/audio/audio_manager.gd:207-229` pushes the model's values into the
   live `AudioServer`; absent engine buses are skipped in headless mode.
4. User changes from `scripts/ui/audio_settings_panel.gd:150-183` call
   `AudioManager.set_bus_volume` / `set_bus_muted`, which mutate the model and
   immediately push live values through `_apply_bus_volumes()`.
5. Save capture stores `audio_manager.get_summary()` in
   `PlayableGeneratedShip._build_run_snapshot` (`scripts/procgen/playable_generated_ship.gd:12707-12711`)
   as `RunSnapshot.audio_summary` (`scripts/systems/run_snapshot.gd:44-45,205-206`).
6. On restore, `PlayableGeneratedShip._apply_run_snapshot` applies settings first
   and then calls `audio_manager.apply_summary(snapshot.audio_summary)` at
   `scripts/procgen/playable_generated_ship.gd:13519-13528`; the bus sub-summary
   updates the loaded authored baseline and re-pushes the live server.

`TopDownPlayableShip._init_systems` also constructs an `AudioManager` directly
at `scripts/topdown/topdown_playable_ship.gd:105-118`. If that path remains a
supported production path, it must use the same authored-resource construction
seam or be explicitly classified as a separate non-production fixture.

## Minimal likely source/test allowlist

The implementation should begin with this narrow allowlist and expand only for
a demonstrated compile or regression failure:

- `data/audio/audio_bus_config.tres` — authored resource; inspect/repair only
  if schema or values are demonstrated inconsistent.
- `scripts/audio/audio_manager.gd` — load/validate the resource in the
  production constructor or an injected factory; detach validated mutable state
  per manager; preserve model setters, `apply_summary`, and headless tolerance.
- `scripts/procgen/playable_generated_ship.gd` — pass the authored resource or
  factory dependency at construction if required by the chosen seam.
- `scripts/topdown/topdown_playable_ship.gd` — only if this remains a supported
  playable path and otherwise bypasses the same seam.
- `scripts/validation/audio_bus_config_smoke.gd` — preserve pure schema/factory
  coverage and add authored-resource loading/identity assertions if necessary.
- `scripts/validation/main_playable_slice_audio_smoke.gd` and
  `scripts/validation/audio_pipeline_smoke.gd` — assert the production manager
  starts from the authored values and that live AudioServer buses agree.
- `scripts/validation/audio_save_load_smoke.gd` — retain the non-default user
  override round trip and add a fresh-manager assertion that the authored
  baseline is applied before the saved override.

No broad audio catalog or playback rewrite is implied. A new focused smoke is
appropriate only if the existing main-scene smoke cannot distinguish authored
resource loading from identical factory constants.

## Behavioral acceptance

The focused acceptance should establish all of the following on the same
production construction path:

- With a fresh run and no save override, every one of the seven bus IDs,
  parent relationships, dB values, and mute flags come from the authored
  `audio_bus_config.tres`; an intentionally changed authored fixture must change
  the observed baseline or be rejected by validation. Do not accept a test that
  merely compares two copies of the same factory constants.
- Missing, malformed, duplicate, unknown, or out-of-range authored bus data
  fails clearly at the resource/schema boundary and does not silently fall back
  to `make_default()` in production.
- A player adjustment through the real audio settings panel changes the live
  bus and is captured in `audio_summary`.
- After save and reload, the saved volume/mute override wins over the authored
  default for the specified buses, while unspecified buses retain the authored
  values. The existing `AudioBusConfig.apply_summary` partial-apply behavior at
  `scripts/systems/audio_bus_config.gd:194-215` should remain intact.
- A fresh run after the override is cleared returns to the authored baseline;
  no prior user override leaks through process or scene construction.
- Main playable and any supported top-down construction paths agree on the
  authored baseline, and the live `AudioServer` values match after application.
- Two managers or fresh scene instances created from the same authored resource
  receive detached mutable state: changing volume/mute in one manager must not
  change the other manager, the cached authored resource, or the next fresh
  manager's baseline. This regression must exercise both a direct settings
  setter and `apply_summary`.
- Existing sound, caption, music, ambient, spatial, meta-event, and save/load
  behavior remains unchanged except for the source of initial bus defaults.

The reviewed trace already records existing save/override evidence
(`audio_save_load_smoke.gd:74-141`) and identifies the missing authored-resource
proof. Reuse that evidence for override behavior; add only the source-identity
and invalid-resource cases needed to close AU002. No product acceptance is
claimed by this brief.
