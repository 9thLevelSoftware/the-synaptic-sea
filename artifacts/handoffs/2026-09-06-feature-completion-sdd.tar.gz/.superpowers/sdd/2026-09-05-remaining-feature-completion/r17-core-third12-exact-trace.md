# R17 Core Third-12 Exact Trace

- Generated: `2026-09-05T22:41:20.8735844-04:00`
- Source revision: `cb3a7f52017befe81dc1f39ab48962bdda68d743`
- Moving WIP: `true`
- Scope: source-only trace; no runtime/test execution, evidence promotion, Git, registry/index writes, or complete-game acceptance
- Registry filter: `domain == "core" && deferred == false`
- Active core rows: `49`
- Prior range explicitly excluded: all 24 exact IDs in `r17-core-first12-exact-trace.json` and `r17-core-second12-exact-trace.json`, including all partial dispositions
- Selection: next 12 rows, zero-based registry indices `396..407`, core orders `25..36`; the semantic index was not used as the sole exclusion source
- Result: `4 traced`, `3 superseded_historical_replacement_traced`, `1 superseded_historical_current_replacement_differs`, `3 source_mapped_validation_gap`, `1 source_mapped_authority_conflict`, `0 runtime defects found`, `0 fresh executions`

Selected IDs, in exact order:

1. `REQ-010::acceptance-4044b27bf2db`
2. `REQ-010::acceptance-4df9b6408012`
3. `REQ-010::acceptance-483db44ee513`
4. `REQ-010::acceptance-4218fa06d7c3`
5. `REQ-011::acceptance-25fe7dbde79d`
6. `REQ-011::acceptance-f0c739b18477`
7. `REQ-011::acceptance-55ae2ca75907`
8. `REQ-011::acceptance-e1142f2fa3d7`
9. `REQ-012::acceptance-43d907f1e012`
10. `REQ-012::acceptance-58c70217c782`
11. `REQ-012::acceptance-438c37595390`
12. `REQ-012::acceptance-19e6269ad126`

All four REQ-010 rows remain active, distinct, self-representative denominator rows: `deferred=false`, no `canonical_id` or `alias_of`, and `counts_toward_proposed_denominator=true`. Their declared status and requirement owner explicitly classify the Gate 2 criteria as historical and superseded by accepted ADR-0041. This report preserves their IDs and frozen accounting while tracing current `FireSuppressionState`; it does not claim retired `FireState` behavior.

REQ-011 uses the actual production chain `scenes/main.tscn` -> `scripts/main.gd` -> `playable_coherent_ship.tscn` -> `coherent_ship_001`. REQ-012 now writes a WorldSnapshot envelope at `current_run.json`. Accepted ADR-0033 permits cross-run meta state in WorldSnapshot while preserving the narrower no-meta-in-RunSnapshot rule. That later authority conflicts with the still-active REQ-012 leaf's broader literal prohibition, so authority reconciliation is required before acceptance accounting can resolve the row.

Static review establishes authority, artifact identity, construction shape, and negative architecture constraints. Dynamic behavior is credited only where an existing smoke contains a meaningful predicate. PASS-marker text is not treated as a predicate, and no fresh PASS is claimed.

## Exact leaf traces

### `REQ-010::acceptance-4044b27bf2db`

**Criterion:** At least one additional hazard type exists in the generated ship scene (the timed fire zone in a side corridor for Gate 2).

- Entry: PlayableGeneratedShip constructs/configures `FireSuppressionState` at `scripts/procgen/playable_generated_ship.gd:1931-1932`. `_tick_active_fire` at `:1963-1976` calls the model and refreshes the burning-set scene nodes.
- Implementation: `_build_fire_zones` maps burning compartments to authored away-ship markers or distributed fallbacks at `:6659-6723`, then creates and attaches passable `Area3D` visual/lookup zones at `:6724-6758`. ADR-0041:28-44 expressly replaces the timed side-corridor design with persistent compartment fire.
- Predicate: `main_playable_slice_fire_smoke.gd:35-48` forces a current-model fire and requires a rendered `Area3D` that is not `StaticBody3D`; `fire_suppression_state_smoke.gd:27-37` requires ignition and persistence.
- Disposition: current replacement behavior is covered. The retired timer/side-corridor conjunct is not claimed.
- Status: `superseded_historical_replacement_traced`.

### `REQ-010::acceptance-4df9b6408012`

**Criterion:** ~~The new hazard toggles real passability via its own pure state model (`FireState`).~~ **Superseded by ADR-0041** (see note).

- Entry: `scripts/systems/fire_state.gd` is absent. PlayableGeneratedShip creates the replacement at `playable_generated_ship.gd:1931-1932` and ticks it at `:1963-1976`.
- Implementation: `scripts/systems/fire_suppression_state.gd` is the pure `RefCounted` owner. The coordinator records the retirement/passable replacement at `playable_generated_ship.gd:3720-3725` and creates passable `Area3D` zones at `:6724-6740`.
- Predicates: `fire_suppression_state_smoke.gd:27-132` asserts current ignite/persist/extinguish/auto-suppress/vent/spread/reignite/cascade/round-trip behavior. `main_playable_slice_fire_smoke.gd:35-48` asserts the live zone is `Area3D`, not `StaticBody3D`.
- Disposition: exact struck-through identity and ADR-0041 supersession are preserved; no retired `FireState` claim is made.
- Status: `superseded_historical_replacement_traced`.

### `REQ-010::acceptance-483db44ee513`

**Criterion:** The new hazard does not alter oxygen, route-gate, or extraction semantics.

- Entry: `_tick_active_fire` applies current fire evolution and system/module damage at `playable_generated_ship.gd:1963-1976`. `_refresh_oxygen_state` derives fire oxygen drain from active intensity and passes it to OxygenState at `:11587-11612`.
- Implementation: current fire deliberately has stronger cross-system behavior. ADR-0041:95-104 requires vitals and ship-system damage; `scripts/systems/oxygen_state.gd:120,132-168` currently subtracts `fire_oxygen_drain`. Route and extraction remain independently owned, but the historical no-oxygen-effect conjunct is not current behavior.
- Predicates: `main_playable_slice_fire_smoke.gd:54-81` requires health and mapped power-system health to decrease. `unlock_trigger_stream_f_smoke.gd:91-96,175-192` requires the fire-oxygen channel to decrease oxygen.
- Disposition: these predicates prove later behavior, not the historical criterion. ADR-0041 and REQ-010's superseded note make this an intentional replacement difference rather than a current runtime defect.
- Status: `superseded_historical_current_replacement_differs`.

### `REQ-010::acceptance-4218fa06d7c3`

**Criterion:** Both a direct model smoke and a main-scene smoke pass.

- Entry: current boundaries are `FireSuppressionState` and PlayableGeneratedShip's fire tick/zone path.
- Static implementation: `docs/game/06_validation_plan.md:433,438-439` registers `fire_suppression_state_smoke.gd`, `main_playable_slice_fire_smoke.gd`, and the full-loop main smoke. The retirement note at `:1239` removes the old `fire_state_smoke` contract.
- Predicates: `fire_suppression_state_smoke.gd:27-132` asserts the current model. `main_playable_slice_fire_smoke.gd:35-81` asserts live zone/passability/vent/teeth; `main_playable_fire_loop_smoke.gd:70-150` adds damaged+oxygen ignition, real-dispatch extinguish, reignition, repair stop, and recharge.
- Status: `superseded_historical_replacement_traced`.

### `REQ-011::acceptance-25fe7dbde79d`

**Criterion:** At least one new objective kind (`repair_junction`) requires multiple interactions in the same room before the sequence advances.

- Entry: `main_playable_slice_objective_variation_smoke.gd:3,10-16` instantiates `scenes/main.tscn`. `scripts/main.gd:5-23` selects `playable_coherent_ship.tscn`, whose `:5-9` selects coherent_ship_001. Its gameplay slice defines sequence 2 as a two-step `repair_junction` of type `restore_systems` in `maintenance_01` at `data/procgen/golden/coherent_ship_001/gameplay_slice.json:34-50`.
- Implementation: `_build_interactables` registers one shared ObjectiveProgressState sequence and creates one interactable per step at `playable_generated_ship.gd:10377-10420`. `_on_interactable_completed` records a step and returns while incomplete at `:10683-10721`.
- Predicates: `main_playable_slice_objective_variation_smoke.gd:44-59` requires 2 steps and 2 live interactables; `:61-90` completes the first sequence and the junction, then requires system/route/progress consequences. `objective_progress_state_smoke.gd:20-59` requires one distinct step to remain incomplete and two to complete.
- Status: `traced`.

### `REQ-011::acceptance-f0c739b18477`

**Criterion:** Multi-step completion advances ship-system and route-control state exactly once.

- Entry: `_on_interactable_completed` returns on duplicate/unchanged steps and until the model reports complete at `playable_generated_ship.gd:10705-10721`. Only then does the shared path increment `objective_completion_count` and apply ship-system/route consequences at `:10723-10749`.
- Implementation: `ObjectiveProgressState.complete_step` is idempotent by step ID at `scripts/systems/objective_progress_state.gd:115-132`. Source has one fall-through application site for the sequence.
- Predicates: `objective_progress_state_smoke.gd:36-59` asserts duplicate idempotence and second-step completion. `main_playable_slice_objective_variation_smoke.gd:66-85` requires final power and route state.
- Gap: neither smoke measures a mutation count or `objective_completion_count` delta around sequence 2. The direct smoke's line 76 `applied_once=true` is literal marker text; the smoke never owns or invokes the ship-system/route application path.
- Status: `source_mapped_validation_gap`.

### `REQ-011::acceptance-55ae2ca75907`

**Criterion:** Single-step objectives remain backward compatible.

- Entry: coherent_ship_001 retains single-step sequences 1, 3, and 4 at `gameplay_slice.json:21-32,52-76`. `_build_interactables` routes every non-multi-step objective through the established `configure_from_objective` path at `playable_generated_ship.gd:10421-10430`.
- Implementation: the completion handler bypasses the multi-step model gate when the pre-required count is one and enters the same system/route path at `:10701-10749`.
- Predicate: `main_playable_slice_objective_variation_smoke.gd:61-64` completes real single-step sequence 1, then `:92-105` completes real single-step sequences 3/4 and requires extraction plus run completion.
- Status: `traced`.

### `REQ-011::acceptance-e1142f2fa3d7`

**Criterion:** Both a direct model smoke and a main-scene smoke pass.

- Entry: pure ownership is ObjectiveProgressState; live ownership is PlayableGeneratedShip's interactable/completion path.
- Static implementation: `docs/game/06_validation_plan.md:449-450` registers both exact smokes. The main smoke uses the production main/coherent_ship_001 chain.
- Predicates: `objective_progress_state_smoke.gd:6-74` asserts initial 0/2 state, one-step incompleteness, duplicate idempotence, second-step completion, and summary IDs. `main_playable_slice_objective_variation_smoke.gd:44-105` asserts the live two-step group, power/route consequences, single-step compatibility, extraction, and completion.
- Note: the marker's `applied_once=true` is not reused as evidence for the separate exactly-once leaf.
- Status: `traced`.

### `REQ-012::acceptance-43d907f1e012`

**Criterion:** Runtime state (player position, objective sequence, ship systems, route control, oxygen, inventory, fire, objective progress) can be serialized to `user://saves/current_run.json`.

- Entry: `_build_run_snapshot` captures paths, player position, objective sequence, ship/expanded summaries, route, oxygen, inventory, and objective progress at `playable_generated_ship.gd:12636-12703`. `_expanded_ship_systems_summary` obtains the authoritative FireSuppressionState summary at `:2092`; `_build_run_snapshot` nests it into `ship_systems_summary` at `:12656-12664`, while the legacy top-level fire field stays empty at `:12692-12695`.
- Implementation: RunSnapshot owns/deep-copies the named fields at `scripts/systems/run_snapshot.gd:30-41,189-202,285-299`. `SaveLoadService.save_current_run` maps the active autosave to `user://saves/current_run.json` at `scripts/systems/save_load_service.gd:24-37,119-136`; `save_to_slot` wraps it in WorldSnapshot and writes JSON at `:786-827`, following accepted ADR-0012.
- Predicate: `save_load_service_smoke.gd:179-240` writes/loads the slot and requires exact paths, position, sequence, and deep equality for ship, route, oxygen, inventory, legacy fire, and objective progress.
- Gap: the smoke's `fire_summary` is an expressly legacy literal at `:63-66`; its constructed ship summary has no live FireSuppressionState. The main save/load smoke never ignites or asserts nested `fire_suppression_summary`. Current authoritative fire serialization is source-mapped without an exact disk predicate.
- Status: `source_mapped_validation_gap`.

### `REQ-012::acceptance-58c70217c782`

**Criterion:** Loading the snapshot reconstructs the same slice and restores all captured state before the next tick.

- Entry: `request_load` prepares and synchronously commits the world at `playable_generated_ship.gd:13076-13098`. `Main.replace_playable_from_prepared` builds a disabled staging instance, validates it, disables the prior instance, activates/switches the staged instance, and returns at `scripts/main.gd:26-87`.
- Implementation: `_apply_run_snapshot` synchronously reloads saved paths and applies ship/fire, route, oxygen, inventory, objective progress, and other summaries at `playable_generated_ship.gd:13104-13231`; it rebuilds fire/interaction consequences, activates the restored sequence, and teleports last before returning at `:13350-13385`. The chain yields no process frame.
- Predicate: `main_playable_slice_save_load_smoke.gd:96-117` moves the player, calls `request_load`, and immediately requires restored sequence, position within 0.01, and recovered-supplies state before another frame. `save_load_service_smoke.gd:191-240` proves disk reconstruction of the named dictionaries.
- Gap: no main-scene predicate seeds and checks all captured live model summaries after the staged swap. Authoritative nested fire is the clearest missing conjunct. Source ordering establishes the before-next-tick structure, but full live-state restoration remains partially unverified.
- Status: `source_mapped_validation_gap`.

### `REQ-012::acceptance-438c37595390`

**Criterion:** Save/load is current-run only: no hub state, meta-currency, unlocks, or cross-run progress is persisted (enforced by ADR-0007).

- Entry: current `request_save` builds WorldSnapshot. `_build_world_snapshot` explicitly captures `meta_progression_state.to_dict()` and `unique_item_state.get_summary()` at `playable_generated_ship.gd:13462-13485`. WorldSnapshot serializes `meta_progression_summary` beside `home_ship` at `scripts/systems/world_snapshot.gd:21-34,55-75`, and restore applies it at `playable_generated_ship.gd:13823-13826`.
- Authority: accepted ADR-0033:23-35 amends ADR-0007, preserves no meta in RunSnapshot, and explicitly allows `meta_progression_summary` in WorldSnapshot as world-scope state. That does not match this still-active leaf's literal prohibition on persisting meta-currency, unlocks, or cross-run progress at all. WorldSnapshot also carries explicit home/visited-ship state. RunSnapshot's `ship_modification_summary` is labeled a hub-ship manifest at `scripts/systems/run_snapshot.gd:110-111`, while accepted ADR-0059:111-125 says ShipModificationState is derived with no second serialized component summary.
- Static disposition: current schema and capture source establish the presence of meta state. A mirror test for absence is neither needed nor appropriate. The unresolved issue is authority/registry reconciliation: the row has no canonical/alias mapping and still counts toward the frozen denominator.
- Status: `source_mapped_authority_conflict`.

### `REQ-012::acceptance-19e6269ad126`

**Criterion:** The save slot is deleted when the run completes.

- Entry: the logical completion path sets `slice_complete` and enters the completion branch at `playable_generated_ship.gd:10764-10776`, then calls `delete_current_run`, removes rotating autosaves, and emits completion at `:10777-10795`.
- Implementation: `SaveLoadService.delete_current_run` removes `current_run.json` and `world.json` and clears their index rows at `scripts/systems/save_load_service.gd:727-757`; `has_save` checks both paths at `:759-764`.
- Predicates: `main_playable_slice_save_load_smoke.gd:119-125` completes all objectives and requires `has_save()` false. `save_load_service_smoke.gd:360-364` independently deletes the current slot and requires the same result.
- Status: `traced`.

## Review disposition

- The four REQ-010 leaves stay in the frozen denominator exactly as registered. ADR-0041 governs their current replacement semantics; old timer/blocker/no-oxygen claims are not inferred from current fire.
- REQ-011's repair-junction shape and single-step compatibility have exact predicates. Its ship-system/route exactly-once conjunct remains source-mapped because the only `applied_once=true` occurrence is marker text.
- REQ-012 disk serialization and staged restore cover most named state, but current nested fire lacks an exact round-trip/live-restore predicate.
- REQ-012's no-meta leaf conflicts with accepted ADR-0033 and current WorldSnapshot capture. This is an explicit authority/registry gap, not a request for an implementation-mirroring absence test.
