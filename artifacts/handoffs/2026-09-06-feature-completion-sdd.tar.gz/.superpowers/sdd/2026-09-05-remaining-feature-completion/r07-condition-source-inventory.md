# R07 condition/effective-health source inventory

Read-only inventory for Task 7 (R07 / P14 / FC-16), against the current
`codex/feature-completion` checkout. This records source state only; it does
not claim implementation or validation.

## Authority already present

- `scripts/systems/component_placement_state.gd:13-27` defines
  `CONDITION_AUTHORITY_VERSION`, `placed`, `condition_authority_version`, and
  `condition_lot_sequence`. `prepare_condition_authority` (439),
  `commit_condition_authority` (532), `get_summary` (549), `apply_summary` (576),
  and `restore_from_layout` (643) provide detached allocation, persistence,
  and restore. `_entry_from_saved` (765) copies a valid `source_lot.condition`
  into the placement mirror (794).
- `ComponentPlacementState.dismount` (859) marks the entry unmounted and
  returns the exact valid `item_lot` (889-895), while `restore_dismounted`
  (898) rolls back a failed inventory return. `mount_by_slot_id` (924) validates
  slot/catalog/fit/inventory/source lot and preserves incoming lot condition
  (989-991). This is the existing lot/placement boundary. It does not derive
  effective ship health or provider aggregation.
- `scripts/systems/component_mount_resolver.gd:10-42` resolves dismount and
  `:58-113` resolves mount through the placement owner. It intentionally leaves
  inventory and scene consequences to callers.
- `scripts/systems/ship_subcomponent.gd:8-14,30-46,50-70` owns persisted
  intrinsic `health`, operational threshold, intrinsic `is_functional`, and
  paid intrinsic repair. `scripts/systems/ship_system.gd:29-45` aggregates
  intrinsic health and intrinsic self-functionality only.
- `scripts/systems/ship_systems_manager.gd:98-122` exposes intrinsic
  `get_system`/`is_operational`; `repair`/`repair_with_inventory` (140-168),
  `force_repair` (174-183), `damage_system` (186-192), and
  `damage_subcomponent` (196-203) mutate intrinsic health. `get_status_summary`
  (223-228) reports intrinsic health. There is currently no placement binding,
  provider list, effective-health query, effective-functionality query, or
  atomic intrinsic-plus-provider repair API. `restore_subcomponent_on_remount`
  (206-220) is the obsolete install healing floor.
- `scripts/systems/ship_modification_state.gd:50-123,143-324` binds physical
  slots and syncs installed rows; it derives power draw and station manifest
  state. `hull_plating_bonus` (23), `sync_from_placement` (91-123), and
  `structure_damage_resist` (322-324) still model plating as a fixed +0.05
  per installed plating row and resistance as `bonus * 2`; there is no
  condition-weighted plating projection.
- `scripts/systems/crafting_state.gd:183-207` has the existing static
  component-derived station-tier helper, and `refresh_station_tier` (643-657)
  applies it. It reads mounted entries/catalog bonuses but does not gate the
  bonus by provider condition or bind to effective health.
- `scripts/tools/repair_point.gd:108-188` prechecks the raw subcomponent's
  `is_functional`; `_target_revision` (337-345) fingerprints raw `sub.health`;
  `_commit_reserved_repair` (360-377) calls `ShipSystemsManager.repair`.
  Repair is already timed/reserved/paid, but it is not routed through a
  connected-provider/disconnected-target authority and cannot repair intrinsic
  plus one deterministic provider atomically.

## Production bypasses and missing R07 behavior

The following are live production call sites, not isolated test helpers:

- `scripts/procgen/playable_generated_ship.gd:2039-2042` feeds
  `power_grid_state.rebalance` with `get_system("power").health()`.
- `:3552-3557` creates repair points by calling `sub.is_functional()` directly;
  `:3907-3909` and `:3987-3989` choose fire candidates from
  `sys.is_self_functional()`; `:4067` applies fire through intrinsic
  `damage_system`.
- `:_apply_ship_mod_system_link` at `:5559-5569` calls
  `restore_subcomponent_on_remount(..., 0.55)` on install and
  `damage_subcomponent(..., 0.6)` on uninstall. These are the explicit healing
  floor and dismount intrinsic damage rejected by ADR-0066.
- `:_apply_ship_mod_plating_repair` at `:5571-5604` identifies plating and calls
  module `repair(0.15)` on the first damaged/breached module. This is the
  install-time plating integrity write rejected by ADR-0066. Its install call
  is at `:4719-4722`; the replay path calls linked effects at `:5625-5634` via
  `_reapply_ship_mod_runtime_effects`, so restore can replay side effects.
- `:_refresh_station_tiers_from_ship_mod` at `:5637-5668` projects installed
  and placement rows into `CraftingState.refresh_station_tier` without the
  ADR-required `min_operational_ratio` condition gate.
- `:_apply_lifeboat_opening_damage` at `:8287-8300` directly writes every
  propulsion subcomponent to `1.0` and then `nav_linkage` to
  `DAMAGED_HEALTH`; ADR-0066 names an explicit manager initializer as the
  allowed form, so this remains a direct field-write seam to review.
- `_sub_health`/`_sub_functional` at `:11165-11179` read raw subcomponent
  health/functionality. `_manager_compat_summary` (`:11187-11202`) uses those
  values for power restoration, reactor stability, route clearing, extraction,
  and HUD percentages. This is a production effective-health bypass.
- Additional raw manager consumers are `:2485-2489` and `:10957-10957`/`14927-14931`
  (`force_repair` objective/validation bridges), and `scripts/tools/repair_point.gd`
  (`:119-123`, `:340-350`). These need classification as intrinsic initializer,
  repair authority, or effective production decision during R07.

## Already implemented versus missing

Implemented foundations: durable placement rows; source lot validation and
condition mirroring; detached condition-lot allocation/commit; exact lot return
on dismount; ordinary intrinsic health persistence; intrinsic paid repair;
physical mount resolver; power budget preflight; station tier projection;
timed repair transaction and target revision; plating resistance projection
hook; and save/restore summaries for placement and ship systems.

Missing for ADR-0066/R07: manager-to-placement binding; stable provider
aggregation per `(system_id, subcomponent_id)`; mapped effective health
`min(intrinsic, max(provider condition))`; disconnected effective zero;
effective functionality/dependency resolution/status/advance consumers;
single-owner damage routing; intrinsic-plus-deterministic-provider paid repair;
condition-gated station tier; condition-weighted plating resistance; removal
of install floor, dismount damage, replayed effect writes, and plating repair;
and production call-site migration from raw health/functionality.

## Existing meaningful coverage

There is no `tests/test_p14_health_authority.py` and no
`scripts/validation/fc_p14_smoke.gd` in this checkout. The registry marks both
planned/missing (`data/validation/feature_completion_cards.json`, P14 card
source rows; `data/validation/feature_completion_cases.json:15`). Existing
focused smokes that exercise the pre-R07 behavior are:

`component_mount_dismount_smoke.gd`, `component_system_link_smoke.gd`,
`ship_mod_system_effect_smoke.gd` and `_away`, `ship_mod_restore_effects_smoke.gd`
and `_away`, `ship_mod_plating_repair_smoke.gd` and `_away`,
`ship_mod_station_tier_smoke.gd` and `_away`,
`ship_mod_overbudget_power_smoke.gd` and `_away`, and
`ship_mod_run_snapshot_smoke.gd`. These are evidence of existing seams and
legacy semantics, not R07 acceptance evidence.

## P14 CARD_SMOKES membership

`tools/build_feature_acceptance.py:706-710` defines the current P14 list:

1. `fc_p14_smoke.gd` (planned/missing)
2. `ship_mod_overbudget_power_smoke.gd`
3. `ship_mod_station_tier_away_smoke.gd`
4. `ship_mod_run_snapshot_smoke.gd`

The P14 card metadata also lists the existing system-effect, restore-effect,
plating-repair, and away variants as source/related coverage, but they are not
members of `CARD_SMOKES["P14"]`. No P14 smoke has been run or promoted here.

## ADR-0066 acceptance obligations relevant to implementation

ADR-0066 requires source lot condition as canonical with placement as an atomic
mirror; intrinsic ship health persisted independently; provider max aggregation;
mapped disconnected zero; unmapped intrinsic health; damage once to provider or
intrinsic owner; connected paid repair of intrinsic plus first stable provider;
full quality-adjusted power draw; tier bonus only at condition >= 0.5; plating
resistance `clamp(2 * sum(0.05 * mounted_plating_condition), 0, 0.5)`; and no
install/remove/replay health or integrity writes. Its final scene proof is ten
timed install/dismount cycles with exact lot identity/condition/provenance,
damaged remount, healthy replacement, paid repair, multiple providers,
condition-gated tier, power rollback, weighted plating, detached initialization,
and disk save/load without effect replay.

