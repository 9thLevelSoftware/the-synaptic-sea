# R06 focused physical-work runner report

Date: 2026-09-06 (America/New_York)  
Workspace: `D:\the-synaptic-sea-feature-completion`

## Scope delivered

Added `tools/run_physical_work_smokes.py`, a narrow focused-suite adapter for
the accepted P11, P12, and P13 card groups. It imports the authoritative
`CARD_SMOKES` lists and marker extraction from `tools/build_feature_acceptance.py`,
then delegates every case to `execute_isolated_case` in the hardened feature
completion runner.

The adapter refuses any pre-existing evidence root, creates one separate owned
home beneath it for every focused case, retains the hardened runner's probe/raw
output/environment artifacts, and writes both per-case result JSON and an
aggregate `summary.json`. It emits `R06 Pxx FOCUSED PASS cases=N` only when all
delegated cases pass.

Added `tests/test_physical_work_runner.py`. The tests cover exact group
coverage, one unique home per case, immutable/reused evidence-root rejection
before launch, failed containment/body result propagation (including missing or
duplicate marker, diagnostic, timeout, and cleanup reasons), withheld aggregate
pass markers, and retained raw/result artifacts.

## Verification

Ran from the feature-completion workspace with the required Python runtime:

```text
.superpowers\test-runtime\Scripts\python.exe -m pytest -q tests/test_physical_work_runner.py tests/test_feature_completion_runner.py
36 passed in 1.29s
```

Also ran:

```text
.superpowers\test-runtime\Scripts\python.exe -m py_compile tools/run_physical_work_smokes.py
git diff --check -- tools/run_physical_work_smokes.py tests/test_physical_work_runner.py
```

No Godot, editor, import, or GDScript execution was run under this bounded
Python-only assignment.

## Afterimage hashes

| Path | SHA-256 |
| --- | --- |
| `tools/run_physical_work_smokes.py` | `0bba3d6423f0a998971a0b22e8792a908bc98c1493a8773c3ce7ea0b9895bc71` |
| `tests/test_physical_work_runner.py` | `2caa5ec1be00dc91bf56f29e347b3b03355f24230690652796e9a4b87ffc2c60` |
