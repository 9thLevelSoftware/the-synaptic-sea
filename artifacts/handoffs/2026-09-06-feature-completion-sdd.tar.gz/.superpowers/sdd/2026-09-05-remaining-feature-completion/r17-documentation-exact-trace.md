# R17 Doc-Domain Exact Trace

- Generated: `2026-09-05T23:23:48.5522211-04:00`
- Source revision: `ed70d37198000529cb8baa5217414f74a0372090`
- Moving WIP: `true`
- Scope: source-only trace; no Godot/runtime/test execution, evidence promotion, registry/index/governance/source changes, or complete-game acceptance
- Registry selection: `domain == "doc" && deferred == false`, excluding IDs already in `r17-source-trace-index.json.semantic_trace_reports`
- Frozen inventory: `668 recorded`, `657 active`, `622 canonical metric leaves`
- Selection: `12 domain rows`, `0 already semantically indexed`, `12 selected`; exact expected count matched
- Result: `8 traced`, `2 source_mapped_validation_gap`, `1 source_mapped_authority_scope_partial`, `1 stale_documentation_authority_mismatch`, `0 unresolved`, `0 fresh executions`, `0 evidence promotions`

The first eight leaves repeat the exact criterion “The currency claim above holds when the validators run with `ROOT` set.” They are not interchangeable. Each inherits a different claim from its REQ-DOC rationale, so this report traces each control path and predicate separately.

ADR-0040 remains the currency-policy authority, and the Mermaid/export ADR at `docs/game/adr/0048-mermaid-architecture-diagram-source-and-svg-exports.md` extends it. A later, distinct file reuses ADR number 0048 for the top-down pivot, but its explicit supersedes list contains only ADR-0010 and ADR-0017. Paths are treated as identities, matching the ADR index's number-reuse rule. Accepted ADR-0060 is the current Windows feature-completion engine authority: it selects exact Godot `4.7.2.stable.mono.official.ed1daf0bf` subject to program gates and expressly describes 4.6.2 as a downgrade. It identifies 4.7.1 as the documented macOS path, so older 4.7.1 project notes do not displace its Windows program decision.

The current program uses the `synaptic-sea-stage-gate` scope recorded by the generated local manifest. Task reports say generated local cards are current/operational while external synchronization remains pending because no board connector is available (`task-1-report.md:56-60`; `task-3-report.md:17-21,326-327`). ADR-0040's historical Task-15 Hermes manifest and validator remain scoped to `synaptic-sea-e2e-systems`; this report does not blanket-rename that legacy contract.

`traced` means current source plus a genuinely matching predicate or direct static review covers the full leaf. `source_mapped_validation_gap` means the route exists but its registered predicate can pass without proving an exact conjunct. `source_mapped_authority_scope_partial` preserves an external or historical fact as unknown. `stale_documentation_authority_mismatch` means a current-documentation claim conflicts with the accepted current authority; it does not assert that the production runtime failed and does not request a runtime change. None of these statuses is a registry promotion or fresh PASS claim.

## Key findings

- REQ-DOC-001's validator accepts any three citations pooled across five evidence fields. It does not require the claimed code/data/smoke-file/marker categories separately.
- REQ-DOC-004 remains an external-state unknown. The historical manifest points to a macOS Hermes DB, while the regression command accepts `KANBAN MANIFEST SKIP` when the DB is absent.
- REQ-DOC-005's command gate requires only `KANBAN MANIFEST`; the stronger `KANBAN MANIFEST PASS` string occurs in a comment, which is enough for `RequirementTraceValidator`'s substring check.
- All five committed SVG metadata hashes match independently recomputed normalized Mermaid SHA-256 values, and all declare Mermaid CLI `11.16.0`.
- The system-context Mermaid calls the current runtime Godot 4.6. `project.godot:16` declares Godot 4.7, and accepted ADR-0060 selects exact Windows Godot 4.7.2 for this feature-completion program while calling 4.6.2 a downgrade. This is stale documentation/authority evidence, not a runtime failure or a request to downgrade the engine.

## Exact leaf traces

### `REQ-DOC-001::acceptance-58d5ed7cdbbc`

**Criterion:** The currency claim above holds when the validators run with `ROOT` set.

- Inherited claim: every validated package's task id, code/data/smoke files, and smoke markers are recorded in the complete systems map.
- Route: `systems_map_currency_smoke.py:1-3` -> ROOT-resolved `doc_currency_validators.main` at `:303-316` -> `SystemsMapCurrencyValidator.validate` at `:123-156` -> `docs/SYNAPTIC_SEA_COMPLETE_SYSTEMS_MAP.md` and the integration matrix.
- Predicate: hard-coded Task-01..15 ids, matrix task ids, at least three pooled evidence values per non-kickoff row, 15 exact stale phrases, and three required map sections are checked before the marker at `:277-280`.
- Gap: the `len(evidence) >= 3` check at `:140-147` pools docs/code/data/smoke files/markers. It can pass without one or more claimed categories, so it does not prove the exact inherited claim.
- Data/save: the matrix and systems map are documentation inputs/outputs; no gameplay model, scene consequence, or save path participates.
- Status: `source_mapped_validation_gap`.

### `REQ-DOC-002::acceptance-69d2a7d58ff3`

**Criterion:** The currency claim above holds when the validators run with `ROOT` set.

- Inherited claim: every package architecture decision is discoverable in both ADR indexes.
- Route: `requirement_trace_smoke.py:1-3` -> `RequirementTraceValidator` -> `AdrIndexValidator` at `doc_currency_validators.py:159-175,217-220`.
- Predicate: every `REQUIRED_ADR_PATHS` file must exist and its exact path must occur in both `docs/game/adr/README.md` and the complete systems map. Direct set comparison found all 16 ADR paths authored by the 14 non-kickoff matrix packages within the 19-path validator allowlist.
- Data/save: package ADR associations come from matrix `docs_files`; no gameplay save or scene route is involved.
- Status: `traced`.

### `REQ-DOC-003::acceptance-878ac9d23144`

**Criterion:** The currency claim above holds when the validators run with `ROOT` set.

- Inherited claim: every matrix-cited requirement has a heading in `05_requirements.md`.
- Route/predicate: `RequirementTraceValidator` iterates every matrix row's `requirements` values and requires exact `## <id>:` headings at `doc_currency_validators.py:203-207`.
- Data/save: `cross_system_integration_matrix.json` is the authored trace input; there is no runtime/save path.
- Status: `traced`.

### `REQ-DOC-004::acceptance-9e872d2b8c60`

**Criterion:** The currency claim above holds when the validators run with `ROOT` set.

- Inherited claim: the Task-15 manifest's task/link/status counts reconcile with the live Hermes board when its DB is available.
- Route: `kanban_manifest_smoke.py:1-3` -> `run_kanban_manifest` -> `KanbanManifestValidator` at `doc_currency_validators.py:224-300`.
- Predicate: the validator reads live task/link/status aggregates from SQLite and compares ids, edges, counts, and allowed aggregate statuses at `:239-273`.
- Authority gap: current equality was not executed and remains unknown. The stored DB path is a historical macOS path. `run_kanban_manifest` returns SKIP when absent at `:289-296`, and the regression plan accepts PASS or SKIP at `06_validation_plan.md:517-521`.
- Data/save: this is external process persistence in Hermes SQLite, not player-save state. ADR-0040 scopes it to `synaptic-sea-e2e-systems`; present project governance names `synaptic-sea-stage-gate`. The current generated local stage-gate cards remain operational/current, while external connector synchronization is unavailable/pending. These are separate scopes; the legacy validator is not renamed.
- Status: `source_mapped_authority_scope_partial`.

### `REQ-DOC-005::acceptance-241b7673827d`

**Criterion:** The currency claim above holds when the validators run with `ROOT` set.

- Inherited claim: the validation plan registers `SYSTEMS MAP CURRENCY PASS`, `REQUIREMENT TRACE PASS`, and `KANBAN MANIFEST PASS`.
- Route/predicate: `RequirementTraceValidator` searches the validation plan for four marker substrings at `doc_currency_validators.py:208-216`.
- Gap: the first two exact markers are command predicates at `06_validation_plan.md:519-520`; the Kanban command at `:521` requires only `KANBAN MANIFEST`. The stronger PASS string is present in the explanatory comment at `:518`, so the validator passes without exact PASS registration.
- Data/save: validation command metadata only; no player-save route.
- Status: `source_mapped_validation_gap`.

### `REQ-DOC-006::acceptance-fd4761eb1694`

**Criterion:** The currency claim above holds when the validators run with `ROOT` set.

- Inherited claim: the systems map no longer carries the enumerated stale MISSING/SPEC'D statements.
- Route/predicate: the 15 exact strings at `doc_currency_validators.py:60-75` are rejected by `SystemsMapCurrencyValidator` at `:148-151`; direct source review found none in the map.
- Data/save: documentation-only negative constraint.
- Status: `traced`.

### `REQ-DOC-007::acceptance-dba509af8f41`

**Criterion:** The currency claim above holds when the validators run with `ROOT` set.

- Inherited claim: within the E2E Systems Wave, the integration matrix links packages to requirements, code, and smoke evidence and drives currency validation.
- Route: `matrix_rows` loads `cross_system_integration_matrix.json` at `doc_currency_validators.py:118-120`; the systems-map and requirement validators consume it at `:126-147,203-207`.
- Predicate: direct bounded review confirms every current non-kickoff row contains requirement, code, and smoke evidence. The enclosing requirements heading scopes this claim to Tasks 01-15, so it is not treated as a whole-September-workspace completeness assertion.
- Data/save: the matrix is the authored profile; no gameplay save or scene effect.
- Status: `traced`.

### `REQ-DOC-008::acceptance-13dcb811fdcd`

**Criterion:** The currency claim above holds when the validators run with `ROOT` set.

- Inherited claim: validators are host-side, ROOT-overridable/autodetecting, and non-zero on failure.
- Route/predicate: `root_path` uses `ROOT` with a file-derived fallback at `doc_currency_validators.py:19-22,89-90`; `ValidationResult.require_ok` raises `SystemExit` at `:77-86`; main is pure Python and returns 0 only after the selected validator completes at `:303-317`. The wrappers preserve its exit status.
- Data/save: Markdown, JSON, and optional Hermes SQLite only; no Godot or player-save path.
- Status: `traced`.

### `REQ-DOC-009::acceptance-04aaed86d9fa`

**Criterion:** Five individual Mermaid diagrams cover system context, containers/data stores, gameplay interaction, threat-AI state, and curated runtime dependencies.

- Route: `parse_all` requires the architecture index and every fixed `DIAGRAM_SPECS` document at `validate_architecture_diagrams.py:446-451`; `full_run` renders and verifies all five at `:466-498`.
- Source: fixed files/IDs/families are declared at `:75-81`; direct review confirmed the five Mermaid fences address the five named topics in `docs/game/architecture/01-*` through `05-*`.
- Data/save: authored Markdown/Mermaid plus SVGs. Containers, interaction, and dependency views describe WorldSnapshot/SaveLoadService, but the validator does not instantiate scenes or write saves.
- Status: `traced`.

### `REQ-DOC-009::acceptance-c1a22a36d9b8`

**Criterion:** Every diagram includes a text equivalent, current evidence paths and symbols, inference/omission notes, current gaps, and export instructions.

- Route/predicate: exact H2 equality at `validate_architecture_diagrams.py:255-257` requires every named section; evidence parsing at `:116-149` requires a four-column table, approved basis, repository-relative existing path, and at least one row. Direct review found substantive content in each section and the named source symbols still exist.
- Production/save trace: diagram 03 maps `PlayerController.request_interact` -> ordered coordinator dispatch -> `Interactable` -> pure objective/system models -> HUD/audio/scene effects -> `WorldSnapshot` -> `SaveLoadService.save_world`. Those production symbols remain at `player_controller.gd:73-82`, `playable_generated_ship.gd:10360-10430,10437-10513,10683-10808,12833-12844`, and `save_load_service.gd:24-30,672-725`.
- Mismatch: `01-c4-system-context.md:20` claims current `Godot 4.6`; its own evidence points to `project.godot`, whose line 16 declares `4.7`. Accepted ADR-0060:9-12 identifies the stale documented macOS 4.7.1 path, the installed Windows 4.7.2 runtime, and 4.6.2 as a downgrade. Its decision at :21-28 selects exact `4.7.2.stable.mono.official.ed1daf0bf` for this program subject to the gates, and :38-52 records the reviewed baseline. The validator checks path existence and date syntax, not evidence-symbol/value agreement with Mermaid semantics. This is a documentation/authority defect, not evidence that production execution failed.
- Status: `stale_documentation_authority_mismatch`.

### `REQ-DOC-009::acceptance-1741bf6f177e`

**Criterion:** Five committed SVGs carry the current Mermaid-source SHA-256 and exact renderer version.

- Route/predicate: exact CLI version checks at `validate_architecture_diagrams.py:335-363`; normalized source-hash metadata at `:404-443`; all-five staged replacement and verification at `:466-498`.
- Direct source check: independently recomputed hashes match all five SVG payloads: context `3bd8d59f...1905f`, containers `42d74e75...fcfdd`, interaction `2bc87236...c4c8`, threat AI `e4e83561...0624`, dependencies `6b6d6293...6750`. All payloads declare `@mermaid-js/mermaid-cli` `11.16.0`.
- Limitation: local `node_modules` is absent, so no fresh syntax render is claimed. The validation plan installs dependencies before `--check` at `06_validation_plan.md:529-530`.
- Data/save: documentation exports only.
- Status: `traced`.

### `REQ-DOC-009::acceptance-e66a18b59d99`

**Criterion:** Planned or deferred behavior is absent from diagram semantics.

- Route/predicate: Mermaid-only rejection of five named retired IDs occurs at `validate_architecture_diagrams.py:33,311-313`, and the self-test proves a prohibited ID inside Mermaid fails at `test_validate_architecture_diagrams.py:162-172`.
- Static review: all five bounded Mermaid fences were reviewed. Cloud/full-audio, save-failure, missing FLEE/INVESTIGATE scene behavior, and deferred audio details remain in prose gap/omission sections, outside diagram semantics. None of the five prohibited identifiers occurs in a fence.
- Top-down authority: the later top-down ADR is Accepted, but `project.godot:15` and `scripts/main.gd:5-14` still configure the title -> Main -> 3D playable scene as the default boot route; this audit does not draw planned/parallel top-down code as the live path.
- Data/save: diagrams describe current save boundaries without mutating them.
- Status: `traced`.

## Review limits

This is a moving-WIP source preparation artifact. It preserves all 622 frozen canonical criteria and leaves registry evidence as `not_verified`. No historical PASS marker, task declaration, external board state, human approval, runtime behavior, or whole-game acceptance was promoted.
