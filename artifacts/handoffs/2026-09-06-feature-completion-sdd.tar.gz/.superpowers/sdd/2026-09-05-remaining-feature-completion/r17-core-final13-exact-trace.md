# R17 Core Final-13 Exact Trace

- Generated: `2026-09-05T22:51:48.9681708-04:00`
- Source revision: `cb3a7f52017befe81dc1f39ab48962bdda68d743`
- Moving WIP: `true`
- Scope: source-only trace; no runtime/test execution, evidence promotion, Git, registry/index writes, or complete-game acceptance
- Registry filter: `domain == "core" && deferred == false`
- Active core rows: `49`
- Prior range explicitly excluded: the exact 36-ID `selected_ids` union from the first12, second12, and third12 reports, including every partial and superseded disposition
- Selection: remaining 13 rows, zero-based registry indices `408..420`, core orders `37..49`
- Result: `9 traced`, `1 static_constraint_traced`, `1 source_mapped_validation_gap`, `2 source_mapped_authority_scope_partial`, `0 runtime defects found`, `0 fresh executions`

Selected IDs, in exact registry order:

1. `REQ-012::acceptance-08a84e90f6c8`
2. `REQ-013::acceptance-f689afa81547`
3. `REQ-013::acceptance-d31052b8776d`
4. `REQ-013::acceptance-64c204076bf0`
5. `REQ-013::acceptance-c327d3d73b18`
6. `REQ-013::acceptance-e0500b00038f`
7. `REQ-014::acceptance-63c59c2ac45a`
8. `REQ-014::acceptance-5e1281f70574`
9. `REQ-014::acceptance-19a102917063`
10. `REQ-014::acceptance-34a419a85db9`
11. `REQ-014::acceptance-fe53430d778e`
12. `REQ-014::acceptance-54527a6ccebe`
13. `REQ-014::acceptance-0da7fd3dc749`

All 13 rows are active, distinct, self-representative denominator rows: `deferred=false`, no `canonical_id` or `alias_of`, and `counts_toward_proposed_denominator=true`.

REQ-013's source list includes `content_complete_target.md`, but that document now labels itself historical/do-not-trust for current status. Its Template B/C taxonomy is used only to identify the two “new template” fixtures; current runtime/source claims come from the Approved hazard spec, accepted ADRs, generated data, production loader/coordinator, and exact predicates. ADR-0005 is amended by ADR-0041: `ElectricalArcState` is the sole timer owner and retired `FireState` is not required.

REQ-014 uses the actual production chain `scenes/main.tscn` -> `scripts/main.gd` -> `playable_coherent_ship.tscn` -> `coherent_ship_001`; that fixture's sequence 2 is a real two-step `repair_junction`. Static review establishes the hazard non-duplication leaf and exposes an unresolved ADR-0004/ADR-0036 scope question. Dynamic claims require meaningful predicates. PASS text is not used as a predicate, and no fresh PASS is claimed.

## Exact leaf traces

### `REQ-012::acceptance-08a84e90f6c8`

**Criterion:** Both a direct model smoke and a main-scene smoke pass.

- Entry: the direct boundary is `SaveLoadService.save_current_run/load_current_run`; the live boundary is the default main/coherent_ship_001 scene and `PlayableGeneratedShip.request_save/request_load` staged restore path.
- Registration: `docs/game/06_validation_plan.md:452-453` registers the exact direct and main artifacts.
- Predicates: `save_load_service_smoke.gd:179-240` writes/reloads and requires exact paths, position, sequence, and deep-equal summaries; `:360-364` requires deletion. `main_playable_slice_save_load_smoke.gd:69-117` saves the live default slice, mutates position, loads, and immediately requires sequence/position/supplies restoration; `:119-125` requires completion deletion.
- Scope: the preceding REQ-012 leaves retain their nested-fire/full-live-restore gaps. This artifact leaf does not erase them.
- Status: `traced`.

### `REQ-013::acceptance-f689afa81547`

**Criterion:** A third hazard type exists in the generated ship scene on at least one non-critical link per new template where topology supports it.

- Entry: `GeneratedShipLoader._add_arc_zone_markers` reads per-layout `arc_zones` without fallback at `generated_ship_loader.gd:1933-1953`. `_build_arc_zone/_resolve_arc_zone_world_positions` builds every resolved current-context marker as scene collision at `playable_generated_ship.gd:11844-11954,11994-12026`.
- Template B: coherent_ship_002 authors `corridor_to_arc_side_arc -> arc_side_01`, outside its critical path, at `data/procgen/golden/coherent_ship_002/gameplay_slice.json:7-18,32-42`.
- Template C: coherent_ship_003 authors `lower_hub_to_tool_storage_arc -> tool_storage_03`, outside its critical path, at `data/procgen/golden/coherent_ship_003/gameplay_slice.json:7-16,37-52`.
- Predicate: `main_playable_slice_arc_smoke.gd:20-46` explicitly loads coherent_ship_002; `:91-103` requires a live arc node/collision, and `:196-249` requires marker/resolved-room agreement off critical and breach paths.
- Gap: no existing smoke loads coherent_ship_003 and asserts its authored arc becomes a live scene node on `tool_storage_03`; `template_c_main_scenario_smoke.gd` contains no arc predicate. Shared source plus static data are not runtime evidence for that per-template conjunct.
- Status: `source_mapped_validation_gap`.

### `REQ-013::acceptance-d31052b8776d`

**Criterion:** The new hazard has its own pure state model and main-scene smoke.

- Entry: `_build_arc_zone` creates/configures `ElectricalArcState` at `playable_generated_ship.gd:11867-11889`; `_tick_electrical_arc` calls it at `:11164-11168`.
- Implementation: `scripts/systems/electrical_arc_state.gd:1-22` is an independent `RefCounted` with no scene-tree access and composes `PhaseTimer`; contract methods are at `:42-130`.
- Predicates: `electrical_arc_state_smoke.gd:15-93` requires initial state, two cycles, four phase changes, and four passability switches. `main_playable_slice_arc_smoke.gd:68-103,106-178` requires the live model/node/collision and two scene cycles.
- Profile note: the named scene smoke directly constructs production `PlayableGeneratedShip` with coherent_ship_002 at `:20-46`; it does not enter `scenes/main.tscn`/coherent_ship_001.
- Status: `traced`.

### `REQ-013::acceptance-64c204076bf0`

**Criterion:** The new hazard toggles real passability, resource pressure, or traversal timing.

- Entry: `_tick_electrical_arc` advances the model and refreshes scene state at `playable_generated_ship.gd:11164-11168`; `_apply_arc_zone_scene_state` maps `arcing` to `CollisionShape3D.disabled` at `:12054-12085`.
- Implementation: `ElectricalArcState` owns fixed DISCHARGED/ARCING durations and derives `passability_blocked` from ARCING at `electrical_arc_state.gd:19-40,57-101,178-187`. The live node starts collision-disabled at `playable_generated_ship.gd:11994-12026`.
- Predicates: `electrical_arc_state_smoke.gd:54-93` requires four model phase/passability transitions. `main_playable_slice_arc_smoke.gd:81-103,137-178` requires initially passable live collision and two scene-summary cycles with no blocked DISCHARGED state, but it does not inspect enabled collision during ARCING. The exact real-blocker predicate is `derelict_arc_smoke.gd:106-139,141-165`: after real main-scene boarding it requires a live arc node under the generated derelict, advances the production away-process path, and fails unless an ARCING zone has an enabled `CollisionShape3D`.
- Status: `traced`.

### `REQ-013::acceptance-c327d3d73b18`

**Criterion:** The new hazard does not duplicate oxygen-breach or timed-fire semantics.

- Entry: the arc model accepts delta and maps a short two-phase timer to collision at `electrical_arc_state.gd:84-101,186-187`. Oxygen remains player-context resource depletion/recovery; ADR-0041 retires timed fire for persistent compartment-keyed `FireSuppressionState`.
- Static disposition: arc has no oxygen/health/resource fields or objective/tool inputs and is now the sole `PhaseTimer` owner. Its historical 1.5s-safe/2.5s-danger cadence is complementary to the retired longer-safe fire cadence. Accepted ADR-0005:7-14,28-62 and current model surfaces establish the semantic separation.
- Predicate context: `electrical_arc_state_smoke.gd:15-93` requires only the arc phase/passability contract. A mirror test asserting absence of oxygen/fire code is not required.
- Status: `static_constraint_traced`.

### `REQ-013::acceptance-e0500b00038f`

**Criterion:** ADR-0005 is authored and accepted before implementation; it defines the `HazardStateContract`, the `PhaseTimer` helper for timer-based hazards, the loader contract for `breach_zones` / `fire_zones` / `arc_zones`, and the save/load serialization shape for hazard state.

- Authority: ADR-0005 is present and Accepted at `docs/game/adr/0005-multi-hazard-architecture.md:1-5`. It defines `HazardStateContract` at `:32-49`, `PhaseTimer` at `:53-62`, all three loader arrays at `:64-78`, and a hazard save shape at `:80-94`.
- Amendment: ADR-0041's note at ADR-0005 `:7-14` retires `FireState` but retains the oxygen/arc contract, PhaseTimer, loader arrays, and save/load authority.
- Current mapping: `ElectricalArcState` implements the contract and composes `PhaseTimer`; `GeneratedShipLoader` exposes arc marker/spec arrays.
- Gaps: the snapshot cannot establish the historical phrase “before implementation” without repository history. The ADR's declared single `hazards` dictionary also differs from current source, which stores oxygen/arc separately and current fire under `ship_systems_summary` at `playable_generated_ship.gd:12656-12703,13218-13231`.
- Disposition: authority/process reconciliation is needed. This is not a runtime-defect claim or a request for a mechanical test.
- Status: `source_mapped_authority_scope_partial`.

### `REQ-014::acceptance-63c59c2ac45a`

**Criterion:** A second tool (`junction_calibrator`) can be acquired by interacting with a pickup.

- Entry: the default main/coherent_ship_001 path builds a second `ToolPickup` at `playable_generated_ship.gd:10200-10204,12409-12425`; production dispatch tries it at `:10553-10564`. `ToolPickup.try_interact` performs direct range validation, adds to inventory, hides marker/collision, and emits acquisition at `scripts/tools/tool_pickup.gd:64-84`.
- Implementation: the definition is `data/tools/tool_definitions.json:9-14`. The validation helper teleports the live player, calls `player.request_interact`, and succeeds only if inventory owns the calibrator at `playable_generated_ship.gd:12540-12563`.
- Predicates: `main_playable_slice_junction_calibrator_smoke.gd:65-91` requires fresh absence plus a visible correctly configured pickup; `:93-122` drives the request and requires exactly one tool, hidden marker, and HUD lines. The save/load smoke repeats acquisition and requires carried state at `:85-104`.
- Status: `traced`.

### `REQ-014::acceptance-5e1281f70574`

**Criterion:** The second tool modifies a `repair_junction` objective by reducing its required step count by one (min 1).

- Entry: `_build_interactables` caches `kind=repair_junction` and registers authored steps at `playable_generated_ship.gd:10389-10420`. `_on_interactable_completed` consumes before step completion at `:10683-10707`; the consume method gates by kind/inventory and removes the tool only on a successful model mutation at `:12466-12523`.
- Implementation: `ObjectiveProgressState.apply_junction_calibrator` rejects missing/complete/already-applied/one-step records and otherwise subtracts exactly one at `objective_progress_state.gd:57-105`.
- Predicates: `junction_calibrator_state_smoke.gd:59-92` requires 3->2, applied flag, and idempotence; `:117-135` requires one step to remain one and the tool to remain carried. `main_playable_slice_junction_calibrator_smoke.gd:136-182` requires coordinator 3->2 and completion in two steps; `:192-221` requires consumption and no uncarried effect.
- Status: `traced`.

### `REQ-014::acceptance-19a102917063`

**Criterion:** Tool state persists for the current ship slice and is captured by REQ-012 save/load.

- Entry: `_build_run_snapshot` captures `InventoryState.get_summary` and `ObjectiveProgressState.get_summary` at `playable_generated_ship.gd:12669-12703`; restore applies both at `:13211-13231`.
- Implementation: inventory summary includes tool IDs at `inventory_state.gd:254-272` and restores lot-aware/legacy tool shapes at `:274-318`. Objective summary includes `calibrator_applied` at `objective_progress_state.gd:158-173`; restore accepts JSON string sequence keys and restores the record at `:178-238`.
- Predicate: `main_playable_slice_junction_calibrator_save_load_smoke.gd:85-120` saves/reloads carried state and requires ownership plus hidden marker; `:134-190` consumes on the real junction, saves/reloads, and requires the spent/applied state.
- Status: `traced`.

### `REQ-014::acceptance-34a419a85db9`

**Criterion:** The carried / consumed / applied state survives save/load round-trips with a real next-frame interaction after load (no "previously freed" crash in the post-load HUD/tracker path; no silent loss of the per-sequence `calibrator_applied` flag through the JSON string-key round-trip; the pickup marker stays hidden after reload in both carried and spent save states).

- Entry: staged load restores inventory/objective summaries at `playable_generated_ship.gd:13211-13231` and reconciles rebuilt pickup visibility at `:12440-12464,13342-13349`. Objective restore normalizes JSON string sequence keys at `objective_progress_state.gd:187-233`.
- Actual profile/path: the save smoke instantiates `scenes/main.tscn` and coherent_ship_001. After load it waits two process frames, then drives actual sequence-2 interactables through `complete_objective_sequence_for_validation`; that helper issues `player.request_interact` and uses the same `Interactable.try_interact` only as a deterministic fallback at `playable_generated_ship.gd:1179-1209`.
- Predicates: `main_playable_slice_junction_calibrator_save_load_smoke.gd:106-135` saves/loads carried state, waits, requires carried+hidden marker, and completes the real junction. `:137-154` requires advancement, consumption, `required_steps=1`, `calibrator_applied=true`, `complete=true`, and a recorded step. `:156-190` saves/loads spent state and requires empty inventory, restored applied/completed record, hidden marker, and sequence 3.
- Stale-reference check: reaching these post-load predicates through the rebuilt HUD/tracker interaction path is the substantive no-previously-freed check.
- Status: `traced`.

### `REQ-014::acceptance-fe53430d778e`

**Criterion:** The live coordinator path records a completed `objective_progress_state` step when the carried calibrator reduces a real 2-step repair_junction to 1 required step (pre-calibration `required_steps` snapshot, not post-calibration).

- Entry: coherent_ship_001 defines real sequence 2 as a two-step `repair_junction` at `data/procgen/golden/coherent_ship_001/gameplay_slice.json:34-50`.
- Implementation: `_on_interactable_completed` reads `pre_required_steps`, consumes/reduces the calibrator, derives `is_multi_step` from the pre-value, and calls `complete_step` before advancement at `playable_generated_ship.gd:10683-10721`.
- Predicate: `main_playable_slice_junction_calibrator_save_load_smoke.gd:122-135` drives the real sequence after carried load; `:137-154` requires sequence 3, consumed inventory, `required_steps=1`, `calibrator_applied=true`, `complete=true`, and `completed_steps>=required_steps`. This fails if the coordinator skips `complete_step` based on the post-calibration value.
- Status: `traced`.

### `REQ-014::acceptance-54527a6ccebe`

**Criterion:** Direct model smoke (`scripts/validation/junction_calibrator_state_smoke.gd`), main-scene smoke (`scripts/validation/main_playable_slice_junction_calibrator_smoke.gd`), and save/load smoke (`scripts/validation/main_playable_slice_junction_calibrator_save_load_smoke.gd`) all pass.

- Registration: all three exact artifacts are in `docs/game/06_validation_plan.md:457-459`.
- Direct predicates: `junction_calibrator_state_smoke.gd:23-169` asserts fresh/acquired inventory, status, 3->2, idempotence, min-one behavior, completion, and summary restore.
- Main predicates: `main_playable_slice_junction_calibrator_smoke.gd:65-221` asserts live pickup acquisition, HUD, coordinator 3->2/consume, completion after two steps, and no uncarried effect. Its three-step record is synthetic and used only for the exact 3->2 feature case.
- Save/load predicates: `main_playable_slice_junction_calibrator_save_load_smoke.gd:85-190` asserts the real coherent_ship_001 two-step junction plus carried/spent staged reload lifecycle.
- Status: `traced`; no fresh execution is claimed.

### `REQ-014::acceptance-0da7fd3dc749`

**Criterion:** ADR-0004 is authored before implementation if the tool/effect system is generalized beyond hard-coded multipliers.

- Tool entry: no ADR-0004 exists. The REQ-014 tool path itself remains explicit: `InventoryState.get_drain_multiplier` hard-codes the portable pump's 0.5 effect at `inventory_state.gd:249-250`; PlayableGeneratedShip names `junction_calibrator` and invokes a dedicated method at `playable_generated_ship.gd:12466-12523`; `ObjectiveProgressState` subtracts one fixed step at `objective_progress_state.gd:83-105`.
- Generalized effect entry: PlayableGeneratedShip instantiates/configures `EffectDispatcher` at `playable_generated_ship.gd:137,1708-1709`. `effect_dispatcher.gd:8-30` loads `data/items/effect_definitions.json` and provides generic `dispatch_effect/dispatch_inline`; `:31-93` dispatches multiple data-defined kinds. `ConsumableState` routes medicine, stimulant, ammo, utility, food, and drink through it at `consumable_state.gd:120-188`.
- Later authority: accepted ADR-0036:1-18 makes `EffectDispatcher` the authoritative pure-model executor for the consumable pipeline and calls it data-driven/expandable.
- Earlier trigger: `docs/game/features/inventory_tools.md:145,150` requires/recommends ADR-0004 if the tool/effect system expands beyond one hard-coded tool/multiplier. `tool_type_2.md:174,179` describes its own trigger as expansion beyond `tool_definitions.json` plus per-tool branches.
- Gap: REQ-014's two tools still use explicit branches, while the later consumable effect subsystem is genuinely generalized under ADR-0036. No authority explicitly says ADR-0036 supersedes/satisfies ADR-0004 or that consumables are outside the older broad “tool/effect system” condition. Source review therefore cannot resolve the exact conditional.
- Test disposition: this is an authority/scope question, not a request to invent ADR-0004, remove runtime, or add a brittle code-absence test.
- Status: `source_mapped_authority_scope_partial`.

## Review disposition

- The final 13 complete the 49-row active core sequence after exact subtraction of all prior 36 report IDs.
- Template B has a meaningful live non-critical arc predicate. Template C's authored arc and shared construction path are source-mapped, but the per-template live scene conjunct remains unverified.
- ADR-0005 exists and defines every named section. Its historical ordering and current save-shape consistency remain unresolved authority/process issues.
- All REQ-014 dynamic leaves have substantive predicates on the actual main/coherent_ship_001 path where the requirement calls for it. The REQ-014 tool branches remain explicit, but the later ADR-0036 consumable dispatcher makes the broad ADR-0004 trigger's scope unresolved until authority explicitly reconciles them.
