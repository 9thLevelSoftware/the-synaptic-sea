"""Run the plan-local R04 traversal diagnostic with hardened isolation evidence."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
TOOLS = ROOT / "tools"
sys.path.insert(0, str(TOOLS))

import run_feature_completion as runner  # noqa: E402


GODOT = Path(
    r"C:/Users/dasbl/Downloads/Godot_v4.7.2-stable_mono_win64/"
    r"Godot_v4.7.2-stable_mono_win64/"
    r"Godot_v4.7.2-stable_mono_win64_console.exe"
)
SCRIPT = (
    ".superpowers/sdd/2026-09-05-remaining-feature-completion/"
    "r04_traversal_diagnostic.gd"
)
MARKER = "R04 TRAVERSAL DIAGNOSTIC PASS all_slide_blocker_selection=true"
HASH_PATHS = [
    SCRIPT,
    ".superpowers/sdd/2026-09-05-remaining-feature-completion/r04_run_traversal_diagnostic.py",
    "scripts/validation/fc_p09_natural_route_smoke.gd",
    "scripts/validation/fc_p10_process_smoke.gd",
    "scripts/player/player_controller.gd",
    "scripts/procgen/playable_generated_ship.gd",
    "scripts/procgen/life_boat.gd",
    "scripts/systems/dock_ports.gd",
    "scripts/systems/docking_manager.gd",
    "scenes/wrappers/structural/ship_structural_v0/floor_1x1.tscn",
    "data/procgen/golden/coherent_ship_001/layout.json",
    "docs/game/adr/0017-physical-docking-and-ports.md",
    "tools/run_feature_completion.py",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    evidence = ROOT / "artifacts" / "feature-completion" / f"P09-R04-traversal-diagnostic-{stamp}"
    runner._prepare_evidence_root(evidence)
    user_data_root = evidence / "user-data"
    user_data_root.mkdir()
    user_data = user_data_root / "r04-traversal-diagnostic"
    case = {
        "id": "R04-traversal-diagnostic",
        "scope": "scene",
        "script": SCRIPT,
        "marker": MARKER,
    }
    result = runner.execute_isolated_case(
        case, GODOT, evidence, user_data, timeout=45.0
    )
    body_command = [str(GODOT), "--headless", "--path", str(ROOT), "--script", "res://" + SCRIPT]
    environment = {key: str(user_data) for key in (
        "APPDATA", "LOCALAPPDATA", "GODOT_USER_PATH", "XDG_DATA_HOME"
    )}
    stdout_path = evidence / "r04-traversal-diagnostic.stdout.log"
    stdout = stdout_path.read_text(encoding="utf-8") if stdout_path.is_file() else ""
    stderr_path = evidence / "r04-traversal-diagnostic.stderr.log"
    stderr = stderr_path.read_text(encoding="utf-8") if stderr_path.is_file() else ""
    marker_lines = [line for line in stdout.splitlines() if line.startswith(MARKER)]
    diagnostics = runner._diagnostics(stdout, stderr)
    accepted_voice_paths = {
        "log_beacon_01.ogg", "log_beacon_02.ogg", "log_pulse_01.ogg",
        "log_groan_01.ogg", "log_tutorial_pickup.ogg", "log_tutorial_calibrator.ogg",
    }
    accepted_diagnostics: list[str] = []
    unexpected_diagnostics: list[str] = []
    voice_prefix = "WARNING: AudioManager: stream file missing, path='res://data/audio/voice/"
    for line in diagnostics:
        if line.startswith(voice_prefix) and line.endswith("'"):
            filename = line[len(voice_prefix):-1]
            if filename in accepted_voice_paths:
                accepted_diagnostics.append(line)
                continue
        unexpected_diagnostics.append(line)
    task_local_accepted = (
        result.get("exit_code") == 0
        and not result.get("cleanup_error")
        and result.get("containment_probe", {}).get("passed") is True
        and len(marker_lines) == 1
        and not unexpected_diagnostics
    )
    (evidence / "r04-traversal-diagnostic.body.command.txt").write_text(
        subprocess.list2cmdline(body_command) + "\n", encoding="utf-8"
    )
    (evidence / "r04-traversal-diagnostic.body.environment.json").write_text(
        json.dumps(environment, indent=2) + "\n", encoding="utf-8"
    )
    (evidence / "r04-traversal-diagnostic.body.exit.txt").write_text(
        str(result.get("exit_code")) + "\n", encoding="utf-8"
    )
    (evidence / "r04-traversal-diagnostic.markers.json").write_text(
        json.dumps({"expected_prefix": MARKER, "lines": marker_lines}, indent=2) + "\n",
        encoding="utf-8",
    )
    hashes = {
        relative: sha256(ROOT / relative)
        for relative in HASH_PATHS
        if (ROOT / relative).is_file()
    }
    (evidence / "r04-traversal-diagnostic.source-hashes.json").write_text(
        json.dumps(hashes, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    summary = {
        "case": case,
        "evidence": str(evidence),
        "raw_result": result,
        "marker_count": len(marker_lines),
        "accepted_voice_diagnostics": accepted_diagnostics,
        "unexpected_diagnostics": unexpected_diagnostics,
        "task_local_accepted": task_local_accepted,
        "classification": (
            "controlled component diagnostic only; not natural-route acceptance"
        ),
    }
    (evidence / "r04-traversal-diagnostic-summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    print(evidence)
    print(json.dumps(summary, indent=2))
    return 0 if task_local_accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
