# R04 physical traversal diagnosis

Date: 2026-09-06 (America/New_York)  
Workspace: `D:\the-synaptic-sea-feature-completion`  
Classification: diagnostic and RED evidence only; no R04 natural-route acceptance

## Conclusion

The reported lifeboat floor contact was not the lateral blocker. The natural
probe used `CharacterBody3D.get_last_slide_collision()`, but Godot returned a
horizontal obstacle collision followed by the vertical support-floor collision.
The retained floor path therefore identified what held the capsule up, not what
stopped its requested horizontal motion.

Fresh all-slide evidence identifies the first natural blocker precisely. After
Title New Game and the ordinary dock-barrier interaction, the production player
stops at `(3.149058, 0.124909, 1.919138)` while moving toward `(4, 0, 2)`.
The selected horizontal collision is:

- collider: `LifeBoat/ShipStructure/airlock_01/ceiling_0_0_0/CollisionRoot`
- normal: `(-1, 0, 0)`
- travel: `(0.000799, -0.000022, 0.000076)`
- remainder: `(0.098753, -0.0027, 0.009384)`
- simultaneous slide count: `2`

This contact matches the authored proxy geometry exactly. The docked lifeboat
airlock ceiling root is at world `(4, 0, 2)`. Its wrapper currently contains a
`1 x 1 x 1` static box centered at its local origin. The west face is `x=3.5`;
subtracting the player capsule radius `0.35` and the `0.001` safe margin yields
`x=3.149`, the measured stop. The collision is horizontal and cannot be caused
by co-planar floor tops.

The load-bearing cause is the boot docking geometry. `DockPorts.for_derelict()`
falls back to the *center* of the home's 2-by-2 airlock, `(2, 0, 2)`, facing
`+X`. The lifeboat port is its airlock's west edge `(-2, 0, 0)`, facing `-X`.
`DockingManager.compute_mobile_transform()` consequently places the lifeboat
root at `(4, 0, 2)`. Its airlock floor AABB is `x=[2,6], z=[0,4]`, exactly over
the east half of the home airlock and across the route to the home's internal
airlock/corridor doorway. The player is spawned at the home start before the
lifeboat is built, at the same `(2, 0, 2)` dock-seam location, so its capsule
begins intersecting or immediately entering docked lifeboat structure.

This is not repairable by lowering floors, disabling lifeboat collision, moving
the player through the obstruction, or changing only probe waypoints.

## Causal comparisons

The controlled plan-local comparison at
`artifacts/feature-completion/P09-R04-traversal-diagnostic-20260906T042710Z`
waited one extra physics frame before movement. Collision recovery put the
capsule on the east side of the first obstruction, after which it stopped at
`(5.549023, 0.125936, 0.617835)`. Its simultaneous collisions were:

1. Lifeboat cockpit wall `edge_0_h_-1_1/CollisionRoot`, normal `(-1,0,0)`.
2. Lifeboat airlock floor, normal `(0,1,0)`.

The approved diagnostic then set every lifeboat `StaticBody3D` layer and mask
to zero while retaining its original values. Motion did not resume. The first
horizontal collision became home
`StructuralEdge_0_v_0_1/CollisionRoot`, also normal `(-1,0,0)`, at the same
contact plane; the home floor remained the support collision. All lifeboat
layers and masks were restored to `1`. This proves both that the floor was not
the blocker and that the lifeboat alone is not a sufficient component cause:
overlapping home and lifeboat structures occupy the intended route.

A temporary aperture-centered RED route at
`artifacts/feature-completion/P09-R04-natural-20260906T043122Z` first moved west
from the dock seam into host-only space, then targeted exact floor and doorway
centers at `z=0`. It could not reach its first waypoint. It stopped at
`(2.286426, 0.125837, 1.69722)` on a lifeboat engine-bay structural edge. That
trial was reverted; it is retained only to distinguish hull overlap from the
original route's later `z=0.4` doorway offset.

The home layout has no exterior dock aperture today. Its real
`airlock_to_corridor` doorway is internal edge `0|v|0|1` at `(6,0,0)`. The west
airlock edges `0|v|0|-1` at `(-2,0,0)` and `0|v|1|-1` at `(-2,0,4)` are solid
walls, and the lifeboat west dock edge is also solid. Merely adding or
subtracting `HALF_CELL` from the current room-center fallback would mate two
hulls at a wall.

## Probe correction and portal dispatch

`scripts/validation/fc_p09_natural_route_smoke.gd` now scans every slide
collision:

- timeout reporting prefers the first collision with `abs(normal.y) < 0.5`;
- authored portal detection searches all slide collisions for
  `PortalBlocker` instead of consulting only the last collision;
- RED output includes normal, travel, remainder and slide count.

The exact beforeimage is
`r04_fc_p09_natural_route_smoke.before.gd`, SHA-256
`74649d0dee6e7a1f96cf7d9c2627c6dc76e81f55b90210638a403a74ae6754a1`.
The corrected smoke is SHA-256
`14d8d84120557902c5e141e5b5cbfa383b0c375c2fc6e57f780291fe20fcc76b`.
The original waypoint list is retained.

A separate controlled route in evidence root `...T042331Z` measured a
`PortalBlocker` as slide 0 with normal `(-1,0,0)` and the lifeboat floor as
slide 1 with normal `(0,1,0)`. This proves why the old helper could miss the
portal. It is not natural acceptance because that route did not reproduce the
fresh boot collision sequence. The production home dispatch order tries the
portable oxygen pump and junction calibrator before
`_try_authored_portal_interact`; an in-range pump may therefore claim the first
ordinary request and the following request opens the portal. The corrected
probe is capable of retrying that ordinary dispatch, but the fresh natural run
never reaches the portal because boot hull collision occurs first.

## Survival and death

The `META PAYOUT reason=death` line is a consequence of remaining stuck while
the live simulation advances. It is not a collision API or portal dispatch.
The diagnostic recorded health `100` with fire intensity `1.0` initially,
health `99.745` / fire `0.85` at baseline frame 5, health `93.226` / fire
`0.434` at frame 30, and health `83.143` when the fire cleared at frame 45.
Later, the home life-support drain rose from `0` to `0.022082` by frame 180
while radiation and temperature sources continued to tick. Production
`_tick_survival_attrition()` feeds fire and atmosphere drains into
`VitalsState`, and `_check_vitals_death()` calls `end_run("death")` when health
reaches zero. The natural smoke's 1,800-frame timeout therefore allows the
real hazard simulation to end the run before it prints its final RED result.

## Smallest prerequisite fix scope

ADR-0017 requires physical port-aligned docking, a bodily walk across the seam
after opening the barrier, and piloted-ship containment at the seam. ADR-0065
section 4 currently says endpoint registration preserves existing production
`DockPorts` geometry. That preservation clause must be amended because the
existing center fallback is the demonstrated defect.

The narrow production design is:

1. Give every production dock endpoint an authored exterior structural edge,
   stable `port_id`, outward facing, owning edge/module identity, and distinct
   threshold/interior clearance points. Registration must reject center-only,
   solid-edge, missing, ambiguous, or hull-overlapping endpoints.
2. Author a real exterior aperture for both sides. A minimal coherent-home
   candidate is west edge `0|v|0|-1` at `(-2,0,0)`, facing `-X`; use the
   lifeboat airlock west edge at `(-2,0,0)`, facing `-X`. Compile both as an
   external `doorway_frame_open_1x1` dock aperture rather than a
   `wall_straight_1x1`. Existing yaw math then rotates the lifeboat 180 degrees
   and places its root at `(-4,0,0)`, making the hulls meet only at `x=-2`
   instead of nesting the lifeboat inside the home.
3. Resolve and consume those registered endpoints in `DockPorts`,
   `_dock_piloted_to()` and `_spawn_dock_barrier()`. `DockingManager`'s transform
   math can remain, but its connection record must retain both stable port IDs
   as ADR-0065 requires.
4. Resolve the `ceiling_cap_1x1` placement/collision contract before changing
   it. The scene's current 1m floor-origin cube conflicts with the input's
   `4 x 0.2 x 4` visual bounds and `nav_blocker=false`, but the same input also
   declares `placement_origin=cell-center-floor` with zero offset, and the
   compiler places ceiling records at the floor-cell world position. Replacing
   the cube mechanically with a `4 x 0.2 x 4` box would create a full floor
   overlay, not an overhead ceiling. Trace the generated-loader ceiling policy
   against `LifeBoat._instance_plan_records()` and decide whether the authored
   cap is visual/nonblocking or requires an explicit overhead transform. Do not
   route around it or guess a height.

The coherent001 coordinates above are the smallest concrete failing fixture,
not a one-layout special case. The same registered exterior-port contract must
cover the production home, fixed lifeboat, and every generated dock/airlock
layout needed by the later advanced route. Endpoint authorship belongs in the
deterministic pure generation/postprocess before structural compilation, with
native/fallback document parity. Live registration may validate and bind the
compiled identity but may not invent a room-center fallback.

Minimum affected production domains are:

- `docs/game/adr/0065-structural-replacement-safety-and-scene-commit.md`
- `scripts/procgen/structural_edge_compiler.gd`
- `scripts/procgen/life_boat.gd`
- authoritative coherent001 source/regenerated
  `data/procgen/golden/coherent_ship_001/layout.json`
- `scripts/systems/dock_ports.gd`
- `scripts/procgen/generated_ship_loader.gd`
- `_dock_piloted_to()` and `_spawn_dock_barrier()` in
  `scripts/procgen/playable_generated_ship.gd`
- conditionally, after the policy trace, the reviewed `ceiling_cap_1x1`
  wrapper/contract/compiler or lifeboat instancing inputs and outputs

Current `world-6` persistence stores dock edges as host/mobile/type/slot only;
it has no port identity or transform, and the saved player position is global.
Silently reinterpreting a current save under corrected geometry can restore the
player inside a moved hull. The pending R02 run7/world7 boundary should carry
the registered endpoint IDs and the player's owner-local pose, dock through the
registered endpoints first, and restore the player relative to
`aboard_ship_id`. Existing world-6 dock geometry must be explicitly migrated
only when its owner-local pose can be proved, or rejected; it must not be
silently accepted with the old global pose.

Required validation is: pure exact-port transform and non-overlapping hull
AABBs; compiler/loader exterior aperture identity; capsule traversal in both
directions with barrier closed/open occupancy checks; doorway center and
clearance-boundary cases; fresh boot, away travel and return; save/reload on
each side and at the threshold; explicit recognized-legacy handling; existing
docking/occupancy/player-carry/persistence smokes; then the unchanged natural
R04 route. Collision toggles and teleports cannot satisfy this matrix.

## Retained evidence and run classification

All Godot invocations used `run_feature_completion.execute_isolated_case()`.
Each evidence root has a fresh owned directory assigned to `APPDATA`,
`LOCALAPPDATA`, `GODOT_USER_PATH` and `XDG_DATA_HOME`; the separate
`fc_p10_process_smoke.gd` probe passed before every body and proved
`globalize_path("user://")` and `OS.get_user_data_dir()` stayed under that
directory. The default user profile was not used.

- `P09-R04-natural-20260906T043302Z`: final all-slide RED reproduction; exit 1,
  no pass marker, expected timeout failure, no diagnostics, containment passed.
  It retains body command, four-variable environment, exit, markers, raw
  stdout/stderr, summary, probe logs and source hashes.
- `P09-R04-natural-20260906T043122Z`: centered-route RED diagnostic; exit 1,
  one raw accepted-set `log_beacon_01.ogg` warning, no acceptance claim.
- `P09-R04-natural-20260906T042839Z`: first all-slide RED run before centered
  trial; exit 1, no pass marker, containment passed.
- `P09-R04-traversal-diagnostic-20260906T042710Z`: controlled component
  comparison; exit 1 after lifeboat removal exposed the home wall; layers
  restored; no natural acceptance.
- `...T042331Z`: controlled wrong-route portal/all-slide observation; retained
  as diagnostic only.
- `...T042055Z`, `...T042154Z`, and `...T042238Z`: retained failed diagnostic
  iterations (script bug, state-machine bug, and wrong direct route). They are
  not evidence of acceptance.

Only the six exact ADR-0044 missing voice-file warnings are eligible for a
task-local classification on an otherwise successful run. No run in this
report is promoted to success by that rule, and every raw warning remains in
its log.

No production geometry, docking, player, portal, or survival source was changed
by this diagnosis.

## Ceiling contract resolution addendum (read-only)

This addendum supersedes the unresolved ceiling choice in prerequisite item 4.
There is no `GeneratedShipLoader` versus `LifeBoat` ceiling-placement split.
`StructuralEdgeCompiler` emits both floor and ceiling records at
`cell_world_position()` (`structural_edge_compiler.gd:158-175`), whose deck Y is
`deck * 4.0` (`:323-324`). `GeneratedShipLoader` assigns that record position
directly to the wrapper (`generated_ship_loader.gd:1070-1075`). `LifeBoat`
subtracts only the selected room parent's cell origin before parenting
(`life_boat.gd:287-305`), producing the same global position. Neither path
adds, removes, or interprets a ceiling height.

The authored ceiling visual already contains the height. The authoritative
focused-nine recipe creates the main cap with size `4.0 - 0.12` by
`4.0 - 0.12` by `0.2`, centered at Blender Z / Godot Y `3.9`
(`tools/focused_nine_blender_recipes.py:1194-1201`); its nominal underside and
top are therefore Y `3.8` and `4.0` relative to the floor-origin wrapper. The
promoted GLB preserves those transforms: its cap node is translated to Godot Y
`3.900000095`, and a transform-aware read of every POSITION accessor gives
scene bounds `[-1.940000057, 3.687500037, -1.940000057]` through
`[1.940000057, 4.000000097, 1.940000057]`. The lower bound includes the
decorative tray/recess detail; the load-bearing cap itself remains the exact
recipe slab from Y `3.8` through `4.0`. Commit `14fbe802` promoted this
overhead GLB but changed the wrapper only by swapping its visual resource path.

The defect is the stale wrapper/contract authority left behind by that visual
promotion:

- `ceiling_cap_1x1.tscn` still has its initial-commit `BoxShape3D(1,1,1)` at
  wrapper-local origin. That is the blocking cube observed at floor level.
- Both canonical contract documents and the wrapper input declare
  floor-origin, zero-offset bounds `[-2,0,-2]` through `[2,0.2,2]`; those
  bounds describe the slab's dimensions but omit the recipe's Y `3.9`
  placement.
- The wrapper input and generated kit carry an unrelated stale proxy record
  with dimensions `4 x 3.6 x 0.25`, base Y `-1.8`, and `nav_blocker=true`.
  That record is wall-shaped and disagrees with both the ceiling recipe and
  the top-level canonical `nav_blocker=false` policy.
- `validate_wrapper_scenes.gd:241-325,472-518` checks collision kind, root
  type, and shape class, but never checks shape dimensions or local transform.
  The focused-nine GLB metadata reader aggregates raw mesh-accessor bounds
  without applying node transforms (`prop_visual_metadata.py:330-360`), so its
  reported Y `[-0.1,0.1]` also concealed the authored Y `3.9` placement.

`nav_blocker=false` does not make this module presentation-only. Floor modules
use the same `static-body-proxy` plus `nav_blocker=false` combination and retain
player collision. The ceiling's declared role is visual occlusion/readability,
but its separately declared `static-body-proxy` still requires a physical
proxy. Removing collision would change the current collision contract and is
not supported by this trace.

The repository's executable meaning for structural contract `bounds` is the
physical proxy envelope, not strict containment of every rendered detail.
The structural toolkit calculates `CollisionProxy` size and center directly
from `bounds.local_min_m/local_max_m`
(`tools/blender_addons/structural_module_toolkit/operators.py:269-304`), and the
focused-nine design names that helper a "wireframe `CollisionProxy` derived
from contract bounds"
(`docs/superpowers/specs/2026-08-03-focused-nine-comparison-batch-design.md:75-81`).
Rendered bounds are separate GLB-derived evidence under ADR-0052
(`docs/game/adr/0052-asset-metadata-and-visual-binding-architecture.md:52-55,78-83`).
Consequently, the known physical slab bounds remain Y `3.8..4.0`; the known
full rendered extent is Y `3.687500037..4.000000097` and must be recorded and
validated separately. Decorative underside detail does not enlarge the player
collision proxy. If an implementation introduces a newer rule that one field
must contain both extents, it must first split physical-proxy bounds from
transform-aware visual bounds instead of silently widening the proxy.

The smallest authoritative correction is confined to the ceiling asset
package. Preserve the floor-origin compiler record, both runtime instancing
paths, and the already-correct promoted visual. Amend the canonical ceiling
bounds so the root-local nominal slab is `[-2,3.8,-2]` through `[2,4.0,2]`,
then regenerate the ceiling wrapper proxy as a `BoxShape3D(4,0.2,4)` centered
at local `(0,3.9,0)`. Regenerate the `.input.json`, `.manifest.json`, and kit
projection from that same contract so the wall-shaped proxy record cannot
survive. The two canonical contract forms (`.json` and `.tres`) must remain
identical in meaning; derivative kit projections must be regenerated rather
than hand-edited. The existing socket graph can remain unchanged for this
collision correction because this trace proves the wrapper root is the floor
cell anchor; changing socket coordinates would be a separate graph-contract
decision.

The minimum regression boundary is: a pure assertion that the recipe cap and
canonical bounds agree at Y `3.8..4.0`; transform-aware GLB-bound validation;
wrapper validation of collision size and center against the contract; parity
that both generated-loader and lifeboat instances put the wrapper root at the
compiled floor origin and the collision at Y `3.8..4.0`; and capsule traversal
under every compiled cap. No compiler offset, loader special case, lifeboat
special case, collision disable, or guessed ceiling height is warranted.
