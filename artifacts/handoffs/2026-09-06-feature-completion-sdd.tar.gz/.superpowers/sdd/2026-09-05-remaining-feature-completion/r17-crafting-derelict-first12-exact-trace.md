# R17 crafting/derelict first-12 exact source trace

Snapshot: `2026-09-05T23:28:13.9977617-04:00` at source revision `ed70d37198000529cb8baa5217414f74a0372090`. The source is moving WIP under R03. This was a read-only source audit: no tests ran, and no Git, registry, semantic-index, governance, runtime, or evidence state changed.

## Selection

`docs/game/inventory/feature_acceptance.json` contains exactly **24** active rows where `domain == "crafting_derelict"` and `deferred == false`, matching the expected total. None of those 24 IDs appears in `r17-source-trace-index.json.semantic_trace_reports`. The bounded first-12 selection is therefore registry indices **100–111**: `FC-01`, `FC-02`, `FC-03`, `FC-04`, `FC-05`, `FC-06`, `FC-07`, `FC-08`, `FC-09`, `FC-10`, `FC-11`, and `FC-12`.

All selected rows are `program_outcome` leaves with no canonical/alias indirection and metric-equivalence count one. The dispositions are **7 traced**, **3 source-mapped validation gaps**, **1 fresh-baseline pending**, and **1 natural-acquisition partial**. No runtime defect was established. “Traced” means exact current source plus a substantive existing predicate, without a fresh run or complete-game acceptance.

ADR-0059 is the accepted transaction authority but still says full acceptance is pending. ADR-0062 supersedes only its pending-output identity row. ADR-0064 explicitly leaves the full canonical baseline pending. ADR-0066 retires the old install/remove/plating repair effects; none is used below as FC-06 evidence.

## Exact leaves

### 1. `FC-01`

> Every runtime file and active design requirement is classified; missing features remain visible

**Trace — traced.** `build_system_inventory.py` and `build_feature_acceptance.py` produce the runtime/system/acceptance inventories from classification and design sources. `test_runtime_inventory_coverage.py:34-47` makes an unclassified runtime file and an active file without inventory ownership fail. `test_feature_acceptance_registry.py:379-448` requires source-leaf denominator movement, exact source-leaf coverage, and explicit acceptance-kind/deferred disposition. Those negative mutation and completeness predicates enforce visibility of missing files/features. No fresh run is claimed, consistently with every other source-traced leaf.

### 2. `FC-02`

> Supported engine and native extension boot with complete runtime imports and accepted diagnostics only

**Trace — fresh-baseline pending.** `project.godot:15-16` boots `scenes/title_main.tscn` under Godot 4.7 Forward Plus; project and GDExtension declarations are the P00 boot/import boundary. The feature runner enforces exact markers and clean diagnostics. ADR-0064 explicitly says its parity smoke uses GDScript `ShipGenerator.generate`, not native `generate_from_seed`, and that the full canonical baseline remains pending. Source cannot prove engine/native boot, complete live imports, or accepted-only diagnostics, and no baseline ran in this audit.

### 3. `FC-03`

> Acceptance runner rejects false PASS, nonzero exit, timeout, errors, and missing markers

**Trace — traced.** `run_feature_completion.py:295-318` accepts a case only for exit zero, one exact stdout marker line, and no parsed diagnostics; `_capture` at `:62-85` reports timeout and cleanup, while the bundle path at `:379-405` requires exact final marker/count shape. `test_feature_completion_runner.py:39-68` asserts rejection for missing/near/stderr-only markers, nonzero exit, timeout, ERROR, WARNING, and SCRIPT ERROR. `:184-221` rejects bundle mismatch, duplicate/stderr/trailing marker forms and diagnostic/nonzero output. These are actual result predicates.

### 4. `FC-04`

> Knowledge, skill, tier and ingredients gate both picker and execution identically

**Trace — source-mapped validation gap.** `CraftingState.list_recipe_entries` (`crafting_state.gd:217-263`) projects knowledge, skill, station-tier, and ingredient failures. `begin_craft` reaches `CraftJobScheduler.enqueue`, which evaluates before reservation and revalidates at start (`craft_job_scheduler.gd:57-127,926-953`). Combined existing predicates cover three complete pairs:

- Knowledge: `fc_p06_smoke.gd:20-51` asserts picker `missing_recipe_knowledge`, denied direct begin/enqueue, then successful unlock. Its live case at `:95-169` reaches picker confirmation through an authored-loot fixture and makes no natural-acquisition claim.
- Skill: `crafting_recipe_list_smoke.gd:71-81` asserts a real list row reports `insufficient_skill`; `fc_p07_smoke.gd:288-306` asserts execution revalidation reports the same semantic and then starts at the required skill.
- Tier: `station_tiers_batch_smoke.gd:58-78` asserts tier-zero execution rejection plus list `insufficient_tier`; `fc_p09_smoke.gd:136-142` checks the live owner-scoped picker blocker, and `fc_p07_smoke.gd:293-306` checks execution revalidation and recovery at tier two.

Ingredients are exact on execution at `fc_p07_smoke.gd:109-121`: the second enqueue is denied as `missing_materials` after the first reserves the only inputs. The remaining gap is only the picker half. `crafting_recipe_list_smoke.gd:20-38` proves an empty inventory leaves every real row non-craftable but does not isolate an otherwise eligible row and assert `missing_ingredients`; `fc_p05_smoke.gd:583-589` merely formats a synthetic row. Source maps `missing_ingredients` and execution `missing_materials` to the same quantity comparison, but the picker blocker semantic lacks a substantive existing predicate.

### 5. `FC-05`

> Quantity and quality survive all relevant holders and transfers

**Trace — source-mapped validation gap.** `ItemLotLedger.add_lot/take_lots` is used by inventory, cargo/cart, equipment, loot, drops, salvage, escrow/output, and persistence. `fc_p03_smoke.gd:21-174` asserts atomic split, identity, quality, provenance, caps, strict round trip, and legacy migration. `fc_p04_smoke.gd:31-194` asserts exact player/cart/cargo/floor/equipment, authored-container, and salvage transfers with capacity rollback. `fc_p04_floor_drop_persistence_smoke.gd:53-132` asserts a partial floor pickup retains quantity, quality, condition, origin, and identity across save/revisit.

The live combat-corpse path reuses `LootContainer` (`playable_generated_ship.gd:8293-8399`), but `weapon_ammo_acquisition_smoke.gd:130-154` asserts only acquired/consumed quantity. Because the owning feature explicitly names corpse loot among relevant holders, exact production corpse-loot quality/provenance remains unverified.

### 6. `FC-06`

> Quality changes the declared live item effect and is visible to the player

**Trace — traced.** `quality_effects.json` plus `ItemQualityEffects` supplies declared lot multipliers to consumables, timed tools, paid repair material, and component power projections; inventory and picker panels render the same declarations/previews. `fc_p05_smoke.gd:52-148` checks every recipe output has a valid consumer and crafts two qualities; `:170-257` compares consumable effects; `:265-375` ties preview/escrow/output/receipt quality; `:409-476` compares component power/gates; `:506-589` checks player-visible effect and prediction text; and `:796-815` checks paid repair quality. `fc_p09_smoke.gd:302-463` proves crafted welder/cutter quality changes timed work. ADR-0066’s retired mount/dismount/plating repair effects are excluded.

### 7. `FC-07`

> Every queued job pays once and has independent identity and station ownership

**Trace — traced.** `CraftJobScheduler.enqueue` validates, reserves exact source-holder lots, and creates `<ship>/<station>/job-######`; completion publishes `<job>/output`. `fc_p07_smoke.gd:98-149` asserts the exact first ID, one payment, immutable escrow-derived output, one receipt, and replay-safe collection. `:151-248` proves two same-kind station queues remain independent and rejects foreign holder/ship operations; `:490-567` uses two physical station owners and asserts exactly two outputs with no third receipt.

### 8. `FC-08`

> Power/cancel/retry preserve correct escrow, progress and quantities

**Trace — traced.** Scheduler and field-work state own pause/cancel/retry, while `PendingOutputStore` owns exact recoverable output/refund lots. `fc_p07_smoke.gd:151-203,265-345,374-430` asserts isolated power pause, no unpowered progress, no duplicate catch-up, exact unstarted refund, started forfeiture, and full-destination recoverable escrow. `fc_p08_smoke.gd:118-236,469-656` asserts store-before-ack interruption, recoverable refund, exhaustion/home/away pause, resume without a second spend, retry without duplicate, and reload/revisit collection once.

### 9. `FC-09`

> Finished outputs and salvage yields remain recoverable when destinations fill

**Trace — traced.** Accepted ADR-0062 makes `PendingOutputStore` the ship-owned receipt authority. `fc_p08_smoke.gd:40-114` asserts partial/full collection, exact remainder, `destination_full`, idempotency, and strict round trip; `:182-287` moves a full salvage yield into one receipt and later collects its exact provenance; `:384-462,469-628` assert station/field orphan persistence and collect-once after reload/revisit. `fc_p09_smoke.gd:263-297` fills the live output stack, requires retained pending plus visible `destination_full`, frees capacity, and collects once.

### 10. `FC-10`

> Recipes and repair BOMs form reachable, non-profitable conversion chains

**Trace — natural-acquisition partial.** `check_crafting_economy.py:1545-1607,2231-2366` loads live recipes/items/loot/components/stations/work actions/systems, binds reviewed production consumers, computes reachability and source cardinality, and rejects unreachable inputs/outputs/repair tools/parts and profitable zero-power cycles. `test_crafting_economy.py:1277-1293` runs that real-source model and requires 61 recipes with empty reachability/knowledge/repair/cycle blockers; `:1014-1164,1198-1260` exercises book/reverse/codex and profitable/neutral cycle predicates.

`fc_p09_smoke.gd:157-191` finds a circuit board from authored starter containers and pays a timed navigation repair, but it is validation-driven and force-repairs other systems. It does not establish the owning feature’s natural end-to-end acquisition scenario. The graph and static live-source reachability are covered; natural acquisition remains partial.

### 11. `FC-11`

> Crafting/field/salvage UI exposes choice, costs, quality, queue and blocked reasons

**Trace — source-mapped validation gap.** `RecipePickerPanel` renders queue/max/power/pending state (`recipe_picker_panel.gd:78-99`), blocked/queued/collection/cancel results (`:192-278`), and status, skill, ingredient costs, output, quality preview/input lot IDs, hints, and field/salvage labels (`:320-360`). `recipe_picker_panel_smoke.gd:128-158,182-278` checks choice, blocked confirm, queue/power/pending/cancel behavior. `fc_p05_smoke.gd:506-589` checks visible quality effect/preview text, and `fc_p09_smoke.gd:91-298` checks physical station blockers, queue, power, cancel, pending, and `destination_full`.

The field and salvage main-scene smokes (`main_playable_slice_recipe_picker_smoke.gd:148-192`; `main_playable_slice_salvage_picker_smoke.gd:54-115`) assert non-first selection, correct mode, confirm, and output using seeded inputs. They do not assert every applicable cost/quality/queue/blocked field in each mode, and the feature’s final mouse/keyboard/controller scenario remains pending.

### 12. `FC-12`

> Jobs, knowledge, output and quality survive old/new save paths

**Trace — traced.** Save/load captures scheduler jobs/escrow/resolved quality, current-run recipe knowledge, ship-owned pending outputs, field history, and exact lots through staged current and recognized-legacy readers. `fc_p10_smoke.gd:268-314` checks coherent current save slots and staged restore; `:472-476` preserves sub-ULP lot quality; `:576-742` checks away jobs, pending receipts, forfeited cancellation, field output, and repeated reload; its legacy cases retain paid progress/history without recharge and migrated output quality.

`fc_p10_process_smoke.gd:347-465` explicitly labels materials/recipe access as fixtures with **no acquisition claim**, then records knowledge, inventory lots, crafting, job and receipt state. `:488-553` requires exact cross-process equality before and after one-time collection. Fixture-assisted setup is suitable evidence for this persistence leaf and is not presented as natural acquisition.

## Material gaps

- FC-02 still needs the explicitly pending full engine/native baseline.
- FC-04’s knowledge, skill, and tier pairs are covered across existing predicates; only an isolated real picker `missing_ingredients` assertion is absent.
- FC-05 lacks exact quality/provenance assertion on the real combat-corpse loot path.
- FC-10’s graph is covered, but natural acquisition remains outside the validation-driven route.
- FC-11 lacks all-applicable-field assertions across field and salvage modes plus the final input-device player scenario.

These are evidence boundaries from a source-only audit. None is promoted to a runtime defect or completion claim.
