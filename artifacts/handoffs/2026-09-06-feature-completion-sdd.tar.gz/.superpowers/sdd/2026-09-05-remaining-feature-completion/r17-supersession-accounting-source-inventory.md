# R17 supersession accounting source inventory

Read-only inspection of `tools/build_feature_acceptance.py`, its tests, the
reviewed supersession source, and current requirement/ADR text. No registry,
runtime, test, or Git mutation was performed.

## Existing authority and accounting contract

- `tools/build_feature_acceptance.py:23-30` names the canonical reviewed source
  `data/validation/reviewed_criterion_supersessions_v1.json` and schema
  `reviewed-criterion-supersessions-v1`.
- The loader at `:616-735` requires each row to preserve the original natural
  ID as `stable_criterion_id`, record original and replacement text/fingerprints,
  and carry an accepted ADR/reviewer/date. The current accounting schema is
  exact-keyed and only accepts `metric_disposition="one_for_one_active_leaf"`,
  `acceptance_kind="requirement"`, `deferred=false`, denominator membership
  true, `representative_id=stable_criterion_id`, and `denominator_delta=0`.
  It rejects a disposition that removes the old leaf or decreases the frozen
  denominator.
- `_apply_reviewed_supersessions` at `:740-784` removes the replacement natural
  ID from the emitted criterion map, then emits the replacement content under
  the original stable ID and annotates `criterion_supersession` with both IDs.
  Coverage is similarly rewritten from replacement ID to stable ID. This gives
  an honest current-contract criterion while preserving original identity and
  one denominator row; it does not retain a separate retired row.
- `_scope_contract_fingerprint` at `:787-820` hashes the replacement criterion
  under the original criterion fingerprint for scope-freeze purposes. The
  frozen contract therefore preserves the original leaf set and ID semantics
  even though the current criterion text is the ADR replacement.
- Registry validation at `:1655-1778` requires superseded rows to appear under
  the stable ID, forbids a separately emitted replacement row, checks the
  annotation and metric representative, and requires the proposed active
  denominator to equal the count of non-deferred rows with denominator
  membership. `FROZEN_SCOPE_CONTRACT` at `:61-67` separately pins both the
  source-leaf fingerprint and reviewed-supersession-set fingerprint.

## What this means for retired source rows

The current schema supports **reviewed replacement under stable identity**, not
a distinct “superseded/retired and no longer active” disposition. An accepted
ADR can replace obsolete FireState wording with the effective
FireSuppressionState contract while keeping the original requirement ID and
denominator contribution. The original criterion and ADR evidence remain in
`criterion_supersession_review`; the emitted row's current criterion is the
replacement and its old evidence is reset on fingerprint change, as covered by
`tests/test_feature_acceptance_registry.py:test_reviewed_supersession_preserves_stable_scope_and_resets_old_evidence`.

This is materially different from claiming the old behavior is still active:
the current criterion text and runtime/source evidence must describe the
replacement contract. The accounting row remains one-for-one solely because
the reviewed source explicitly mandates that metric disposition.

## Concrete existing evidence

- `data/validation/reviewed_criterion_supersessions_v1.json` currently contains
  one accepted ADR-0066 mapping (`REQ-SMOD-001`), demonstrating the supported
  shape: original wording, replacement wording, accepted review, and
  `denominator_delta: 0`.
- The current requirements text already records the FireState retirement in
  `docs/game/05_requirements.md:217-222`: the old FireState criterion is struck
  through and says it is superseded by ADR-0041, with FireSuppressionState as
  the live authority. `docs/game/adr/0041-fire-as-persistent-compartment-hazard.md`
  is the authority for that retirement. The acceptance registry still contains
  the source wording as a criterion row (`docs/game/inventory/feature_acceptance.json`
  around entry 16901), showing why a reviewed mapping is needed if this is to
  be represented as a stable current contract rather than merely prose.
- `REQ-012` remains an autosave requirement in the validation plan and registry;
  this source inventory found no generic registry status field that can mark a
  requirement “retired by ADR” while retaining its original ID and excluding
  it from the frozen denominator. The supersession schema's one-for-one rule is
  the available honest path when an effective replacement criterion exists.

## Minimal authority gap

For an R17 report that says “REQ010 retired FireState” or “REQ012 no-meta
superseded by ADR-0033,” the coordinator must provide a reviewed mapping with
the exact source heading, original and effective criterion fingerprints, and
accepted ADR provenance. If the intended disposition is truly **removed from
the active contract** rather than replaced one-for-one, the current v1 schema
cannot express that without violating its loader assertions and frozen
denominator rules. That requires a separately reviewed schema/contract update;
inventing a new status field or changing the denominator in the current files
would be unsupported by the existing validator.

