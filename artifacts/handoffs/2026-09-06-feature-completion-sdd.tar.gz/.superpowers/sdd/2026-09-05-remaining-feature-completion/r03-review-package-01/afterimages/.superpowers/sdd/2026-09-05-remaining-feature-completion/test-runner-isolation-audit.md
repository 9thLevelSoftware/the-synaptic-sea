# Test-runner isolation audit

Read-only audit of the feature-completion runner, P02 canonical extraction
path, and P10 process runner. No Godot/tests were run.

## `tools/run_feature_completion.py`

Per-case execution is isolated when invoked through this Python runner:

- `main()` creates `evidence/user-data` (`lines 250-251`).
- `execute_case()` passes the run-local home through its command and environment
  (`lines 154-166`). The current `--user-data-dir` argument is unsupported in
  this Godot context and must not be treated as isolation evidence.
- `_environment()` propagates the same path through `GODOT_USER_PATH`,
  `XDG_DATA_HOME`, `APPDATA`, and `LOCALAPPDATA` (`lines 147-151`).
- The canonical bundle receives those four variables in its child environment
  (`lines 212-220`). Containment must be verified from inside the Godot project
  using `ProjectSettings.globalize_path("user://")`; command-line
  `--user-data-dir` is not a valid guard here.

The runner does not require a new empty evidence directory. It uses
`evidence.mkdir(..., exist_ok=True)` and `user_data.mkdir(exist_ok=True)`, so a
reused evidence directory can reuse prior user-data. There is no preflight
probe that starts Godot with a fresh home and proves the project creates no
files outside it. `metadata()` invokes `godot --version` with the host process
environment (`lines 138-145`), also outside the run-local environment, although
that probe does not load the project.

## P02 canonical regression path

The P02 path is `run_feature_completion.py --profile baseline|all`, which
extracts the current Regression bundle from
`docs/game/06_validation_plan.md` (`extract_regression_bundle`, lines 104-133),
prepares it, and executes it with verified Bash (`_verified_bash`, lines
180-194). The historical `tools/synaptic_sea_gate4_regression.sh` is
macOS-hardcoded and should not be used unchanged.

The canonical `run_clean()` in `docs/game/06_validation_plan.md:401-419`
invokes Godot as `--headless --path "$ROOT" --script ...` with no
`--user-data-dir` and no per-command cleanup. The P02 wrapper currently sets
the four environment variables for the Bash process, so child Godot processes
inherit them, but the script itself has no assertion that Godot actually uses
the intended home and no protection against a smoke or subprocess overriding
the variables. Direct execution of the documented bundle bypasses even that
wrapper containment.

No separate no-save/user-data containment probe is present in the feature
runner, canonical regression bundle, or P02 extraction path.

## `tools/run_p10_process_smoke.py`

P10 has the strongest isolation currently present:

- `execute()` rejects a nonempty evidence directory (`lines 153-166`).
- It creates separate `producer-user-data`, `consumer1-user-data`, and
  `consumer2-user-data` homes (`lines 163-169`).
- `_execute_mode()` passes the mode home as the script's `--user_data` argument
  (`lines 122-132`); the current `--user-data-dir` argument is unsupported and
  is not valid containment evidence.
- `_environment()` sets all four Godot data variables to that same mode home
  (`lines 87-94`).

The metadata version probe uses `os.environ.copy()` rather than a mode home
(`lines 107-120`), but it only runs `godot --version` before project processes;
that command does not load the project and does not need runtime containment.
The P10 runner currently has no independent in-project no-save probe.

## Minimal follow-up

For R03 and R18, the smallest containment closure is:

1. Keep the unique-empty-root requirement: the feature runner currently allows
   reused evidence/user-data directories, while P10 rejects a nonempty evidence
   root.
2. Add a no-save Godot script/probe that runs before smoke logic under the four
   environment variables and asserts
   `ProjectSettings.globalize_path("user://")` is inside the owned root. This
   is the containment check; do not infer containment from unsupported
   `--user-data-dir` or from a global/default-profile filesystem scan.
3. R02 should invoke that probe separately for each P10 producer/consumer home.
   R03/R18 feature and P02 runners need the equivalent guard before their smoke
   bodies, with the four environment variables propagated unchanged.
4. Do not add runtime containment requirements to the `godot --version`
   metadata probe; it does not load the project.

These changes are tooling/test-runner follow-up only. The R02 implementer owns
any P10 smoke probe addition; this audit does not implement it.
