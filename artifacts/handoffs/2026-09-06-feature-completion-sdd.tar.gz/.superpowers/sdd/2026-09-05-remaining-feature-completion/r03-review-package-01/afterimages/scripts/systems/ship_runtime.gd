extends RefCounted
class_name ShipRuntime

## Per-ship simulation context (pre-polish PKG-A1a strangler).
##
## Owns the advance / catch-up seam formerly inlined on PlayableGeneratedShip.
## The coordinator still owns scene tree, player, UI, and hub-expanded recompute;
## this class is the per-ship systems + web/hull tick entry point.
##
## Hub ships may inject coordinator-owned hull/web models via configure() because
## the home ship historically keeps those on the coordinator, not ShipInstance.
##
## Types: ShipInstance / HullIntegrityState / WebInfestationState are loaded by
## script path (class_name globals are unreliable under headless --script).

const CATCHUP_SUBSTEP_SECONDS: float = 5.0
const MAX_CATCHUP_SECONDS: float = 1800.0

## PKG-A3 tick bands (accumulators; no balance retune of rates themselves).
const SLOW_INTERVAL_SECONDS: float = 0.35
const LAZY_INTERVAL_SECONDS: float = 3.0

const ShipInstanceScript: GDScript = preload("res://scripts/systems/ship_instance.gd")
const HullIntegrityStateScript: GDScript = preload("res://scripts/systems/hull_integrity_state.gd")
const WebInfestationStateScript: GDScript = preload("res://scripts/systems/web_infestation_state.gd")

## ShipInstance (typed as RefCounted for headless class_name safety).
var ship: RefCounted = null
var is_home: bool = false
## HullIntegrityState override for hub; null → ship.get_hull().
var hull_override: RefCounted = null
## WebInfestationState override for hub; null → ship.get_web().
var web_override: RefCounted = null
## Callable() -> bool: contact boost for hub web growth (attached derelict docked).
var contact_boost_provider: Callable = Callable()
## PKG-B2.1b: optional ModuleIntegrityMap owned by this runtime.
var module_integrity: RefCounted = null
## PKG-D6.1: optional ComponentPlacementState owned by this runtime.
var component_placement: RefCounted = null
## FC-07: optional paid craft-job authority owned by this ship runtime.
var craft_job_scheduler: RefCounted = null
## Callable() -> Dictionary containing this ship's live inventory/station/knowledge context.
var craft_job_context_provider: Callable = Callable()
## Callable(Array) forwards completion events to the gameplay delivery owner.
var craft_job_receipt_sink: Callable = Callable()
## Durable event hand-off for callers that collect completed craft receipts.
var craft_job_receipts: Array = []

var _slow_acc: float = 0.0
var _lazy_acc: float = 0.0
## Diagnostic counters (smokes / balance tools).
var frame_band_fires: int = 0
var slow_band_fires: int = 0
var lazy_band_fires: int = 0


func configure(ship_inst: RefCounted, opts: Dictionary = {}) -> void:
	ship = ship_inst
	is_home = bool(opts.get("is_home", false))
	var hull_opt: Variant = opts.get("hull_override", null)
	hull_override = hull_opt as RefCounted if hull_opt is RefCounted else null
	var web_opt: Variant = opts.get("web_override", null)
	web_override = web_opt as RefCounted if web_opt is RefCounted else null
	var provider: Variant = opts.get("contact_boost_provider", Callable())
	if provider is Callable:
		contact_boost_provider = provider as Callable
	else:
		contact_boost_provider = Callable()
	var mi: Variant = opts.get("module_integrity",
		ship.call("get_live_module_integrity") if ship != null and ship.has_method("get_live_module_integrity") else null)
	module_integrity = mi as RefCounted if mi is RefCounted else null
	var cp: Variant = opts.get("component_placement",
		ship.call("get_live_component_placement") if ship != null and ship.has_method("get_live_component_placement") else null)
	component_placement = cp as RefCounted if cp is RefCounted else null
	var scheduler_opt: Variant = opts.get("craft_job_scheduler", null)
	craft_job_scheduler = scheduler_opt as RefCounted if scheduler_opt is RefCounted else null
	var craft_provider: Variant = opts.get("craft_job_context_provider", Callable())
	craft_job_context_provider = craft_provider as Callable if craft_provider is Callable else Callable()
	var craft_sink: Variant = opts.get("craft_job_receipt_sink", Callable())
	craft_job_receipt_sink = craft_sink as Callable if craft_sink is Callable else Callable()
	craft_job_receipts.clear()
	_slow_acc = 0.0
	_lazy_acc = 0.0
	frame_band_fires = 0
	slow_band_fires = 0
	lazy_band_fires = 0


func get_ship() -> RefCounted:
	return ship


func _resolve_hull() -> RefCounted:
	if hull_override != null:
		return hull_override
	if ship != null and ship.has_method("get_hull"):
		var h: Variant = ship.call("get_hull")
		return h as RefCounted if h is RefCounted else null
	return null


func _resolve_web() -> RefCounted:
	if web_override != null:
		return web_override
	if ship != null and ship.has_method("get_web"):
		var w: Variant = ship.call("get_web")
		return w as RefCounted if w is RefCounted else null
	return null


func _contact_boost() -> bool:
	if not is_home:
		return false
	if contact_boost_provider.is_valid():
		return bool(contact_boost_provider.call())
	return false


## Advance ONE ship's systems manager + biomatter-web hull damage (FRAME band).
## Does NOT tick fire, expanded hub recompute, player, or UI.
func advance(delta: float, world_time: float) -> void:
	if ship == null or delta < 0.0:
		return
	frame_band_fires += 1
	ship.set("last_sim_time", world_time)
	var systems_manager: Variant = ship.get("systems_manager")
	if systems_manager != null and systems_manager is Object and (systems_manager as Object).has_method("advance"):
		(systems_manager as Object).call("advance", delta)
	_advance_craft_jobs(delta)
	var web: RefCounted = _resolve_web()
	var hull: RefCounted = _resolve_hull()
	if web == null or hull == null:
		return
	if not web.has_method("tick") or not hull.has_method("damage_compartment"):
		return
	var contact: bool = _contact_boost()
	var dmg: float = float(web.call("tick", delta, contact))
	if dmg <= 0.0:
		return
	var compartments: Variant = hull.get("compartments")
	if typeof(compartments) != TYPE_DICTIONARY:
		return
	for cid in (compartments as Dictionary).keys():
		hull.call("damage_compartment", str(cid), dmg)


## PKG-A3: accumulate delta and report which bands should fire this call.
## Returns { "frame": true, "slow": bool, "lazy": bool, "slow_dt": float, "lazy_dt": float }.
func poll_bands(delta: float) -> Dictionary:
	var result: Dictionary = {
		"frame": true,
		"slow": false,
		"lazy": false,
		"slow_dt": 0.0,
		"lazy_dt": 0.0,
	}
	if delta <= 0.0:
		result["frame"] = false
		return result
	_slow_acc += delta
	_lazy_acc += delta
	if _slow_acc >= SLOW_INTERVAL_SECONDS:
		result["slow"] = true
		result["slow_dt"] = _slow_acc
		_slow_acc = 0.0
		slow_band_fires += 1
	if _lazy_acc >= LAZY_INTERVAL_SECONDS:
		result["lazy"] = true
		result["lazy_dt"] = _lazy_acc
		_lazy_acc = 0.0
		lazy_band_fires += 1
	return result


## Fast-forward an absent ship by world_time - last_sim_time in capped sub-steps.
## Home ships are never catch-up targets (always present).
## PKG-A3: prefer LAZY quanta for inactive catch-up when gap is large; still
## bounded by CATCHUP_SUBSTEP_SECONDS so model rates stay stable.
func catch_up(world_time: float) -> void:
	if ship == null or is_home:
		return
	var last: float = float(ship.get("last_sim_time"))
	var dt: float = minf(world_time - last, MAX_CATCHUP_SECONDS)
	if dt <= 0.0:
		return
	ship.set("last_sim_time", world_time)
	var quantum: float = minf(CATCHUP_SUBSTEP_SECONDS, LAZY_INTERVAL_SECONDS)
	while dt > 0.0:
		var step: float = minf(quantum, dt)
		advance(step, world_time)
		lazy_band_fires += 1
		dt -= step


## PKG-A1b: compose one ship's runtime state for higher-level snapshots.
## RunSnapshot/WorldSnapshot still own top-level schema; this is the per-ship
## composition unit (ship_summary + last_sim_time + empty extension slots).
func to_snapshot() -> Dictionary:
	if ship == null:
		return {}
	var ship_id: String = str(ship.get("ship_id"))
	var last_sim_time: float = float(ship.get("last_sim_time"))
	var out: Dictionary = {
		"schema": "ship_runtime_v1",
		"ship_id": ship_id,
		"last_sim_time": last_sim_time,
		"is_home": is_home,
		"module_integrity": {},
		"component_manifest": {},
	}
	if ship.has_method("get_summary"):
		out["ship_summary"] = ship.call("get_summary")
	if module_integrity != null and module_integrity.has_method("get_summary"):
		out["module_integrity"] = module_integrity.call("get_summary")
	elif ship != null:
		var ship_mi: Variant = ship.get("module_integrity_summary")
		if typeof(ship_mi) == TYPE_DICTIONARY and not (ship_mi as Dictionary).is_empty():
			out["module_integrity"] = (ship_mi as Dictionary).duplicate(true)
	if component_placement != null and component_placement.has_method("get_summary"):
		out["component_manifest"] = component_placement.call("get_summary")
	elif ship != null:
		var ship_cp: Variant = ship.get("component_placement_summary")
		if typeof(ship_cp) == TYPE_DICTIONARY and not (ship_cp as Dictionary).is_empty():
			out["component_manifest"] = (ship_cp as Dictionary).duplicate(true)
	if craft_job_scheduler != null and craft_job_scheduler.has_method("get_summary_for_ship"):
		out["craft_jobs_v1"] = craft_job_scheduler.call("get_summary_for_ship", ship_id)
	return out


func from_snapshot(data: Dictionary) -> bool:
	if ship == null or data.is_empty():
		return false
	var restore_ship_id: String = str(ship.get("ship_id"))
	if data.has("craft_jobs_v1"):
		var strict_jobs: Variant = data.get("craft_jobs_v1", null)
		if not _valid_current_craft_snapshot(data, restore_ship_id) \
				or craft_job_scheduler == null \
				or not craft_job_scheduler.has_method("merge_summary_for_ship") \
				or not strict_jobs is Dictionary \
				or not bool(craft_job_scheduler.call(
					"merge_summary_for_ship", restore_ship_id, strict_jobs)):
			return false
	if data.has("last_sim_time"):
		ship.set("last_sim_time", float(data.get("last_sim_time", ship.get("last_sim_time"))))
	if data.has("ship_summary") and ship.has_method("apply_summary"):
		var summary: Variant = data.get("ship_summary", {})
		if typeof(summary) == TYPE_DICTIONARY and not (summary as Dictionary).is_empty():
			ship.call("apply_summary", summary)
	if data.has("module_integrity"):
		var mi: Variant = data.get("module_integrity", {})
		if typeof(mi) == TYPE_DICTIONARY:
			var mi_dict: Dictionary = mi as Dictionary
			if module_integrity != null and module_integrity.has_method("apply_summary"):
				module_integrity.call("apply_summary", mi_dict)
			# PKG-D6.1: always mirror onto ShipInstance sparse pack for revisit.
			ship.set("module_integrity_summary", mi_dict.duplicate(true))
	if data.has("component_manifest"):
		var cp: Variant = data.get("component_manifest", {})
		if typeof(cp) == TYPE_DICTIONARY:
			var cp_dict: Dictionary = cp as Dictionary
			if component_placement != null and component_placement.has_method("apply_summary"):
				component_placement.call("apply_summary", cp_dict, restore_ship_id)
			ship.set("component_placement_summary", cp_dict.duplicate(true))
	return true


func _valid_current_craft_snapshot(data: Dictionary, restore_ship_id: String) -> bool:
	for key in [
		"schema", "ship_id", "last_sim_time", "is_home",
		"module_integrity", "component_manifest", "craft_jobs_v1",
	]:
		if not data.has(key):
			return false
	var time_variant: Variant = data.last_sim_time
	if restore_ship_id.is_empty() \
			or typeof(data.schema) != TYPE_STRING or str(data.schema) != "ship_runtime_v1" \
			or typeof(data.ship_id) != TYPE_STRING or str(data.ship_id) != restore_ship_id \
			or (typeof(time_variant) != TYPE_INT and typeof(time_variant) != TYPE_FLOAT) \
			or not is_finite(float(time_variant)) \
			or typeof(data.is_home) != TYPE_BOOL or bool(data.is_home) != is_home \
			or not data.module_integrity is Dictionary \
			or not data.component_manifest is Dictionary \
			or not data.craft_jobs_v1 is Dictionary:
		return false
	if data.has("ship_summary"):
		if not data.ship_summary is Dictionary:
			return false
		var ship_summary: Dictionary = data.ship_summary
		if typeof(ship_summary.get("ship_id", null)) != TYPE_STRING \
				or str(ship_summary.ship_id) != restore_ship_id:
			return false
	return true


func _advance_craft_jobs(delta: float) -> void:
	if ship == null or craft_job_scheduler == null \
			or not craft_job_scheduler.has_method("advance") \
			or not craft_job_context_provider.is_valid():
		return
	var resolved: Variant = craft_job_context_provider.call()
	if not (resolved is Dictionary):
		return
	var context: Dictionary = resolved as Dictionary
	var runtime_ship_id: String = str(ship.get("ship_id"))
	if runtime_ship_id.is_empty() or typeof(context.get("ship_id", null)) != TYPE_STRING \
			or str(context.get("ship_id", "")) != runtime_ship_id:
		return
	var emitted: Variant = craft_job_scheduler.call("advance", delta, context)
	if emitted is Array:
		var receipts: Array = []
		for receipt in emitted:
			if receipt is Dictionary:
				var copied: Dictionary = (receipt as Dictionary).duplicate(true)
				craft_job_receipts.append(copied)
				receipts.append(copied)
		if not receipts.is_empty() and craft_job_receipt_sink.is_valid():
			craft_job_receipt_sink.call(receipts)


## Compose multiple runtimes into one dictionary for multi-ship persistence tests.
static func compose_runtime_snapshots(runtimes: Array) -> Dictionary:
	var ships: Array = []
	for rt_variant in runtimes:
		if rt_variant is RefCounted and (rt_variant as RefCounted).has_method("to_snapshot"):
			ships.append((rt_variant as RefCounted).call("to_snapshot"))
	return {"schema": "ship_runtime_bundle_v1", "ships": ships}
