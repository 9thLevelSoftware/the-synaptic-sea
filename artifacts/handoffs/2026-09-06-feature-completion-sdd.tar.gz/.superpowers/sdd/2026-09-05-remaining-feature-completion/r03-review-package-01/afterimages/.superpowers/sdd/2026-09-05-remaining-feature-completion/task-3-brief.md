### Task 3: R03 — Close atomic save/load and migration acceptance

**Parent:** P10/FC-12. **Owner:** Sol. **Dependencies:** R02.

**Files:** existing P10 allowed files and `scripts/validation/fc_p10_smoke.gd`, `fc_p10_process_smoke.gd`, `fc_p13_smoke.gd`; `tools/run_p10_process_smoke.py`; `tests/test_p10_process_runner.py`; historical fixtures under `tests/fixtures/feature_completion/`.

- [ ] Review and rerun the latest terminal/refund/field forgery, legacy downgrade, started/unstarted cancellation, partial collection, station destruction, inactive catch-up, and source-buffer mutation matrix against the final combat fix.
- [ ] Confirm failure snapshots compare inventory/escrow/receipts, owner graph, mounted lots, audio buses/playback state, current camera, source file bytes, index, and absence of precommit migrated sidecars.
- [ ] Verify present malformed audio/settings/system data rejects atomically; valid nondefault values survive two loads. Preserve exact quality beyond default JSON precision.
- [ ] Test the one documented derived oxygen projection: boolean validation, exact exception path only, unrelated oxygen drift rejection, and correct context after activation/revisit/tick.
- [ ] Verify old world-4 absent home access becomes explicit local ownership in the detached candidate, present foreign access remains unchanged, and present empty/malformed access rejects. A migrated sidecar is published only after successful commit.
- [ ] Cover manual/auto/quick/title load, same-ship and cross-ship component moves, stale coordinator pointers, and station interactions after partial/full output collection.
- [ ] Run focused P10/P13, all save-migration/load/world smokes named in the original plan, sixteen process-runner tests, and the complete three-process proof with unique initially empty homes.
- [ ] Obtain final independent review on one stable diff and source manifest, replacing obsolete moving-source review conclusions with an evidence-linked disposition.

**Exit:** no known P10 production blocker or required untested matrix row remains. This closes P10 evidence, not G1 by itself.

## R03 local governance checkpoint

- **Requirement/spec authority:** FC-12, REQ-012, REQ-013, the atomic persistence
  closure in `docs/game/features/crafting_derelict_feature_completion.md`, and
  ADR-0059 decisions 17-31 and 33-43. Decision 43 requires current v6 exact
  String `combat_hotbar_text`, adapts recognized pre-v6 absence to `""`, and
  preserves present historical text byte-for-byte. Any new persistence policy is recorded as
  an additive ADR-0059 decision before its runtime implementation.
- **Local card:** P10 on board `synaptic-sea-stage-gate`; external synchronization
  remains explicitly `pending` until a real connector confirms it.
- **Added allowed files:** `scripts/systems/ship_work_context.gd`;
  `scripts/systems/electrical_arc_state.gd` only for exact persisted
  `time_in_state` hydration and `scripts/validation/electrical_arc_state_smoke.gd`
  for the sub-millisecond regression;
  `scripts/ui/recipe_picker_panel.gd`; `scripts/ui/ship_modification_panel.gd`;
  `scripts/tools/crafting_station.gd`; `scripts/validation/fc_p13_smoke.gd`;
  `scripts/validation/ship_mod_run_snapshot_smoke.gd`; existing
  `main_playable_quicksave_smoke.gd`, `main_playable_meta_autosave_smoke.gd`,
  `title_save_query_smoke.gd`, and `title_load_failure_smoke.gd` for R03 load
  assertions only; `tools/run_feature_completion.py` and
  `tests/test_feature_completion_runner.py` for runner containment; this brief,
  the P10 plan/spec/ADR/requirement references, and the generated local card and
  acceptance registry sources.
- **Non-goals:** no save filename changes, historical-data deletion, default
  profile cleanup, comparison epsilon, new ignored fields, generalized oxygen
  normalization, combat-schema weakening, editor/import/plugin launch, or
  unrelated P09/P17/catalog/navigation behavior.
- **Verification:** isolated no-save probe then each focused Godot case; P10,
  P13, migration service, migration world, save/load service, RunSnapshot,
  WorldSnapshot, world-save, ship-mod RunSnapshot, combat, procgen, manual,
  quick, auto, and title paths; `tests/test_p10_process_runner.py` and
  `tests/test_feature_completion_runner.py`; the complete three-process proof;
  `tools/build_feature_acceptance.py --check`. Every retained row includes the
  exact command/environment, probe and smoke logs, exit/timeout/marker count,
  diagnostics scan, and source hashes.


## Preliminary validation inventory
Read r03-validation-inventory.md in this workspace as source-trace preparation, not acceptance. Verify its suspected missing rows against the stable R02 result: successful title load; independent quick/auto load authority; malformed oxygen projection and postactivation/revisit/tick context. Existing full-snapshot equality assertions can establish unchanged state; do not add noisy success logs or require changed-key diffs for successful equality merely because the inventory suggests them. Existing tests/markers/constants may change under R02, so derive final commands and markers from reviewed code. Include RunSnapshot/WorldSnapshot/world-save and combat/procgen regressions newly required by R02 scope, alongside original P10/P13 suite. Preserve exact only-oxygen exception. Root owns runtime windows and commits; write report with final source closure and raw evidence before independent review.

## Mandatory test isolation inherited from R02 incident
Every Godot run must set fresh APPDATA, LOCALAPPDATA, GODOT_USER_PATH, and XDG_DATA_HOME and first run the accepted no-save probe to prove resolved user:// containment in the owned initially empty root before any smoke body or cleanup. Reuse the reviewed R02 runner/probe, and retain raw command, environment, containment result, stdout/stderr, exit, timeout, marker count, diagnostic scan and source hashes. The default profile is read-only; R02-default-profile-observed-20260905 is an AFTER image, not a recovery baseline. Do not rerun legacy shell commands that set only GODOT_USER_PATH/XDG or unsupported --user-data-dir.
Read test-runner-isolation-audit.md: add per-owned-home no-save probe invocation to process runner before smoke modes, and equivalent feature/P02 guards with unique initially empty evidence roots before broader runs. Unsupported --user-data-dir is not containment. Extend allowed tooling scope to tools/run_feature_completion.py and its existing tests for this demonstrated isolation gap; record governance scope before implementation. Version-only metadata probes do not load the project and need no gameplay containment proof.

## R02 accepted handoff and newly observed persistence case
R02 spec/quality approved in task-2-fix1-review.md: all8 findings addressed;9 isolated focused gates, Python38 and process03 PASS. Preserve current combat schema/pair matrix/home profiles/canonical host bootstrap and all exact comparison rules. Read task-2-fix1-report.md. The process proof normalized an unrelated inactive electrical-arc timer only in fixture setup: process-proof-01 captured 1.49954052188553 and production rebuilt it as1.5, rejecting consumer1 before combat checks. R03 must investigate/reproduce and close that valid nondefault arc-timer round-trip issue, not carry fixture normalization forward as general persistence acceptance. Raw evidence: artifacts/feature-completion/R02-fix1-evidence-20260905-01/process-proof-01. No comparison exemption beyond documented derived oxygen is authorized. Also finish world_save_service missing ship_id and ship_mod_run_snapshot condition-lot fixtures, preserving their behavioral assertions. Existing process runner now invokes the accepted no-save probe itself; avoid reimplementing it.

## Coherent commit dependency closure
Root accepted R02 and deferred its runtime commit to this coherent P10 closure. In addition to existing P10 scope, inspect/preserve these preexisting uncommitted dependencies before any edits and include them in beforeimages/review: scripts/systems/component_placement_state.gd, crafting_state.gd, field_crafting_state.gd, recipe_knowledge_state.gd, craft_job_scheduler.gd, craft_job_state.gd, ship_work_context.gd, ship_runtime.gd; scripts/main.gd; scripts/title_main.gd; scripts/audio/audio_manager.gd; scripts/camera/iso_camera_rig.gd; scripts/ui/save_load_menu.gd, menu_coordinator.gd, recipe_picker_panel.gd, ship_modification_panel.gd; scripts/tools/crafting_station.gd. These carry owner/job schemas, detached activation, protected audio/camera effects and matching UI arities. This is not blanket permission to change their unrelated gameplay. Include exact P10-relevant scope in governance before edits. ShipNavGraph P17 additions, work_action_driver/pillar P09 changes and modified item/loot/quality/recipe catalogs are not R02 dependency closure and remain outside this task unless a concrete scoped finding establishes need.
