# Task 2 / R02 Fix Round 1 Independent Review

## Review result

**Final round verdict: APPROVED.** All eight findings from `task-2-review.md` are addressed. The scoped fix is consistent with the accepted historical-pair and post-restore-anchor rulings in ADR-0059 decisions 40–42. I found no material regression introduced by `task-2-fix1-root-review.patch`.

**R02 spec verdict: PASS.** **Task quality verdict: Approved.** This verdict covers implementation and the retained automated evidence. Player acceptance remains unassessed and is not implied by this approval.

I verified the supplied patch SHA-256 `8bc3ee0c95f8edfbf91ee4cc3568f0f9c00862ca82d7cc182743a73bcb3f6306`, the fix report SHA-256 `f4486d31dfd65642a4fda475176e76700e9ce81ec2ba03e2654810882e7b8b8e`, and all 16 current source hashes against `task-2-fix1-source-manifest.json`. No Godot or test process was rerun for this review.

## Per-finding verdicts

### 1. HIGH — A world version does not pin the embedded run version

**Verdict: ADDRESSED.**

`scripts/systems/save_migration_service.gd:34-44` records the historical pair matrix established by ADR-0059 decision 40. `migrate_world()` validates the pair for current world-v6 and before every historical outer step at lines 118–153. `_validate_world_home_pair()` at lines 223–248 distinguishes missing, wrong-typed, and historically impossible versions with a stable structured reason. The v5-to-v6 result path at lines 799–832 retains the exact inner failure.

`scripts/validation/combat_persistence_smoke.gd:269-331` covers the complete accepted/rejected matrix, malformed inner versions, public world-v5/run-v4 and world-v5/run-v6 rejection, exact reasons, and source preservation. `scripts/validation/save_migration_world_smoke.gd:87-139` separately exercises public current and historical migration paths. The implementation no longer permits a new outer step to select an arbitrary older or newer inner migration chain.

### 2. HIGH — Active-away bootstrap hard-codes one anchor and does not restore relocated or docked ownership

**Verdict: ADDRESSED.**

ADR-0059 decision 41 establishes the recoverable authority available in historical saves: the persisted topology can prove that the current derelict is the stationary host after canonical restore, but it cannot recover an unrecorded historical root/socket transform. `scripts/systems/save_load_service.gd:294-315` now refuses to bootstrap absent active combat until that authority is established. `_active_host_anchor_is_reconstructable()` at lines 338–375 requires the active marker/ship identity, a positive `host == current_location` edge with a known non-active mobile owner, and rejects an active ship named as mobile.

`scripts/validation/combat_persistence_smoke.gd:452-544` exercises the service path with the production host/lifeboat relationship, compares against an independent literal production restore anchor, and rejects both missing-witness and active-mobile/relocated shapes with `combat_bootstrap_active_anchor_unreconstructable`. The fix no longer infers stationarity merely because a transform was absent.

### 3. HIGH — Home bootstrap treats a saved path as the authoritative generation source

**Verdict: ADDRESSED.**

`scripts/systems/save_load_service.gd:52-69` defines the three complete production bootstrap profiles approved by ADR-0059 decision 41. At lines 270–280, bootstrap first resolves the saved layout/kit/gameplay triple through `_canonical_home_combat_profile()`. That resolver at lines 320–335 requires exact String fields and an exact complete profile match, then returns the canonical profile value used for the resource read. An arbitrary caller-selected existing path is no longer used as authority.

`scripts/validation/combat_persistence_smoke.gd:419-449` proves a supported canonical profile succeeds and an existing but unsupported coherent-003 document pair fails with `combat_bootstrap_home_profile_unknown` while the source file remains byte-for-byte unchanged. Static inspection of `prepare_world_load()` at `scripts/systems/save_load_service.gd:160-240` confirms this rejection occurs on detached dictionaries before candidate storage, seal creation, manifest publication, or live-manager mutation.

### 4. HIGH — The R02 version bump leaves `save_load_service_smoke` failing

**Verdict: ADDRESSED.**

`scripts/validation/save_load_service_smoke.gd:52-113` now creates a coherent current owner graph and supplies an initialized-empty `threat-manager-2` summary at line 98. It uses current item-lot quality authority, compatible crafting/field summaries, and aligned owner identities. The later run-A fixture likewise rebuilds its inventory and knowledge ownership and adds current combat at lines 449–459. The version-negative test now persists a valid current envelope and mutates only the on-disk inner version before load, so it tests the reader rather than relying on the writer to preserve an invalid live version.

The retained `save_load_service_retry07` evidence has exit 0, exactly one `SAVE LOAD SERVICE PASS ...` marker, empty stderr, zero Godot diagnostics, and no timeout. This closes the R02-induced `invalid_world_snapshot` fixture regression.

### 5. HIGH — The focused validation isolation claim is false and the runs touched the default Godot profile

**Verdict: ADDRESSED.**

`.superpowers/sdd/2026-09-05-remaining-feature-completion/task-2-fix1-report.md:12-18` explicitly retracts the original isolation statement, classifies the old runs as debug history, discloses the default-profile side effect, and preserves the observed profile copy as an afterimage rather than a recovery source. It also states that the default profile was not cleaned or guessed back into an unknown prior state.

`scripts/validation/fc_p10_process_smoke.gd:17-31` adds a no-save probe before scene creation. Its containment checks at lines 715–741 require `ProjectSettings.globalize_path("user://")` and `OS.get_user_data_dir()` to agree under the requested root and require `APPDATA`, `LOCALAPPDATA`, `GODOT_USER_PATH`, and `XDG_DATA_HOME` to equal that root. `tools/run_p10_process_smoke.py:154-191` retains probe output and refuses to execute a process body after probe failure; lines 211–269 require all three probes for final PASS.

I inspected `focused-summary.json` and the raw probe/smoke stdout, stderr, and Godot logs for all nine final cases. Every probe and smoke had exit 0, exactly one expected marker, empty stderr, zero `ERROR:`, `WARNING:`, or `SCRIPT ERROR:` diagnostics, no timeout, and four equal environment roots. The aggregate file hash matches the report's `057c472d93c64dfa226966ef55dfd0c38bf29391f2d7b21352f2e3e2aaa9873d`. The final process-03 summary separately reports three passing probes, three passing modes, one marker per mode, existing artifacts, and `source_drift_detected=false`.

### 6. MEDIUM — Codec failure reasons are discarded by outer migration

**Verdict: ADDRESSED.**

`scripts/systems/save_migration_service.gd:176-220` routes the v5 run and world steps through structured result functions. `_migrate_v5_to_v6_result()` at lines 375–411 and `_migrate_world_v5_to_v6_result()` at lines 799–832 propagate the precise `ThreatSaveContract` reason rather than reducing it to an empty dictionary and generic malformed-payload result.

`scripts/validation/combat_persistence_smoke.gd:250-331` asserts exact `legacy_combat_unknown_archetype:<id>` reasons for an invalid inactive visited owner and invalid home combat, along with unchanged serialized source. The public migration wrapper retains those reasons.

### 7. MEDIUM — `last_attack_result` is not strict and the reward assertion stops before production behavior

**Verdict: ADDRESSED.**

`scripts/systems/threat_save_contract.gd:93-97` routes current receipts through `_validate_last_attack_result()`. The validator at lines 242–293 accepts only empty, exact incoming-damage, or exact weapon-hit shapes; it enforces exact String keys and identity types, finite bounded numeric values, complete typed armor profile, source/weapon agreement, true Boolean success, and integral ammunition count. `scripts/systems/threat_manager.gd:277-283` restores the already-validated String weapon ID without coercion.

`scripts/validation/combat_persistence_smoke.gd:100-163` covers a valid production incoming receipt and wrong-typed, unknown-field, non-finite, Boolean, and fractional ammunition mutants. `scripts/validation/fc_p10_smoke.gd:129-183` applies a restored lethal flare-pistol receipt to the production-connected threat manager, sweeps the dead threat through the real signal callback, and verifies one scavenging kill event/reward, the kill counter increment, and no intimidation event or XP change. The test is invoked from the live production validation path at lines 228–234.

### 8. MEDIUM — Apply retains derived LOS cache entries

**Verdict: ADDRESSED.**

`scripts/systems/threat_manager.gd:528-538` now clears `engaged_los` with the other derived runtime caches on successful hydration. Because validation still occurs before `_clear_runtime_nodes()`, a rejected summary preserves the prior cache. `scripts/validation/combat_persistence_smoke.gd:181-217` proves both sides: invalid apply retains the seeded LOS dictionary and all other protected state, while valid apply clears a stale LOS entry before restoring threats.

## New breakage

No CRITICAL, HIGH, MEDIUM, or LOW breakage was found in the scoped fix diff. The new receipt schema matches both production producers in `DamagePipeline.apply_to_vitals()` and `DamagePipeline.apply_to_threat()`, including the weapon extension added by `ThreatManager.attack_with_weapon()`.

## Out-of-scope observations

- The earlier `world_save_service_smoke` missing-`ship_id` failure and `ship_mod_run_snapshot_smoke` condition-lot WIP remain separately attributed pre-existing/downstream work. This fix neither claims nor supplies acceptance evidence for them.
- The default Windows profile has no known beforeimage. Its retained observed copy remains an after-state artifact and must not be used to guess a restoration.
- Player acceptance remains unassessed. The focused and process PASS markers establish the scoped automated gates only.

## Final assessment

The fix closes the prior correctness, authority, migration, validation, and evidence defects without weakening exact IDs, lot authority, capacity rules, or native generation contracts. R02 is approved for integration into the parent review flow.
