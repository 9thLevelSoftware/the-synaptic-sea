# R03 validation inventory (read-only preparation)

This inventory maps the eight R03 acceptance bullets in `task-3-brief.md` and
P10 in `docs/superpowers/plans/2026-09-04-crafting-derelict-feature-completion.md`
to the current validation sources. The checked-out source is moving R02 WIP;
this is a test inventory, not an acceptance of R02 combat code. No Godot or
Python tests were run while preparing this file.

## Required commands and markers

Run from `D:\the-synaptic-sea-feature-completion`, with Godot 4.7.2 accepted by
ADR-0060 and the project Python at `.superpowers/test-runtime/Scripts/python.exe`.

```powershell
$Godot = "<installedGodot4.7.2>"
$Python = ".superpowers/test-runtime/Scripts/python.exe"
& $Godot --headless --path . --script res://scripts/validation/fc_p10_smoke.gd
& $Godot --headless --path . --script res://scripts/validation/fc_p13_smoke.gd
& $Godot --headless --path . --script res://scripts/validation/save_migration_service_smoke.gd
& $Godot --headless --path . --script res://scripts/validation/save_migration_world_smoke.gd
& $Godot --headless --path . --script res://scripts/validation/save_load_service_smoke.gd
& $Python -m pytest -q tests/test_p10_process_runner.py
& $Python tools/run_p10_process_smoke.py --godot $Godot --evidence-dir <new-empty-unique-evidence-dir>
```

Expected exact markers are respectively `FC P10 PASS`, `FC P13 PASS`, `SAVE
MIGRATION SERVICE PASS`, `SAVE MIGRATION WORLD PASS
unknown_version_passthrough=true legacy_home_ship_migrated=true
current_world_home_ship_migrated=true`, `SAVE LOAD SERVICE PASS
round_trip=true version_match=true summaries=32 survival_roundtrip=true`, 16
passing Python tests, and the runner's `FC P10 PROCESS PASS` with producer,
consumer1, and consumer2 mode markers in retained logs. The process command
must use a new initially empty evidence directory; the runner creates unique
child homes and rejects reuse.

The original P10 plan explicitly names only the three migration/load smokes
above. `fc_p10_smoke.gd` and `fc_p13_smoke.gd` are the focused R03 additions.

## Acceptance-to-coverage matrix

### 1. Adversarial transaction matrix against the final combat fix

**Existing coverage:** `fc_p10_smoke.gd` calls
`_validate_terminal_authority_matrix`, `_validate_legacy_terminal_contracts`,
`_validate_away_field_pin`, `_validate_inactive` behavior in
`_validate_away_owner_graph`, and `_validate_component_move_round_trips` from
`_validate_live_production`. The terminal/field/refund mutant helpers are
`_validate_field_receipt_authority_mutants`,
`_validate_refund_receipt_authority_mutants`, and
`_validate_current_terminal_contract_mutants`. Legacy started/unstarted
cancellation is exercised by `_legacy_terminal_world` plus
`_round_trip_legacy_terminal_world`; partial collection and station destruction
are represented by pending output/receipt and malformed station descriptor
cases. Source-buffer mutation is `_validate_exact_read_buffer_seal` and
`_validate_changed_source_rollback`. Fresh-process output collection is covered
by `fc_p10_process_smoke.gd` `_run_producer_step`, `_run_consumer_one`, and
`_run_consumer_two`.

**R03 run row:** execute focused P10, then the three named migration/load smokes,
then the process proof. Review the resulting logs against the final R02 source
manifest. Combat persistence itself remains R02-owned and must be reviewed by
the R02 owner; do not treat this inventory as a second combat review.

**Gap/qualification:** the brief requires the *latest* matrix after R02 fixes.
Current helper names show the matrix exists, but no fresh evidence is present in
this inventory. Mark this row pending until fresh logs and a stable source
manifest are captured.

### 2. Complete failure snapshot and rollback

**Existing coverage:** `_validate_injected_rollback` runs at
`after_rebuild`, `after_world_apply`, and `before_activation`, and compares the
live world, active run, metadata, source bytes, audio model, global AudioServer
bus volume/mute, physical playback count, camera, input map, and
`_persistence_file_snapshot()`. The latter recursively snapshots `user://saves`
(including the index) plus progression files. `_validate_changed_source_rollback`
proves a post-prepare source-byte mutation is rejected. `_validate_rejected_run`
and `_validate_rejected_world` assert unchanged source/path and no
`.migrated.json` sidecar. `_validate_invalid_json_prepare_read_only` asserts an
invalid source does not mutate disk/index/diagnostics. Prepared-token seal and
mutation rejection are exercised in the live production sequence around lines
240–255.

**Expected evidence:** each injected failure leaves the old playable pointer,
owner graph, mounted lots, camera, audio server/playback, source bytes, save
index, and sidecar set unchanged. A rejected legacy/current malformed fixture
must retain original bytes and have no precommit migrated sidecar.

**Gap/qualification:** the helper snapshot is broad, but the final report must
list the changed-key diff for every failure point and explicitly identify the
index and `*.migrated.json` entries. A zero exit without these log assertions is
insufficient.

### 3. Malformed audio/settings/system data and precision

**Existing coverage:** `_validate_staged_malformed_subsystem_rejections` has
three present-malformed cases: non-string audio voice-log ID, non-boolean
settings `motion_reduce`, and malformed ship-system `systems` array. It checks
candidate rejection, unchanged live pointer/camera/world/source, and no leaked
prepared authority. The normal path sets nondefault settings and audio values
(`music=-13.375000000000002`, ambient mute, voice log), then loads twice and
compares settings and bus config. `_validate_exact_authority_precision_and_oxygen_projection`
also checks two distinct quality values (`0.293333333333333` versus
`0.293333333333334`).

**Expected evidence:** `FC P10 PASS`; malformed cases must be visible in the
failure diagnostics if one fails, and the two-load comparison must retain the
nondefault values and exact quality distinction.

**Gap/qualification:** current malformed coverage is exactly three subsystem
mutants. If R02 adds a new persisted combat/settings field, add a named mutant
row before acceptance rather than relying on generic snapshot equality.

### 4. The single derived oxygen projection exception

**Existing coverage:** `_validate_exact_authority_precision_and_oxygen_projection`
computes expected production context from field-suit pressure or breach-zone
occupancy, checks the restored boolean, mutates unrelated `drain_rate` and
requires canonical restore inequality, and preserves sub-ULP quality. The
persisted `oxygen_summary.player_in_breach_zone` is the only documented
comparison exception in the original P10 plan.

**Required explicit rows for the next run:**

1. Present oxygen projection is boolean and accepted only through the exact
   derived exception path.
2. One staged-rebuild projection difference is accepted.
3. A malformed non-boolean projection is rejected atomically.
4. Unrelated oxygen drift (already represented by `drain_rate`) is rejected.
5. After activation, revisit, and tick, the projection matches current scene
   overlap or active field-atmosphere context.

**Gap:** the current helper visibly covers (1), (2), (4), and initial context;
it does not name a standalone malformed non-boolean oxygen mutant or separate
post-activation/revisit/tick assertions. Add/identify those exact log rows in
the R03 implementation before claiming full coverage. Do not broaden the
exception to any other oxygen, combat, or summary field.

### 5. Legacy world-4 home access and sidecar publication

**Existing coverage:** `fc_p13_smoke.gd` `_validate_pure_contract` checks a
foreign modern owner remains `remote_owner` and a verified legacy absent owner
is claimed by `player_local`. `_validate_home_access_disk_round_trip` exercises
legacy absent access through a real world file and checks the detached candidate,
publication, and restored owner. `fc_p10_smoke.gd` `_validate_legacy_world`
checks world-4 to world-5/home current-run-5 migration, bound legacy knowledge
across three loads, unchanged original source bytes, and normalized reload.
`_validate_current_world` checks present foreign access remains `player:foreign`.
`_validate_rejected_world` checks present empty/malformed cases retain bytes and
write no sidecar. `_validate_legacy_run` and `_validate_rejected_run` provide the
run-side equivalents.

**Expected evidence:** detached legacy candidate has explicit local ownership;
foreign ownership is unchanged; empty/malformed present access rejects; a
`.migrated.json` appears only after successful commit/publication, never during
prepare or failed apply.

**Gap/qualification:** confirm the final log distinguishes prepare-time source
bytes from post-commit sidecar publication. Existing helper names establish the
cases, but sidecar publication timing must be cited from fresh evidence.

### 6. Manual/auto/quick/title paths, component moves, stale pointers, stations

**Existing coverage:** `fc_p10_smoke.gd` production setup saves a manual slot,
quicksave, and autosave (`_validate_live_production` lines 170–185), opens the
manual row through the visible save/load menu, and checks replacement
`menu_coordinator`/`save_load_menu` pointers. It loads twice and interacts with
all station kinds through `_validate_all_station_kinds_through_ordinary_interact`.
`_validate_component_move_round_trips` explicitly performs same-ship and
cross-ship moves, saves/loads twice, revisits the source owner, and checks one
immutable lot and hard/soft links. `fc_p13_smoke.gd` covers per-ship restoration
binding, stale binding generations, explicit selected-ship context, stale target
pause/cancel, and coordinator-map fallback denial via
`_validate_transaction_authority_fail_closed`.

Existing standalone path smokes and markers are:

| Path | Command suffix | Expected marker | Current limitation |
|---|---|---|---|
| manual UI save/load | `res://scripts/validation/fc_p10_smoke.gd` | `FC P10 PASS` | Covered in production flow |
| quick save | `res://scripts/validation/main_playable_quicksave_smoke.gd` | `MAIN PLAYABLE QUICKSAVE PASS slot=quicksave kind=quick cooldown=true` | Save/cooldown focused; no full R03 two-load authority matrix alone |
| auto save | `res://scripts/validation/main_playable_meta_autosave_smoke.gd` | `MAIN PLAYABLE META AUTOSAVE PASS slot_rotated=true reachable=true` | Rotation/reachability focused; full load is in P10 flow |
| title query/load failure | `res://scripts/validation/title_save_query_smoke.gd` and `title_load_failure_smoke.gd` | `TITLE SAVE QUERY PASS no_save=true has_save=true frozen_blocks=true`; `TITLE LOAD FAILURE PASS returned_to_title=true error_surfaced=true menu_visible=true` | Failure-return path only; no successful title-initiated load round-trip is named |

**Gap:** successful title load and independent auto/quick load round-trips are
not named in the current focused P10 flow. Add explicit checks or record them as
remaining missing coverage. Manual load pointer rebinding is covered; stale
coordinator pointers are covered by P13 fail-closed and P10 replacement checks.

### 7. Full validation suite and three-process proof

**Exact focused commands:** the seven commands in the first section. For the
standalone path rows, use the same Godot command shape, replacing the script
suffix with the table entry.

**Existing process runner test names (count 16):**

1. `test_mode_requires_exact_marker_and_no_diagnostics`
2. `test_timeout_cleans_only_owned_tree`
3. `test_rejects_reused_evidence_directory`
4. `test_environment_is_run_local`
5. `test_windows_cleanup_uses_only_child_pid`
6. `test_producer_digest_mismatch_fails_before_consumer_and_retains_logs`
7. `test_missing_marker_fails_even_with_zero_exit`
8. `test_json_array_manifest_is_rejected_with_retained_summary`
9. `test_explicit_root_is_used_as_child_cwd_and_path`
10. `test_wrong_or_duplicate_process_marker_fails`
11. `test_reviewed_production_output_prefixes_are_allowed_but_unknown_is_not`
12. `test_nonempty_mode_stderr_fails_even_without_diagnostic`
13. `test_version_probe_requires_nonempty_clean_engine_evidence`
14. `test_mode_receives_only_its_declared_disk_inputs`
15. `test_bad_post_manifest_stops_before_consumer_two`
16. `test_post_run_gameplay_source_drift_fails_completed_modes`

The runner must retain producer/consumer logs, baseline and post artifacts,
manifests, summary, source hashes, and unique child homes on failure. Consumer
one receives only baseline plus expected manifest; consumer two receives only
post plus post manifest. The post-consumer checks in
`fc_p10_process_smoke.gd` assert no remaining output, recharge, duplicate
reservation, duplicate collection, receipt replay, or migrated sidecar.

**Gap/qualification:** current `tests/test_p10_process_runner.py` has exactly
16 test methods, but the acceptance still requires fresh execution and the
three-process proof against the final R02 source. Record marker counts and
diagnostic output; zero exit alone is not evidence.

### 8. Independent final review and source manifest

**Existing support:** `tools/run_p10_process_smoke.py` `_metadata` and
`_source_hashes` capture engine/source metadata; the final process test
`test_post_run_gameplay_source_drift_fails_completed_modes` rejects source drift
after completed modes. The repository's R02 review artifacts are moving-source
history and must not be reused as the final R03 review.

**Required missing evidence:** one independent reviewer must inspect one stable
diff plus the exact source manifest after R02 lands, map every accepted row to
fresh marker/log evidence, and explicitly disposition obsolete moving-source
conclusions. This inventory does not perform or claim that review.

## Suite counts and outstanding rows

- Acceptance bullets inventoried: **8**.
- Focused R03 markers: **2** (`FC P10 PASS`, `FC P13 PASS`).
- Original-plan migration/load markers: **3**.
- Process-runner unit tests: **16 named methods**.
- Fresh three-process modes: **3** (producer, consumer1, consumer2), summarized by `FC P10 PROCESS PASS`.
- Explicit missing/needs-fresh-evidence rows: malformed oxygen boolean mutant; activation/revisit/tick oxygen assertions; successful title load; independent auto/quick load round-trips; sidecar publication timing in fresh logs; latest post-R02 matrix logs; stable source manifest and independent review.

The next R03 implementer should close those named rows and rerun the exact
commands above before reporting the P10 exit. This file intentionally makes no
whole-feature acceptance claim.
