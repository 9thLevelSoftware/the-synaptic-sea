# Task 2 / R02 Fix Round 1 Report

Date: 2026-09-05  
Fix baseline: the 28 exact files in `task-2-reviewed-afterimages/` plus the named pre-fix sources below  
Governance commit: `d850c26ab596b8130be57c8ba4024ef92617f61d`  
Frozen runtime source: 16 files, also recorded in `task-2-fix1-source-manifest.json` and `task-2-fix1-afterimages/`

## Result

All eight findings in `task-2-review.md` were addressed. The required isolated Godot matrix, the save/load regression smoke, the final three-process proof, and all 38 scoped Python tests pass. The runtime source was frozen after the final affected reruns. Player acceptance remains unassessed and is not claimed.

## Corrections to the original Task 2 report

The isolation statement at `task-2-report.md:46` is false and is superseded by this report. Those original focused commands set only `GODOT_USER_PATH` and `XDG_DATA_HOME` and passed the unsupported `--user-data-dir` option. They did not set `APPDATA` or `LOCALAPPDATA`; the requested directories remained empty while matching Godot log/save timestamps appeared in the default Windows profile. Those logs remain behavioral/debug history, not isolated acceptance evidence.

The default profile was never cleaned, restored, or otherwise touched during this fix round. Root retained the observed **after-state** at `artifacts/feature-completion/R02-default-profile-observed-20260905`; it is not a pre-test recovery backup. All new Godot evidence used new owned directories and four exact environment bindings before any smoke cleanup or save operation.

The original report also misclassified `save_load_service_smoke.gd` as unrelated R03 work. Its `invalid_world_snapshot` failure was an R02 current-version fixture regression. This round repaired and validated it. The earlier `world_save_service_smoke.gd` (`invalid_visited_ship`/missing `ship_id`) and `ship_mod_run_snapshot_smoke.gd` (placement/condition-lot WIP) observations remain separately attributed; no raw log files for those two exploratory runs were retained, so this report makes no reproducibility claim and does not use them as acceptance evidence.

## Review findings resolved

### 1. Historical world/run pair boundaries

`SaveMigrationService` now validates the embedded home run version before every outer world step and again for current `world-6`. The accepted historical matrix is:

| World source | Permitted embedded run source |
|---|---|
| `world-1` | `gate2-current-run-1` |
| `world-2` | `gate2-current-run-1` |
| `world-3` | `gate2-current-run-1` |
| `world-4` | `gate2-current-run-1`, `gate2-current-run-3`, or `gate2-current-run-4` |
| `world-5` | `gate2-current-run-5` |
| `world-6` | `gate2-current-run-6` |

This matrix comes from repository history rather than numeric-name inference: `a20338e` recorded world1/run1; `463c17b` world2/run1; `1f37241` world3/run1; `fbdf991` world4/run1; `54454807` jumped the then-current run from run1 to run3 while world4 remained current, so run2 was never a current world pairing; `a09440a` recorded world4/run4; accepted P10 WIP introduced world5/run5; R02 introduced world6/run6.

Wrong, missing, empty, and wrong-typed inner versions now return a stable structured reason without mutating the source, for example `world_home_version_mismatch:world-5:expected=gate2-current-run-5:actual=gate2-current-run-4`. Coverage includes every boundary plus public `world-5/run-4`, `world-5/run-6`, and current-world mismatches.

### 2. Active-away bootstrap authority

Legacy snapshots never stored per-ship scene transforms or socket world transforms. Their dock rows contain only host/mobile/port type/slot index. The accepted reconstruction therefore uses the production restore invariant rather than claiming recovery of an absent historical position:

- `_activate_derelict_from_instance -> _attach_derelict_active` constructs the current active derelict at canonical post-restore `(100, 0, 0)`.
- `_apply_docking_snapshot` moves mobile endpoints and does not move the host.
- Missing legacy combat may use that anchor only when a persisted docking edge positively identifies `current_location` as host, identifies a known non-active ship as mobile, and does not also identify the active ship as mobile.
- A missing witness or an active-mobile/ambiguous topology returns `combat_bootstrap_active_anchor_unreconstructable` instead of guessing an anchor.

The service-level smoke uses an actual dock topology with the active derelict as host and a lifeboat as mobile. It derives the expected coordinates from an independent literal anchor, then covers missing-witness and mobile-active denial. A ship cannot travel while retaining its own `current_location`: travel to self returns already-here, while travel elsewhere changes `current_location`. The policy is canonical post-restore authority, not original transform recovery.

### 3. Canonical home identity

Home bootstrap no longer trusts an arbitrary existing `layout_path`. `SaveLoadService` accepts only an exact, complete immutable profile triple (`layout_path`, `kit_path`, `gameplay_slice_path`) for supported production profiles: default seed 17, `coherent_ship_001`, and `coherent_ship_002`. It then reads the canonical profile value. A forged-but-existing `coherent_ship_003` path, an incomplete triple, or a mismatched triple returns `combat_bootstrap_home_profile_unknown` with source, live state, slot, and index unchanged.

### 4. Current-version save/load regression

`save_load_service_smoke.gd` now builds one coherent current owner graph. The active run, item-lot owner, and recipe-knowledge owner agree; crafting/field/station state is initialized empty rather than referencing consumed anonymous inventory; item lots are the material-quality authority and the parallel material projection is empty; every current owner includes `threat-manager-2`.

The incompatible-version case first writes a valid current world and then mutates the embedded home version on disk, because the production write boundary correctly stamps a live capture with the current version. The run-A ownership case rebuilds inventory and knowledge under `player:A`. Temporary diagnostic output was removed. The smoke defers success exit long enough for local objects to release and explicitly frees its temporary threat manager. Final evidence has one marker and no ObjectDB/resource diagnostics.

### 5. Windows home containment

`fc_p10_process_smoke.gd` has a no-save `probe` mode that checks both `ProjectSettings.globalize_path("user://")` and `OS.get_user_data_dir()`, requires them to agree, and requires both to be contained by the caller-provided root. It also checks that `APPDATA`, `LOCALAPPDATA`, `GODOT_USER_PATH`, and `XDG_DATA_HOME` exactly equal that root. `run_p10_process_smoke.py` executes the probe before each producer/consumer process and refuses to run the smoke body when containment fails.

Every focused smoke in the final matrix has its own newly created `user-root`, its own successful pre-smoke probe, all four environment variables, command record, raw stdout/stderr, Godot log, exit record, marker count, diagnostic count, and `timed_out=false` completion status.

### 6. Explicit migration reasons

Run and world migration steps now return structured results and propagate the codec reason instead of collapsing every failure to `malformed_legacy_payload`. Tests assert exact reasons for unknown home archetypes, mixed home combat, and invalid inactive visited-owner combat, together with source and protected live-state preservation.

### 7. Strict attack receipts and production reward callback

`ThreatSaveContract` accepts `last_attack_result` only as `{}`, the exact incoming-damage receipt produced by `ThreatManager.tick -> DamagePipeline.apply_to_vitals`, or the exact weapon-hit extension produced by `ThreatManager.attack_with_weapon -> DamagePipeline.apply_to_threat`. It enforces exact keys and types, finite bounded numbers, a complete typed armor profile, String identifiers, weapon/source agreement, `ok == true`, and integral `ammo_remaining >= -1`. Booleans, non-finite values, fractional ammo, wrong-typed weapon IDs, and unknown keys are rejected. Restore no longer coerces a saved weapon ID with `str()`.

`fc_p10_smoke.gd` restores a lethal flare-pistol receipt and calls the real `ThreatManager._sweep_dead_threats` path connected to production `PlayableGeneratedShip._on_threat_killed`. It observes exactly one `threat_killed`, base combat XP `10`, the expected scavenging progression increase and kill-count increment, and no `intimidate_threat` event or reward.

### 8. Derived LOS reset

Successful `ThreatManager.apply_summary()` now clears `engaged_los` with the rest of derived runtime state before hydration. The smoke proves stale LOS for a reused threat ID is absent after a valid apply, while a rejected summary preserves the prior cache and all other protected live state.

## Validation environment and commands

Godot executable:

`C:\Users\dasbl\Downloads\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64_console.exe`

Each focused case used the same two-command pattern with a distinct newly empty `<case>/user-root` and all four variables set to that exact absolute path:

```powershell
$env:APPDATA = '<case>/user-root'
$env:LOCALAPPDATA = '<case>/user-root'
$env:GODOT_USER_PATH = '<case>/user-root'
$env:XDG_DATA_HOME = '<case>/user-root'
& $GODOT --headless --path 'D:\the-synaptic-sea-feature-completion' --log-file '<case>/probe.godot.log' --script res://scripts/validation/fc_p10_process_smoke.gd -- --mode=probe --user_data='<case>/user-root'
& $GODOT --headless --path 'D:\the-synaptic-sea-feature-completion' --log-file '<case>/smoke.godot.log' --script res://scripts/validation/<smoke>.gd
```

The initial standalone containment probe passed with one marker, exit 0, and no diagnostics. Its exact resolved path was:

`D:/the-synaptic-sea-feature-completion/artifacts/feature-completion/R02-fix1-evidence-20260905-01/containment-user-root/Godot/app_userdata/The Synaptic Sea`

This lies under the owned `containment-user-root`, agrees with `OS.get_user_data_dir()`, and was computed from `ProjectSettings.globalize_path("user://")` before any smoke body.

### Focused Godot matrix

Aggregate machine-readable evidence: `artifacts/feature-completion/R02-fix1-evidence-20260905-01/focused-summary.json` (SHA-256 `057c472d93c64dfa226966ef55dfd0c38bf29391f2d7b21352f2e3e2aaa9873d`). Each row below has probe exit 0, exactly one containment marker, zero probe diagnostics, smoke exit 0, exactly one required marker, zero smoke diagnostics, and `timed_out=false`.

| Evidence case | Required marker |
|---|---|
| `combat_persistence_final02` | `COMBAT PERSISTENCE PASS schema=threat-manager-2 hull=0.4 callback=true owners=home+away` |
| `save_migration_service` | `SAVE MIGRATION SERVICE PASS` |
| `save_migration_world` | `SAVE MIGRATION WORLD PASS unknown_version_passthrough=true legacy_home_ship_migrated=true current_world_home_ship_migrated=true` |
| `save_load_service_retry07` | `SAVE LOAD SERVICE PASS round_trip=true version_match=true summaries=32 survival_roundtrip=true` |
| `threat_ai_state` | `THREAT AI STATE PASS final_state=dead previous=hunt awareness=0.00` |
| `tendril_structure_damage` | `TENDRIL STRUCTURE DAMAGE PASS archetype=true hit=true damaged=true` |
| `world_snapshot` | `WORLD SNAPSHOT PASS round_trip=true version_gated=true` |
| `ship_generator` | `SHIP GENERATOR PASS life_boat=true small=true deterministic=true documents=true life_rooms=9 small_rooms=24` |
| `fc_p10` | `FC P10 PASS` |

All raw per-case files are under `artifacts/feature-completion/R02-fix1-evidence-20260905-01/<case>/`: `environment.json`, `probe.command.txt`, `probe.stdout.log`, `probe.stderr.log`, `probe.godot.log`, `smoke.command.txt`, `smoke.stdout.log`, `smoke.stderr.log`, `smoke.godot.log`, and `smoke.exit.txt`.

`combat_persistence_final02` reran the combat/service gate after the final comment correction in `save_load_service.gd`. Earlier passing focused cases were behaviorally unaffected because that last source edit changed documentation only.

### Final three-process proof

Exact command: `artifacts/feature-completion/R02-fix1-evidence-20260905-01/process-proof-03.command.txt`

```powershell
& 'D:\the-synaptic-sea-feature-completion\.superpowers\test-runtime\Scripts\python.exe' 'tools/run_p10_process_smoke.py' --godot 'C:\Users\dasbl\Downloads\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64_console.exe' --root 'D:\the-synaptic-sea-feature-completion' --evidence-dir 'D:\the-synaptic-sea-feature-completion\artifacts\feature-completion\R02-fix1-evidence-20260905-01\process-proof-03' --timeout 180
```

Result: runner exit 0; `passed=true`; `source_drift_detected=false`; producer, consumer1, and consumer2 each exited 0 without timeout, emitted exactly one mode marker, and had empty diagnostics/unexpected stdout/unexpected stderr. Their three prerequisite probes likewise exited 0, emitted exactly one containment marker, and resolved `user://` inside three distinct owned homes.

The producer saved different home and away combat states. Consumer1 loaded them through production prepare/resolve/apply, found the restored hull tendril at `structure_damage=0.4`, required a valid production `on_structure_attack` callback, set live attack/LOS input, called `tick_threats`, and proved the actual restored module-integrity summary changed with a non-empty damage delta. Consumer2 loaded the post-damage save and proved the new structure state persisted across the second process boundary.

Final artifact SHA-256 values:

- baseline world: `92213f0307f716355a40c70384d1144d3a29b6fdf987a211e1a1c59afae6da79`
- expected observations: `73f68a9ab1b946850c328257e8f11d9dcbc986c7f096f5c27f25b1cbf4b146a5`
- post-collection world: `077bff595e564aa00a65188e758e6d90c0bc3fb473ba5643fd5b86647d605f88`
- post-collection manifest: `a93bd1f83f0dcc13bd4286c72a385ae9ce96f35579d3ffd98744f1ca606fe80f`

The complete source closure is embedded at `process-proof-03/summary.json -> metadata.source_sha256`. `process-proof-03` supersedes passing `process-proof-02` solely because the final canonical-anchor comment changed a hashed source file. `process-proof-01` is retained as debug history: consumer1 rejected the baseline because an unrelated inactive arc timer was captured at `1.49954052188553` and rebuilt as `1.5`. The proof now normalizes that inactive, out-of-scope arc timer immediately before the production save; it does not exclude or relax any combat comparison.

### Python and governance checks

```powershell
& 'D:\the-synaptic-sea-feature-completion\.superpowers\test-runtime\Scripts\python.exe' -m pytest -q tests/test_p10_process_runner.py tests/test_feature_acceptance_registry.py
```

Result: exit 0, stderr empty, `38 passed in 0.98s`. Raw evidence is under `artifacts/feature-completion/R02-fix1-evidence-20260905-01/python38-final/`.

Registry regeneration/check result before runtime release: `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0`.

## Retained diagnostic history

All failed attempts remain under the fix evidence root; none is presented as acceptance evidence.

- `save_load_service` and `retry01`: `invalid_world_snapshot` because the fixture graph was not a valid current owner graph.
- `save_load_service_diag01`: temporary diagnostic confirmed the combat summary itself was valid and exposed incoherent crafting/knowledge ownership; the temporary print was removed.
- `retry02`: `crafting_summary mismatch` after removing an unclosed running craft job.
- `retry03`: `material_summary mismatch` after establishing item lots as quality authority.
- `retry04`: the incompatible-version negative attempted to save an invalid live version rather than mutate a valid persisted payload.
- `retry05`: the run-A ownership fixture retained run-specific sub-owner identities.
- `retry06`: the functional marker passed, but exit diagnostics reported 14 leaked ObjectDB instances and four resources still in use.
- `retry07`: clean final pass after explicit temporary-manager release and deferred exit.
- `process-proof-01`: inactive arc-timer rebuild precision rejected consumer1 before R02 structural-damage assertions; `process-proof-03` is the clean final closure.

## Frozen files and provenance

Root produced `task-2-fix1-root-review.patch`, 136,733 bytes, SHA-256 `8bc3ee0c95f8edfbf91ee4cc3568f0f9c00862ca82d7cc182743a73bcb3f6306`, against the previous reviewed afterimages and named pre-fix sources. The frozen 16-file source manifest has SHA-256 `6e813b487bab1c3c71e2212b3faf2e3d613629771ed833f30f560efa3d3f8e52`.

| File | Frozen SHA-256 |
|---|---|
| `data/validation/feature_completion_cards.json` | `6cf48834dd7bcf643fe7ab20fce854adfab5f6958b256c4860d8cdd776be5616` |
| `docs/game/adr/0059-crafting-and-derelict-restoration-transactions.md` | `57d75218b7c8ff9dc6395e1618912a0ba06953eef06b293a0b7e4c64cf24e3a9` |
| `docs/game/inventory/feature_acceptance.json` | `a04ed9f30186583590acf13d89dd0b65be042b66ef0b261f7e612ddee9e5d955` |
| `docs/superpowers/plans/2026-09-04-crafting-derelict-feature-completion.md` | `2942fd31eed39e8eecce8adfd3a4dce4f59d8dd68a2fa97864e79417ff5f0798` |
| `scripts/systems/save_load_service.gd` | `ab624a27ed8ac1912d6c351609e26a4ed791e0a877c221d5378316e19e404615` |
| `scripts/systems/save_migration_service.gd` | `bb73a9dd9a3760edc86e50f5fb96c1f05d0f7bf24fb0f2798267cdce7302b330` |
| `scripts/systems/threat_manager.gd` | `e06d4d08596e9dd75129da52d389d422496dfe9d91e015856dbe3a8a00f2c6ec` |
| `scripts/systems/threat_save_contract.gd` | `f9724e865108fb279ac84585eee51136f3c2eb2f0a6dcb550aa1f55a181cc557` |
| `scripts/validation/combat_persistence_smoke.gd` | `34a65ccd36835f3bdd0f8a6d90038a2553a5cf29e5b25aeba24d2668abfb6e18` |
| `scripts/validation/fc_p10_process_smoke.gd` | `7d7642fc4fe7e477a9b29f30de1aa18013fc6d1fc84a603f329944ce55e6b757` |
| `scripts/validation/fc_p10_smoke.gd` | `f8cb9c3242ba720d227cf84d1742cea56e5d993bc312c7d4904dc1d601d4f7da` |
| `scripts/validation/save_load_service_smoke.gd` | `a9efd8bfbca1428fed832762eb577a827256cc985e2c5ecfb2824ded817294ac` |
| `scripts/validation/save_migration_world_smoke.gd` | `fcc6e2488e63382339ac51707ec9bdcf4b9ac142a41c7dd7ff0c081418db496f` |
| `tests/test_p10_process_runner.py` | `87209c1e0de78026beb160545b7c4d9b28949748a05ad618ebc4acdf653931e3` |
| `tools/build_feature_acceptance.py` | `032117786230b92da5a3a016a7b29ed68058be4cb7e4958c1c7fd76ad436f3e9` |
| `tools/run_p10_process_smoke.py` | `4d51e997ccfab4579d2e19c30e270e7637e88ce9fc27bb342b82169c5c0fd5a3` |

Exact pre-fix copies are in `task-2-fix1-beforeimages/` for files captured at fix release. The original reviewed runtime files are in the unchanged `task-2-reviewed-afterimages/`. The untracked runner's exact pre-fix source is `task-2-before-untracked/tools__run_p10_process_smoke.py` (SHA-256 `ecebc0ede8dfcc0d523f843bb94f7f0df62e12f9254a4b2926a8820e2c8d3b22`). The test baseline is available in both named backup sets (SHA-256 `4a3cfe8297c43d1f6e71296c82cf3212c2ab1ebde404ed75eae8b75cd4a0df53`). The original `SaveRestoreCandidate` preimage limitation remains documented in `task-2-report.md`; this fix round did not edit that file.

No runtime, test, fixture, governance, or generated source changed after the frozen hashes above. Only this report was added afterward.
