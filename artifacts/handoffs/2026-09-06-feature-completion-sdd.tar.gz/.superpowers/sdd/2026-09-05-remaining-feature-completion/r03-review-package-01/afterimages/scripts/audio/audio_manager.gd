extends Node
class_name AudioManagerScript
## AudioManager — service node owned by PlayableGeneratedShip (ADR-0029).
##
## The manager is NOT an autoload per AGENTS.md. It is added as a child
## of the playable scene by _build_runtime_nodes() and removed when the
## scene tree frees the playable.
##
## Responsibilities:
## - Owns one AudioStreamPlayer per bus (sfx, music, voice, ui, ambient,
##   meta) plus a pool of AudioStreamPlayer3D nodes for spatial emitters.
## - Reads summaries from the six pure models (bus_config, ambient, sfx,
##   music, spatial, meta_event) and pushes them into AudioServer bus
##   indices and AudioStreamPlayer volume_db values.
## - Exposes play_sfx(event_id, position), set_bus_volume(bus_id, db),
##   transition_music(state), attach_listener(node), play_voice_log(id),
##   trigger_meta_event(event_id), apply_summary(dict), get_summary().
## - Maintains the AudioLog registry (data-only) and routes voice-log
##   playback through the voice bus.
##
## Headless: when --headless is active, AudioServer.get_bus_index() returns
## -1 for any bus that was never registered, so the manager tolerates a
## missing device by skipping volume pushes and only keeping the pure-model
## state coherent. The smoke verifies the path runs without errors.

const AmbientZoneStateScript := preload("res://scripts/systems/ambient_zone_state.gd")
const SfxEventRouterScript := preload("res://scripts/systems/sfx_event_router.gd")
const DynamicMusicStateScript := preload("res://scripts/systems/dynamic_music_state.gd")
const SpatialAudioResolverScript := preload("res://scripts/systems/spatial_audio_resolver.gd")
const MetaEventStateScript := preload("res://scripts/systems/meta_event_state.gd")
const AudioBusConfigScript := preload("res://scripts/systems/audio_bus_config.gd")
const AudioLogScript := preload("res://scripts/audio/audio_log.gd")

const AudioEventSeamScript := preload("res://scripts/audio/audio_event_seam.gd")

## Stream F: voice log successfully scheduled (decode_signal training).
signal voice_log_played(entry_id: String)

## Bus -> AudioStreamPlayer node (one per bus, all routed through master).
var _bus_players: Dictionary = {}
## Bus -> AudioStreamPlayer3D pool (spatial emitters, keyed by event id).
var _spatial_pool: Dictionary = {}
## AudioListener3D that follows the player when attached.
var _listener: AudioListener3D
## Reference to the listener's anchor (usually the player node). Updated
## each frame in _process when set.
var _listener_anchor: Node3D

var bus_config = AudioBusConfigScript.make_default()
var ambient_zone_state = AmbientZoneStateScript.new()
var sfx_router = SfxEventRouterScript.new()
var music_state = DynamicMusicStateScript.new()
var spatial_resolver = SpatialAudioResolverScript.new()
var meta_event_state = MetaEventStateScript.new()
var audio_log = AudioLogScript.new()

## Last-played voice-log entry id (for the panel to show "now playing").
var current_voice_log_id: String = ""

## Event/layer id -> res:// path. Lives in the manager (the only scene-aware
## audio object), NOT in SfxEventRouter, which stays a pure RefCounted
## (ADR-0029/ADR-0044). Only entries listed here get a real .stream assigned;
## every other cataloged event id falls back to the pre-Domain-9 volume-push-
## only behavior (the deferred asset library is honest about what plays).
const STREAM_CATALOG: Dictionary = {
	"sfx.tool.pickup": "res://data/audio/sfx/tool_pickup.wav",
	"sfx.footstep": "res://data/audio/sfx/footstep.wav",
	"ui.panel.open": "res://data/audio/ui/panel_open.wav",
	"ui.panel.close": "res://data/audio/ui/panel_close.wav",
	"sfx.fire.crackle": "res://data/audio/sfx/fire_crackle.wav",
	# Hull-groan is the existing breach/meta cue; the content pack supplies
	# the authored-id-compatible alarm placeholder without a new event system.
	"meta.hull.groan": "res://data/audio/sfx/breach_alarm.wav",
	"sfx.combat.hit": "res://data/audio/sfx/combat_hit.wav",
	"sfx.combat.threat_alert": "res://data/audio/sfx/threat_alert.wav",
	"sfx.door.open": "res://data/audio/sfx/door_open.wav",
	"sfx.door.close": "res://data/audio/sfx/door_close.wav",
	"sfx.dock.land": "res://data/audio/sfx/dock_land.wav",
	"ui.vitals.low": "res://data/audio/sfx/vitals_low.wav",
	"layer.base": "res://data/audio/music/exploration_base.wav",
	"layer.tension_drone": "res://data/audio/music/tension_drone.wav",
	"layer.critical_pad": "res://data/audio/music/critical_pad.wav",
}

## Path -> loaded AudioStream cache. Avoids re-loading the same WAV from
## disk on every play_sfx call.
var _loaded_streams: Dictionary = {}

## Paths that already logged a missing/corrupt-file warning (warn-once so a
## missing asset doesn't spam push_warning every frame it's requested).
var _warned_missing_paths: Dictionary = {}

## Internal: is the audio device headless (no real audio output)?
## Used to skip player.play() calls that create AudioStreamPlayback
## objects whose references are held by the AudioServer's mixing thread.
var _headless: bool = false
## A disposable restore sibling may build and hydrate its pure audio models,
## but it must not change process-global AudioServer buses before Main accepts
## the complete world. The coordinator enables writes exactly once at the
## successful activation boundary.
var _server_writes_deferred: bool = false
var _physical_playback_count_for_validation: int = 0


func configure_restore_staging() -> bool:
	if is_inside_tree():
		return false
	_server_writes_deferred = true
	return true


func activate_deferred_server_writes() -> void:
	if not _server_writes_deferred:
		return
	_server_writes_deferred = false
	_apply_bus_volumes()

func _ready() -> void:
	_headless = DisplayServer.get_name() == "headless"
	_build_stream_players()
	if not _server_writes_deferred:
		_apply_bus_volumes()
	_initialize_sub_models()

## Explicit teardown: release all cached AudioStream references so the
## RefCounted AudioStreamWAV / AudioStreamPlaybackWAV instances are freed
## before Godot's ObjectDB leak check runs. Without this, the cleanup
## order during scene-tree destruction leaves dangling references in
## _loaded_streams and in each AudioStreamPlayer.stream property.
func _exit_tree() -> void:
	_release_audio_refs()

## Shared cleanup logic for both _exit_tree and NOTIFICATION_PREDELETE.
func _release_audio_refs() -> void:
	# Drop the stream cache so RefCounted entries lose our reference.
	_loaded_streams.clear()
	# Detach streams from every bus player so the internal
	# AudioStreamPlayback is released.
	for key in _bus_players:
		var player = _bus_players[key]
		if player != null and is_instance_valid(player):
			player.stop()
			player.stream = null
	_bus_players.clear()
	for key in _spatial_pool:
		var pool: Array = _spatial_pool[key]
		for player in pool:
			if player != null and is_instance_valid(player):
				player.stop()
				player.stream = null
	_spatial_pool.clear()
	music_state = null
	ambient_zone_state = null
	sfx_router = null
	spatial_resolver = null
	meta_event_state = null
	bus_config = null

## Call configure() on each of the six pure models with a baseline
## dictionary. Per ADR-0029, AudioManager owns the model instances;
## callers do not poke at the models directly. The ambient_zone_state,
## dynamic_music_state, and spatial_audio_resolver accept defaults that
## match the ADR-0029 baseline; the sfx_router and meta_event_state
## accept empty dictionaries (their defaults already match the spec).
func _initialize_sub_models() -> void:
	if ambient_zone_state != null:
		ambient_zone_state.configure({})
	if sfx_router != null:
		sfx_router.configure({})
	if music_state != null:
		music_state.configure({})
	if spatial_resolver != null:
		spatial_resolver.configure({})
	if meta_event_state != null:
		meta_event_state.configure({})

## Construct the per-bus AudioStreamPlayer children. Safe in headless mode:
## AudioStreamPlayer nodes exist (they're regular Nodes), only the audio
## output is silent. Smoke tests verify the node tree was built.
func _build_stream_players() -> void:
	for bus_id in AudioEventSeamScript.ALL_BUS_IDS:
		if String(bus_id) == String(AudioEventSeamScript.BUS_MASTER):
			# Master is the AudioServer's built-in root bus; we do not own
			# a per-stream player for it. We only own a player for each
			# child bus.
			continue
		var player: AudioStreamPlayer = AudioStreamPlayer.new()
		player.name = "AudioStreamPlayer_%s" % String(bus_id)
		player.bus = String(bus_id)
		add_child(player)
		_bus_players[String(bus_id)] = player

## Translate a pure-model bus id (lowercase, e.g. &"master") to the engine's
## AudioServer bus name. Godot's bus 0 is immutably named "Master" (capital
## M) and AudioServer.get_bus_index("master") always returns -1 for it; the
## six child buses (sfx/music/voice/ui/ambient/meta) need no translation
## because their names already match between the pure model and the engine.
## This is the ONLY place the Master-name mismatch is bridged — every
## AudioServer boundary call goes through this helper (ADR-0044).
## Returns StringName to avoid a String allocation per call; AudioServer's
## bus-name APIs accept StringName/String interchangeably.
func _engine_bus_name(bus_id: StringName) -> StringName:
	if bus_id == AudioEventSeamScript.BUS_MASTER:
		return &"Master"
	return bus_id

## Push per-bus dB values into AudioServer. Skipped for buses that
## AudioServer doesn't know about (e.g. in headless tests where the
## .tres has not been loaded). The pure-model state remains the source
## of truth in that case.
func _apply_bus_volumes() -> void:
	if _server_writes_deferred:
		return
	for bus in bus_config.buses:
		if typeof(bus) != TYPE_DICTIONARY:
			continue
		var bus_id: String = String(bus.get("id", ""))
		if bus_id.is_empty():
			continue
		var engine_name: StringName = _engine_bus_name(StringName(bus_id))
		var bus_idx: int = AudioServer.get_bus_index(engine_name)
		if bus_idx < 0:
			# Bus not registered in AudioServer yet (headless / pre-init).
			# Skip without error so the manager survives --script mode.
			continue
		var vol_db: float = float(bus.get("volume_db", 0.0))
		var muted: bool = bool(bus.get("muted", false))
		AudioServer.set_bus_volume_db(bus_idx, vol_db)
		AudioServer.set_bus_mute(bus_idx, muted)

## Apply a full summary (the 9th RunSnapshot summary, REQ-AU-010) to the
## manager. Returns true if any sub-summary was applied.
func apply_summary(summary: Dictionary) -> bool:
	if summary == null or summary.is_empty():
		return false
	var changed: bool = false
	var bus: Variant = summary.get("bus_config", null)
	if typeof(bus) == TYPE_DICTIONARY:
		if bus_config.apply_summary(bus):
			changed = true
			_apply_bus_volumes()
	var ambient: Variant = summary.get("ambient", null)
	if typeof(ambient) == TYPE_DICTIONARY:
		if ambient_zone_state.apply_summary(ambient):
			changed = true
	var sfx: Variant = summary.get("sfx_router", null)
	if typeof(sfx) == TYPE_DICTIONARY:
		if sfx_router.apply_summary(sfx):
			changed = true
	var music: Variant = summary.get("music", null)
	if typeof(music) == TYPE_DICTIONARY:
		if music_state.apply_summary(music):
			changed = true
	var spatial: Variant = summary.get("spatial", null)
	if typeof(spatial) == TYPE_DICTIONARY:
		if spatial_resolver.apply_summary(spatial):
			changed = true
	var meta: Variant = summary.get("meta_event", null)
	if typeof(meta) == TYPE_DICTIONARY:
		if meta_event_state.apply_summary(meta):
			changed = true
	var voice_id_v: Variant = summary.get("current_voice_log_id", "")
	if typeof(voice_id_v) != TYPE_STRING:
		return false
	current_voice_log_id = str(voice_id_v)
	changed = true
	return changed

## Collect a summary from the manager (and its six sub-models). The result
## is a flat dictionary with six sub-dicts plus a small set of manager-level
## fields (current_voice_log_id). Listener attachment is derived from the live
## player/camera tree and is deliberately not persisted as gameplay authority.
func get_summary() -> Dictionary:
	var persisted_sfx: Dictionary = sfx_router.get_summary()
	# Pending caption rows are transient presentation events. The router exposes
	# their count for diagnostics, but no payload capable of recreating them;
	# persisting only the count would create false authority that cannot roundtrip.
	persisted_sfx.erase("caption_queue_size")
	return {
		"bus_config": bus_config.get_summary(),
		"ambient": ambient_zone_state.get_summary(),
		"sfx_router": persisted_sfx,
		"music": music_state.get_summary(),
		"spatial": spatial_resolver.get_summary(),
		"meta_event": meta_event_state.get_summary(),
		"current_voice_log_id": current_voice_log_id,
	}

## Update the player-vitals / hazard / engagement flags driving the music
## state machine. The manager resolves the new state and updates the
## target gains; per-frame `tick(delta)` applies the crossfade.
func update_music_flags(engagement: bool, hazard_active: bool, vitals_critical: bool) -> void:
	music_state.set_flags(engagement, hazard_active, vitals_critical)

## Per-frame tick. Advances the music crossfade, the ambient crossfade,
## the SFX cooldowns / captions, and the meta-event scheduler. Returns
## the array of meta-events that fired during this tick (so the playable
## scene can route them to SfxEventRouter).
func tick(delta_seconds: float) -> Array:
	if delta_seconds <= 0.0:
		return []
	ambient_zone_state.tick(delta_seconds)
	sfx_router.tick(delta_seconds)
	music_state.tick(delta_seconds)
	_apply_music_layer_gains()
	var due: Array = meta_event_state.tick(delta_seconds)
	for ev in due:
		# Route scheduled meta events through SfxEventRouter via play_sfx so
		# captions + routed_count match live META_* catalog ids (beacon/pulse/groan).
		var id_str: String = String(ev.get("id", ""))
		var catalog_id: StringName = _catalog_id_for_meta_schedule(id_str)
		if not String(catalog_id).is_empty():
			play_sfx(catalog_id)
		else:
			var bus_id: String = _bus_for_meta_event_id(id_str)
			var vol: float = float(ev.get("volume_db", -6.0))
			_play_via_bus(bus_id, vol)
		var voice_log_id: String = String(ev.get("voice_log_id", ""))
		if not voice_log_id.is_empty():
			play_voice_log(StringName(voice_log_id))
	return due

## Fire a named SFX event. Routes through SfxEventRouter (which dedups /
## captions) then plays through the routed bus.
## When `position` is provided and the AudioStreamPlayer3D pool has a slot,
## the sound is emitted spatially (REQ-AU-005).
func play_sfx(event_id: StringName, position: Variant = null) -> bool:
	# Scene reconstruction can invoke ordinary consequence emitters (for
	# example dock/land). A disposable sibling must remain acoustically and
	# model-silent: routing would mutate cooldown/caption history even if the
	# actual player.play() call were suppressed.
	if _server_writes_deferred:
		return false
	var route_result: Variant = sfx_router.route(event_id)
	if route_result == null:
		return false
	if typeof(route_result) != TYPE_DICTIONARY:
		return false
	var route_dict: Dictionary = route_result
	var bus_id: String = String(route_dict.get("bus", AudioEventSeamScript.BUS_SFX))
	var vol_db: float = float(route_dict.get("volume_db", -6.0))
	if position != null and position is Vector3:
		_play_spatial(event_id, position, bus_id, vol_db)
	else:
		_play_via_bus(bus_id, vol_db, event_id)
	return true

## Convenience: get pending captions and clear the queue. The HUD calls
## this each frame.
func drain_captions() -> Array:
	return sfx_router.get_pending_captions()

## Per-frame: capture (and clear) pending captions and forward them to the
## `caption_target` callable (typically the HUD label). Default null = no-op.
func pump_captions(caption_target: Callable = Callable()) -> int:
	var captions: Array = drain_captions()
	if caption_target.is_valid():
		for caption in captions:
			caption_target.call(caption)
	return captions.size()

## Per-frame: apply spatial attenuation to the live spatial-pool players
## using the listener anchor's global_position. Returns the number of
## spatial players touched.
func apply_spatial_attenuation() -> int:
	if _listener_anchor == null or not is_instance_valid(_listener_anchor):
		return 0
	var listener_pos: Vector3 = _listener_anchor.global_position
	var touched: int = 0
	for event_id_str in _spatial_pool.keys():
		var players: Array = _spatial_pool[event_id_str]
		for player in players:
			if player == null or not is_instance_valid(player):
				continue
			var dist: float = SpatialAudioResolverScript.distance(player.global_position, listener_pos)
			var occluded: bool = _is_occluded(player.global_position, listener_pos)
			var base_db: float = SfxEventRouterScript.get_volume_for_event(StringName(event_id_str))
			var resolved: float = spatial_resolver.resolve_volume_db(player.global_position, listener_pos, occluded, base_db)
			player.volume_db = resolved
			touched += 1
	return touched

## Per-frame: orient the AudioListener3D toward the player anchor.
func update_listener_transform() -> void:
	if _listener_anchor == null or not is_instance_valid(_listener_anchor):
		return
	if _listener == null or not is_instance_valid(_listener):
		_listener = AudioListener3D.new()
		_listener.name = "AudioListener"
		# Parent the listener directly to the anchor. add_child re-parents
		# automatically when the new parent differs from the current one,
		# so we do not add the listener to the AudioManager tree first.
		if _listener.get_parent() != _listener_anchor:
			if _listener.get_parent() != null:
				_listener.get_parent().remove_child(_listener)
			_listener_anchor.add_child(_listener)
	# AudioListener3D inherits from Node3D, so we set global_transform.
	_listener.global_transform = _listener_anchor.global_transform

## Set the bus volume (clamped). Returns true on success.
func set_bus_volume(bus_id: StringName, volume_db: float) -> bool:
	if not bus_config.set_volume_db(bus_id, volume_db):
		return false
	_apply_bus_volumes()
	return true

func get_bus_volume(bus_id: StringName) -> float:
	return bus_config.get_volume_db(bus_id)

func set_bus_muted(bus_id: StringName, muted: bool) -> bool:
	if not bus_config.set_muted(bus_id, muted):
		return false
	_apply_bus_volumes()
	return true

func is_bus_muted(bus_id: StringName) -> bool:
	return bus_config.is_muted(bus_id)

## Force a music state override (used by scripted cues).
func transition_music(target_state: StringName) -> bool:
	return music_state.override_state(target_state)

## Schedule an AudioLog entry for playback through the voice bus.
func play_voice_log(entry_id: StringName) -> bool:
	if _server_writes_deferred:
		return false
	if not audio_log.has_entry(entry_id):
		push_warning("AudioManager: unknown voice log entry '%s'" % String(entry_id))
		return false
	var entry: Dictionary = audio_log.get_entry(entry_id)
	var vol_db: float = float(entry.get("volume_db", -3.0))
	# Tranche 4 (2026-07-06 audit): route the entry's authored clip_path
	# through the warn-once stream loader. Before this, the clip_path data
	# was dead — no load attempt, so not even the ADR-0044 honest missing-
	# asset warning fired. With the voice library still deferred the loader
	# warns once per path and the volume push remains the fallback; when the
	# assets land they play with no further code change.
	_play_via_bus(String(AudioEventSeamScript.BUS_VOICE), vol_db, &"", String(entry.get("clip_path", "")))
	current_voice_log_id = String(entry_id)
	voice_log_played.emit(String(entry_id))
	return true

## Trigger an immediate meta-event (in addition to the scheduled ones).
func trigger_meta_event(event_id: StringName) -> bool:
	if _server_writes_deferred or String(event_id).is_empty():
		return false
	var bus_id: String = _bus_for_meta_event_id(String(event_id))
	var vol: float = -6.0
	if String(event_id) == String(AudioEventSeamScript.META_BEACON_DISTRESS):
		vol = -3.0
	_play_via_bus(bus_id, vol)
	return true

## Attach the AudioListener3D to a player anchor (any Node3D).
func attach_listener(anchor: Node3D) -> void:
	_listener_anchor = anchor

func get_listener_anchor() -> Node3D:
	return _listener_anchor

func get_bus_player(bus_id: StringName) -> AudioStreamPlayer:
	return _bus_players.get(String(bus_id), null)

func get_spatial_player_count() -> int:
	var total: int = 0
	for key in _spatial_pool.keys():
		total += (_spatial_pool[key] as Array).size()
	return total


func get_physical_playback_count_for_validation() -> int:
	return _physical_playback_count_for_validation

## Internal: load (and cache) an AudioStream from a res:// path. Returns null
## on a missing/corrupt file; logs exactly one push_warning per path (never
## per-frame spam) via the _warned_missing_paths flag.
func _load_stream_cached(path: String) -> AudioStream:
	if _loaded_streams.has(path):
		return _loaded_streams[path]
	if not FileAccess.file_exists(path):
		if not _warned_missing_paths.has(path):
			push_warning("AudioManager: stream file missing, path='%s'" % path)
			_warned_missing_paths[path] = true
		return null
	# PR #66 review (Codex P2): the voice-log entries author .ogg paths, so
	# the loader must dispatch by extension — WAV-only decoding would leave
	# the voice path silent even after the deferred assets land.
	var stream: AudioStream = null
	if path.get_extension().to_lower() == "ogg":
		stream = AudioStreamOggVorbis.load_from_file(path)
	else:
		stream = AudioStreamWAV.load_from_file(path)
	if stream == null:
		if not _warned_missing_paths.has(path):
			push_warning("AudioManager: load_from_file failed, path='%s'" % path)
			_warned_missing_paths[path] = true
		return null
	_loaded_streams[path] = stream
	return stream

## Internal: play through a non-spatial AudioStreamPlayer on a bus. When
## `event_id` is cataloged in STREAM_CATALOG, lazily loads and assigns the
## clip and calls play(); when not cataloged, behavior is byte-identical to
## pre-Domain-9 (volume push only) — the graceful missing-asset fallback
## that keeps the deferred asset library honest (ADR-0044).
## `stream_path` (Tranche 4, 2026-07-06 audit): callers whose clip path lives
## outside STREAM_CATALOG (voice logs author clip_path on their AudioLog
## entries) pass it directly; it takes precedence over the catalog lookup and
## goes through the same warn-once loader.
func _play_via_bus(bus_id: String, volume_db: float, event_id: StringName = &"", stream_path: String = "") -> void:
	if _server_writes_deferred:
		return
	var player: AudioStreamPlayer = _bus_players.get(bus_id, null)
	if player == null:
		return
	player.volume_db = volume_db
	var path: String = stream_path
	if path.is_empty():
		var id_str: String = String(event_id)
		if not id_str.is_empty() and STREAM_CATALOG.has(id_str):
			path = String(STREAM_CATALOG[id_str])
	if not path.is_empty():
		var stream: AudioStream = _load_stream_cached(path)
		if stream != null:
			if player.stream != stream:
				player.stream = stream
			if not _headless:
				_physical_playback_count_for_validation += 1
				player.play()

## Internal: play through a spatial AudioStreamPlayer3D pool entry. Stream
## assignment mirrors _play_via_bus exactly (ADR-0044): a STREAM_CATALOG
## event lazily loads + assigns the clip and calls play(); an uncatalogued
## event keeps the volume-push-only fallback so the deferred asset library
## stays honest about what plays.
func _play_spatial(event_id: StringName, position: Vector3, bus_id: String, volume_db: float) -> void:
	if _server_writes_deferred:
		return
	var key: String = String(event_id)
	var pool: Array = _spatial_pool.get(key, [])
	# Reuse a free entry if any, otherwise allocate a new one.
	var player: AudioStreamPlayer3D = null
	for candidate in pool:
		if candidate != null and is_instance_valid(candidate):
			player = candidate
			break
	if player == null:
		player = AudioStreamPlayer3D.new()
		player.name = "AudioStreamPlayer3D_%s" % key
		add_child(player)
		pool.append(player)
		_spatial_pool[key] = pool
	player.bus = bus_id
	player.volume_db = volume_db
	player.global_position = position
	if STREAM_CATALOG.has(key):
		var stream: AudioStream = _load_stream_cached(String(STREAM_CATALOG[key]))
		if stream != null:
			if player.stream != stream:
				player.stream = stream
			if not _headless:
				_physical_playback_count_for_validation += 1
				player.play()

## Internal: deterministic "is this emitter occluded" check. Real LOS
## raycasts are out of scope; we report true when the emitter sits in a
## different room from the listener (room-role comparison via the parent).
func _is_occluded(emitter_pos: Vector3, listener_pos: Vector3) -> bool:
	# A pure distance-based heuristic: anything beyond `occluded_distance`
	# and in a different Y-band (more than 1.5 m apart in Y) counts as
	# occluded. This is a placeholder for a real LOS raycast; the
	# deterministic output is the architectural invariant here.
	var delta: Vector3 = emitter_pos - listener_pos
	if absf(delta.y) > 1.5 and delta.length() > 4.0:
		return true
	return false

## Internal: apply per-layer music gains to the music bus player.
func _apply_music_layer_gains() -> void:
	var player: AudioStreamPlayer = _bus_players.get(String(AudioEventSeamScript.BUS_MUSIC), null)
	if player == null:
		return
	# Base layer proof-of-stream (REQ-AU criterion 2): the base layer is
	# always-on in the default EXPLORATION state, so it is the one music
	# layer that gets an actual assigned+looping .stream. Lazily assigned
	# once; subsequent calls only touch volume_db (avoids restarting the
	# clip every frame).
	if player.stream == null:
		var base_path: Variant = STREAM_CATALOG.get(String(AudioEventSeamScript.MUSIC_LAYER_BASE), null)
		if base_path != null:
			var stream: AudioStream = _load_stream_cached(String(base_path))
			if stream != null:
				if stream is AudioStreamWAV:
					(stream as AudioStreamWAV).loop_mode = AudioStreamWAV.LOOP_FORWARD
				player.stream = stream
				if not _headless:
					player.play()
	var gains: Dictionary = music_state.get_layer_gains()
	# Combined layer gain is the maximum across the four layers (they
	# stack rather than average so exploration always has audible base).
	var combined: float = 0.0
	for layer_id in AudioEventSeamScript.ALL_MUSIC_LAYERS:
		combined = maxf(combined, float(gains.get(layer_id, 0.0)))
	# Combined in [0, 1] -> dB mapping: -24 dB at 0.0 -> 0 dB at 1.0.
	player.volume_db = -24.0 + combined * 24.0

## Map MetaEventState schedule ids (beacon_distress / biomatter_pulse / hull_groan)
## onto the AudioEventSeam META_* catalog constants used by SfxEventRouter.
func _catalog_id_for_meta_schedule(id_str: String) -> StringName:
	if id_str == String(AudioEventSeamScript.META_EVENT_BEACON) \
			or id_str == String(AudioEventSeamScript.META_BEACON_DISTRESS):
		return AudioEventSeamScript.META_BEACON_DISTRESS
	if id_str == String(AudioEventSeamScript.META_EVENT_PULSE) \
			or id_str == String(AudioEventSeamScript.META_BIOMATTER_PULSE):
		return AudioEventSeamScript.META_BIOMATTER_PULSE
	if id_str == String(AudioEventSeamScript.META_EVENT_GROAN) \
			or id_str == String(AudioEventSeamScript.META_HULL_GROAN):
		return AudioEventSeamScript.META_HULL_GROAN
	if id_str == String(AudioEventSeamScript.META_REACTOR_HUM):
		return AudioEventSeamScript.META_REACTOR_HUM
	return &""


## Internal: route a meta-event id to its bus.
func _bus_for_meta_event_id(id_str: String) -> String:
	if id_str == String(AudioEventSeamScript.META_BEACON_DISTRESS):
		return String(AudioEventSeamScript.BUS_META)
	if id_str == String(AudioEventSeamScript.META_BIOMATTER_PULSE):
		return String(AudioEventSeamScript.BUS_META)
	if id_str == String(AudioEventSeamScript.META_HULL_GROAN):
		return String(AudioEventSeamScript.BUS_META)
	if id_str == String(AudioEventSeamScript.META_REACTOR_HUM):
		return String(AudioEventSeamScript.BUS_META)
	# Schedule short ids also land on meta bus.
	if id_str == String(AudioEventSeamScript.META_EVENT_BEACON) \
			or id_str == String(AudioEventSeamScript.META_EVENT_PULSE) \
			or id_str == String(AudioEventSeamScript.META_EVENT_GROAN):
		return String(AudioEventSeamScript.BUS_META)
	return String(AudioEventSeamScript.BUS_SFX)
