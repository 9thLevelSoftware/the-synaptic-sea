# R19 packaging implementation brief

This is a proposal for the bounded packaging/evidence implementation. It is
not an export result and does not authorize source, preset, template-install,
Godot, or runtime changes by itself. The exact official 4.7.2 Mono template
archive and the Windows release x86_64 entry are in the owned cache recorded by
`r19-template-acquisition.md`.

## Current seams and required implementation scope

The implementation should be limited to the export configuration/checks and
release evidence named by R19:

- `scripts/export/build_release.sh:4-11,70-115,122-153` is the existing export
  path. It is POSIX Bash, defaults to a macOS Godot 4.6.2 path, checks a macOS
  4.6.2 template directory, deletes shared `build/` output, calls
  `--headless --path ... --export-release`, packages artifacts, and writes a
  SHA-256 ledger. It needs a Windows-supported invocation or a bounded Windows
  companion script; preserve the existing script unless a demonstrated defect
  requires changing it.
- `export_presets.cfg:155-202` defines the Windows Desktop preset, currently
  `export_path="build/exports/windows/the-synaptic-sea.exe"`, embeds the PCK,
  excludes `addons/gdai-mcp-plugin-godot/**,.godot/**,build/**`, and does not
  exclude `addons/godot_control_mcp/**` or `addons/derelict/**`. The Windows
  native extension must remain packaged; local/editor plugin independence must
  be proved from the artifact and clean launch rather than assumed.
- `tools/check_export_pipeline.py:12-17,40-78` expects different
  `synaptic-sea-of-stars.*` paths and 4.6.2 script/docs tokens. Reconcile the
  checker with the actual supported Windows target in one scoped change, or
  record a precise replacement check. Do not make a passing checker by
  accepting stale paths.
- `scripts/release/export_presets_validator.gd` and
  `scripts/validation/export_presets_smoke.gd` validate preset/catalog shape
  only. The smoke is classified `release-audit-tool` in
  `docs/game/06_validation_plan.md:1399`; it cannot substitute for an export.
- `addons/derelict/derelict.gdextension` and
  `addons/derelict/bin/win64/derelict_godot.dll` are the Windows extension
  contract. The archive contains the 4.7.2 Mono Windows release template;
  acquisition does not prove that Godot discovers it or that the DLL loads in
  the exported game.

The output root must be a fresh, task-owned directory such as
`artifacts/feature-completion/r19-<UTC-stamp>/`, with separate `export/`,
`package/`, `user/`, `logs/`, and `manifest/` children. Do not use the shared
`build/` directory as the evidence root: the existing script removes its
`build/exports`, `build/release`, and `build/logs` children at lines 122–123.
Record absolute paths only after a containment check.

## Template and runtime resolution

Use the accepted runtime from the remaining-work plan at lines 429–437:

```powershell
$Godot = 'C:/Users/dasbl/Downloads/Godot_v4.7.2-stable_mono_win64/Godot_v4.7.2-stable_mono_win64/Godot_v4.7.2-stable_mono_win64_console.exe'
```

The acquired archive has `templates/version.txt = 4.7.2.stable.mono` and the
required entry `templates/windows_release_x86_64.exe`. Do not invent a Godot
flag for pointing at an archive or extracted template. Godot's official Windows
4.7 documentation supports either the standard `%APPDATA%\\Godot\\export_templates\\<version>`
layout with the documented Windows template filenames, or a custom release
template path through the Windows export preset's
`custom_template/release` option. See the official
[Windows export platform reference](https://docs.godotengine.org/en/4.7/classes/class_editorexportplatformwindows.html)
and [Windows template installation guidance](https://docs.godotengine.org/en/4.7/engine_details/development/compiling/compiling_for_windows.html).
The owned cache can therefore support an isolated-profile discovery arrangement
or a custom-template preset arrangement; neither implies a default-profile
installation or a new user approval. The current evidence has deliberately not
installed or wired either arrangement. The implementation must fail closed if
the selected template version is not exactly `4.7.2.stable.mono` and must retain
the source archive, selected template path, engine version, and template hash
in the evidence manifest.

The export preflight should verify, without running the game:

1. the exact `$Godot` file exists;
2. the discovered Windows release template exists and corresponds to the
   acquired asset (`windows_release_x86_64.exe`), without assuming a filename
   for unrelated platform templates;
3. `export_presets.cfg` has the Windows preset and output path;
4. the project contains the Windows extension DLL and its `.gdextension`
   declaration; and
5. output/evidence/user roots pass the containment probe below.

The existing script's 4.6.2 web/Linux/macOS checks should not be silently
reused for a Windows-only R19 candidate. Linux is optional in
`docs/game/export_pipeline.md`; its declared native `.so` is absent and is a
separate platform disposition.

## Mandatory containment and isolated user environment

The four variables are the same four owned by the strict feature-completion
runner (`tools/run_feature_completion.py:224-227,261-264` and
`tools/run_p10_process_smoke.py:88-93`):

```text
APPDATA
LOCALAPPDATA
GODOT_USER_PATH
XDG_DATA_HOME
```

For every exported-build launch, set all four to the same fresh directory under
the R19 evidence root, save their original values, and restore them in a
`finally`/PowerShell `try/finally` block. Do not reuse a mutable proof home
between independent consumers. The exported game must receive no editor or
Python process in its launch chain.

Before creating or launching anything, add a mandatory shell/path containment
probe that:

- resolves the R19 evidence root, export output, package, logs, and user-data
  paths to absolute paths;
- rejects any path outside the R19 root, any path equal to the workspace root,
  and any path containing a traversal escape;
- rejects an existing destination unless it is the exact task-owned destination
  created for this run; and
- writes the four environment paths and path-probe result to the evidence
  manifest.

This shell/path probe is only the first layer. Before any save-capable body or
journey begins, the packaged executable must run a separate actual-Godot probe
that resolves `user://` through Godot's own `globalize_path("user://")` (or an
equivalent production validation seam), compares the resolved path with
`OS.get_user_data_dir()`, and proves that both are contained under the owned
user root. The probe must exit before creating saves and must emit its own
marker/log with the resolved paths. The packaged lane for this probe is a
required implementation item and remains unverified; the source-tree
`tools/run_feature_completion.py` containment probe cannot substitute for it.
Existing feature-completion probe behavior may be reused only if it accepts the
exported executable and preserves this actual Godot resolution check plus the
four-variable record. No application-wide firewall or machine network changes
are permitted.

## Proposed Windows packaging sequence

The implementation should produce a command file and evidence manifest with
these stages, using only already documented Godot options (`--headless`,
`--path`, and `--export-release` are used by
`scripts/export/build_release.sh:77-80`):

1. Create the fresh R19 root and run the shell/path containment probe.
2. Run the accepted Godot engine against the source tree in a separate no-save
   probe. Resolve `user://` through Godot, compare it with
   `OS.get_user_data_dir()`, and require both paths to remain within the owned
   four-variable root before any save-capable source body or export step.
3. Run the static preset/catalog check after reconciling its expected Windows
   path (`tools/check_export_pipeline.py`) and run the existing Godot preset
   shape smoke later in the validation phase. The latter remains config-only.
4. Export the Windows preset to the owned output path with the exact 4.7.2
   runtime and discovered Mono release template. Capture raw stdout/stderr,
   exit code, command, engine identity, template identity/hash, source revision,
   and diagnostics. Treat any unexpected `ERROR:`, `WARNING:`, or
   `SCRIPT ERROR:` as a failure under the clean-output rule.
5. Verify the exported directory/package contains the executable, embedded PCK
   or expected companion files, `CHANGELOG.txt`, release catalogs/resources,
   and `addons/derelict/bin/win64/derelict_godot.dll` where the export format
   exposes project files. Record a sorted file list and hashes. Prove the local
   `addons/gdai-mcp-plugin-godot/**` content is absent. Check the
   `godot_control_mcp` content explicitly and classify any presence; editor-only
   content must not be required for launch.
6. Run the packaged executable's separate no-save Godot `user://` resolution
   probe. Require its resolved path and `OS.get_user_data_dir()` to remain
   within the owned four-variable root before any packaged save-capable body or
   journey begins.
7. Launch the packaged Windows build from the fresh four-variable user root
   using the repository’s documented launch/quit form. The old release report
   uses `--headless --quit` for an exported app, but Windows acceptance must
   confirm the exact executable invocation against local Godot/runtime help
   before relying on it. Capture clean startup, the expected playable-ready
   signal if available, clean exit, exit code, and diagnostics. Do not claim an
   exported smoke from an editor or from `--main-pack` against the source tree.
8. Run the exported build with application networking unavailable through a
   scoped test arrangement that does not alter unrelated machine networking.
   Record the arrangement and restore state. A process environment alone is
   not proof of network unavailability.
9. Run the supported historical-save load and the core journey only after the
   packaged startup gate passes. Preserve saves and raw logs under the R19 root.
10. Run `performance_profiler.gd` only for headless load/procgen/memory evidence
   and `windowed_fps_capture.gd` in a real window for frame-time evidence, as
   required by `docs/game/performance_baseline.md`. Headless duration cannot
   satisfy the frame-rate requirement.
11. Generate a manifest with every command, environment path, source/template/
   extension hash, artifact hash, marker count, exit code, diagnostics
   classification, save digest, and reviewer disposition. Preserve the raw
   logs; do not reduce a failure to a Boolean PASS.

The canonical plan commands at
`docs/superpowers/plans/2026-09-05-remaining-feature-completion.md:431-451`
remain the baseline for acceptance accounting:

```powershell
& $Python tools/build_feature_acceptance.py --check
& $Python -m pytest -q tests/test_feature_acceptance_registry.py tests/test_p10_process_runner.py
& 'C:/Program Files/Git/bin/bash.exe' tools/classify_orphan_smokes.sh --check
& $Python tools/run_feature_completion.py --godot $Godot --profile restoration --evidence-dir <owned-root>
& $Python tools/run_feature_completion.py --godot $Godot --profile all --evidence-dir <owned-root>
```

Those feature-completion commands target the Godot executable and source tree;
they are regression/accounting commands, not exported-build proof. The final
R19 runner needs an explicit packaged-executable lane, or must record that lane
as missing rather than treating the source-tree profile as equivalent.

## Automatable checks versus human signoff

Automatable evidence can establish: exact engine/template/archive hashes;
containment; four-variable user-home isolation; preset/static-check validity;
export exit status; artifact file list/hashes; absence of excluded GDAI
content; extension file presence; startup/clean exit; diagnostic classification;
historical-save load if the save case is deterministic; canonical regression
markers; and headless performance/load/memory metrics.

Human evidence is still required for the R19 product claim: ordinary
keyboard/mouse and controller controls; crafting, salvage, selected repair,
rebuild, claim/pilot/travel, and save/load as a player journey; no debug stock,
forced repair, teleport, editor, Python, or authoring aid; network-unavailable
behavior; readable feedback and blocked-action explanations; cold launch/clean
exit observation; and final signoff with input method and debug-assistance
status. The plan requires a build, instructions, saves, and recording/evidence
packet before requesting this acceptance.

## Dependencies and current blockers

- R19 depends on R18 for the whole-game claim and on R16/R15 for the core
  journey and restoration UX. The plan explicitly says an unregistered smoke is
  incomplete, not skipped (`docs/superpowers/plans/2026-09-05-remaining-feature-completion.md:451`).
- The feature-completion manifest references `fc_p20_smoke.gd`,
  `fc_p21_smoke.gd`, and `fc_p22_smoke.gd`, but those scripts were absent during
  the inventory. Their owning runtime/profile work must register fresh cases or
  document a bounded replacement before R19 can claim the core journey.
- The accepted Windows engine/runtime and official Mono template asset are now
  available in the owned cache, but template installation/discovery and actual
  export remain unverified.
- The Windows native DLL is present. Linux remains optional and lacks its
  declared `.so`; macOS/Web evidence is historical and does not qualify the
  accepted Windows native candidate.
- `project.godot` enables `res://addons/godot_control_mcp/plugin.cfg`, while
  presets exclude only `addons/gdai-mcp-plugin-godot/**`. Artifact inspection and
  clean launch must settle whether editor/local plugin content is packaged or
  required; source inspection alone cannot certify independence.
