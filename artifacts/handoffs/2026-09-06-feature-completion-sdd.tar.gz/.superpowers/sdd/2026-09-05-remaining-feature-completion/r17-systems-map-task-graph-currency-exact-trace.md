# R17 systems-map-task-graph-currency exact source trace (moving WIP)

Read-only source-audit draft pending root review. Generated 2026-09-05T21:58:59.6312341-04:00 from d850c26ab596b8130be57c8ba4024ef92617f61d. No tests were run. Full IDs and criterion strings were checked against `docs/game/inventory/feature_acceptance.json` and `docs/game/features/systems_map_task_graph_currency.md`.

## FEATURE::docs/game/features/systems_map_task_graph_currency.md::92c4409e88e6

Criterion: Given the final systems map, when `systems_map_currency_smoke.py` runs, then every completed package has source-backed file evidence and the smoke prints `SYSTEMS MAP CURRENCY PASS`.

Status: `partially_traced_unresolved`.

Production trace: `scripts/validation/systems_map_currency_smoke.py:1-3` dispatches `main(['systems-map'])`. `SystemsMapCurrencyValidator.validate` reads the systems map and integration matrix, checks configured/matrix task IDs, counts cited code/data/docs/smoke-file/smoke-marker values, rejects stale phrases, and requires three currency sections (`scripts/validation/doc_currency_validators.py:123-156`). `run_systems_map` calls `require_ok` before constructing PASS (`:277-280`).

Exact assertion and gap: the validation predicates are `scripts/validation/doc_currency_validators.py:129-155`, not the PASS constructor. The evidence loop at `:140-147` only requires any three configured values to occur as text. It counts `smoke_markers` as evidence and never calls `file_exists` for code, data, docs, or smoke paths. The smoke can therefore print PASS without proving the cited files exist; source-backed file existence remains unresolved.

## FEATURE::docs/game/features/systems_map_task_graph_currency.md::1c08155c0a1b

Criterion: Given requirements and ADR docs, when `requirement_trace_smoke.py` runs, then `REQ-DOC-001..008` and package requirement/ADR references are present and the smoke prints `REQUIREMENT TRACE PASS`.

Status: `traced`.

Production trace: `scripts/validation/requirement_trace_smoke.py:1-3` dispatches `main(['requirement-trace'])`. `RequirementTraceValidator` validates each configured REQ-DOC heading, status, and feature-spec filename; every matrix requirement heading; Task-15 validation-plan markers; and the composed ADR index result (`scripts/validation/doc_currency_validators.py:178-221`). `AdrIndexValidator` requires each configured package ADR file to exist and its path to appear in both the ADR index and systems map (`:159-175`). `run_requirement_trace` calls `require_ok` before constructing PASS (`:283-286`).

Exact assertion: `scripts/validation/doc_currency_validators.py:184-202` validates the configured REQ-DOC set, which includes 001..009; `:203-207` validates all integration-matrix requirement headings; `:165-175` validates ADR file existence and references; `:217-220` propagates ADR failures into the requirement result.

## FEATURE::docs/game/features/systems_map_task_graph_currency.md::45aaca948703

Criterion: Given the active Kanban DB and manifest, when `kanban_manifest_smoke.py` runs, then manifest counts/ids/links/statuses match the board and the smoke prints `KANBAN MANIFEST PASS`.

Status: `source_mapped_unresolved`.

Production trace: `scripts/validation/kanban_manifest_smoke.py:1-3` dispatches `main(['kanban-manifest'])`. `KanbanManifestValidator` reads its manifest and SQLite board, checks board name/duplicate IDs, verifies manifest IDs and declared/additional edges, and compares task count, link count, and aggregate status counts (`scripts/validation/doc_currency_validators.py:224-274`).

Exact assertion and gap: the DB predicates are `scripts/validation/doc_currency_validators.py:229-274`. `run_kanban_manifest` returns `KANBAN MANIFEST SKIP` when the configured DB is absent (`:289-296`), so smoke execution does not guarantee PASS. More seriously, `BOARD_DEFAULT` and the manifest path target `synaptic-sea-e2e-systems` (`:23-24,226,293`), while current repository policy names `synaptic-sea-stage-gate` as the active board (`AGENTS.md:33,50,58`; `.omh/kanban/synaptic-sea-stage-gate-task-graph.json:2`). The legacy predicates do not prove currency of the currently active board.

Counts: 3 registry leaves; 1 traced; 2 unresolved; 0 fresh executions.
