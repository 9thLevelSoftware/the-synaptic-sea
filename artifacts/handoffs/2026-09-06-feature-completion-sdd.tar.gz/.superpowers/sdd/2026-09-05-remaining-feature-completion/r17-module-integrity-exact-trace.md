# R17 module-integrity exact source trace (moving WIP)

Read-only source-audit draft pending root review. Generated 2026-09-05T21:58:59.6312341-04:00 from d850c26ab596b8130be57c8ba4024ef92617f61d. No tests were run. Full IDs and criterion strings were checked against `docs/game/inventory/feature_acceptance.json` and `docs/game/features/module_integrity.md`.

## FEATURE::docs/game/features/module_integrity.md::9a7d007899cb

Criterion: Given a wall module at full integrity, when fire damage accumulates past thresholds, then state transitions intact→damaged→breached with atmosphere/nav consequences.

Status: `partially_traced_unresolved`.

Production trace: `_tick_active_fire` calls `_apply_fire_module_integrity` (`scripts/procgen/playable_generated_ship.gd:1967-1976`). That method seeds the compiled map, routes burning-compartment intensity through `ModuleIntegrityConsequences.apply_fire_damage`, applies changed scene states, and refreshes nav gaps (`:4068-4096`). `ModuleIntegrityState.apply_damage/_recompute_state` owns the thresholds (`scripts/systems/module_integrity_state.gd:45-49,86-96`), and `consequence_for_state` owns crawl/atmosphere/nav/collision flags (`scripts/systems/module_integrity_consequences.gd:45-89`).

Exact assertion and gap: `scripts/validation/module_integrity_smoke.gd:18-31` proves the state sequence after direct damage, not fire. `scripts/validation/module_integrity_consequences_smoke.gd:63-80` proves fire changes a wall from intact but does not observe damaged and breached in sequence; `:14-30` checks consequence descriptors separately; `:155-170` applies only the destroyed scene consequence; `:187-189` calls nav-gap application without an outcome assertion. No test follows one full-integrity wall through the complete fire-driven sequence and resulting live atmosphere/nav effects.

## FEATURE::docs/game/features/module_integrity.md::3204cbafadd2

Criterion: Given a sparse snapshot of touched modules, when geometry regenerates from seed and deltas apply, then states match pre-save.

Status: `source_mapped_unresolved`.

Production trace: `_sync_current_ship_pillar_summaries` persists the leaving ship and `_restore_module_integrity_for_current_ship` binds the regenerated loader's map, applies its summary, and reapplies scene states (`scripts/procgen/playable_generated_ship.gd:9531-9574`). `ModuleIntegrityMap.to_sparse_deltas/apply_summary` persists non-pristine states and rebuilds descriptor-seeded pristine modules before applying deltas (`scripts/systems/module_integrity_map.gd:105-154`).

Exact assertion and gap: `scripts/validation/module_integrity_smoke.gd:34-50,80-86` proves pure map round trips. `scripts/validation/pillar_revisit_persistence_smoke.gd:50-75` applies a ShipInstance summary to a fresh map, but its line-68 “geometry regenerated” comment is not backed by generated geometry or a seed. `scripts/validation/fc_p16_smoke.gd:64-94` reapplies a sparse summary to an existing loaded wrapper, not a wrapper regenerated from seed. The exact regenerate/apply/compare sequence is absent.

## FEATURE::docs/game/features/module_integrity.md::507847c085df

Criterion: Given two identical seeds and event sequences, when integrity advances, then maps are bit-equal.

Status: `partially_traced_unresolved`.

Production trace: `ModuleIntegrityMap.apply_damage` delegates deterministic mutation and `fingerprint` sorts module IDs before emitting ID/state/integrity tuples (`scripts/systems/module_integrity_map.gd:63-65,176-184`). The map has no seed input or stored seed field.

Exact assertion and gap: `scripts/validation/module_integrity_smoke.gd:52-58` applies one identical direct-damage event to two maps and compares `fingerprint()`. That fingerprint excludes kind, room ownership, materials, mounted components, base integrity, and tool class, and no seed is supplied. It proves a narrow deterministic fingerprint rather than bit-equality of complete maps under identical seeds and event sequences.

Counts: 3 registry leaves; 0 fully traced; 3 unresolved; 0 fresh executions.
