"""Run the R04 natural-route smoke through the hardened isolated-case API."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))

from tools import run_feature_completion as runner


def main() -> int:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    evidence = ROOT / "artifacts" / "feature-completion" / f"P09-R04-natural-{stamp}"
    user_data = evidence / "user-data" / "r04-natural"
    runner._prepare_evidence_root(evidence)
    case = {
        "id": "R04-natural",
        "scope": "scene",
        "script": "scripts/validation/fc_p09_natural_route_smoke.gd",
        "marker": "FC P09 NATURAL ROUTE PASS",
    }
    result = runner.execute_isolated_case(
        case,
        Path(r"C:\Users\dasbl\Downloads\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64_console.exe"),
        evidence,
        user_data,
        timeout=120.0,
    )
    summary = {"case": case, "evidence": str(evidence), "result": result}
    (evidence / "r04-natural-summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))
    return 0 if result.get("passed") else 1


if __name__ == "__main__":
    raise SystemExit(main())
