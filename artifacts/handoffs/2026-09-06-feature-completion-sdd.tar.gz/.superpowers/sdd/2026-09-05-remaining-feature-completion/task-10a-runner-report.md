# R10-A runner tooling report

The tracked adapter runs exactly the fifteen R10-A governance-listed prerequisite cases
through `tools/run_feature_completion.py`'s `execute_isolated_case` seam.  It
creates a new evidence root, gives every case a distinct owned home, retains the
raw stdout/stderr and a per-case result, and writes SHA-256/byte records for all
retained evidence. The hardened seam supplies the four process-home variables
and the separate P10 containment probe.

The three planned R10-A smokes are mandatory. Since they are currently absent,
the underlying seam records each as `missing script`; this runner still writes
their result and cannot print the aggregate pass marker. The aggregate marker is
exactly `R10-A DOCKING PREREQUISITE PASS cases=15` and is emitted only when every
mandatory case succeeds. The unchanged R04 natural-route smoke is outside the
aggregate: the R10 owner runs it separately last and reports its next real
blocker without claiming R04.

The coordinator ruled this separation necessary to avoid an R10-A → R04 → R10-A
cycle. The adapter obtains markers from the accepted
`build_feature_acceptance._smoke_marker` helper. The two source smokes with
`%`-formatted status data use their explicit complete all-true expected lines;
all cases therefore use the hardened exact-line check. Failed executions never
become successes in this adapter and keep their original reason, including
`missing script`; only success claims must provide retained raw logs.

The unit tests use an injected mock engine seam only; no Godot or gameplay
acceptance command was run.

Commands and results:

- `.superpowers/test-runtime/Scripts/python.exe -m unittest tests.test_r10a_docking_runner` — `Ran 10 tests ... OK`; the exact current-file output is retained in `task-10a-runner-final-evidence/test_r10a_docking_runner.txt`.
- `.superpowers/test-runtime/Scripts/python.exe -m py_compile tools/run_r10a_docking_smokes.py tests/test_r10a_docking_runner.py` — passed.
- `git diff --check -- tools/run_r10a_docking_smokes.py tests/test_r10a_docking_runner.py` — passed.

Immutable source beforeimages are in `task-10a-runner-beforeimages/manifest.json`.
Immutable source afterimages are in `task-10a-runner-afterimages/manifest.json`.
The creation diff is retained as `task-10a-runner.diff` (12,054 bytes,
SHA-256 `63672030400564c306a9a16c9a01a5c65a6d09e1e367da4bfcd5bdef66c02436`).
The additive correction's before/after manifests are
`task-10a-runner-fix-beforeimages/manifest.json` and
`task-10a-runner-fix-afterimages/manifest.json`.

The initial and first additive packages are immutable historical evidence. The
first additive afterimage is superseded by the second correction. The second
afterimage correctly records the current runner and test source bytes/hashes,
but its report entry predates this reconciliation. The final immutable package
at `task-10a-runner-final-evidence/manifest.json` is the current authority for
the runner, tests, report, and retained ten-test output.
