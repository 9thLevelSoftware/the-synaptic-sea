# R19 export readiness inventory

Read-only inventory for Task 19 (R19 / P24 / FC-24 / G6), checked against the
execution worktree on 2026-09-06. No export, build, Godot run, network action, or
test was performed.

## Required R19 evidence

Task 19 in `docs/superpowers/plans/2026-09-05-remaining-feature-completion.md`
requires a supported native export using the exact validated engine/templates and
packaged native extension; clean user data with the application network
unavailable; the core crafting/salvage/repair/rebuild/claim/travel/save-load
journey through ordinary controls; proof that editor/Python/developer absolute
paths/local plugins/authoring tools/asset caches are unnecessary; actual windowed
performance, cold launch/clean exit, and supported historical saves; and a final
build/evidence packet. R18 is a dependency for the whole-game claim, although
export diagnosis may start after R16.

`docs/game/features/crafting_derelict_feature_completion.md` defines FC-24 as
“Core loop works in an offline native export without dev tools” and specifies a
clean-machine exported-build playthrough. A helper PASS or editor/headless PASS
cannot establish this criterion.

## Engine and export templates

| Item | Source / observed state | Disposition |
|---|---|---|
| Accepted validation runtime | `docs/game/adr/0060-windows-feature-completion-validation-runtime.md` accepts `Godot 4.7.2.stable.mono.official.ed1daf0bf` for Windows feature-completion validation and explicitly says export qualification is pending. | Required identity for the Windows R19 candidate; runtime baseline is not export acceptance. |
| Named Windows runtime | `C:/Users/dasbl/Downloads/Godot_v4.7.2-stable_mono_win64/Godot_v4.7.2-stable_mono_win64/Godot_v4.7.2-stable_mono_win64_console.exe` exists (198,152 bytes). | Available prerequisite. Version still needs to be recorded from the actual export run. |
| Current export documentation | `docs/game/export_pipeline.md` and `scripts/export/build_release.sh` are hardcoded to Godot 4.6.2, a macOS binary path, and `~/Library/Application Support/Godot/export_templates/4.6.2.stable`. | Required packaging diagnosis: stale/incompatible for the accepted Windows 4.7.2 path. |
| 4.7.2 templates | Immediate inspection found `C:/Users/dasbl/AppData/Roaming/Godot/export_templates` present but empty, and `C:/Users/dasbl/.local/share/godot/export_templates` absent. Exact Mono directory checks for `4.7.2.stable.mono` at both roots found no directory. The named Downloads runtime parent contains only the two Godot executables and `GodotSharp`; no template directory was present there. The exact official Mono template archive was subsequently acquired and checksum-verified in the owned cache; see `r19-template-acquisition.md`. | The official compatible template asset is now available in the owned cache, but has not been installed into a user-profile discovery directory or exercised by Godot. Template discovery/install remains unresolved; export qualification remains pending. |
| Template files expected by the existing script | Script lines 111–115 require `web_dlink_release.zip`, `linux_release.x86_64`, `macos.zip`, and `windows_release_x86_64.exe` under the 4.6.2 Mac template directory. The 4.7.2 Mono archive contains `templates/windows_release_x86_64.exe` plus debug/release Windows variants and other native platform entries. | Existing script filenames/path contract is stale; the required Windows x86_64 release entry is available in the owned cache, but exact Godot 4.7.2 discovery path still requires a scoped packaging adjustment or documented install step. |

The runtime distribution parent contains `GodotSharp` and both Mono/non-console
Windows executables, consistent with the ADR’s accepted Mono runtime. No `.cs`,
`.csproj`, or `.sln` files are present in the project, so there is no source-file
evidence of a C# gameplay dependency that would independently require the Mono
export variant; the accepted engine/template contract still governs R19.

## Presets, scripts, and static checks

`export_presets.cfg` exists and defines four runnable presets: `web`, `linux`,
`macos`, and `windows`. All use `export_filter="all_resources"`, include
`CHANGELOG.txt`, exclude `addons/gdai-mcp-plugin-godot/**`, `.godot/**`, and
`build/**`, and write under `build/exports/<preset>/`.

The configured paths are:

- Windows: `build/exports/windows/the-synaptic-sea.exe`
- Linux: `build/exports/linux/the-synaptic-sea.x86_64`
- macOS: `build/exports/macos/the-synaptic-sea.zip`
- Web: `build/exports/web/index.html`

`scripts/release/export_presets_validator.gd` and
`scripts/validation/export_presets_smoke.gd` validate preset shape, all four
names, runnable flags, paths under `build/exports/<name>/`, build metadata,
credits, and demo manifest. This is a config-only smoke; its own comments state
that it does not execute Godot export because templates may be absent.

`tools/check_export_pipeline.py` is inconsistent with the checked-in presets:
it expects `synaptic-sea-of-stars.x86_64`, `synaptic-sea-of-stars.zip`, and
`synaptic-sea-of-stars.exe`, while the presets use `the-synaptic-sea.*`. It also
requires the 4.6.2 `scripts/export/build_release.sh` contract and 4.6.2 docs.
Thus the static checker is not evidence of a valid current Windows 4.7.2 export
until this drift is resolved in a scoped card.

`scripts/export/build_release.sh` is POSIX Bash, defaults to a Mac Godot path,
uses a Mac template path, calls `--export-release`, packages release zips, and
temporarily removes a `GDAIMCPRuntime=` line before export. The current
`project.godot` has only the editor plugin declaration
`res://addons/godot_control_mcp/plugin.cfg`; no `GDAIMCPRuntime=` line is
present. The script is therefore not a Windows-native build entrypoint as-is.

The script also deletes `build/exports`, `build/release`, and `build/logs` before
export. That mutation was not performed here and must be treated as a separate,
authorized build step.

## Native extension and packaged dependency paths

`addons/derelict/derelict.gdextension` declares `gdext_rust_init`, minimum
compatibility 4.3, and these libraries:

- Windows debug/release: `res://addons/derelict/bin/win64/derelict_godot.dll`
  (present, 5,279,744 bytes).
- Linux debug/release: `res://addons/derelict/bin/linux64/libderelict_godot.so`
  (directory/file absent in this worktree).
- macOS debug/release: `res://addons/derelict/bin/macos/libderelict_godot.dylib`
  (present, 3,995,840 bytes).

The export filter excludes the local `addons/gdai-mcp-plugin-godot/**` path, but
does not exclude `addons/godot_control_mcp/**` or `addons/derelict/**`. The
editor plugin is enabled in `project.godot`; whether Godot omits editor-only
plugin content automatically in a release export is not established by source
inspection. R19 must prove the exported game launches and runs without either
editor/local plugin or authoring environment. The Windows derelict DLL is an
available required dependency for the supported Windows target; Linux is
optional per `docs/game/export_pipeline.md` and currently lacks its declared
native library. macOS is a documented RC target, but its old 4.6.2 evidence does
not qualify the accepted Windows 4.7.2 candidate.

`docs/game/adr/0060-windows-feature-completion-validation-runtime.md` records a
fresh native-generation probe as part of the 4.7.2 runtime baseline, but also
explicitly says native initialization alone does not establish native generation
coverage and export compatibility remains a separate P24 gate.

## Existing offline/native proof entrypoints

These are useful inputs to an R19 evidence packet, but none is an exported-build
playthrough by itself:

- `scripts/validation/fc_p00_native_arc_smoke.gd` — native selection,
  deterministic seed repeat, and scene marker proof; expected marker begins
  `FC P00 NATIVE ARC PASS`.
- `scripts/validation/first_run_contract_smoke.gd` — production `ShipGenerator`
  candidate selection, standing route, lock rejection, determinism, and fail
  closed; expected marker `FIRST RUN CONTRACT PASS`.
- `scripts/validation/derelict_generator_smoke.gd`,
  `scripts/validation/ship_generator_smoke.gd`,
  `scripts/validation/procgen_loader_playable_contract_smoke.gd`, and
  `scripts/validation/start_scenario_smoke.gd` — native/procgen and playable
  scene checks used by the canonical validation plan.
- `scripts/validation/performance_profiler.gd` — headless load/procgen/memory
  measurements; `docs/game/06_validation_plan.md` expects
  `PERFORMANCE BASELINE PASS templates=3`.
- `scripts/validation/windowed_fps_capture.gd` — non-headless 240-frame
  windowed capture and the documented source of truth for frame-time evidence;
  it is intentionally excluded from the headless regression bundle.
- `scripts/validation/export_presets_smoke.gd` — preset/catalog shape only; it
  explicitly does not run an export.

The feature-completion manifest references future
`fc_p20_smoke.gd`, `fc_p21_smoke.gd`, and `fc_p22_smoke.gd` plus restoration
profile commands, but those files are not present under `scripts/validation/` in
this worktree. They are concrete missing prerequisites for the core journey
evidence unless the owning R14–R16 packages replace/register them. No `fc_p24`
or exported-build runner is present. R19 must use a registered replacement or
record these as missing, rather than treating nonexistent/unregistered smokes as
skips (per the plan).

## Performance and human acceptance requirements

`docs/game/performance_baseline.md` sets targets of stable 60 FPS, <512 MB peak
memory, <3 s scene load, and <2 s procgen, with a documented caveat that
headless frame deltas are not real FPS. Existing baseline evidence is Mac mini
M4/Godot 4.6.2 and includes the editor GDAI plugin in RSS; it is historical and
does not qualify a clean Windows export. R19 requires actual windowed evidence
on the selected target/hardware, cold launch/clean exit, and supported historical
saves.

The plan requires ordinary controls, clean user data, network unavailable for
the application, and no injected stock/forced repair/teleport/debug assistance.
Human observations must identify input method and debug assistance status. A
build/instructions/save/recording evidence packet is required before final human
acceptance; automation cannot invent that sign-off. Existing Gate 1 protocols in
`docs/game/playtests/` are related evidence infrastructure but are not an FC-24
export playthrough.

## Readiness disposition

Required blockers currently evidenced: a Windows-compatible export
invocation/package path; the
preset/checker/script version/path reconciliation; and an exported-build core
journey/evidence runner (including the absent P20–P22 smoke registrations or an
explicit replacement). The Windows native DLL and named 4.7.2 executable are
present. Linux export is optional and its declared `.so` is missing. Actual
template installation elsewhere, exported plugin exclusion behavior, final
runtime dependencies, clean-user-data journey, offline network isolation,
windowed performance, historical-save compatibility, and human acceptance are
unknown until a real export and controlled playthrough are performed.
