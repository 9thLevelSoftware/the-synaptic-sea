#!/usr/bin/env python3
"""Build a local R03 review package only after root declares source frozen."""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

WORKSPACE = Path(__file__).resolve().parent
SOURCE_ROOT = WORKSPACE.parents[2]
BASELINE_DIR = WORKSPACE / "task-3-beforeimages"
ADDENDUM_DIR = WORKSPACE / "task-3-scope-addendum-beforeimages"
INHERITED_INVENTORY = WORKSPACE / "task-3-inherited-closure-inventory.json"
RECOVERY_RECORD = ADDENDUM_DIR / "main-playable-save-load-recovery.json"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def safe_source_path(relative: str) -> Path:
    candidate = (SOURCE_ROOT / relative).resolve()
    if candidate != SOURCE_ROOT and SOURCE_ROOT not in candidate.parents:
        raise ValueError(f"path escapes source root: {relative}")
    return candidate


def safe_output_path(value: str | None) -> Path:
    output = (Path(value).resolve() if value else (WORKSPACE / "r03-review-package").resolve())
    if output == WORKSPACE or WORKSPACE not in output.parents:
        raise ValueError(f"output must be a strict descendant of plan workspace: {WORKSPACE}")
    if output.exists():
        raise FileExistsError(f"output must be a new nonexistent path: {output}")
    return output


def entries_from(directory: Path, label: str) -> list[dict[str, Any]]:
    manifest = read_json(directory / "manifest.json")
    entries = manifest.get("entries")
    if not isinstance(entries, list):
        raise ValueError(f"entries missing from {directory / 'manifest.json'}")
    result: list[dict[str, Any]] = []
    for raw in entries:
        if not isinstance(raw, dict) or not isinstance(raw.get("path"), str):
            raise ValueError(f"invalid manifest entry in {directory}")
        item = dict(raw)
        item["beforeimage_root"] = directory
        item["beforeimage_label"] = label
        result.append(item)
    return result


def recovered_scope_entry() -> dict[str, Any]:
    record = read_json(RECOVERY_RECORD)
    relative = record.get("path")
    expected = record.get("recovered_blob_sha256")
    blob_head = record.get("recovered_from_immutable_head")
    if not isinstance(relative, str) or not isinstance(expected, str) or not isinstance(blob_head, str):
        raise ValueError("invalid recovered main-playable save-load record")
    if record.get("original_worktree_disk_sha256") is not None:
        raise ValueError("recovery record must not claim unavailable original disk hash")
    image = ADDENDUM_DIR / relative
    if not image.is_file() or sha256(image.read_bytes()) != expected:
        raise ValueError("recovered immutable Git blob representation is absent or hash-mismatched")
    return {
        "path": relative,
        "exists": True,
        "tracked": True,
        "sha256": expected,
        "bytes": record.get("recovered_blob_bytes"),
        "beforeimage_root": ADDENDUM_DIR,
        "beforeimage_label": "task-3-scope-addendum recovered main-playable save-load",
        "beforeimage_provenance": "immutable Git blob representation; original disk bytehash unavailable",
        "recovered_from_immutable_head": blob_head,
    }

def before_bytes(entry: dict[str, Any]) -> bytes:
    if not bool(entry.get("exists", False)):
        return b""
    image = Path(entry["beforeimage_root"]) / str(entry["path"])
    if not image.is_file():
        raise FileNotFoundError(f"missing beforeimage: {image}")
    data = image.read_bytes()
    expected = entry.get("sha256")
    if expected and sha256(data) != expected:
        raise ValueError(f"beforeimage SHA256 mismatch: {entry['path']}")
    return data


def text_lines(data: bytes) -> list[str] | None:
    if b"\x00" in data:
        return None
    try:
        return data.decode("utf-8").replace("\r\n", "\n").replace("\r", "\n").splitlines(keepends=True)
    except UnicodeDecodeError:
        return None


def normalized_diff(before: bytes, after: bytes, relative: str, context: int) -> str:
    left, right = text_lines(before), text_lines(after)
    if left is None or right is None:
        return f"Binary change omitted: {relative} (before={len(before)} after={len(after)})\n"
    return "".join(difflib.unified_diff(left, right, f"a/{relative}", f"b/{relative}", n=context, lineterm="\n"))


def git_current_head() -> str:
    proc = subprocess.run(["git", "rev-parse", "HEAD"], cwd=SOURCE_ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if proc.returncode != 0:
        raise RuntimeError(f"git rev-parse HEAD failed: {proc.stderr.decode(errors='replace').strip()}")
    return proc.stdout.decode().strip()


def git_blob(revision: str, relative: str, tracked: bool, expected_blob: str | None) -> bytes | None:
    if not tracked:
        if expected_blob is not None:
            raise ValueError(f"untracked inherited row unexpectedly declares HEAD blob: {relative}")
        return None
    if not expected_blob:
        raise ValueError(f"tracked inherited row lacks HEAD blob: {relative}")
    proc = subprocess.run(["git", "rev-parse", f"{revision}:{relative}"], cwd=SOURCE_ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if proc.returncode != 0:
        raise RuntimeError(f"git blob lookup failed for {relative}: {proc.stderr.decode(errors='replace').strip()}")
    actual_blob = proc.stdout.decode().strip()
    if actual_blob != expected_blob:
        raise ValueError(f"inventory HEAD blob mismatch for {relative}: expected {expected_blob}, got {actual_blob}")
    show = subprocess.run(["git", "show", actual_blob], cwd=SOURCE_ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if show.returncode != 0:
        raise RuntimeError(f"git show failed for {relative}: {show.stderr.decode(errors='replace').strip()}")
    return show.stdout


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def copy_afterimage(root: Path, relative: str, data: bytes) -> str:
    target = root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return str(target.relative_to(root.parent)).replace("\\", "/")


def build(args: argparse.Namespace) -> int:
    if not BASELINE_DIR.is_dir() or not ADDENDUM_DIR.is_dir() or not INHERITED_INVENTORY.is_file():
        raise FileNotFoundError("required beforeimage or inherited inventory input is missing")
    output = safe_output_path(args.output)
    output.mkdir(parents=True)
    scope_after = output / "afterimages"
    inherited_after = output / "inherited17-afterimages"
    scope_after.mkdir()
    inherited_after.mkdir()

    merged: dict[str, dict[str, Any]] = {}
    for item in entries_from(BASELINE_DIR, "task-3-beforeimages") + entries_from(ADDENDUM_DIR, "task-3-scope-addendum-beforeimages") + [recovered_scope_entry()]:
        relative = str(item["path"])
        safe_source_path(relative)
        if relative in merged:
            raise ValueError(f"overlapping manifests require explicit reconciliation: {relative}")
        merged[relative] = item

    scope_entries: list[dict[str, Any]] = []
    incremental_parts: list[str] = []
    for relative in sorted(merged):
        item = merged[relative]
        before = before_bytes(item)
        source = safe_source_path(relative)
        after_exists = source.is_file()
        after = source.read_bytes() if after_exists else b""
        changed = before != after or bool(item.get("exists", False)) != after_exists
        after_path = copy_afterimage(scope_after, relative, after) if after_exists else None
        scope_entries.append({"path": relative, "beforeimage_label": item["beforeimage_label"], "beforeimage_provenance": item.get("beforeimage_provenance", "captured worktree beforeimage"), "recovered_from_immutable_head": item.get("recovered_from_immutable_head"), "before_exists": bool(item.get("exists", False)), "before_sha256": item.get("sha256") if item.get("exists", False) else None, "after_exists": after_exists, "after_sha256": sha256(after) if after_exists else None, "afterimage_path": after_path, "changed": changed})
        if changed:
            incremental_parts.append(normalized_diff(before, after, relative, args.context))

    inventory = read_json(INHERITED_INVENTORY)
    inherited = inventory.get("entries")
    if not isinstance(inherited, list) or len(inherited) != 17:
        raise ValueError("inherited closure inventory must contain exactly 17 entries")
    baseline_head = str(inventory.get("head", ""))
    if len(baseline_head) != 40:
        raise ValueError("inherited inventory baseline HEAD is invalid")
    current_head = git_current_head()
    inherited_entries: list[dict[str, Any]] = []
    supplemental_parts: list[str] = []
    for row in inherited:
        if not isinstance(row, dict) or not isinstance(row.get("path"), str):
            raise ValueError("invalid inherited inventory entry")
        relative = row["path"]
        before = git_blob(baseline_head, relative, bool(row.get("tracked", False)), row.get("head_blob_id"))
        before_data = before if before is not None else b""
        source = safe_source_path(relative)
        after_exists = source.is_file()
        after = source.read_bytes() if after_exists else b""
        baseline_exists = before is not None
        changed = before_data != after or baseline_exists != after_exists
        after_path = copy_afterimage(inherited_after, relative, after) if after_exists else None
        inherited_entries.append({"path": relative, "tracked_at_inventory": bool(row.get("tracked", False)), "baseline_head_blob_id": row.get("head_blob_id"), "baseline_exists": baseline_exists, "baseline_sha256": sha256(before_data) if baseline_exists else None, "after_exists": after_exists, "after_sha256": sha256(after) if after_exists else None, "afterimage_path": after_path, "changed_vs_inventory_head": changed})
        if changed:
            supplemental_parts.append(normalized_diff(before_data, after, relative, args.context))

    generated = datetime.now(timezone.utc).isoformat()
    write_json(output / "afterimages-manifest.json", {"schema":"r03-review-afterimages-v2","generated_at_utc":generated,"current_head":current_head,"scope":"All manifest-listed source afterimages plus the explicit recovered main-playable save-load entry, including unchanged files. Incremental diff contains changed subset only.","source_frozen_declaration_required":True,"entry_count":len(scope_entries),"changed_file_count":sum(x["changed"] for x in scope_entries),"entries":scope_entries})
    (output / "incremental-review.diff").write_text("".join(incremental_parts), encoding="utf-8")
    write_json(output / "inherited17-vs-head-manifest.json", {"schema":"r03-inherited17-supplement-v2","generated_at_utc":generated,"current_head":current_head,"inventory_baseline_head":baseline_head,"provenance":"Supplemental inherited P10/R02 closure context; never attribute this work as newly authored R03.","entry_count":len(inherited_entries),"changed_file_count":sum(x["changed_vs_inventory_head"] for x in inherited_entries),"entries":inherited_entries})
    (output / "inherited17-vs-head-supplemental.diff").write_text("".join(supplemental_parts), encoding="utf-8")
    print(f"R03 review package written: {output}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", help="new nonexistent descendant of the plan workspace")
    parser.add_argument("--context", type=int, default=20, help="normalized unified-diff context lines")
    args = parser.parse_args()
    if args.context < 0:
        parser.error("--context must be non-negative")
    try:
        return build(args)
    except Exception as exc:
        print(f"R03 review package failed: {exc}", file=sys.stderr)
        return 2

if __name__ == "__main__":
    raise SystemExit(main())

