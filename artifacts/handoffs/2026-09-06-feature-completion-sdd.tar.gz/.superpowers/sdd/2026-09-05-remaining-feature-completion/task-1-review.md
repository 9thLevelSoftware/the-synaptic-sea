# Task 1 review — R01 baseline, evidence, and completion register

## Verdicts

- **Spec compliance: FAIL.** The register keeps all current completion totals unknown, the new smokes are classified as standalone, and the current registry/card generation checks pass. R01 is still blocked because the durable P13 run8 log has no exact-source manifest from that run, while the report presents an older run summary as its source manifest. The report also identifies an incomplete worker patch as the exact change ledger.
- **Code quality: NEEDS CHANGES.** The accounting implementation is conservative for today's zero-mapped state, but its partial- and complete-mapping transitions are untested. The only added assertions hard-code the current `0 mapped / 622 unknown` snapshot.

No CRITICAL findings were identified.

## Findings

### HIGH — The P13 log is paired with a different run's summary, so exact-source identity is unproven

- **Affected component:** `artifacts/feature-completion/R01-evidence-20260905/p13-integration-fc_p13_smoke.log`, `p13-integration-source-manifest.json`, and `.superpowers/sdd/2026-09-05-remaining-feature-completion/task-1-report.md` lines 11, 28–30, and 45.
- **Specific problem:** The durable P13 log is copied from `.tmp/p13-p10-pointer-run8/fc_p13_smoke.log` and has SHA-256 `7c99d3bd1789fdee25521678ad44056765adac5094163310a98f29ba903fe561`, 894 bytes, and a 2026-09-05 22:45 UTC timestamp. The file named `p13-integration-source-manifest.json` is instead copied from the older `p13-final-837adcc1-20260905/summary.json`. That older summary points to a 769-byte `p13.stdout.log` with SHA-256 `b890e79c83c52c6ca09e2e24c080fe9af2ad77115027316e387e979dcf4517cd` and a 17:34 UTC timestamp. The outputs differ: the older run contains `GameplaySliceBuilder slot_fallback...`, while the run8 log has two additional `PLAYABLE SHIP READY` lines and no fallback line. The older summary also contains no source-content hash map; it records only a commit and a large dirty-path list, so it cannot establish the exact dirty source snapshot even for its own run.
- **Why it matters:** R01 explicitly requires source-pinned review and durable source identity. Pairing a passing log with a different run's summary makes the P13 evidence non-reproducible and could later let it be mistaken for proof executed against the claimed sources. Labeling both artifacts “historical” does not restore the missing linkage.
- **Concrete remediation:** Produce a P13 run whose runner captures source hashes before and after execution in the same summary, then copy that log, world manifest, and summary together. If rerunning is deferred, rename and describe the older summary as unrelated historical context, state that run8 source identity is unknown, and do not call it the run8 source manifest or say the log is on its recorded source snapshot.

### MEDIUM — Accounting tests do not exercise partial or complete evidence mappings

- **Affected component:** `tools/build_feature_acceptance.py` lines 1218–1244 and 1315–1321; `tests/test_feature_acceptance_registry.py` lines 484–506.
- **Specific problem:** The new behavior has three materially different branches: no mappings, partial mappings (headline totals and percentages must remain `null` while mapped coverage and promoted counts advance), and complete mappings (headline totals and percentages must be derived from the mapped criterion evidence). The added test covers only the current generated snapshot and hard-codes `mapped_criteria=0`, `unknown_criteria=622`, and all promoted counts at zero. It never exercises either transition or verifies mixed true/false evidence dimensions.
- **Why it matters:** R17 will populate this data. A regression in the mapped predicate, denominator selection, promoted aggregation, or complete-map publication can pass all 20 current tests and either suppress valid progress or publish incorrect completion numbers. This is the central behavior introduced by the code change, not an incidental branch.
- **Concrete remediation:** Add focused temporary-source tests that preserve evidence through the prior registry: (1) map one denominator criterion with nonzero evidence and assert partial coverage, nonzero `promoted_evidence_counts`, and `null` headline totals/percentages; (2) give every denominator criterion a referenced reviewed disposition, including both positive and negative dimensions, and assert `complete`, zero unknown, exact totals, and exact percentages; (3) verify aliases/deferred criteria do not change the active metric denominator or counts.

### MEDIUM — The reconciliation report cites an incomplete patch as the exact audit ledger

- **Affected component:** `.superpowers/sdd/2026-09-05-remaining-feature-completion/task-1-report.md` line 32 and the referenced `task-1-diff.patch`.
- **Specific problem:** The report says `task-1-diff.patch` retains the exact tracked diff and before/after identity ledger, but the supplied review instructions identify that worker artifact as incomplete and direct reviewers to the later root-generated `task-1-review.patch`. The report therefore points future reviewers at evidence known not to contain the complete reviewed change.
- **Why it matters:** R01 is an audit/reconciliation task. An inaccurate canonical-change pointer makes later review and provenance reconstruction unreliable even though the root-generated patch allowed this review to proceed.
- **Concrete remediation:** Replace/regenerate the incomplete artifact or update the report to identify `task-1-review.patch` as the canonical reviewed diff. Ensure the referenced ledger includes the durable untracked additions and their hashes, then remove the claim that the incomplete worker patch is exact.

## Verification performed

- Inspected the root-generated `task-1-review.patch` once against the task brief and R01/P01 acceptance language.
- Confirmed `fc_p10_process_smoke` and `structural_rebuild_candidate_nav_smoke` are classified only as `standalone-feature-completion` in both the validation plan and classifier; neither classification promotes an FC row.
- Confirmed current accounting publishes `null` for implemented, production-reachable, freshly validated, player-accepted, accepted, and their percentages while reporting `0/622` evidence mapping coverage.
- Confirmed the copied P10 process summary is byte-identical to its named source and reports all three processes passing, exact marker counts, verified baseline digest, and `source_drift_detected=false`.
- Confirmed the P13 run8 log is byte-identical to its `.tmp` source, then compared it with the older summary's referenced stdout and established that they are different runs and different content.
- Accepted the coordinator's fresh canonical-runtime evidence: 20 Python unit tests and the registry check passed. No Godot command was run during this review.

