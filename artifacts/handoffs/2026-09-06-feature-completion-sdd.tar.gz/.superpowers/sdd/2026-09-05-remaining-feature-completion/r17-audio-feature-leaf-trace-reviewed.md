# R17 reviewed audio feature-leaf source trace (moving WIP)

This replaces the semantic mapping in `r17-audio-feature-leaf-trace.json` while preserving that file as rejected-artifact provenance. It is a source audit only: no test was run, no runtime/document/registry source was edited, and no evidence is promoted.

The reviewed JSON traces every one of the 36 exact active FEATURE IDs from `docs/game/features/audio-music-spatial.md`. It records source implementation, a production caller, player consequence, persistence boundary, and a matching existing smoke assertion or explicitly says that coverage is absent.

Counts: **36/36 source-traced; 0 source-unresolved; 3 contradiction leaves from 1 root cause; 0 evidence promotions.**

## Identity verification

The reviewed JSON carries the actual creation timestamp and current `git rev-parse HEAD` as `source_revision`, with `moving_wip: true` and a source-only audit qualifier. The following read-only PowerShell check was run from the feature-completion workspace:

```powershell
$trace = Get-Content -Raw '.superpowers/sdd/2026-09-05-remaining-feature-completion/r17-audio-feature-leaf-trace-reviewed.json' | ConvertFrom-Json
$registry = (Get-Content -Raw 'docs/game/inventory/feature_acceptance.json' | ConvertFrom-Json).criteria | Where-Object { $_.id -like 'FEATURE::docs/game/features/audio-music-spatial.md::*' }
# Build exact-ID -> criterion map; fail on duplicate, missing, extra, or ordinal criterion mismatch.
```

Result: `trace_count=36 registry_count=36 missing=0 extra=0 criterion_mismatch=0`; `source_revision` equaled the current HEAD (`28af73c85049039ed894bec81af641ee2686508d`).

## Corrections to the rejected mapping

- `59e0955b8e78` is REQ-AU-005's deterministic spatial-volume-formula leaf. Its implementation is `SpatialAudioResolver.resolve_volume_db` (`scripts/systems/spatial_audio_resolver.gd:55`) and its production caller is `AudioManager.apply_spatial_attenuation` (`scripts/audio/audio_manager.gd:365`), not voice playback.
- `00e503834b83` is REQ-AU-009's “When the SFX event fires” leaf. Its implementation is `AudioManager.play_sfx` (`scripts/audio/audio_manager.gd:327`) plus `SfxEventRouter.route` (`scripts/systems/sfx_event_router.gd:117`), not save capture.

## Registry metadata defect

`docs/game/inventory/feature_acceptance.json` has all 36 source leaves, but each has blank feature requirement metadata. The source feature file explicitly assigns the criteria to REQ-AU-001 through REQ-AU-010. This audit derives those labels from the source feature section only; it does not classify the blank metadata as a generator defect because the generator contract was not inspected.

## Source contradiction

`data/audio/audio_bus_config.tres` exists and contains the specified seven bus defaults, but runtime source does not load it. `AudioManager` instead initializes `bus_config` with `AudioBusConfig.make_default()` at `scripts/audio/audio_manager.gd:49`; the play load path constructs this manager at `scripts/procgen/playable_generated_ship.gd:1738-1745`. The three REQ-AU-002 leaves share one `canonical_bus_resource_bypass` root cause because the feature spec declares that resource canonical and forbids a missing-file fallback. No spec change is proposed.

Known source-only coverage gaps are recorded per leaf: ambient threat gain, music gain interpolation/rule combination, live room traversal, panel slider signal-to-save, linked meta-event voice invocation, voice bus-volume assertion, and spatial-subsummary value restore.
