# R03 save restore candidate recovery

Target SHA-256:

`01C44043DA4BAC276E1D83C9AAB3AEB754EB1BB313C8CE3958B87E335C222EFE`

No matching copy was found. Filename filtering for `save_restore_candidate.gd`
returned zero candidates, so no hashes were available to compare.

Actual bounded command (native filesystem traversal; it includes ignored
directories and does not consult Git):

```powershell
$roots=@('D:\the-synaptic-sea-feature-completion\.tmp',
  'D:\the-synaptic-sea-feature-completion\artifacts',
  'D:\the-synaptic-sea-feature-completion\.superpowers',
  'D:\the-synaptic-sea')
$hits=@(); foreach($root in $roots){
  if(Test-Path -LiteralPath $root){
    $hits += Get-ChildItem -LiteralPath $root -Recurse -File
      -Filter 'save_restore_candidate.gd' -ErrorAction SilentlyContinue
  }
}
$hits | Sort-Object FullName -Unique
```

Result: `ZERO_HITS=1` (zero candidates).

Read-only searched roots:

- `D:\the-synaptic-sea-feature-completion\.tmp`
- `D:\the-synaptic-sea-feature-completion\artifacts`
- `D:\the-synaptic-sea-feature-completion\.superpowers`
- `D:\the-synaptic-sea`

No reconstruction or source edits were attempted.
