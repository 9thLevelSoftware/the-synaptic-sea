# R04 economy checker component review

## Spec compliance

**Verdict: FAIL.** The frozen component implements the requested unseeded mandatory-prerequisite SCC report, preserves and reports both authored titanium donor routes, and keeps the canonical production source pin fail-closed for R05/G1 after reviewed R11. One exact contract is not enforced correctly: the new titanium-route validator coerces malformed `required_skill_level` values instead of requiring the authored integer `1`.

This is a bounded verdict for `tools/check_crafting_economy.py` and `tests/test_crafting_economy.py` only. It does not review or accept the R04 natural starter, machinery-donor, or advanced gameplay routes, and it makes no R04-complete or G1 claim.

## Frozen artifact identity accepted for review

- `tools/check_crafting_economy.py`: SHA-256 `d2ca55e11a5d35ae8c1740bd34eb03c5eea18625e82df7074d622235e038ece7`, 110296 bytes.
- `tests/test_crafting_economy.py`: SHA-256 `e69c9b29d9cf37592a4ac5745ad9109cb14224277bc0ec7646b88b2c78fa239a`, 64404 bytes.
- Both workspace files match the frozen copies in `task-4-economy-afterimages/manifest.json` byte-for-byte by SHA-256 and size.
- The R04 delta from `task-4-beforeimages` is 110 inserted checker lines plus 56 inserted/10 removed test lines. The implementation finding below is introduced by that R04 delta. No additional material inherited defect was found in the bounded full-component review.

## Strengths

- `tools/check_crafting_economy.py:2038-2074` computes item dependency SCCs across recipes, junk conversions, and production conversions, then distinguishes an unseeded deadlock from a cycle with a reachable entry item. The result is included in both blockers and the structured report at `tools/check_crafting_economy.py:2418-2475`.
- `tools/check_crafting_economy.py:2077-2128` verifies the two specific authored titanium donor recipes, exact donor BOMs and titanium outputs, workbench binding, loot-backed donor roots, and graph reachability without requiring either item to appear in a particular sampled container.
- `tools/check_crafting_economy.py:79-102,346-358` retains the production guard with the coordinator pin set to `None`. There is no production CLI bypass. The test-only current-source hashes at `tests/test_crafting_economy.py:101-114` are applied with `unittest.mock.patch` and never persist to the checker.
- The stale source-pin test was corrected without weakening drift protection: `tests/test_crafting_economy.py:356-429` asserts the pending production pin, creates only a copied-fixture approval, and continues to reject full-file and semantic mutations.
- The existing full checker remains conservative for zero-power economy analysis: profitable and inconclusive SCCs block, while a positive conservation certificate is required before a group is accepted (`tools/check_crafting_economy.py:2182-2329`).

## Findings

### HIGH

1. **Affected component:** `tools/check_crafting_economy.py:2102-2123`; coverage at `tests/test_crafting_economy.py:1213-1238`.

   **Problem:** The exact skill-1 donor contract is checked with `int(recipe.get("required_skill_level", -1))`. Python accepts malformed values such as `true`, `1.9`, and `"1"` as integer `1`; other malformed values such as `"one"` or `null` raise `ValueError`/`TypeError`, which bypass the CLI's `SourceError` handling at `tools/check_crafting_economy.py:2491-2495`. The same coercion is repeated while constructing the route evidence row. The new test mutates only the valid integer `1` to integer `0`, so it does not exercise either false acceptance or the uncaught-error path.

   **Why it matters:** This guard is the task's explicit proof that both authored donor recipes remain skill-1 workbench deconstructions. It can approve an invalid JSON schema as the required route, or emit a traceback instead of the checker's deterministic blocked marker. A later R05 source re-pin would freeze whatever bytes were reviewed; it would not repair this semantic false acceptance.

   **Concrete remediation:** Validate `required_skill_level` once as a non-Boolean `int` equal to `1`, without coercion. Raise `SourceError` for a malformed type and add `invalid_skill_level` for a well-typed integer other than `1`. Reuse the validated value in the evidence row. Add focused cases for `true`, `1.9`, `"1"`, `"one"`, and `null`, plus the valid integer `1`, and assert deterministic `SourceError` or blocker behavior as appropriate.

### MEDIUM

2. **Affected component:** `tests/test_crafting_economy.py:149-179,934-950`; blocker wiring at `tools/check_crafting_economy.py:2418-2444`.

   **Problem:** The new mandatory-cycle test asserts the reported SCC and then asserts only `report["ok"]` is false. Its synthetic model is independently blocked by unreachable recipe inputs/outputs and by both missing titanium donor recipes. A focused probe of that exact fixture produces four blocker groups: `unreachable_prerequisite_ids`, `unreachable_output_ids`, `mandatory_prerequisite_cycles`, and `titanium_donor_deconstruction_gaps`. The test would therefore stay green if `mandatory_prerequisite_cycles` stopped contributing to `blockers`.

   **Why it matters:** The R04 change specifically promises to reject circular mandatory prerequisites. The test proves SCC reporting, but does not protect the rejection wiring that turns that finding into a failed economy check.

   **Concrete remediation:** Assert the exact `mandatory_prerequisite_cycles` blocker row, or construct an isolated model whose only blocker is the mandatory cycle. If the production analyzer intentionally applies the titanium route invariant to every model, update the synthetic helper to install valid titanium fixtures by default and opt out only in donor-negative tests. Also assert that seeding the SCC removes the mandatory-cycle blocker.

## Test and evidence assessment

- Raw evidence is present and legible. `unittest.result.json` records exit 0; `unittest.stdout.log` is zero bytes; `unittest.stderr.log` is 161 bytes and reports `Ran 56 tests in 15.431s` followed by `OK` with no warnings or errors.
- `canonical.result.json` records the expected exit 1. Its zero-byte stderr and 139-byte stdout contain exactly `CRAFTING ECONOMY BLOCKED source_error=runtime scripts/procgen/playable_generated_ship.gd: compatible tool action proof pin pending review`.
- `provisional_diagnostic.py` computes current source hashes, patches `REVIEWED_TOOL_ACTION_FILE_HASHES` only inside the evidence process, and prints provenance stating that it is never canonical approval. Its result is appropriately provisional and cannot satisfy the R05/G1 production pin.
- The independent focused probe used `python -B` and did not modify the checkout. It confirmed that `required_skill_level=True` and `1.9` yield no titanium donor gap, while `"one"` escapes as `ValueError`. A second probe confirmed the mandatory-cycle fixture has the four blocker groups listed above.
- Existing coverage is substantial for source-adapter drift, runtime-source reachability, item/recipe/knowledge/station/repair graph closure, zero-power cycle classification, and the current real catalog. The missing type-boundary and blocker-isolation cases are the material gaps identified above.

## Quality assessment

**Quality: NEEDS WORK.** The design is conservative and the frozen evidence accurately preserves the intentional canonical block, but the exact titanium skill contract and its regression tests are not yet reliable enough to approve this component. Re-review can be limited to the original Terra fix for the findings above and the resulting frozen checker/test hashes and focused raw evidence.
