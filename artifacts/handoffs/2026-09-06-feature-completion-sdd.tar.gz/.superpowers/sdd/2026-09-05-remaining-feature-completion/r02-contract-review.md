# R02 save-contract preflight

## Verdict

**NEEDS CONTRACT CORRECTION before runtime edits.** The v6/v2 direction is sound, but the ADR/card must lock the following points. Without them, a plausible implementation can silently convert an uninitialized combat owner into an authoritative zero-threat owner, accept downgrade-shaped v6 payloads, or discard the home combat summary during detached preparation.

## HIGH — Distinguish absent combat authority from a canonical empty manager

**Affected:** `RunSnapshot.inventory_summary.threat_summary`, `ShipInstance.combat`, `ThreatManager.get_summary/apply_summary`, v1-v5 migration.

An absent combat key and a complete manager whose `threats` array is empty do not mean the same thing today. Missing or `{}` is skipped by the restore callers and causes the ship layout to initialize/regenerate combat; a complete manager with `threats: []` is authoritative evidence that the initialized owner currently has no threats. Converting legacy omission/`{}` into a v2 empty manager would suppress regeneration and change save behavior.

Lock these rules:

- The outer locations remain optional at the decoding boundary. Omission means **no persisted combat authority was initialized for that owner**.
- For a recognized pre-v6 envelope, an absent key remains absent. A present `{}` has the same historical meaning and is normalized to omission on the detached copy.
- Any present, nonempty legacy manager is migrated. Any present manager in an outer v6 payload must be a complete `schema: "threat-manager-2"` object; present `{}` is invalid.
- A current initialized-empty manager is a complete v2 object with all manager fields and `threats: []`; it is never represented by omission or `{}`.
- Current writers must emit the home `inventory_summary.threat_summary`, because `_build_run_snapshot()` always captures the live manager. Production visited ships are registered on first activation and `_build_world_snapshot()` syncs the current ship before serializing all retained ships, so an initialized visited owner must also emit `combat`. If a future path retains a never-initialized ship, it may omit `combat` and thereby retain the initialization-on-first-use meaning.

Tests must distinguish legacy omission/`{}` (later initialization) from current canonical empty (no respawn), rather than asserting only that both contain zero serialized rows.

## HIGH — Pin normalization to the declared outer source version

**Affected:** `SaveMigrationService`, `RunSnapshot.from_dict`, `WorldSnapshot._validate_detached_nested_state`, `SaveRestoreCandidate._materialize`, `SaveLoadService`.

The current `_migrate_current_run_contracts()` is a v5 compatibility adapter: it can add missing nested crafting envelopes and migrate `craft-jobs-1`/unversioned field-pending data. After `TARGET_VERSION` becomes v6, reusing that routine for an already-declared v6 payload would make malformed or downgrade-shaped v6 crafting load successfully. Likewise, the generic `_migrate_world_home_ship()` currently migrates whatever embedded run version it sees; using it for an already-declared `world-6` would accept a mixed `world-6` + home-v5 document.

Lock these rules:

- `gate2-current-run-5 -> gate2-current-run-6` first runs the established v5 nested crafting normalization with the literal source version `gate2-current-run-5`, then performs combat migration, then passes the result through the full v6 structural decoder.
- An input already declaring `gate2-current-run-6` receives no legacy crafting defaults or nested downgrade migration. Missing current crafting fields, `craft-jobs-1`, unversioned field-pending data, or legacy combat shapes reject.
- `world-5 -> world-6` is the only step allowed to migrate its embedded home run from v5 to v6. An input already declaring `world-6` must embed exactly `gate2-current-run-6`; older, newer, absent, or mismatched inner versions reject rather than being upgraded in place.
- Keep the existing v5 crafting/knowledge/component/oxygen structural checks effective for v6. Update both hard-coded v5 consumers (`WorldSnapshot` and `SaveRestoreCandidate`) deliberately; do not replace historical fixture/version strings globally.

Required mutants are: v6 missing each old mandatory crafting/knowledge/component field; v6 containing each recognized legacy nested crafting form; world-6 with home-v5; world-6 with home-v7; and a valid v5 legacy-crafting payload that still migrates and reloads twice.

## HIGH — Detached preparation currently drops the home threat summary

**Affected:** `SaveRestoreCandidate._materialize/_normalize_migrated_authority`, home run recapture.

`InventoryState.apply_summary()` intentionally ignores non-inventory extension keys, and `InventoryState.get_summary()` does not emit `threat_summary`. `SaveRestoreCandidate._normalize_migrated_authority()` currently replaces the entire home `inventory_summary` with that inventory-only result. Therefore a correctly migrated home manager, including `last_attack_result.weapon_id` and the new `structure_damage`, would be removed before staging/resave.

The contract must require the candidate to extract and validate the optional home combat payload before inventory materialization, retain a detached exact copy, and reattach that copy after canonical inventory normalization. Absence must remain absence. The combat payload receives no recapture-comparison exemption. Do not preserve it by teaching `InventoryState` to own arbitrary combat extensions; combat remains a separate authority nested at the legacy storage path.

## HIGH — One pure, version-pinned combat codec must gate every consumer

**Affected:** `SaveMigrationService`, `RunSnapshot`, `WorldSnapshot`, `SaveRestoreCandidate`, `ShipInstance`, `ThreatManager`.

`ThreatManager.apply_summary()` currently clears runtime state before permissively coercing manager fields, ignores malformed threat rows, and accepts child summaries even when their apply routines normalize or ignore malformed data. `ShipInstance.apply_summary()` currently copies any dictionary under `combat`. Adding only a `structure_damage` check in one outer decoder leaves other application paths able to partially apply malformed current summaries.

Before implementation, list one small pure helper in the card (suggested path: `scripts/systems/threat_save_contract.gd`) and freeze its API. It should:

- recognize/migrate legacy manager summaries only when called from a recognized pre-v6 outer step;
- validate a complete current v2 manager and every threat row without instantiating `ThreatManager`, scene nodes, or reading the scene tree;
- return a detached canonical dictionary or an explicit reason, without mutating its input;
- be used by both outer snapshot paths and by `ThreatManager.apply_summary()`/`ShipInstance.apply_summary()` before any live or owner mutation.

`ThreatManager.apply_summary()` may clear derived nodes only after this validation succeeds. Failure must preserve the existing threats, detection state, damage pipeline, last attack result, weapon cache, and child nodes. Successful application must continue deriving `_last_attack_weapon_id` solely from persisted `last_attack_result.weapon_id`.

The v2 validator must at minimum require the complete keys emitted by `ThreatManager.get_summary()`, strict container/scalar types, finite numeric state, and complete threat rows; otherwise “validate completely before mutating” is not satisfied. Current coercions such as `float(...)`, `bool(...)`, skipped non-dictionary rows, or child defaulting cannot serve as validation.

## MEDIUM — Freeze legacy reconstruction by exact persisted archetype ID

**Affected:** legacy threat-row migration map.

The immutable map is exactly:

| Persisted `archetype_id` | `structure_damage` |
|---|---:|
| `hull_tendril` | 0.4 |
| `biomatter_swarm` | 0.0 |
| `puppet_corpse` | 0.0 |
| `stalker` | 0.0 |
| `mimic` | 0.0 |
| `drone_swarm` | 0.0 |

Match a strict nonempty string from each persisted threat row directly against this map. Do not run encounter-kind aliases (`biomatter_lurker`, `breach_lurker`, `drone_scout`, `derelict_pirate`), infer from markers/tags/instance IDs, or consult `threat_archetypes.json`. Missing, non-string, aliased, unknown, or otherwise ambiguous IDs reject the complete outer preparation with a specific reason.

A recognized legacy manager has no manager `schema` and no `structure_damage` key on any threat row. If an unversioned manager contains the v2-only field anywhere, or a pre-v6 outer envelope carries a v2/unknown manager schema, reject it as a mixed/ambiguous shape. For v2, every row must contain `structure_damage` as `TYPE_INT` or `TYPE_FLOAT`, finite and nonnegative; bool and string coercions reject. `ThreatAIState.get_summary()` must emit the field even when it is zero.

Document the evidence limit exactly: the map reconstructs the six shipped archetype defaults; historical custom per-instance overrides were never serialized and cannot be recovered.

## Acceptance impact

R02 may proceed after these points are in ADR-0059 and the board scope. The focused proof must cover both storage paths, inactive visited owners, mixed home/away rejection, source/index/live-state rollback, exact current nonzero roundtrip, legacy resave twice, canonical empty versus absent behavior, frozen-map rejection, v5 crafting preservation, mixed outer/inner version rejection, and future v7 rejection.

## Addendum — Home and active-away combat are separate authorities

**Verdict:** this is an additional **HIGH** contract correction.

**Affected:** `PlayableGeneratedShip._build_world_snapshot/_build_run_snapshot`, `SaveRestoreCandidate._normalize_migrated_authority`, staged apply/recapture.

The current away-save capture mixes owners:

1. `_build_world_snapshot()` first syncs the live, active-away manager into `current_ship.combat_summary`.
2. It then calls `_build_run_snapshot(away_from_start)` for the embedded home run.
3. `_build_run_snapshot()` correctly switches arc, module integrity, component placement, and ship modification to retained home state when that flag is true, but lines 12684-12686 still write the live active-away `threat_manager.get_summary()` into the home inventory.
4. The visited current ship also serializes its just-synced `combat`, so the away manager is written twice and the retained `home_ship.combat_summary` is lost.

On restore, `_apply_world_snapshot()` applies the embedded home run before activating the saved derelict. The incorrect home payload therefore hydrates the home manager and `_sync_current_ship_combat_summary()` records the away state onto the rebuilt home `ShipInstance`; activation later applies the visited ship's away state again. This can make a later return home use derelict threats and prevents exact owner-aware recapture.

Lock the minimal owner contract:

- `inventory_summary.threat_summary` in the embedded home run always belongs to `home_ship`, even when the player saved away.
- At home, capture it from the live manager. While away, capture it only from the retained `home_ship.combat_summary`; never fall back to the live active-away manager.
- `visited_ships[marker].combat` belongs only to that visited ship. The current visited ship is synced from the live manager immediately before world capture; inactive ships retain their stored summaries.
- On an away save, the embedded home manager and the current visited manager are independent and may legitimately differ. Do not require equality between the two paths.
- A retained complete v2 manager with `threats: []` remains present and authoritative. A retained absent/`{}` legacy owner remains omitted under the absence rules above; it must not be replaced with the active-away manager or converted to canonical empty. In current production, leaving home already syncs its initialized manager, so absence while away is a legacy/uninitialized case rather than a reason to borrow another owner's state.

`SaveRestoreCandidate` also strips `combat_hotbar_text`: it replaces the whole inventory dictionary with `player_inventory.get_summary()`, which emits neither extension key. The candidate must preserve both extensions explicitly across that normalization:

- retain and reattach the validated home `threat_summary` exactly when present;
- retain and reattach `combat_hotbar_text` exactly when present, after requiring `TYPE_STRING` for current v6 input.

`combat_hotbar_text` is a player-facing derived cache for the active player context, not home ship combat authority. Its legacy nesting under home inventory does not make it an input to owner selection or the v2 manager codec. Preserving the string is the smallest compatible behavior and avoids adding a new recapture exception or silently deleting an existing saved field.

The staged sequence should therefore be: apply the home manager from the embedded run; retain it on the rebuilt home `ShipInstance`; restore visited ship summaries; activate the saved away ship and apply that ship's manager; recapture the home run from retained home combat and the current visited slice from live away combat. Add a proof with deliberately different nonzero home and away manager states, including one initialized-empty side, then save/load/recapture and assert each stays with its owner and the hotbar string survives candidate normalization.

## Final clarification — Resolve legacy initialization before sealing the candidate

The smallest deterministic rule is to make combat mandatory for every owner that staging necessarily initializes, and to turn recognized legacy absence into a concrete initial v2 summary **before** the prepared payload is sealed. This supersedes the earlier broad statement that both outer locations are always optional.

- A current `gate2-current-run-6` home run must contain `inventory_summary.threat_summary`. The live production home manager is initialized in `_on_ship_loaded()` before any save, so current omission is malformed.
- A current `world-6` must also contain `combat` for the ship named by nonempty `current_location`, because staging activates that ship. Other inactive visited ships may omit `combat`; omission retains the legitimate initialize-on-first-activation meaning. A complete `threats: []` remains distinct and authoritative.
- For recognized pre-v6 input only, missing/`{}` home combat and missing/`{}` combat on the saved `current_location` owner authorize a one-time deterministic legacy initialization. Produce the complete v2 summary from the same original inputs used by first activation: the saved home layout document/encounter markers for home, or the layout deterministically regenerated from the visited ship's saved blueprint and generation context for the active visited ship, plus the normal owner anchor and current canonical threat definitions.
- Use a shared pure `build_initial_v2(layout, markers, anchor)` path that is also consumed by `ThreatManager.configure_for_layout()`. Do not call `get_summary()` on an initialized live manager and adopt that result as expected authority. The derived summary must exist in the detached migrated world before `WorldSnapshot.from_dict`, `SaveRestoreCandidate.build`, payload hashing, and `_store_prepared_load`; then the existing strict full-world recapture compares concrete expected v2 data with concrete recaptured v2 data and needs no combat exclusion.
- If the original layout/blueprint/context cannot be validated or deterministically regenerated, reject migration explicitly. Do not leave an owner that staging will initialize absent, and do not defer authorization through a self-declared save field.

The existing preparation flow makes pre-seal materialization important: `_store_prepared_load()` hashes and stores `snapshot.to_dict()`, and `resolve_prepared_load()` later rebuilds a new candidate from that sealed dictionary without retaining the first candidate's attached migration metadata. A stage-time “fill from live” would therefore either diverge from the seal/migrated sidecar or require a broad comparison escape hatch.

Inactive omitted visited ships cause no present mismatch: `_apply_world_snapshot()` materializes their `ShipInstance` data but does not configure the single live `ThreatManager`; only `current_location` is activated. They remain absent through recapture and initialize normally on a later first visit, after which the next save emits a complete v2 manager.
