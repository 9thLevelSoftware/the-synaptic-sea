# R17 Core Second-12 Exact Trace

- Generated: `2026-09-05T22:30:57.5830748-04:00`
- Source revision: `50bf1d03d0322d41216f9f4033f1fd683c8d2642`
- Moving WIP: `true`
- Scope: source-only trace; no runtime/test execution, evidence promotion, Git, registry/index writes, or complete-game acceptance
- Registry filter: `domain == "core" && deferred == false`
- Active core rows: `49`
- Prior range explicitly excluded: all 12 exact IDs in `r17-core-first12-exact-trace.json`, including both partial dispositions
- Selection: next 12 rows after the prior range, zero-based registry indices `377..388`, core orders `13..24`; the semantic index was not used as the sole exclusion source
- Result: `10 traced`, `1 source_mapped_authority_scope_partial`, `1 source_mapped_validation_gap`, `0 runtime defects found`, `0 fresh executions`

Selected IDs, in exact order:

1. `REQ-004::acceptance-0ee840e56a92`
2. `REQ-005::acceptance-cff583234ac0`
3. `REQ-005::acceptance-8e288af41691`
4. `REQ-006::acceptance-81ad427f1a21`
5. `REQ-006::acceptance-f403d9bba694`
6. `REQ-006::acceptance-e902d909817b`
7. `REQ-006::acceptance-b1bb3eb989a4`
8. `REQ-006::acceptance-c6d7d08e28fb`
9. `REQ-007::acceptance-49d816526b6e`
10. `REQ-007::acceptance-a38582f629e8`
11. `REQ-007::acceptance-6f89aa75535f`
12. `REQ-007::acceptance-ebf6f57ae0a7`

REQ-004 names `docs/game/08_milestone_gates.md`, which is absent. The current bundle contains the relevant hazard/tool smokes, but the missing owner/checklist and source-only inability to establish historical “before completion” timing limit the exact process claim. REQ-005 is a static governance/non-goal constraint; accepted ADR-0001, `AGENTS.md`, the vision, and the validation plan provide the appropriate evidence without a mirror test.

REQ-006 and its hazard spec are validated. Accepted ADR-0005, as amended by ADR-0041, leaves the OxygenState contract and independent-model boundary in force. The later inventory spec supersedes only the old no-pickup non-goal. Accepted ADR-0007 explicitly includes InventoryState in current-run persistence; ADR-0031 expands slot identity while preserving that payload boundary.

Static review establishes process/non-goal authority, construction shape, isolation, and smoke registration. Dynamic behavior is credited only where an existing smoke contains a meaningful predicate. No fresh PASS is claimed.

## Exact leaf traces

### `REQ-004::acceptance-0ee840e56a92`

**Criterion:** Regression bundle includes the new smoke before a feature is marked done.

- Entry: this is a completion-process rule. The adjacent hazard/tool specs designate `oxygen_state_smoke.gd`, `main_playable_slice_hazard_smoke.gd`, `inventory_state_smoke.gd`, and `main_playable_slice_inventory_smoke.gd` at `docs/game/features/hazards.md:92-103` and `inventory_tools.md:124-138`.
- Static implementation: the live regression bundle registers those four smokes at `docs/game/06_validation_plan.md:429-432`. ADR-0001:28 requires headless validation before completion, and ADR-0005:132 repeats the model/main-smoke rule for new hazards.
- Evidence: static review confirms the four named smokes are presently registered and contain the substantive predicates detailed below.
- Gap: `docs/game/08_milestone_gates.md` and the named review-card checklist are absent. A current source snapshot cannot establish the historical ordering phrase “before a feature is marked done.” This is an authority/process-population limit, not a runtime defect or a mechanical-test obligation.
- Status: `source_mapped_authority_scope_partial`.

### `REQ-005::acceptance-cff583234ac0`

**Criterion:** A milestone cannot be completed solely by HTML, PNG, screenshot, contact sheet, or proof doc artifacts.

- Entry: this is static milestone governance. The controlling decision enters through accepted ADR-0001 and the repository workflow contract.
- Static implementation: `docs/game/adr/0001-adopt-stage-gate-kanban-godot-validation.md:21-29` mandates headless Godot validation and disallows proof-only deliverables unless explicitly scoped. `AGENTS.md:17-24` forbids substituting the listed artifacts for gameplay and requires fresh completion evidence; `docs/game/00_vision.md:27-33` records the same current-gate non-goal.
- Evidence: `docs/game/06_validation_plan.md:1202-1212` supplies the named artifact-scope detector and requires printed proof artifacts to be explained. The detector supports review; ADR-0001 and the workflow/vision documents bind the no-substitution rule. No absence/call-name mirror test is required.
- Status: `traced`.

### `REQ-005::acceptance-8e288af41691`

**Criterion:** If visual evidence is required, it is secondary to in-engine runtime behavior.

- Entry: this is a static evidence-ordering rule applied by the validation plan and accepted Stage-Gate decision.
- Static implementation: ADR-0001:28-29 requires runtime validation and bars proof-only completion. `AGENTS.md:19-24` requires actual in-engine behavior plus fresh validation.
- Evidence: `docs/game/06_validation_plan.md:1218-1224` states that in-engine behavioral playtests run on top of a passing regression bundle and cannot substitute for any smoke. This establishes visual/playtest evidence as additional evidence rather than completion authority. A fabricated runtime test of policy wording is inappropriate.
- Status: `traced`.

### `REQ-006::acceptance-81ad427f1a21`

**Criterion:** At least one hazard exists in the generated ship scene (one oxygen breach zone on the objective 3 → objective 4 corridor for Gate 1).

- Entry: `main_playable_slice_hazard_smoke.gd:3,24-30` instantiates `scenes/main.tscn`; that scene attaches `scripts/main.gd` at `scenes/main.tscn:3-6`. `scripts/main.gd:5-7,13-23` instantiates its default `scenes/procgen/playable_coherent_ship.tscn`, whose `:5-9` selects the `coherent_ship_001` layout/gameplay data. `_on_ship_loaded` then calls `_build_breach_zone(false)` at `scripts/procgen/playable_generated_ship.gd:10188-10197`.
- Implementation: `_build_breach_zone` consumes authored markers or injects fallback ID `corridor_to_reactor` at `:11389-11441`, then constructs and parents at least one `StaticBody3D` breach node at `:11458-11465`. The Gate 1 fallback position is exactly the objective-3/objective-4 midpoint at `:11476-11500`.
- Predicate: `scripts/validation/main_playable_slice_hazard_smoke.gd:64-103` requires a non-null live breach node, exact ID `corridor_to_reactor`, exact kind `oxygen_breach`, open/unsealed state, and the initial collision consequence. The actually loaded `coherent_ship_001` layout has an empty `breach_zones` array at `data/procgen/golden/coherent_ship_001/layout.json:768-770`, while its gameplay slice defines objectives 3 and 4 at `data/procgen/golden/coherent_ship_001/gameplay_slice.json:52-73`. The tested path therefore exercises the empty-position fallback at `playable_generated_ship.gd:11425-11427` and the exact objective-3/objective-4 midpoint at `:11476-11500`; the positional conjunct is traced through the actual main-scene fixture.
- Status: `traced`.

### `REQ-006::acceptance-f403d9bba694`

**Criterion:** The hazard affects traversal, resources, timing, and objective risk: drain rate consumes oxygen while inside the unsealed breach zone, regeneration is gated by leaving any breach zone, objective 2 seals the breach, and a zero-oxygen state blocks passability through the breach zone until oxygen recovers above the recovery threshold.

- Entry: the main-scene `_process` paths call `_refresh_oxygen_state(false, delta)` at `scripts/procgen/playable_generated_ship.gd:11047,11077`. The coordinator supplies spatial context, ticks OxygenState, and applies collision at `:11565-11615`; objective completion applies the ship summary at `:10734-10749`.
- Implementation: `OxygenState.tick` drains only for an open, unsealed occupied home breach and regenerates only outside home/field hazard context at `scripts/systems/oxygen_state.gd:116-174`. `apply_ship_systems_summary` seals on `main_power_restored` at `:233-248`; the scene applier enables collision only when the breach is open and passability blocked at `playable_generated_ship.gd:11669-11695`.
- Predicate: `oxygen_state_smoke.gd:49-84` asserts exact inside drain and outside regeneration; `:106-129` asserts objective-2 sealing and no post-seal drain; `:145-165` asserts zero blocking; `:167-196` asserts recovery above the threshold reopens passability. `main_playable_slice_hazard_smoke.gd:123-210` observes drain and regeneration across real process frames; `:213-243` requires live zero state plus enabled collision; `:246-280` requires objective-2 seal and disabled collision.
- Status: `traced`.

### `REQ-006::acceptance-e902d909817b`

**Criterion:** Player can observe and respond to the hazard: HUD oxygen line, room unsafe marker on the locked-isometric view, and collision-blocked traversal when oxygen is zero.

- Entry: `_build_breach_zone` creates the breach visual and marker at `scripts/procgen/playable_generated_ship.gd:11458-11465`; per-frame `_refresh_oxygen_state` updates model, scene state, and player vitals at `:11565-11615`.
- Implementation: `_create_unsafe_room_marker` creates a billboarded, no-depth-test `Label3D` at `:11546-11563`; `_apply_breach_zone_scene_state` drives its open/unsealed visibility at `:11669-11690`. The same applier drives collision, and `get_player_vitals_lines` exposes the HUD source at `:11665-11667`.
- Predicate: `main_playable_slice_hazard_smoke.gd:104-120` requires the initial HUD oxygen line; `:150-176` requires it to change after live drain; `:213-243` requires zero oxygen, blocked summary, one enabled collision, blocked metadata, and an `Oxygen: 0` HUD line.
- Gap: the hazard smoke never requires `unsafe_room_marker` to exist or be visible. `main_playable_slice_text_scale_smoke.gd:101-104,144-147,180-183` checks pixel size only if the marker is non-null, so it does not close the existence/visibility gap. Production source is mapped, but this room-marker consequence remains dynamically unverified.
- Status: `source_mapped_validation_gap`.

### `REQ-006::acceptance-b1bb3eb989a4`

**Criterion:** The hazard has both a direct state model smoke (`oxygen_state_smoke.gd`) and a main-scene smoke (`main_playable_slice_hazard_smoke.gd`).

- Entry: the pure behavior owner is `scripts/systems/oxygen_state.gd`; the scene coordinator is `scripts/procgen/playable_generated_ship.gd`. The feature spec assigns one smoke to each boundary.
- Static implementation: `oxygen_state_smoke.gd` directly constructs/configures OxygenState. `main_playable_slice_hazard_smoke.gd` instantiates `scenes/main.tscn` and locates PlayableGeneratedShip. `docs/game/06_validation_plan.md:429,432` registers both.
- Predicates: the direct smoke asserts drain, regeneration, seal, zero blocking, recovery, and summary fields at `oxygen_state_smoke.gd:49-235`. The main smoke requires live node, HUD, process, collision, and objective consequences at `main_playable_slice_hazard_smoke.gd:64-309`. This establishes two substantive smoke artifacts; it does not claim a fresh PASS.
- Status: `traced`.

### `REQ-006::acceptance-c6d7d08e28fb`

**Criterion:** Hazard state is parallel to route-control and ship-system state; sealing the breach does not alter route-gate or extraction state.

- Entry: objective completion derives one compatibility summary, then independently refreshes RouteControlState and passes the summary to OxygenState at `scripts/procgen/playable_generated_ship.gd:10734-10749`. The route path is `_refresh_route_control_from_ship_systems` at `:10837-10843`; hazard scene application is separate at `:11565-11615`.
- Static implementation: accepted ADR-0005:24-49 requires OxygenState to remain an independent `RefCounted` model. `OxygenState.apply_ship_systems_summary` at `scripts/systems/oxygen_state.gd:233-248` reads only `main_power_restored` and mutates only its breach/passability fields; it has no route-control, route-gate, extraction, or scene-tree dependency.
- Predicate: `main_playable_slice_hazard_smoke.gd:246-280` seals via objective 2 and separately asserts extraction remains locked; `:284-309` asserts objectives 3/4 do not reopen the breach and normal run completion still occurs.
- Disposition: objective 2 legitimately opens powered route gates through the independent route path. An isolated mirror test demanding no route change across objective 2 would encode the wrong behavior. Accepted architecture plus source side-effect review establishes the exact parallelism constraint.
- Status: `traced`.

### `REQ-007::acceptance-49d816526b6e`

**Criterion:** At least one tool (`portable_oxygen_pump`) can be acquired by interacting with a pickup.

- Entry: `_on_ship_loaded` calls `_build_tool_pickup` after the breach at `scripts/procgen/playable_generated_ship.gd:10192-10197`. `PlayerController.request_interact` emits `interact_requested` at `scripts/player/player_controller.gd:73-81`; the coordinator connects it at `playable_generated_ship.gd:10360-10365` and prioritizes the pump at `:10553-10604`.
- Implementation: `_build_tool_pickup` constructs `ToolPickup` with exact ID `portable_oxygen_pump` and InventoryState at `playable_generated_ship.gd:12342-12361`. `ToolPickup.try_interact` enforces range, adds the tool, hides its marker/disables collision, and emits acquisition at `scripts/tools/tool_pickup.gd:57-84`.
- Predicate: `main_playable_slice_inventory_smoke.gd:49-81` requires empty inventory plus a live visible pickup marker; `:84-130` calls `acquire_tool_for_validation`, which teleports then emits the real player interaction request at `playable_generated_ship.gd:12613-12628`, and asserts exactly one pump, hidden marker, carried-tool HUD lines, and idempotent repeat acquisition.
- Status: `traced`.

### `REQ-007::acceptance-a38582f629e8`

**Criterion:** Carrying the tool changes the oxygen hazard outcome (reduces drain rate while inside an unsealed breach zone).

- Entry: every `_refresh_oxygen_state` pushes `inventory_state.get_summary()` into OxygenState before tick at `scripts/procgen/playable_generated_ship.gd:11565-11576`; the live `_process` paths invoke it at `:11047,11077`.
- Implementation: `OxygenState._compute_drain_multiplier` reads the InventoryState summary only while the home breach is open/unsealed, and `tick` multiplies `drain_rate` by it at `scripts/systems/oxygen_state.gd:140-161,176-211`. InventoryState owns the `0.5`/`1.0` summary value.
- Predicate: `inventory_state_smoke.gd:46-67` applies a carried-pump summary, ticks inside, and asserts `effective_drain_rate=3.0` and `oxygen=97.0` from base rate 6.0; `:69-79` removes the tool and asserts rate 6.0; `:88-103` asserts the summary multipliers. `main_playable_slice_inventory_smoke.gd:133-168` enters the live breach, observes oxygen decrease, and requires multiplier 0.5 plus rate 3.0.
- Status: `traced`.

### `REQ-007::acceptance-6f89aa75535f`

**Criterion:** Tool state persists for the current ship slice and is captured by REQ-012 save/load.

- Entry: PlayableGeneratedShip owns InventoryState for the slice. Snapshot capture writes `inventory_state.get_summary()` at `scripts/procgen/playable_generated_ship.gd:12660-12670`; restore applies `snapshot.inventory_summary` at `:13211-13217`.
- Implementation: RunSnapshot owns `inventory_summary` and deep-copies it through serialization/deserialization at `scripts/systems/run_snapshot.gd:30-40,189-200,285-297`. Accepted ADR-0007:19-27 explicitly includes InventoryState; accepted `ADR-0031-multi-slot-save-architecture.md:3-8` preserves the current-run payload boundary while expanding slots.
- Predicate: `main_playable_slice_inventory_smoke.gd:84-183` keeps the acquired pump through teleport/process phases and asserts it in the final inventory. `save_load_service_smoke.gd:60-61` inserts the pump, `:85-100` captures its summary, and `:218-228` requires the loaded inventory summary to deep-equal the original.
- Status: `traced`.

### `REQ-007::acceptance-ebf6f57ae0a7`

**Criterion:** A direct model smoke and a main-scene smoke both pass.

- Entry: the pure owner is `scripts/systems/inventory_state.gd` with its OxygenState summary boundary; the live owner is PlayableGeneratedShip plus ToolPickup. The feature spec assigns `inventory_state_smoke.gd` and `main_playable_slice_inventory_smoke.gd` to those boundaries.
- Static implementation: `docs/game/06_validation_plan.md:430-431` registers both exact markers. The direct smoke constructs the models; the main smoke instantiates `scenes/main.tscn` and drives acquisition plus live breach frames.
- Predicates: `inventory_state_smoke.gd:3-104` asserts empty/add/unique/status and the 0.5 hazard effect. `main_playable_slice_inventory_smoke.gd:49-183` asserts the live pickup, real interaction dispatch, hidden marker/HUD, retained inventory, live drain, 0.5 multiplier, and no early extraction. This establishes exact test coverage and registration; no current PASS execution is claimed.
- Status: `traced`.

## Review disposition

- Ten leaves have exact static or production traces with meaningful existing predicates where behavior is dynamic.
- The REQ-004 regression-timing leaf remains partial because its owner/checklist and historical completion ordering are unavailable from current source.
- The REQ-006 observability leaf remains partial only for the unsafe-room marker's required existence/visibility assertion; HUD and collision behavior are covered.
- No runtime implementation change, fresh evidence promotion, or unsolicited mirror-test requirement is proposed by this source audit.
