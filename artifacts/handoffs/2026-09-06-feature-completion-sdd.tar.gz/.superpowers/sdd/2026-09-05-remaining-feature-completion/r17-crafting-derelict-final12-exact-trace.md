# R17 crafting/derelict final-12 exact source trace

Snapshot: `2026-09-05T23:36:19.9473474-04:00` at source revision `ed70d37198000529cb8baa5217414f74a0372090`. The source is moving WIP under R03, which was frozen for independent review during this audit. This was a read-only source audit: no tests ran, and no Git, registry, semantic-index, governance, runtime, or evidence state changed.

## Selection and authority

The registry contains exactly **24** active `crafting_derelict` rows. Subtracting the exact prior selection `FC-01` through `FC-12`, regardless of their trace status, leaves registry indices **112–123**: `FC-13` through `FC-24`. None of these final twelve was already in the semantic index at the recorded snapshot. Every selected row is an active `program_outcome` leaf with no canonical/alias indirection and its own metric representative.

The dispositions are **3 traced** and **9 bounded partial/pending**: one ADR-0066 runtime migration, one player-target selection, one replacement transaction, one foundation-only admission, one staged application, one restored-player journey, one replacement persistence, one all-domain qualification, and one export qualification. No runtime defect or complete-game result is claimed.

ADR-0066 is current authority for FC-16. It retires the old `+0.55` mount heal, `-0.6` dismount damage, and `+0.15` plating repair, and requires exact-lot component condition, provider-derived effective system health, reversible power/tier/system effects and no structural repair from plating. Old smokes asserting the retired effects cannot support FC-16.

P11, P12 and P16 have accepted scoped source slices. P17’s policy/nav/volume foundations explicitly cannot satisfy FC-19. The plan’s P18–P24 and the remaining-program R06–R19 map staged application, persistence, restored flight, player journey, all-domain acceptance and export work. Those records establish ownership and future scope; they are not acceptance evidence.

## Exact leaves

### 1. `FC-13`

> Only compatible catalogued parts install into physical slots

**Trace — traced.** The panel’s install request reaches `PlayableGeneratedShip._on_ship_mod_install_requested`, selected-ship preflight, timed `component_install`, and `_apply_ship_work_commit`, which passes the exact physical descriptor and paid lot to `ComponentMountResolver.resolve_mount`. `ComponentCatalog.load_default` (`component_catalog.gd:14-40`) reads the live catalog; `validate_component_fit` (`:84-128`) rejects unknown components, absent/unknown profiles, slot-kind, footprint, socket, and item-form mismatches.

`fc_p11_smoke.gd:15-71` denies water, unknown, wrong-slot and wrong-ship installs without placement/inventory/power mutation, then installs compatible wall/deck parts. `:77-134` rejects invalid profiles across generated, fallback and native slots; `:174-197` proves the panel searches past an incompatible same-kind slot; `:199-255` rejects/quarantines stale saved fit. `fc_p11_live_smoke.gd:35-102` performs the same incompatible denial and timed compatible round trip on a real main-scene slot with exact marker/inventory checks. Its later force-repair travel setup is outside natural-progression evidence and unnecessary for this leaf.

### 2. `FC-14`

> Physical repair/install is timed, interruptible and exactly-once

**Trace — traced.** `_start_transactional_work` (`playable_generated_ship.gd:4299-4363`) configures `WorkActionDriver` and the selected ship’s `ShipWorkTransaction`; `_tick_work_action` (`:6137-6214`) advances only while physical gates hold; `_commit_active_ship_work` (`:4626-4649`) delegates one staged commit. Panel requests never mutate placement or integrity directly.

`fc_p12_smoke.gd:33-112` asserts progress, pause/resume, cancel, and exact-lot refund. `:113-211` asserts rollback, one commit, duplicate `already_committed`, stale retention and cancel recovery; `:215-299` rejects reentrant operations; `:304-354` strictly restores state. Its live case at `:459-575` proves uninstall/install has no immediate effect, can pause/cancel/interruption, reserves first, commits after time, denies a duplicate, and preserves exact lot identity. `fc_p05_smoke.gd:791-824` supplies the repair half: paid material is reserved before effect, timed commit applies one exact quality-adjusted delta, and duplicate commit is denied. Combined predicates cover the criterion without requiring one synthetic umbrella test.

### 3. `FC-15`

> Selected derelict edits never modify the home ship accidentally

**Trace — traced.** `_ship_work_context_for` (`playable_generated_ship.gd:4189-4207`) resolves systems, integrity, placement, modification and transaction owners from the explicit ShipInstance. `_physical_work_preflight` (`:4210-4229`) and commit (`:4528-4539`) require matching selection and binding generation. Missing, foreign, inaccessible or stale owners fail before escrow/mutation instead of falling back to the home ship.

`fc_p13_smoke.gd:51-174` preserves foreign home ownership and rejects cross-owner, wrong-selection/access/range and stale-binding operations. `:176-291` isolates station tier and away-job progress. `:352-506` boards a second loaded ship, commits the exact derelict placement change, and requires the home snapshot to remain identical; missing authority and stale callbacks cannot mutate either owner. `:526-563` pays a derelict module repair and asserts exact ship/module/material while home integrity stays unchanged; `:686-729` covers noncurrent-home selection/cancel. Fixture-assisted travel is suitable for this isolation predicate and is not presented as natural restoration progression.

### 4. `FC-16`

> Power/tier/system effects match installed condition and reverse once

**Trace — accepted ADR runtime pending.** The intended path is exact-lot install/dismount through `ComponentPlacementState` provider condition, `ShipSystemsManager` effective health, power projection and station-tier derivation on the selected ship. Preparatory condition-authority APIs exist and generated placement initializes them at `playable_generated_ship.gd:9646-9657`.

The current commit still invokes `_apply_ship_mod_system_link` at `:4553-4557,4587-4589`; its body writes the retired `+0.55/-0.6` intrinsic-health effects at `:5313-5337`. Install also invokes `_apply_ship_mod_plating_repair`, which performs the retired `+0.15` first-damaged-module repair at `:5340-5369`, and restore replays links at `:5394-5404`. ADR-0066 requires replacement markers and a ten-cycle scene proof of identity/condition, unchanged intrinsic health, provider-derived effective health, multiple-provider reversal, condition-gated tier, full power draw, overbudget rollback, condition-weighted plating, and no-replay disk restoration. No `fc_p14_smoke.gd` exists. All FC-16 conjuncts remain pending the R07/P14 migration; legacy markers are not counted.

### 5. `FC-17`

> Patch targets a chosen damaged module and costs materials

**Trace — player selection partial.** The transaction freezes exact ship/module/revision and reserves `hull_plate`/tool lots before time advances. `WorkActionDriver.complete` mutates only that target. The normal interaction currently resolves `_nearest_workable_wall_module` (`playable_generated_ship.gd:6037+`) rather than presenting a choice among multiple damaged modules.

`fc_p13_smoke.gd:526-563` damages one discovered derelict module, supplies plate/welder, starts the production interaction, and asserts exact ship/target/material, timed improvement and unchanged home integrity. `fc_p05_smoke.gd:791-824` directly selects a named live module and asserts exact lot reservation, no early effect, one quality-adjusted commit and duplicate denial. Paid exact-target behavior is covered after selection. No predicate creates two damaged modules, chooses the non-nearest through normal player UI, and proves the other same-ship target unchanged. R08/P15 owns that precise gap; P21/P22 own normal controls and the journey.

### 6. `FC-18`

> Destroyed structures remain inspectable and replaceable

**Trace — replacement transaction pending.** `GeneratedShipLoader` registers immutable `StructuralRebuildState` descriptors before damage, and `ModuleIntegrityMap.inspect_rebuild_target` joins descriptor identity to current integrity. Destroyed wrappers become hidden/noncolliding without losing module, placement, wrapper, transform, footprint, socket or source-contract identity. `evaluate_replace` can form a pure compatible plan but always returns `scene_authorized=false` and has no production coordinator caller.

`fc_p16_smoke.gd:37-94` loads real generated/authored documents, destroys through the production integrity owner, asserts replaceable inspection, and requires the actual wrapper hidden/noncolliding. `:106-172` covers pristine/ordinary-repair/regeneration/initial-wreck identity and no repair resurrection; `:176-224` covers revision/fingerprint changes and missing target; `:230-277` proves the coordinator uses the loader’s integrity owner; `:349-512` checks all 60 source identities and fail-closed unsupported contracts. Inspectability and durable replacement data are covered. No paid authorized replacement occurs, so actual player replaceability remains for R11/P17 and R12/P18.

### 7. `FC-19`

> Replacement enforces footprint/sockets/occupancy/egress

**Trace — foundation only.** The future production coordinator must combine `StructuralRebuildState.evaluate_replace`, physical-volume clearance and `ShipNavGraph` route evaluation before P12 reserves materials. No such coordinator caller exists.

`structural_rebuild_state.gd:97-163` checks exact owner, destroyed target, catalog identity, footprint and socket mapping, then withholds scene authorization. `structural_rebuild_policy_smoke.gd:35-117,177-211` loads all 60 rows and rejects forged owner/catalog/material/module/wrapper/footprint/socket claims while requiring `scene_authorized=false`. `structural_rebuild_candidate_nav_smoke.gd:159-270` exercises alternate route, portal and no-egress cases, and `:205-207,790-793` explicitly requires every result to remain unauthorized. The P17 plan says these foundations cannot satisfy FC-19. Footprint/socket policy is statically covered; selected-world occupancy/collision, dock/endpoint support, egress authorization and the resulting paid transaction await R09–R11.

### 8. `FC-20`

> Replacement restores visible, collision, nav and atmosphere behavior

**Trace — planned application gap.** The planned entry is a P18 applier that consumes one immutable authorized token, barriers the ship, stages wrapper geometry/collision/navigation/atmosphere, proves readiness, then finalizes once or rolls back coherently. No structural rebuild applier or `fc_p18_smoke.gd` exists. P16 only disables destroyed wrappers; P17 produces unauthorized pure plans.

No predicate installs replacement geometry and then asserts visible wrapper, live collision, navigable connectivity and atmosphere behavior on both rooms sharing the edge. All four dynamic consequences remain an explicit R12/P18 implementation and validation gap after R09–R11.

### 9. `FC-21`

> Claimed repaired ship becomes a usable ride under real readiness rules

**Trace — player journey pending.** `_on_login_requested` (`playable_generated_ship.gd:2363-2376`) checks `ShipInstance.is_working_vessel`, then claim/pilot code applies access. `TravelController` checks destination, range and operational propulsion. There is no restoration-readiness authority joining an actually repaired/rebuilt derelict’s power, propulsion, navigation, atmosphere, bridge, collision/nav state and transaction completion.

`pilot_switch_smoke.gd:17-33` registers a test ship and calls `make_ship_working_for_validation` before asserting claim/pilot. `repair_loop_smoke.gd:35-106` naturally obtains one circuit board and times a nav-linkage repair, but force-repairs power/navigation before travel and never claims a restored derelict. `docking_loop_smoke.gd:54-112` also force-repairs systems. `claim_persistence_smoke.gd:17-70` proves validation-assisted claim/pilot/geometry/dock persistence without rebuilding or natural readiness. These are useful narrow scaffolds, not proof that the repaired ship becomes a normal usable ride. R14/P20 and R15–R16/P21–P22 own the integrated path.

### 10. `FC-22`

> Repairs/replacements/machinery survive revisit, docking and save/load

**Trace — replacement persistence pending.** Save/load carries per-ship `module_integrity` and `component_placement` summaries, and world snapshots carry claim/dock graphs. `StructuralRebuildState` explicitly labels inspection as a runtime, non-save payload owned later by P19. No rebuilt descriptor/application journal appears in `ShipInstance`, `RunSnapshot`, `WorldSnapshot` or migration; live physical work transaction state is also absent from `ShipInstance.get_summary`.

Combined existing predicates cover narrower completed state: `fc_p11_live_smoke.gd:104-129` preserves installed machinery through validation-assisted revisit/save-load; `fc_p13_smoke.gd:735-854` preserves per-ship state and rejects malformed-present disk data; `repair_loop_smoke.gd` retains completed system repair; `claim_persistence_smoke.gd:60-70` preserves derelict ownership, piloted geometry and dock edge. None saves and reloads an applied replacement with its geometry/collision/nav/air consequences, or proves one repaired/rebuilt derelict through the full revisit+docking+save-load combination. R13/P19 owns rebuilt/interrupted state and R14/P20 owns the integrated journey.

### 11. `FC-23`

> Every active designed system passes its own player acceptance criteria

**Trace — all-domain qualification pending.** At the recorded index snapshot the project had **657 active rows**, frozen canonical denominator **622**, **133 semantic source mappings**, **524 pending semantic IDs**, and **0 runtime evidence promotions**. This report is source preparation and was not indexed here.

P23 requires every active leaf to be traced through implementation, production caller, consequence, persistence and player acceptance, all gap cards closed, and one same-candidate full regression. Those gates are not recorded complete. FC-16 through FC-22 also retain concrete gaps above. Source mappings cannot be averaged into player acceptance or a game-complete result. R17/P23 owns domain closure and R18 integrated qualification.

### 12. `FC-24`

> Core loop works in an offline native export without dev tools

**Trace — export qualification pending.** `export_presets.cfg` declares runnable native presets and resource inclusion. `ExportPresetsValidator` checks their static names, platforms, paths and filters. ADR-0060 accepts the Windows validation-engine baseline, not an exported product.

`export_presets_smoke.gd:3-13` explicitly says it parses configuration and **does not execute Godot export**; `:32-99` checks only preset data. Native generation/editor smokes also do not launch a packaged binary. No predicate builds the current candidate, disconnects network/development tools, launches the export with a clean user directory, and completes natural loot/craft/repair/rebuild/claim/travel/save-load. The core-loop prerequisites FC-17–FC-23 remain open as well. R19/P24 owns this final gate after integrated qualification.

## Material gaps

- FC-16 still uses call sites and markers retired by accepted ADR-0066; the new condition/effective-health integration and exact cycle predicates remain pending.
- FC-17 pays and mutates one exact target, but normal player selection among multiple damaged modules is absent.
- FC-18 retains inspectable replacement identity, while an authorized paid replacement transaction is absent.
- FC-19 has useful footprint/socket/nav/volume foundations that deliberately withhold live authorization; occupancy and egress admission remain for R09–R11.
- FC-20 has no staged geometry/collision/nav/atmosphere application path.
- FC-21 and FC-22 have narrow readiness, repair, machinery, claim and docking scaffolds, without an actual repaired/rebuilt ship journey or rebuilt-state persistence.
- FC-23 and FC-24 remain final qualification gates; source traces and configuration checks do not satisfy them.

These are precise source/evidence boundaries. They do not promote an unrun smoke, planned task, static mapping or validation fixture to runtime/player acceptance.
