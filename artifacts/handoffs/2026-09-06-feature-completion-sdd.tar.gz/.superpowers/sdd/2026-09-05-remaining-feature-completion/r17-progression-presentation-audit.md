# R17 bounded audit: progression and presentation

Read-only source trace completed 2026-09-05T20:01:46-04:00 at worktree HEAD
`a12d3eed502b99739d08c6b7961e3fc689a6a329`. R02 is editing persistence and
coordinator-adjacent sources; this report does not claim frozen-source
validation or current runtime behavior.

## Active registry leaves

All leaves below currently have `state=not_verified`, all four evidence
booleans false, and `refs=[]` in `docs/game/inventory/feature_acceptance.json`:

* Progression: `REQ-PM-001::acceptance-9f5bb521ed4c`,
  `REQ-PM-006::acceptance-f2cac75ab75d`,
  `REQ-PM-007::acceptance-c2b054344bea`.
* UI/accessibility: `REQ-UI-001::acceptance-da23fa3544bb`,
  `REQ-UI-003::acceptance-6c52ec25023b`,
  `REQ-UI-006::acceptance-5ce9d2b12a86`.
* Audio: `REQ-AU-001::acceptance-d06b7c5e4bf9`,
  `REQ-AU-004::acceptance-712752c032c4`,
  `REQ-AU-010::acceptance-0d4615c4d367`.

These are package-level representatives after reviewed equivalence. They do
not prove every detailed plan bullet, and no historical declared status was
promoted.

## Progression trace (plan 08)

The coordinator instantiates/configures `PlayerProgressionState`,
`TrainingEventBus`, `SkillTreeState`, `MetaProgressionState`, `HubUpgradeState`,
and `UnlockRegistry` at `scripts/procgen/playable_generated_ship.gd:1608-1652`.
Training reaches the shared `emit_training_event` seam at
`playable_generated_ship.gd:2284-2287`; callers cover repair, salvage, combat,
crafting, discovery, medicine, consumables, and astrogation (examples at
3686-3687, 4616, 6289, 7644-7648, 8303, 8488-8498, 8647-8648, and
10030-10032). The skill gate callback joins training to skill-tree unlocks at
`playable_generated_ship.gd:1625-1631`.

Current-run progression and skill summaries are captured at
`playable_generated_ship.gd:12700-12703` and restored at `13227-13230`;
`scripts/systems/run_snapshot.gd:41-42,154-155,202-203,288-289` defines the
fields. Meta progression is separate: it loads at
`playable_generated_ship.gd:1632-1635`, saves at `12935-12936`, and is carried
by the world snapshot at `13473`/`13810-13811`; model disk methods are at
`scripts/systems/meta_progression_state.gd:278-300`.

This establishes model wiring/save boundaries only. It does not establish all
classes/skills are reachable, every major loop emits intended XP, or death/run
rules are accepted. PM leaves remain unverified with no refs.

## UI/accessibility and ChartPanel trace (plan 09)

The plan's `MapFogState`/minimap requirement is retired by ADR-0045. The
feature spec says `MapFogState` and `MinimapPanel` were deleted and replaced by
item-gated web charts (`docs/game/features/ui_ux_accessibility.md`, Web charts
and functional-contract sections). Production wiring is concrete:

* `PlayableGeneratedShip` preloads `ChartPanel`/`WebChartState` at lines 13/17,
  creates and binds the panel at `8835-8839`, and records chart views for a
  possessed `web_chart` at `2576-2580`.
* `open_chart_panel_for_validation` at `5195-5219` denies without a chart,
  emits “No web chart”, opens the read-only panel when owned, and routes UI SFX.
  The live `ui_open_map` path repeats the gate at `14474-14483`.
* `scripts/ui/chart_panel.gd:2-9` documents the same ownership gate.

`MenuCoordinator` configures `ControllerGlyphState`/`SettingsState` at
`scripts/ui/menu_coordinator.gd:141-153`; setting changes apply to
`AccessibilitySettings` at 400-407 and 453, and glyph resolution uses the
selected scheme at 1144-1147. `SettingsState` is the single write-back path
for captions and glyph scheme (`scripts/systems/settings_state.gd:95-169`).
Settings are captured at `playable_generated_ship.gd:12704` and restored at
`13231-13232`.

Tutorial/codex/menu models have owners in `tutorial_state.gd`,
`unlock_registry.gd`, and `menu_coordinator.gd`, but the current trace did not
verify every input path or player readability outcome. Those remain unverified,
not defects inferred from the retired map-fog smoke name.

## Audio, captions, and settings trace (plan 10)

`PlayableGeneratedShip` creates `AudioManager` at
`playable_generated_ship.gd:1732-1745`. `_refresh_audio_state` at
`12135-12207` derives engagement, hazard, and critical-vitals flags; updates
music, room-role ambience, hazard SFX, listener/spatial attenuation, and
caption pumping. `_push_ambient_zone_from_gameplay` maps room roles/threat at
`12273-12291`.

`SfxEventRouter` defines buses, cooldowns, captions, and caption queue at
`scripts/systems/sfx_event_router.gd:26-85,88-106,115-202`. The coordinator
routes gameplay/UI events through `AudioEventSeam`/`play_sfx` (docking
3276-3287, objectives 8489-8499, and vitals/audio refresh 12180-12207).
Captions reconcile from settings at `playable_generated_ship.gd:10118-10125`
and pump to HUD at `12203-12207`.

Audio persistence is explicit: `_build_run_snapshot` captures
`audio_manager.get_summary()` at `playable_generated_ship.gd:12704-12706`, and
restore calls `audio_manager.apply_summary()` at `13234-13237`. This is
model/scene evidence only; no current validation or human audible acceptance
is claimed. Catalog/file presence is not proof that every clip is shipped,
audible, spatially mixed, or player-acceptable.

## Remaining leaves and bounded findings

1. No additional source contradiction was found in PM/UI/AU during this read;
   R02 edits mean these are read-snapshot references, not fresh validation.
2. The old map-fog item is intentionally retired. Validate the ChartPanel/
   web-chart gate; do not promote volumetric atmosphere-fog checks as map proof.
3. PM remains unverified for complete class/skill data, player-reachable XP,
   meta separation, and run-end behavior.
4. UI remains unverified for multi-input navigation, accessibility readability,
   tutorial/codex interaction, ChartPanel feedback, and settings persistence.
5. AU remains unverified for live audible content, spatial/ambient/music
   behavior, captions/settings interaction, and save/reload restoration.
6. The nine leaves listed above remain `not_verified`; no denominator or
   registry status changed.

