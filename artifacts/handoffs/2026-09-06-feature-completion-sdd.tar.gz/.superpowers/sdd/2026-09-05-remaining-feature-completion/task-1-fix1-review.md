# Task 1 fix round 1 review — R01

## Verdicts

- **Spec compliance: PASS.** The P13 run8 evidence is now accurately reported as source-unknown historical evidence and is not promoted. The report identifies the root-generated patch as canonical and the worker patch as superseded. Current production accounting remains conservative and the standalone smoke classifications remain unchanged.
- **Code quality: NEEDS CHANGES.** The partial/full tests improve coverage, but the complete-mapping test was enabled by introducing an inconsistency between `build()` and `validate()`, and it still verifies only part of the aggregate dimensions.

## Prior finding status

### HIGH — P13 log paired with a different run summary: ADDRESSED

The updated report explicitly states that the older P13 summary is unrelated historical context, that the run8 exact source snapshot is unavailable, and that the run is not source-pinned evidence. It no longer claims the older summary proves run8 source identity or promotes the run to an FC row. This satisfies the conservative fallback remediation from the original review.

### MEDIUM — Partial and complete mapping behavior untested: PARTIALLY ADDRESSED

Two transition tests were added. The partial test verifies one mapped criterion, nonzero promoted counts, and withheld headline totals/percentages. The complete test verifies publication for one headline count and one percentage. A material correctness issue and incomplete assertions remain, described below.

### MEDIUM — Incomplete worker patch called the exact ledger: ADDRESSED

The updated report identifies `task-1-review.patch` as the root-generated canonical review diff and explicitly says `task-1-diff.patch` is superseded and must not be used as an exact ledger.

## Remaining finding

### MEDIUM — Complete mapping now publishes percentages for an unfrozen denominator, contradicting validation

- **Affected component:** `tools/build_feature_acceptance.py`, percentage construction near lines 1239–1248; `validate()` near lines 1663–1666; `tests/test_feature_acceptance_registry.py`, `test_complete_evidence_mapping_publishes_derived_counts`.
- **Specific problem:** Fix round 1 changes the outer percentage guard from `scope_frozen is not None` to `evidence_mapping["status"] == "complete"`. The complete-mapping test uses the temporary root, whose scope is unfrozen, and therefore expects a percentage to be published. Existing `validate()` explicitly rejects every non-null percentage when `scope_frozen` is `None`. The new test calls `build()` but not `validate()`, so all 22 tests can pass while `build()` produces a registry that its own validator rejects. The test also supplies mixed production-reachability and fresh-validation values but never asserts those totals or percentages, and it does not exercise accepted-state aggregation.
- **Why it matters:** Generator and validator disagreement makes the registry API internally inconsistent and weakens the freeze rule that prevents percentages from being published against an unreviewed denominator. Incomplete dimension assertions still allow regressions in most of the newly introduced aggregation behavior.
- **Concrete remediation:** Restore the outer freeze guard: percentages should be published only when the scope is frozen and evidence mapping is complete. Exercise the complete branch with a temporary frozen-scope contract rather than weakening the production invariant, call `validate()` on the rebuilt registry, and assert exact `promoted_evidence_counts`, headline totals, and percentages for implemented, production-reachable, freshly validated, player-accepted, and accepted states. Retain the partial test's assertions that all headline values remain `null`.

## Verification

- Inspected `task-1-fix1-review.patch` against the prior review and the three scoped findings.
- Confirmed the report now distinguishes the P13 run8 log from the older summary and explicitly records unknown source provenance.
- Confirmed the canonical/superseded patch wording is corrected.
- Traced the new partial and complete tests through `build()` and the existing unfrozen-scope assertion in `validate()`.
- Accepted the coordinator's fresh canonical-runtime result: 22 tests passed in 0.78 seconds; registry and orphan checks also passed. No runtime or Git command was run for this review.

