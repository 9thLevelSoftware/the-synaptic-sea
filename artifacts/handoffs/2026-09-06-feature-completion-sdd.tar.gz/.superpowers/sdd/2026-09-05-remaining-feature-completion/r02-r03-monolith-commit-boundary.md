# R02/R03 monolith commit boundary

Date: 2026-09-05  
Audit mode: read-only source/diff inspection; no staging, runtime edits, or tests  
Current Git documentation revision at inspection: `4590a4058f631fdfd316d276d116b1ec8001df17`  
Runtime authority: the unchanged accepted R02/R03 source hashes and retained evidence; `ed70d371` is the final R03 governance revision named by the task.

## Recommendation

Do not create a partial runtime commit from selected HEAD hunks, and do not stage the whole current playable/persistence files as an implied acceptance of their remaining pre-R02 WIP. Preserve the pinned, independently accepted R02/R03 source and defer the coherent whole-file runtime commit until R04/R06 have reviewed the relevant inherited hunk families in `playable_generated_ship.gd` and the six persistence files listed below. The separately packaged 17-file companion closure is already covered by complete immutable-diff review.

If an earlier runtime commit is required, the safe alternative is an immutable review of the **exact current HEAD-to-working-tree whole-file diffs** for the remaining seven files: the playable monolith and six persistence files. Approval must cover the exact source already validated by R02/R03. The 17-file companion closure does not need that review repeated: R03's supplemental package already presented and received review of its complete current-versus-HEAD diffs. This requires no source synthesis or rerun unless that review requests a code change. A documentation/review-artifact checkpoint may be committed separately in the meantime, but it must not claim that the remaining runtime files are integrated.

## Exact decomposition

The preserved R02 preimage at
`.superpowers/sdd/2026-09-05-remaining-feature-completion/r02-review-baseline/scripts/procgen/playable_generated_ship.gd`
has SHA-256 `1247959c18511a46e5985fb15f412498b1ceea4b7e386ee8bed8c8a4dc794db5`.
The frozen current file has SHA-256
`194febaf886d5035faf4cd530079830637d64d86ecfc4383fa217d873221d5af`.

The preserved `task-2-before-runtime.patch` shows that `playable_generated_ship.gd`
already differed from HEAD by `+1711/-361` before R02. The accepted R02 package
then changed that preimage by only `+18/-1`:

- capture home combat from the retained home owner when building the home run;
- retain validated `combat_hotbar_text` across active-owner reconstruction and
  publish it after docking/activation.

R03 did not edit `playable_generated_ship.gd`; it exercised the inherited staged
replacement behavior and accepted the R03 delta in other files. The current whole
HEAD diff is `+1729/-362`, exactly accounting for the preexisting monolith plus
the reviewed R02 delta. Consequently, almost the entire whole-file Git diff is
outside the immutable R02/R03 implementation deltas.

The same stacking pattern exists in the six tracked persistence files preserved
before R02:

| File | Pre-R02 HEAD delta recorded in `task-2-before-runtime.patch` | Accepted changes on top |
|---|---:|---|
| `scripts/systems/run_snapshot.gd` | `+327/-3` | R02 combat authority; R03 mandatory current hotbar |
| `scripts/systems/save_load_service.gd` | `+521/-146` | R02 versioned bootstrap/owner fixes; R03 covering evidence |
| `scripts/systems/save_migration_service.gd` | `+585/-25` | R02 combat/version pairing; R03 historical hotbar adapter |
| `scripts/systems/ship_instance.gd` | `+98/-6` | R02 visited-owner combat |
| `scripts/systems/threat_manager.gd` | `+11/-2` | R02 strict combat hydration and LOS reset |
| `scripts/systems/world_snapshot.gd` | `+144/-7` | R02 current combat ownership |

Those preexisting hunks are the P10 transaction/candidate substrate on which the
reviewed R02/R03 deltas were built. R02 and R03 validated their behavior as part
of the exact full source closure, but their immutable implementation patches did
not present all HEAD-to-preimage hunks as newly reviewed changes.

The inherited 17-file companion closure has a different review status. R03's
`r03-review-package-01/inherited17-vs-head-supplemental.diff` is the complete
current-versus-HEAD diff for all 17 companion sources, including the entire
`scripts/main.gd` `+76/-0` change. The artifact is 232,958 bytes with SHA-256
`7f8b87d2766647eae5e0385c2ced89b649b34e08526fae54783fae1035ea8434`, and the
R03 reviewer explicitly read and approved it. Those 17 sources are therefore
immutable-diff-reviewed; they are not part of the remaining review boundary.

## Specific inherited hunk families outside the R02/R03 deltas

### Necessary P10 staging and persistence substrate

The pre-R02 playable/persistence source contains the detached prepare/resolve/apply
flow, source sealing, staged sibling construction, full holder materialization,
world-envelope save paths, current owner/job capture, and failure rollback. It
also establishes run identity before lot creation, carries owner-keyed crafting
jobs and pending receipts, and restores component condition authority.

These behaviors are necessary dependencies of R02/R03. The R03 reviewer inspected
and approved the resulting atomic publication behavior and its evidence. The
supplemental immutable diff also covered the entire preexisting `scripts/main.gd`
`+76/-0` atomic replacement coordinator (SHA-256
`34bfe9b3d215ba5bbe16f5b340077c5b5a5d3320b9f3dfc5aa1eece402e3e4ea`), rather
than only the focused `scripts/main.gd:26-87` semantic path.

The inherited title pointer update, deferred audio server writes, deferred
camera-current activation, prepared-load UI propagation, owner-aware
component/crafting models, and craft-job migration models are also among that
fully reviewed 17-file P10 companion closure. They may travel with the accepted
closure on the supplemental review's authority. The remaining P10 boundary is
the pre-R02 HEAD-diff body of the playable monolith and six persistence files.

### P13 work and ship-owner authority

The preserved playable preimage adds `selected_ship_id`, `ShipWorkContext`, live
binding generations, per-ship module/component/modification/work-transaction
owners, selected-ship modification binding, exact physical mutation preflight,
per-owner scene consequences, and owner-aware component marker/layout transforms.
These hunks account for a large contiguous portion of the pre-R02 diff. They are
not required by the narrow R02 combat codec or R03 exact-hotbar/arc changes, even
though the validated monolith contains them and the P10 candidate uses the
resulting owner graph.

### P09 timed tool-quality and crafting interaction authority

The preserved preimage adds exact selected tool-lot capture, authored work-action
compatibility, timed work commit/revision checks, owner-specific crafting station
placement, physical-station preflight, pending-output collection priority,
owner/binding-aware recipe-picker actions, exact-job cancellation, and durable
completion/refund receipt settlement. These are the P09/P10 crafting interaction
hunks visible from `_selected_work_tool_lot`, `_work_tool_item_is_compatible`,
`_ensure_crafting_stations_for_owner`, `_physical_crafting_station_preflight`,
and the expanded recipe-picker request methods.

These playable-file hunks were present in every R02/R03 run and therefore
influence the accepted full source hash, but they remain outside the R02/R03
implementation deltas and outside the separate 17-file supplemental diff.

### P17/structural navigation and per-owner projection changes

The preimage also threads explicit ship owners through component/world-position
projection, module-integrity scene application, structural floor selection, and
integrity navigation-gap refresh. The companion working tree contains the larger
`ShipNavGraph` structural projection/path-classification work. R02 threat
persistence uses only the established navigation interfaces; the P17 additions
are not an R02/R03 implementation delta.

The current monolith nevertheless shares owner/projection call sites with these
families. Removing selected navigation or owner arguments from the playable file
would require a newly designed and retested composition rather than a clean
subtraction of R02/R03.

## Why a selective runtime commit is unsafe now

There are three possible source compositions:

1. **Stage the whole current playable and six persistence files.** This preserves
   the exact source validated by R02/R03, but implicitly commits their unreviewed
   preexisting P09/P13/P17 families. This concern does not apply to the separately
   reviewed 17-file companion closure.
2. **Stage only the accepted R02/R03 hunks against HEAD.** Those hunks were authored
   against the preserved pre-R02 P10/WIP APIs and context. HEAD lacks several
   required methods, signatures, and the untracked `ShipWorkContext`; the result
   is incomplete or behaviorally incompatible.
3. **Remove unrelated families while retaining P10/R02/R03.** The families are
   interleaved in `playable_generated_ship.gd` and share owner, component, station,
   navigation, capture, and restore paths. Such a rewrite may be possible as a
   future refactor, but it would have a new source hash and no R02/R03 validation
   evidence. It is synthetic untested source and cannot inherit either approval.

The current accepted source should therefore remain pinned and unchanged. A later
whole-file review of the remaining seven files can approve exactly what was
tested, or R04/R06 can supply the missing family-level review as their scopes
converge on these owners. Any code change made to split the monolith must be
treated as new implementation with new affected validation and source manifests.

## Files intentionally not promoted by this boundary

This audit does not make unrelated modified navigation, work-action, pillar, or
gameplay-data files part of R02/R03 merely because they are reachable transitively.
In particular, the current `ship_nav_graph.gd` P17 additions,
`work_action_driver.gd`/`pillar_persistence.gd` P09 changes, and modified component,
item, loot, quality, and recipe catalogs remain outside the R02/R03 commit claim.
Relevant later reviews may include them on their own authority.

No source or index state was changed and no validation was rerun for this audit.
