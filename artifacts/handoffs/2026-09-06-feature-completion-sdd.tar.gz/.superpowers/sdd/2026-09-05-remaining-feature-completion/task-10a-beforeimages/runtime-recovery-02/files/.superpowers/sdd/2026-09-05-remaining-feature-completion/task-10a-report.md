# Task 10A / R10-A governance checkpoint report

Date: 2026-09-06 (America/New_York)  
Workspace: `D:\the-synaptic-sea-feature-completion`  
Branch / base: `codex/feature-completion` / `c51bcacbcb5557fd54ccf5a3e2775f0e35c61bad`  
Status: governance accepted and run7/world7 allocated; runtime waits accepted R06 re-review handoff

## Outcome

R10 is split into a baseline prerequisite and the existing candidate-result
safety integration. R10-A now precedes the R04 natural-route runtime and R09
live-scene acceptance. R10-B retains full rebuild egress/support work and remains
required for `FC P17 PASS`.

The source-backed P17 card, feature spec, original/remaining plans and accepted
ADR amendments agree on these contracts:

- All production home, native, fallback and fixed-lifeboat layouts precompile
  exact `boarding_endpoints_v1` rows from real occupancy and explicit one-sided
  exterior portals. A port is accepted only on a supporting exterior plane with
  every non-join shape inward and clearance outward. Only separately
  authenticated bounded join-box portions may cross that plane. The fixed lifeboat's
  west airlock/engine seam is forbidden; no diagnostic coordinate is frozen.
- Dock pose comes only from opposing authenticated descriptors. Actual wrapper
  evidence rules out a universal zero-overlap constraint: the open frame uses
  0.2 m-deep boxes and the floor reaches the cell edge. Only authenticated open-
  frame/directly-incident-floor join boxes may intersect, and their exact
  intersection must be contained in a finite envelope derived by clipping those
  contract-selected wrapper boxes to both outward half-spaces. Walls, ceilings,
  opaque portals, interiors, unrelated floors and dynamics never qualify; no
  epsilon/global margin is allowed. The mobile endpoint owns the threshold and
  instantiates one separate physical barrier. Full-capsule clearance is an
  independent condition. Rejection occurs before root/connection state changes.
- The docking transaction moves all established owner state coherently. Existing
  ship-local carts, floor drops, corpse drops and station positions inherit the
  root. Active/stored combat world and last-known positions receive the same
  old-root to new-root delta. Unknown world-space ownership rejects.
- `ceiling_cap_1x1` keeps its floor-origin wrapper and visual. Canonical physical
  bounds become `[-2,3.8,-2]..[2,4.0,2]`, yielding a 4x0.2x4 proxy centered at
  `(0,3.9,0)`. Transform-aware visual bounds remain separate and retain the
  decorative underside near Y 3.6875.
- The allocated `gate2-current-run-7`/`world-7` pair combines registered connection
  identity, endpoint-keyed barrier state, owner-local player pose and ADR-0042
  ephemeral hallucination removal. Runtime constants remain unchanged.
  Historical run-6/world-6 stays admitted and v5-to-v6 targets literal run-6.
  Legacy migration needs an explicit aboard owner and version-pinned old geometry;
  every ambiguity rejects recoverably.
- The accepted full-precision owner-local pose remains authoritative. An exact
  central restore receipt preserves unchanged recapture without epsilon, numeric
  rounding or a second inverse transform. Restore creates roots, connections and
  barriers before projecting the body and proving its real capsule clear.
- ADR-0017's canonical opening remains aboard the lifeboat. The fixed layout owns
  one strict lifeboat-local initial spawn, distinct from the threshold/clearance
  points. New Game applies it once after corrected pair/barrier construction and
  publishes only when the capsule is clear, occupancy identifies the lifeboat,
  and the closed barrier excludes home. It is never a load/migration fallback.
- Run 7 removes `RunSnapshot.player_position` without adding another run-pose
  field. World 7's `player_owner_pose_v1` is the sole current player-pose
  authority. At-home world-6 migration requires exact embedded/top-level
  position equality and uses explicit `aboard_ship_id`; away migration validates
  and discards the finite obsolete home-departure value without inferring
  `ship_start` or rejecting solely for its missing owner.

## Run-6/world-6 player-position source trace

`RunSnapshot.player_position` is an ownerless raw global coordinate. The producer
copies `player.global_position` in
`scripts/procgen/playable_generated_ship.gd:12858-12876`; the model reads the
three numeric values without an owner in `scripts/systems/run_snapshot.gd:288-291`;
and the run applier writes them directly back to `player.global_position` in
`scripts/procgen/playable_generated_ship.gd:13591-13598`.

Production user saves are coherent world envelopes. The live menu receives
`_build_world_snapshot` at `playable_generated_ship.gd:9155-9159`; objective
autosave, rotating autosave, quicksave and manual save build a WorldSnapshot at
`:13048-13064`, `:13077-13099`, `:13172-13197`, and `:13207-13231`.
`SaveLoadService.save_to_slot` normalizes every accepted write to a world
envelope at `scripts/systems/save_load_service.gd:783-826,830-906`. The
`save_current_run` entry point at `:130-136` is a legacy alias; when handed a
RunSnapshot it wraps it into a closed world, copies the run coordinate to the
top-level position and sets `aboard_ship_id="ship_start"` at `:464-489`. A raw
standalone current run-6 payload is already rejected as `unclosed_owner_graph`
at `:193-207`; only recognized older run schemas reach the historical adapter.
Because that branch currently compares against `CURRENT_SLICE_VERSION`, the
run7 change must add an explicit run-6 literal rejection before older-run
adaptation; advancing the constant alone would accidentally admit run6.

World capture has two embedded-home cases. At home, the embedded run retains the
same live global coordinate later copied to top-level world position, and the
world stores explicit `aboard_ship_id` at
`playable_generated_ship.gd:13684-13735`. Away from home, the builder overwrites
the embedded run coordinate with `_home_player_position` at `:13703-13707`.
That value was captured at departure at `:8819-8823`, after travel recomputed
occupancy and required `current_occupancy == piloted_ship` at `:8729-8747`.
Consequently the field role cannot prove occupied owner `ship_start`; a normal
lifeboat departure proves the player occupied the piloted lifeboat.

The away-world loader copies that embedded coordinate back into
`_home_player_position` before applying the home run at `:13983-13994`.
Phase-5b `travel_home` instead preserves the current mobile-local carry and never
reads `_home_player_position` (`:8875-8965`). The regression itself records that
the old exact home-position behavior was superseded in
`scripts/validation/world_save_anywhere_smoke.gd:140-146`. Repository search
finds no other runtime reader. The away embedded value is therefore validated
legacy residue, not a second current pose or a reason to reject an otherwise
provable world migration.

The migration admission matrix is therefore:

| Source | R10-A result |
|---|---|
| Raw `gate2-current-run-6` | Reject `unclosed_owner_graph` by an explicit literal branch before older-run adaptation, even after the current constant becomes run7. |
| Recognized pre-v6 direct run | Retain only the existing strict closed-world adapter preconditions. |
| `world-6`, `current_location == ""` | Require finite exact embedded/top-level position equality and explicit `aboard_ship_id`; migrate one pose, discard the embedded duplicate. |
| `world-6`, `current_location != ""` | Require a finite embedded legacy coordinate, discard it as obsolete, and migrate only the top-level pose through explicit `aboard_ship_id`. |

## Governance and provenance

The initial beforeimage manifest contains 66 paths, including absent planned
files. After R06 reported canonical P10-P13, 12 focused Godot and 36 Python checks
green but before independent review, a second 56-path runtime/test manifest
captured the then-current WIP. Both are historical provenance. R06 review has
three HIGH fixes underway, so runtime implementation requires a new additive
post-fix manifest after root accepts the R06 re-review handoff.

The requirements source was deliberately unchanged at SHA-256
`ddcfa8934eae874901edc4313072b5d875b763c0ddb9d7521e1faa79212b462c`.
Frozen acceptance remains 668 recorded, 657 active, 11 deferred and 622 distinct
active criteria. R10-A adds rationale and acceptance detail under existing
FC-18/FC-19; it creates no requirement row and changes no completion evidence.

Governance files changed or created:

- `task-10a-brief.md`, `task-10a-report.md`, and both task beforeimage manifests;
- the remaining-feature plan and original P17/P19 plan;
- ADR-0017's accepted opening amendment, ADR-0059's accepted decisions 44-49,
  and ADR-0065's accepted section-4 amendment;
- the crafting/derelict feature spec;
- `tools/build_feature_acceptance.py` and its generated card/register JSON.

No GDScript, scene, catalog, canonical asset, save fixture, runtime version,
Godot project/import state or global configuration was edited by this task.

## Verification

- Python source compile: pass for `tools/build_feature_acceptance.py`.
- Source generator write/check: `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0`.
- Frozen accounting: 668 / 657 / 11 / 622.
- Requirements hash: unchanged against the initial beforeimage.
- Focused governance diff check: no whitespace errors.
- P11-P13 source constants, smoke lists, marker lookup and verification branches
  were not edited; R06's reported-green pre-review generated deltas remain
  present while its review fixes proceed.

Godot and gameplay Python tests were intentionally not run because this
checkpoint contains governance and beforeimages only. The generated P17 card now
contains the future tracked command
`tools/run_r10a_docking_smokes.py` with marker
`R10-A DOCKING PREREQUISITE PASS`; that runner is planned missing and cannot be
used until implementation.

## Version allocation and runtime entry conditions

1. Governance allocates `gate2-current-run-7` and `world-7` as one production
   pair. R06/P10 still uses those literals as strict future-rejection sentinels
   in generated governance, `combat_persistence_smoke.gd`, and two fixtures.
   During implementation, retain those old artifacts as historical evidence,
   move the active sentinel/fixtures to `gate2-current-run-8`/`world-8`, then
   make run7/world7 current. No runtime constant or fixture changed here.
2. Wait for R06's independent review and any accepted shared-owner fixes, then
   capture a new additive post-fix accepted-handoff manifest before editing any
   shared path; preserve both historical manifests and all inherited WIP.
3. Implement R10-A through the tracked hardened runner, Godot 4.7.2, fresh
   four-variable process homes and a separate accepted P10 containment probe.
   R04's unchanged natural route runs last and remains the authority for R04.

The main implementation risks are exact legacy geometry reconstruction for
world-6, full-shape hull preflight across nested/rotated roots, transactional
rebasing of world-space combat state, and ensuring the ceiling pipeline keeps
physical and visual bounds separate. Each risk has a required rejection case in
the brief's validation matrix.
