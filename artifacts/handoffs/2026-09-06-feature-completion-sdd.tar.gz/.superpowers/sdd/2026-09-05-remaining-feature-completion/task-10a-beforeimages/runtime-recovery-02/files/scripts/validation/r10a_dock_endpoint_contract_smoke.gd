extends SceneTree

const DockEndpointAuthoringScript := preload("res://scripts/procgen/dock_endpoint_authoring.gd")
const DockPortsScript := preload("res://scripts/systems/dock_ports.gd")
const LifeBoatBuilderScript := preload("res://scripts/procgen/life_boat.gd")
const ENDPOINT_KEYS := [
    "endpoint_id", "port_id", "portal_id", "type", "size_class", "room_id",
    "deck", "edge_cell", "edge_direction", "structural_edge_key",
    "target_module_id", "structural_module_id", "local_position", "outward_normal",
    "threshold_nav_node_id", "interior_nav_node_id",
    "threshold_clearance_point_local", "interior_clearance_point_local",
    "join_piece_placement_ids", "join_collision_fingerprint",
]

func _initialize() -> void:
    var lifeboat: Dictionary = LifeBoatBuilderScript.build_layout()
    if not _check_layout(lifeboat, "lifeboat"):
        return
    var spawn: Variant = lifeboat.get("initial_player_spawn_v1", null)
    if not spawn is Dictionary or (spawn as Dictionary).keys().size() != 5:
        _fail("fixed lifeboat initial spawn is missing or non-strict")
        return
    for key in ["spawn_id", "owner_ship_id", "room_id", "nav_node_id", "local_position"]:
        if not (spawn as Dictionary).has(key):
            _fail("initial spawn missing %s" % key)
            return
    if str((spawn as Dictionary).get("owner_ship_id", "")) != "lifeboat":
        _fail("initial spawn owner is not lifeboat")
        return

    var home: Variant = JSON.parse_string(FileAccess.get_file_as_string(
        "res://data/procgen/golden/coherent_ship_001/layout.json"))
    if not home is Dictionary or not _check_layout(home as Dictionary, "home"):
        return

    var lifeboat_port: Dictionary = DockPortsScript.for_lifeboat(lifeboat)
    var home_port: Dictionary = DockPortsScript.for_derelict(home as Dictionary)
    if lifeboat_port.is_empty() or home_port.is_empty():
        _fail("registered port resolution failed")
        return
    if (lifeboat_port.get("facing", Vector3.ZERO) as Vector3).dot(
            home_port.get("facing", Vector3.ZERO) as Vector3) != 0.0:
        # Local authoring directions need not oppose until alignment, but the fixed
        # lifeboat must use a different exterior edge than its internal west seam.
        _fail("fixed lifeboat still authors its internal west seam")
        return
    print("R10A DOCK ENDPOINT CONTRACT PASS")
    quit(0)

func _check_layout(layout: Dictionary, label: String) -> bool:
    var verdict: Dictionary = DockEndpointAuthoringScript.validate_layout(layout)
    if not bool(verdict.get("ok", false)):
        _fail("%s endpoint validation failed: %s" % [label, str(verdict.get("reason", ""))])
        return false
    var endpoints: Variant = layout.get("boarding_endpoints_v1", null)
    if not endpoints is Array or (endpoints as Array).size() != 1:
        _fail("%s must have exactly one endpoint" % label)
        return false
    var endpoint: Dictionary = (endpoints as Array)[0]
    if endpoint.keys().size() != ENDPOINT_KEYS.size():
        _fail("%s endpoint is not strict" % label)
        return false
    for key in ENDPOINT_KEYS:
        if not endpoint.has(key):
            _fail("%s endpoint missing %s" % [label, key])
            return false
    if endpoint.get("threshold_clearance_point_local") == endpoint.get("interior_clearance_point_local"):
        _fail("%s clearance anchors are not distinct" % label)
        return false
    return true

func _fail(reason: String) -> void:
    push_error("R10A DOCK ENDPOINT CONTRACT FAIL reason=%s" % reason)
    quit(1)
