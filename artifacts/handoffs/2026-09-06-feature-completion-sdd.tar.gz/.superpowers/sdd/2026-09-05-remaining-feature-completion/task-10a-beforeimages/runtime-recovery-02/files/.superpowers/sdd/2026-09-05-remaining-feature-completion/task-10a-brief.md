# Task 10A / R10-A baseline physical-docking prerequisite brief

Date: 2026-09-06 (America/New_York)  
Workspace: `D:\the-synaptic-sea-feature-completion`  
Branch: `codex/feature-completion`  
Status: governance accepted and run7/world7 allocated; runtime waits accepted R06 re-review handoff

## Purpose and dependency correction

The ordinary Title-to-starter route is blocked before R04 can prove natural
acquisition. Fresh all-slide evidence shows that the home and fixed lifeboat are
docked through room-derived points that place structural collision across the
walkable route. The same trace found a stale floor-level ceiling proxy. R10's
original ordering after R09 therefore cannot stand: baseline docking and ceiling
traversal are prerequisites for the R04 natural route and for trustworthy R09
live-scene blocker binding.

Split remaining Task 10 without creating a new acceptance row:

- **R10-A** restores baseline physical docking, registered production endpoints,
  the ceiling collision contract, safe save semantics, and ordinary two-way seam
  traversal. It precedes R04's runtime route and R09's runtime acceptance.
- **R10-B** retains the existing candidate-result docking, egress, floor/ramp and
  structural-support preflight. It follows R09 and consumes R10-A's registered
  endpoint authority.

R10-A remains inside P17/FC-19 and is a prerequisite slice only. It cannot emit
`FC P17 PASS`, close R10-B, claim all live rebuild blockers, or accept R04's
starter/donor/advanced routes. R04's independent two-file economy package and
read-only source preparation may proceed.

The frozen program remains 668 source rows, 657 active rows, 11 explicit
deferrals, and 622 distinct active criteria. No requirement identity, disposition,
or product-completion percentage changes in this checkpoint.

## Established RED evidence

`r04-traversal-diagnosis.md` is the source report. Its final natural run
`P09-R04-natural-20260906T043302Z` exited 1 as expected, emitted no pass marker,
had no diagnostics, and retained contained process-home evidence. The player
started at the home seam and stopped against the fixed lifeboat's floor-level
`ceiling_cap_1x1` proxy. Disabling every lifeboat static collision then exposed a
home structural wall at the same route. No geometry, collision mask, spawn,
portal, or survival source was changed by that diagnosis.

The current implementation is insufficient in four independently material ways:

1. `DockPorts.for_derelict()` selects a dock/airlock room center and does not bind
   a compiled exterior aperture.
2. `DockingManager` retains position/facing dictionaries rather than one stable
   registered connection with both endpoint identities.
3. `DockPortBarrier` is an interaction sensor; closed state is enforced through
   occupancy filtering rather than a physical seam blocker.
4. `world-6` serializes host/mobile/type/slot and a globally captured value named
   `player_position_in_ship`; corrected docking geometry cannot safely reinterpret
   either value.

## Authored endpoint contract

Add one pure `DockEndpointAuthoring` policy before structural compilation. It
receives solved occupancy plus an immutable normalized collision catalog produced
from contract-selected canonical wrapper trees; it never loads a Node or reads
the scene tree. It is called by fixed-lifeboat construction, fallback layout
generation, native layout postprocessing, and the golden-home regeneration path.
The live loader validates and binds its result; it never invents a port from a
room role, name prefix, centroid, nearest edge, or `HALF_CELL` offset.

Each production layout contains a strict `boarding_endpoints_v1` array. Each row
has exactly these authority fields:

```text
endpoint_id, port_id, portal_id, type, size_class,
room_id, deck, edge_cell, edge_direction, structural_edge_key,
target_module_id, structural_module_id,
local_position, outward_normal,
threshold_nav_node_id, interior_nav_node_id,
threshold_clearance_point_local, interior_clearance_point_local,
join_piece_placement_ids, join_collision_fingerprint
```

The authoring policy chooses only an edge whose owner cell belongs to the exact
dock/airlock room and whose outward adjacent cell is unoccupied. The edge receives
an explicit exterior portal row with `exterior=true`, an empty exterior room,
the same `portal_id`, and `doorway_frame_open_1x1`. The structural compiler must
accept this explicit one-sided portal form, preserve its portal ID, and emit the
declared edge/module identity. It must continue rejecting a one-sided ordinary
portal without the exterior discriminator.

The compiler/loader validation requires one-to-one agreement among endpoint,
portal, structural edge and wrapper. Duplicate IDs, duplicate edge ownership,
solid edges, non-exterior edges, wrong modules, missing wrappers, mismatched
positions or normals, and ambiguous mappings fail the document. The threshold
and interior navigation IDs resolve distinct authored nodes. Their clearance
points are finite, separated by at least the traversal capsule diameter, and
continuously clear into the room network.

The endpoint authorizer uses solved layout occupancy and a deterministic stable
ordering. It prefers a real `dock` role and otherwise a real `airlock` role,
selects only empty exterior neighbors, and accepts only a supporting exterior
plane: every non-join collision shape of the complete owning hull remains in
the inward half-space while the threshold/clearance envelope is outside. Only
the separately authenticated portions of the endpoint's named join boxes may
cross that plane, bounded by the exact half-space clips that construct the seam
envelope. This
excludes concave exterior edges that would still place another room through the
mated hull. The endpoint points outward from that plane and
breaks equal geometric candidates by documented room/deck/cell/direction ordering.
The same helper and input document must produce byte-equivalent endpoint identity
for native and fallback paths. A layout without one valid candidate fails; it
does not receive a center fallback.

The coherent-home fixture must convert west exterior edge `0|v|0|-1` at local
`(-2,0,0)` from `wall_straight_1x1` to the registered exterior aperture. The
fixed lifeboat's endpoint is derived from its actual occupancy. Its airlock west
edge is shared with `engine_bay_01`, so `(-2,0,0)` is not accepted as a lifeboat
exterior merely because the old `DockPorts` method returned it. The exact mobile
edge and resulting root transform are frozen only after the authorizer proves an
unoccupied exterior neighbor and the non-overlap test passes.

`DockPorts` becomes a strict resolver over registered rows. A live descriptor
adds the bound `ship_id`, current condition/usable state, and world transform, but
cannot change stable local identity. `DockingManager` accepts only authenticated
descriptors and stores one connection record:

```text
connection_id, port_type, slot_index,
host {ship_id, endpoint_id, port_id},
mobile {ship_id, endpoint_id, port_id}
```

Both `parent_ship` and `docked_ships` resolve that same record. Port transforms
must be coincident with opposing normals. The two structural hull volumes must be
disjoint outside one constructed seam envelope. The envelope is not an authored
tolerance. Each endpoint's `join_piece_placement_ids` may name only its exact
open-doorway-frame placement and floor/corridor-floor placements directly incident
to its exterior edge. A wall, ceiling, blocked/solid portal, room-interior shape,
dynamic body, or unrelated floor can never become a join piece.

The live loader resolves those IDs to the exact `CollisionShape3D` boxes in the
contract-selected canonical wrappers, validates their size/local transforms and
cardinal endpoint transforms, and requires their normalized-record fingerprint to
equal the precompiled `join_collision_fingerprint`. The build-time fingerprint
comes from the contract-selected wrapper tree and stable placement IDs; it is not
calculated from the live scene and then trusted against itself.
Current evidence explains why logical-cell or nominal-bounds tests are
insufficient: `doorway_frame_open_1x1.tscn` has two 1.4x3.2x0.2 posts and one
4x1x0.2 header centered on the edge plane, while `floor_1x1.tscn` has a
4x0.25x4 box centered on the floor origin. Existing Blender proxy sidecars do not
match these runtime shapes and cannot authorize overlap.

In threshold coordinates (tangent, up, outward), the constructor clips each
authenticated join box to the outward half-space and takes the exact AABB union
of those clipped pieces on both mated sides. Cardinal transforms make those
bounds exact; a non-box or non-cardinal join shape is unsupported. This produces
a finite contract/wrapper-derived slab (0.1 m per side for the current doorway
frame), rather than a global overlap margin. Every cross-ship shape pair is then
tested: pairs involving a non-join shape reject on any intersection; two join
shapes may intersect only when their exact box-intersection AABB is wholly inside
that seam envelope. Empty/zero-volume plane contact is allowed. The mobile
threshold owner instantiates the separate closed-state barrier exactly once.
Finally, a full player capsule must sweep continuously from each interior point
through the open aperture to the other; seam classification never substitutes
for passage clearance. A disallowed overlap, same-direction normal, missing
identity, stale fingerprint, or uncleared capsule denies docking before moving
the mobile root.

The same pre-mutation transaction inventories established mobile-owned spatial
state. Ship-local carts, floor drops, corpse drops and station positions inherit
the moved root unchanged. Active/stored combat currently uses world-space threat
and last-known positions, so those points receive the exact old-root to new-root
delta together with the moved scene/root, or docking rejects before any state
changes. The player uses the explicit owner-local carry path. No mobile
world-space state may be left at its old anchor.

## Physical seam and ownership

The registered aperture is structural. Closed barrier state also owns an actual
collision blocker sized to the aperture and synchronized with the interaction
state. Opening removes/disables that blocker only after the existing intact or
timed-breach transaction succeeds; closing reinstates it after the seam is clear.
Occupancy filtering remains a second policy check, not the only barrier.

Ordinary `PlayerController.move_and_slide` must cross the open seam in both
directions without a teleport, collision-layer toggle, floor lowering, or direct
position assignment. A closed barrier blocks the capsule physically and prevents
host boarding. With the barrier open, occupancy changes only after the capsule
clears the registered threshold. At the exact shared threshold, the connection's
mobile side owns containment, preserving ADR-0017's piloted-mobile tiebreak.

Endpoint-local threshold and interior clearance points drive barrier placement,
occupancy boundary tests, P17 candidate navigation, and persistence validation.
These consumers may not derive different samples from room centers.

The canonical opening remains "aboard your ride": the fixed lifeboat layout owns
one strict `initial_player_spawn_v1` row with exactly `spawn_id`,
`owner_ship_id`, `room_id`, `nav_node_id`, and `local_position`. It names the
lifeboat and resolves to a capsule-clear interior point distinct from the
threshold and both clearance anchors. New Game constructs and validates the
corrected ship pair and closed home barrier first, resolves this local point
through the lifeboat root, places the player once, and only then publishes
occupancy. The result must be lifeboat ownership while the closed barrier denies
home ownership. Failure aborts New Game publication. The row is never available
to save/load, migration, load recovery, room-center fallback, clamping, or a
later teleport path.

## Ceiling collision correction

The compiler, `GeneratedShipLoader`, and `LifeBoat` already agree that every
ceiling wrapper root sits at the floor-cell origin. The promoted GLB embeds its
load-bearing slab at local Y 3.8 through 4.0, centered at 3.9. Its complete
transform-aware visual bounds extend to about Y 3.6875 because of decorative
underside details. The stale wrapper instead has a 1 m cube centered at the floor.

Keep the compiler, both instancing paths, and the promoted visual transform.
Correct the canonical ceiling collision bounds to `[-2,3.8,-2]` through
`[2,4.0,2]`, then regenerate the wrapper proxy as a `BoxShape3D(4,0.2,4)` centered
at `(0,3.9,0)`. Regenerate the JSON/TRES contract pair, `.input.json`,
`.manifest.json`, and `ship_structural_v0` kit projection from the same authority.
Do not hand-edit derivative proxy data.

Physical proxy bounds and full visual bounds are separate facts. If the current
metadata schema requires one bounds value to describe both, split the schema
before updating the ceiling rather than widening the collision proxy over the
decorative detail or truncating the transformed visual extent. Extend GLB
metadata inspection to apply node transforms, and extend wrapper validation to
compare collision shape size and local center with canonical physical bounds.
`nav_blocker=false` does not disable collision.

## Allocated paired run-7/world-7 transition

Governance allocates `gate2-current-run-7` and `world-7` as one production pair.
R06/P10 currently uses those literals as strict future-rejection sentinels in
generated governance, combat persistence smoke and fixtures. The coordinated
runtime change must preserve those artifacts as historical evidence, move the
active future sentinel to `gate2-current-run-8`/`world-8`, and only then make the
allocated pair current. No runtime constant or fixture changes in this
governance checkpoint.

Run 7 follows ADR-0042: remove `hallucination_summary` from the snapshot model,
field count, capture and restore. Current run-7 input forbids the key even when
its value is `{}`. The detached v6-to-v7 migration strictly validates every
present historical hallucination envelope before erasing it; malformed legacy
content rejects. A missing v6 key remains recognized because v6 historically
accepted that omission. Restore performs the late clean-episode/projection reset
specified in `r17-hallucination-save-remediation-design.md`; exact staged
recapture retains ADR-0059's oxygen flag as its sole comparison exception.

Run 7 removes and forbids global `RunSnapshot.player_position` without adding a
replacement run-pose field. World 7 is the sole current player-pose authority.
It removes the ambiguous legacy keys `dock_edges` and
`player_position_in_ship`, replaces marker-only `opened_ports` with exact
endpoint state, and owns strict `player_owner_pose_v1`. Current input containing
any legacy key rejects. World requires:

```json
{
  "dock_connections_v1": [
    {
      "connection_id": "...",
      "port_type": "airlock",
      "slot_index": -1,
      "host": {"ship_id": "...", "endpoint_id": "...", "port_id": "..."},
      "mobile": {"ship_id": "...", "endpoint_id": "...", "port_id": "..."}
    }
  ],
  "player_owner_pose_v1": {
    "owner_ship_id": "...",
    "location_kind": "interior",
    "local_position": [0.0, 0.0, 0.0],
    "connection_id": "",
    "endpoint_id": ""
  },
  "boarding_port_states_v1": [
    {"ship_id": "...", "endpoint_id": "...", "barrier_open": false}
  ],
  "aboard_ship_id": "..."
}
```

`location_kind` is exactly `interior` or `dock_threshold`. Interior records have
empty connection/endpoint IDs. Threshold records name one live connection and
the endpoint on its mobile side; `owner_ship_id` is that mobile ship. In all
cases `owner_ship_id == aboard_ship_id`. Numeric coordinates are finite and
booleans/strings do not coerce. Current rows require exact keys and reject unknown,
duplicate, missing, foreign-owner or mixed old/new shapes.

Every active registered endpoint has exactly one strict port-state row. The
Boolean `barrier_open` state owns the real physical/occupancy blocker. World-6
`opened_ports` marker IDs migrate only when each marker resolves uniquely to its
version-pinned old barrier and one new endpoint; an unmatched or ambiguous open
marker rejects. Closed endpoints are explicit `false`, so omission cannot reopen
or reseal a connection by default.

Capture converts the player's global transform through the explicit occupied
owner root. It never selects the nearest ship. Restore regenerates owners,
resolves all registered endpoints, re-establishes every connection, restores
barrier/open state, then transforms the owner-local point to world. Before
publication it proves the full traversal capsule is clear in the corrected live
scene and that threshold ownership matches the named connection. Failure rejects
the complete candidate without clamping, center snapping, fallback spawn,
teleport, source mutation, index mutation, or partial live publication.

Owner-local pose is serialized as full-precision numeric data. Restore keeps the
accepted local array as the authoritative pose and records an ephemeral central
restore receipt containing the exact owner/root revision and exact projected
global body position. An unchanged capture reuses that accepted local array only
when all receipt values and the body position are bit-exact; after any movement
or owner/root revision, capture computes one new local pose and makes that value
the next authority. This is part of the central save transaction, not another
gameplay owner or a comparison exception. Rotated and far-away root tests must
prove two unchanged recaptures remain exactly equal without epsilon or numeric
rounding rules.

### Recognized run-6/world-6 migration

Preserve `world-6`/run-6 as a historical pair. When a world-5 payload is chained,
the existing world-5-to-world-6 helper must target literal
`gate2-current-run-6`; it must not follow a changed current constant directly to
run 7. Only the next explicit world-6-to-world-7 step may invoke run-7 migration.

Run-6/world-6 migration first validates the complete old pair, old dock rows and
every global player position on a detached copy. A raw standalone current run-6
payload retains the existing recoverable `unclosed_owner_graph` rejection;
recognized older direct-run adapters retain only their current strict historical
preconditions. Because the current loader's branch compares the source literal
to `CURRENT_SLICE_VERSION`, the run7 implementation must add an explicit run-6
rejection before older-run adaptation; changing the constant alone would
silently broaden admission. World-6's top-level pose uses its nonempty
`aboard_ship_id`. When
`current_location` is empty, embedded `home_ship.player_position` must exactly
equal top-level `player_position_in_ship`; migrate that value once through the
explicit aboard owner and discard the embedded duplicate. When
`current_location` is nonempty, strictly validate the embedded home-departure
coordinates as finite obsolete data and discard them without inferring
`ship_start` or rejecting solely for absent ownership. A
version-pinned legacy geometry resolver reconstructs the exact old owner transform
graph from shipped historical home/lifeboat layouts, persisted generation context,
host/mobile relations and hangar slots. It may not call the corrected current
endpoint resolver. Every old host/mobile row must map uniquely to one new
registered endpoint pair. The named aboard owner must resolve exactly once in the
old graph. Missing owners, active-mobile ambiguity, cycles, unsupported custom
layouts, missing generation context, multiple candidate ports, or a transform
that cannot be proven reject with a stable recoverable reason.

The migration also audits every existing spatial payload owned by any root whose
dock transform changes. Carts, floor drops, corpse drops and physical station
positions are already explicitly ship-local and remain byte-identical. Existing
visited-ship combat rows instead contain `world_position` and optional
`last_known_position`; each finite nonempty point is transformed through that
same version-pinned old root into the corrected owner root before the new
candidate is sealed. The obsolete home-departure duplicate has no new pose
projection; home combat remains in the unchanged home frame. Any other
present world-space field, missing owner, or
unprovable frame rejects. R10-A does not invent a parallel owner model for data
that is already ship-local.

After proving the old transform, migration computes
`owner_local = old_owner_global.affine_inverse() * legacy_global_position` once
with full-precision engine numerics and makes that exact result authoritative.
The restore receipt above preserves it across unchanged staged recapture without
an epsilon or a second inverse-transform round trip. It then emits the new
connection, endpoint-state and sole world-pose fields, erases the legacy fields,
migrates the home run to run 7, and stamps
world 7. The later staged restore must additionally prove
that this same local capsule is clear under corrected geometry. A recognized
document can therefore still reject safely when the old pose was inside geometry
that moved; migration never invents a replacement point.

Source dictionaries and bytes, slot index, backup/sidecars, and live world remain
unchanged on every rejection.

## Planned implementation ownership and beforeimages

The initial 66-path disk-byte manifest is
`task-10a-beforeimages/manifest.json`. It captures governance sources and the
provisional runtime/validation surface at HEAD `c51bcacb`. After R06 reported its
canonical P10-P13, 12 focused Godot and 36 Python checks green but before
independent review, the 56-path additive runtime/test manifest
`task-10a-beforeimages/runtime-after-r06-manifest.json` captured the resulting
shared-owner bytes. Both manifests remain historical provenance. R06 review has
three HIGH fixes underway, so neither manifest is an accepted implementation
base. R10-A requires a new additive post-fix manifest after the coordinator
accepts the R06 re-review handoff and before it edits any shared path.

Expected endpoint/docking source scope is the new authorizer, compiler/validator,
fallback/native generators, fixed lifeboat, generated loader, coherent-home
golden, strict port resolver, docking manager, ship instance, physical barrier,
navigation graph, and narrow coordinator seams. The save transition additionally
touches the existing snapshot/migration/candidate owners and hallucination
capture/reset seams under the coordinated P10/R17 boundary.

The ceiling package is limited to the canonical contract JSON/TRES, generated
wrapper/input/manifest/kit projection, wrapper and transformed-GLB validators,
their meaningful tests, and the existing recipe as an asserted source. The
promoted GLB, compiler and loader transforms are not replacement targets.

Root owns the Git index and commit. No editor/import/plugin process, default user
profile, native binary edit, global configuration, cleanup, or unrelated catalog
change is authorized.

## Validation matrix before implementation

All Godot execution uses 4.7.2 and the hardened tracked runner. Each body receives
a fresh runner-owned `APPDATA`, `LOCALAPPDATA`, `GODOT_USER_PATH`, and
`XDG_DATA_HOME`, plus a separate accepted P10 user-data probe. The new runner and
its own tests are tracked production tooling; plan-local scripts are not durable
command targets.

1. **Endpoint authoring:** exact schema, stable IDs, one exterior portal/edge,
   outward normal, wrapper/module agreement, distinct clearance anchors, native /
   fallback / fixed lifeboat / coherent-home coverage; reject room centers,
   occupied neighbors, solid edges, duplicates and ambiguity.
2. **Dock math and hulls:** transformed endpoints coincide with opposing normals;
   broad-phase bounds followed by authoritative collision-shape queries reject
   every cross-ship overlap except an exact join-box intersection contained in
   the wrapper-derived seam envelope. Prove the current 0.2 m doorway depth,
   floor/frame contact, duplicate frame join, non-join/opaque overlap rejection,
   cardinal transform requirement and independent full-capsule clearance. Include
   rotated and moved hosts plus exact rebasing of live/stored mobile combat positions.
3. **Ceiling:** recipe slab and physical bounds agree at Y 3.8..4.0; transformed
   GLB visual bounds retain underside detail; wrapper size/center matches contract;
   both loader paths place the root at floor origin and capsules clear every cap.
4. **Barrier and traversal:** closed barrier physically blocks and denies boarding;
   ordinary input opens/breaches it; open seam crosses both directions; occupancy
   changes past the threshold; exact threshold belongs to the mobile side. Include
   center and capsule-clearance boundary cases.
5. **Travel and fresh spawn:** Title fresh boot, away travel, host/mobile
   rotation, return home, and repeated undock/redock use registered identities.
   New Game proves the authored lifeboat-local initial point capsule-clear after
   pair/barrier construction, places once, publishes occupancy as lifeboat, and
   rejects wrong owner/barrier/threshold or fallback coordinates.
6. **Current persistence:** run-7 hallucination and global `player_position` key
   presence rejects; world-7 legacy key presence rejects; exact connection IDs, endpoint barrier rows and
   interior/threshold pose round-trip; rotated/far roots preserve an unchanged
   authoritative local array across two recaptures bit-for-bit without epsilon;
   save/reload on both sides and at the threshold remains capsule-clear.
7. **Legacy migration:** raw current run-6 retains `unclosed_owner_graph` after
   the current-version constant advances; prove it cannot fall through the
   older-run adapter. The supported-run matrix admits only recognized pre-v6
   direct runs under their existing strict closed-world preconditions.
   world-6 home saves require exact embedded/top-level equality and migrate only
   the top-level pose; away saves validate and discard the finite obsolete
   home-departure value. Also cover chained v5, literal v5-to-v6 target, strict
   hallucination-envelope removal, unique old-transform conversion, missing
   top-level owner, unequal at-home duplicate, ambiguous edge, unsupported
   layout, bad transform, mixed version,
   nonfinite pose and post-redock obstruction reject with bytes/index/live state
   unchanged. Moved-owner combat world/last-known points follow the proven root
   delta, while established local carts/drops/corpses/stations remain exact; an
   unknown world-space field rejects.
8. **Regression:** existing docking manager/ports, boot alignment, occupancy,
   player carry, physical travel, docking persistence, migration, snapshot,
   hallucination pure-model and relevant procgen golden/native parity checks.
9. **Dependency proof:** rerun the unchanged R04 natural route last. It may advance
   to its next real gameplay blocker; only its own full route can accept R04.

Every positive case requires exit 0, its exact marker once, no unexpected
diagnostic, no timeout/cleanup failure and retained raw output. Every negative
requires its exact denial, unchanged protected state, and absence of the success
effect/marker. R10-A receives independent consequential review before root stages
or commits its eventual runtime slice.
