extends RefCounted
class_name DockingManager

const DockEndpointAuthoringScript := preload("res://scripts/procgen/dock_endpoint_authoring.gd")
const DEFAULT_KIT_PATH: String = "res://data/kits/ship_structural_v0.json"

## Pure docking math + relationship bookkeeping. Aligns a mobile ship's dock
## port to a host ship's dock port (coincident position, opposing facing,
## yaw-only) and writes the parent/child fields already declared on ShipInstance.
## No scene-tree ownership: callers own add_child/remove_child of ship_roots.
##
## PORT-SPACE CONTRACT (important for the 5b integration):
##   - host_port is WORLD-space (the host is already placed in the world).
##   - mobile_port is MOBILE-LOCAL (relative to the mobile ship's own root); dock()
##     computes the mobile root's transform that brings it onto the host port.
## DockPorts.for_*() return SHIP-LOCAL descriptors. A caller docking a real, non-origin
## host must therefore lift the host's local port to world FIRST, e.g.
##   var hx := host_inst.scene_root.global_transform
##   var host_world := {"position": hx * local.position,
##                      "facing": (hx.basis * local.facing).normalized()}
## (host_inst.scene_root must be in the scene tree for global_transform to be valid).
## dock() deliberately stays scene-tree-free so it is pure/unit-testable; the lift is the
## integration layer's job. Passing a local host port for a non-origin host mis-places the
## mobile — that is a contract violation, not a dock() bug.

## Yaw (radians) that rotates `from` onto `to` in the X-Z plane.
static func _yaw_between(from: Vector3, to: Vector3) -> float:
	var a := atan2(from.x, from.z)
	var b := atan2(to.x, to.z)
	return b - a

static func compute_mobile_transform(host_port: Dictionary, mobile_port: Dictionary) -> Transform3D:
	var host_pos: Vector3 = host_port.get("position", Vector3.ZERO)
	var host_facing: Vector3 = (host_port.get("facing", Vector3.FORWARD) as Vector3).normalized()
	var local_pos: Vector3 = mobile_port.get("position", Vector3.ZERO)
	var local_facing: Vector3 = (mobile_port.get("facing", Vector3.FORWARD) as Vector3).normalized()
	# Rotate the mobile so its local port facing becomes the OPPOSITE of the host facing.
	var target_facing: Vector3 = -host_facing
	var yaw: float = _yaw_between(local_facing, target_facing)
	var basis := _exact_cardinal_basis(local_facing, target_facing)
	# Translate so the (rotated) local port position lands on the host port position.
	var origin: Vector3 = host_pos - (basis * local_pos)
	return Transform3D(basis, origin)

static func _exact_cardinal_basis(from: Vector3, to: Vector3) -> Basis:
	var from_cardinal: Vector3 = _cardinal(from)
	var to_cardinal: Vector3 = _cardinal(to)
	var from_index: int = _cardinal_index(from_cardinal)
	var to_index: int = _cardinal_index(to_cardinal)
	if from_index < 0 or to_index < 0:
		return Basis(Vector3.UP, _yaw_between(from, to))
	var quarter_turns: int = posmod(to_index - from_index, 4)
	match quarter_turns:
		1:
			return Basis(Vector3(0.0, 0.0, -1.0), Vector3.UP, Vector3(1.0, 0.0, 0.0))
		2:
			return Basis(Vector3(-1.0, 0.0, 0.0), Vector3.UP, Vector3(0.0, 0.0, -1.0))
		3:
			return Basis(Vector3(0.0, 0.0, 1.0), Vector3.UP, Vector3(-1.0, 0.0, 0.0))
		_:
			return Basis.IDENTITY

static func _cardinal_index(value: Vector3) -> int:
	if value == Vector3(0.0, 0.0, 1.0):
		return 0
	if value == Vector3(1.0, 0.0, 0.0):
		return 1
	if value == Vector3(0.0, 0.0, -1.0):
		return 2
	if value == Vector3(-1.0, 0.0, 0.0):
		return 3
	return -1

static func _port_valid(p: Dictionary) -> bool:
	return p.has("position") and p.has("facing") \
		and typeof(p["position"]) == TYPE_VECTOR3 and typeof(p["facing"]) == TYPE_VECTOR3 \
		and (p["facing"] as Vector3).length() > 0.0001

static func dock(host_inst, mobile_inst, host_port: Dictionary, mobile_port: Dictionary) -> Dictionary:
	# Reject null insts and self-docking (a ship docking to itself would create a
	# self-referential parent_ship/docked_ships cycle).
	if host_inst == null or mobile_inst == null or host_inst == mobile_inst:
		return {"success": false, "reason": "dock_failed"}
	if not _port_valid(host_port) or not _port_valid(mobile_port):
		return {"success": false, "reason": "dock_failed"}
	if not ("scene_root" in mobile_inst):
		return {"success": false, "reason": "dock_failed"}
	var root = mobile_inst.scene_root
	if not is_instance_valid(root) or not (root is Node3D):
		return {"success": false, "reason": "dock_failed"}
	# Registered production endpoints are a pre-mutation transaction. Legacy
	# hand-built pure-model fixtures remain supported only when neither descriptor
	# claims a registered endpoint.
	if host_port.has("endpoint_id") or mobile_port.has("endpoint_id"):
		if not host_port.has("endpoint_id") or not mobile_port.has("endpoint_id") \
				or not ("built_layout" in host_inst) or not ("built_layout" in mobile_inst):
			return {"success": false, "reason": "dock_endpoint_missing"}
		var host_root = host_inst.scene_root
		if not is_instance_valid(host_root) or not (host_root is Node3D):
			return {"success": false, "reason": "dock_host_missing"}
		var host_transform: Transform3D = (host_root as Node3D).global_transform \
			if (host_root as Node3D).is_inside_tree() else (host_root as Node3D).transform
		var preflight: Dictionary = preflight_registered_pair(
			host_inst.built_layout, mobile_inst.built_layout,
			host_transform, host_port, mobile_port)
		if not bool(preflight.get("ok", false)):
			return {"success": false, "reason": str(preflight.get("reason", "dock_preflight_failed"))}
	# Sever any existing dock relationship first so the previous host's
	# docked_ships list does not retain a stale reference to this mobile ship.
	if mobile_inst.parent_ship != null:
		undock(mobile_inst)
	# host_port is WORLD-space per the port-space contract (see class docstring);
	# mobile_port is mobile-local. compute_mobile_transform yields the mobile root transform.
	(root as Node3D).transform = compute_mobile_transform(host_port, mobile_port)
	mobile_inst.parent_ship = host_inst
	if not host_inst.docked_ships.has(mobile_inst):
		host_inst.docked_ships.append(mobile_inst)
	mobile_inst.docking_ports = [{"host_port": host_port, "mobile_port": mobile_port}]
	return {"success": true, "reason": "ok"}

## Lifts a ship-LOCAL dock port to WORLD space via the host's placed transform.
## host_inst.scene_root must be in the scene tree for global_transform to be valid.
## Returns {} when the host has no valid in-tree scene_root or local_port is empty.
static func host_port_to_world(host_inst, local_port: Dictionary) -> Dictionary:
	if host_inst == null or local_port.is_empty():
		return {}
	if not ("scene_root" in host_inst):
		return {}
	var root = host_inst.scene_root
	if not is_instance_valid(root) or not (root is Node3D) or not (root as Node3D).is_inside_tree():
		return {}
	var x: Transform3D = (root as Node3D).global_transform
	var world_port: Dictionary = local_port.duplicate(true)
	world_port["position"] = x * (local_port.get("position", Vector3.ZERO) as Vector3)
	world_port["facing"] = (x.basis * (local_port.get("facing", Vector3.FORWARD) as Vector3)).normalized()
	return world_port


## Validates the complete registered pair before a mobile root is moved. Every
## positive-volume cross-hull collision must be between the two explicitly named
## join pieces and contained by the exact 0.2 m doorway seam slab.
static func preflight_registered_pair(
		host_layout: Dictionary, mobile_layout: Dictionary,
		host_transform: Transform3D, host_port: Dictionary,
		mobile_port: Dictionary) -> Dictionary:
	var host_verdict: Dictionary = DockEndpointAuthoringScript.validate_layout(host_layout)
	var mobile_verdict: Dictionary = DockEndpointAuthoringScript.validate_layout(mobile_layout)
	if not bool(host_verdict.get("ok", false)) or not bool(mobile_verdict.get("ok", false)):
		return {"ok": false, "reason": "invalid_registered_endpoint"}
	if str(host_port.get("endpoint_id", "")) != str((host_verdict.endpoint as Dictionary).get("endpoint_id", "")) \
			or str(mobile_port.get("endpoint_id", "")) != str((mobile_verdict.endpoint as Dictionary).get("endpoint_id", "")):
		return {"ok": false, "reason": "endpoint_identity_mismatch"}
	if not _port_valid(host_port) or not _port_valid(mobile_port):
		return {"ok": false, "reason": "invalid_port_transform"}
	var mobile_transform: Transform3D = compute_mobile_transform(host_port, mobile_port)
	var host_facing: Vector3 = _cardinal(host_port.get("facing", Vector3.ZERO) as Vector3)
	var mobile_facing: Vector3 = _cardinal(
		mobile_transform.basis * (mobile_port.get("facing", Vector3.ZERO) as Vector3))
	if host_facing == Vector3.ZERO or mobile_facing != -host_facing:
		return {"ok": false, "reason": "normals_not_opposed"}
	var host_boxes: Dictionary = _layout_collision_boxes(host_layout, host_transform)
	var mobile_boxes: Dictionary = _layout_collision_boxes(mobile_layout, mobile_transform)
	if not bool(host_boxes.get("ok", false)) or not bool(mobile_boxes.get("ok", false)):
		return {"ok": false, "reason": str(host_boxes.get("reason",
			mobile_boxes.get("reason", "unsupported_hull_collision")))}
	var seam: AABB = _seam_envelope(host_port)
	var non_join_overlap_count: int = 0
	var join_overlap_count: int = 0
	var non_join_overlaps: Array[Dictionary] = []
	for host_box_variant in host_boxes.get("boxes", []):
		var host_box: Dictionary = host_box_variant
		for mobile_box_variant in mobile_boxes.get("boxes", []):
			var mobile_box: Dictionary = mobile_box_variant
			var overlap: AABB = _positive_intersection(host_box.aabb, mobile_box.aabb)
			if overlap.size == Vector3.ZERO:
				continue
			if not bool(host_box.get("join", false)) or not bool(mobile_box.get("join", false)):
				non_join_overlap_count += 1
				non_join_overlaps.append({
					"host": "%s/%s" % [host_box.placement_id, host_box.shape_name],
					"mobile": "%s/%s" % [mobile_box.placement_id, mobile_box.shape_name],
					"intersection_position": overlap.position,
					"intersection_size": overlap.size,
				})
				continue
			if not _contains_aabb(seam, overlap):
				return {"ok": false, "reason": "join_overlap_outside_seam"}
			join_overlap_count += 1
	if non_join_overlap_count > 0:
		return {"ok": false, "reason": "non_join_hull_overlap",
			"non_join_overlap_count": non_join_overlap_count,
			"non_join_overlaps": non_join_overlaps}
	var capsule_clear: bool = _registered_capsule_path_clear(
		host_verdict.endpoint, mobile_verdict.endpoint, host_transform,
		mobile_transform, host_facing)
	if not capsule_clear:
		return {"ok": false, "reason": "open_capsule_blocked"}
	return {
		"ok": true,
		"reason": "ok",
		"mobile_transform": mobile_transform,
		"non_join_overlap_count": 0,
		"join_overlap_count": join_overlap_count,
		"open_capsule_clear": true,
		"seam_envelope": seam,
	}


static func _layout_collision_boxes(layout: Dictionary, root_transform: Transform3D) -> Dictionary:
	var endpoint: Dictionary = DockEndpointAuthoringScript.endpoint(layout)
	var join_ids: Array = endpoint.get("join_piece_placement_ids", []) as Array
	var module_paths: Dictionary = _module_scene_paths()
	if module_paths.is_empty():
		return {"ok": false, "reason": "collision_wrapper_catalog_missing"}
	var plan: Dictionary = layout.get("structural_plan", {}) as Dictionary
	var boxes: Array[Dictionary] = []
	for group in ["floor_placements", "placements", "ceiling_placements"]:
		for record_variant in plan.get(group, []):
			if not record_variant is Dictionary:
				return {"ok": false, "reason": "malformed_collision_record"}
			var record: Dictionary = record_variant
			var module_id: String = str(record.get("module_id", ""))
			if module_id.is_empty():
				continue
			var scene_path: String = str(module_paths.get(module_id, ""))
			if scene_path.is_empty() or not ResourceLoader.exists(scene_path):
				return {"ok": false, "reason": "collision_wrapper_missing"}
			var resource: Resource = ResourceLoader.load(scene_path)
			if not resource is PackedScene:
				return {"ok": false, "reason": "collision_wrapper_invalid"}
			var wrapper: Node = (resource as PackedScene).instantiate()
			var placement_id: String = str(record.get("placement_id", record.get("id", "")))
			var placement_transform := Transform3D(
				Basis(Vector3.UP, deg_to_rad(float(record.get("yaw_degrees", 0.0)))),
				_as_vector3(record.get("position", Vector3.ZERO)))
			var append_result: Dictionary = _append_collision_boxes(
				wrapper, root_transform * placement_transform, boxes,
				placement_id, join_ids.has(placement_id))
			wrapper.free()
			if not bool(append_result.get("ok", false)):
				return append_result
	return {"ok": true, "boxes": boxes}


static func _append_collision_boxes(
		node: Node, parent_transform: Transform3D, boxes: Array[Dictionary],
		placement_id: String, join_piece: bool) -> Dictionary:
	var current_transform: Transform3D = parent_transform
	if node is Node3D:
		current_transform = parent_transform * (node as Node3D).transform
	if node is CollisionShape3D and not (node as CollisionShape3D).disabled:
		var shape: Shape3D = (node as CollisionShape3D).shape
		if not shape is BoxShape3D:
			return {"ok": false, "reason": "non_box_hull_collision"}
		var size: Vector3 = (shape as BoxShape3D).size
		boxes.append({
			"placement_id": placement_id,
			"shape_name": str(node.name),
			"join": join_piece,
			"aabb": current_transform * AABB(-size * 0.5, size),
		})
	for child in node.get_children():
		var child_result: Dictionary = _append_collision_boxes(
			child, current_transform, boxes, placement_id, join_piece)
		if not bool(child_result.get("ok", false)):
			return child_result
	return {"ok": true}


static func _module_scene_paths() -> Dictionary:
	if not FileAccess.file_exists(DEFAULT_KIT_PATH):
		return {}
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(DEFAULT_KIT_PATH))
	if not parsed is Dictionary:
		return {}
	var result: Dictionary = {}
	for module_variant in (parsed as Dictionary).get("modules", []):
		if module_variant is Dictionary:
			var module: Dictionary = module_variant
			result[str(module.get("module_id", ""))] = str(module.get("godot_wrapper_scene", ""))
	return result


static func _seam_envelope(host_port: Dictionary) -> AABB:
	var center: Vector3 = host_port.get("position", Vector3.ZERO) as Vector3
	var facing: Vector3 = _cardinal(host_port.get("facing", Vector3.ZERO) as Vector3)
	center.y += 1.5375
	var size := Vector3(4.0, 3.325, 0.2)
	if absf(facing.x) > 0.5:
		size = Vector3(0.2, 3.325, 4.0)
	return AABB(center - size * 0.5, size)


static func _positive_intersection(a: AABB, b: AABB) -> AABB:
	var minimum := Vector3(maxf(a.position.x, b.position.x),
		maxf(a.position.y, b.position.y), maxf(a.position.z, b.position.z))
	var maximum := Vector3(minf(a.end.x, b.end.x),
		minf(a.end.y, b.end.y), minf(a.end.z, b.end.z))
	if maximum.x <= minimum.x or maximum.y <= minimum.y or maximum.z <= minimum.z:
		return AABB()
	return AABB(minimum, maximum - minimum)


static func _contains_aabb(outer: AABB, inner: AABB) -> bool:
	return inner.position.x >= outer.position.x and inner.position.y >= outer.position.y \
		and inner.position.z >= outer.position.z and inner.end.x <= outer.end.x \
		and inner.end.y <= outer.end.y and inner.end.z <= outer.end.z


static func _registered_capsule_path_clear(
		host_endpoint: Dictionary, mobile_endpoint: Dictionary,
		host_transform: Transform3D, mobile_transform: Transform3D,
		host_facing: Vector3) -> bool:
	var host_position: Vector3 = host_transform * _as_vector3(
		host_endpoint.get("local_position", []))
	var host_interior: Vector3 = host_transform * _as_vector3(
		host_endpoint.get("interior_clearance_point_local", []))
	var mobile_interior: Vector3 = mobile_transform * _as_vector3(
		mobile_endpoint.get("interior_clearance_point_local", []))
	return host_interior != host_position and mobile_interior != host_position \
		and (host_interior - host_position).dot(host_facing) < 0.0 \
		and (mobile_interior - host_position).dot(host_facing) > 0.0


static func _cardinal(value: Vector3) -> Vector3:
	if absf(value.x) > absf(value.z):
		return Vector3(signf(value.x), 0.0, 0.0) if value.x != 0.0 else Vector3.ZERO
	return Vector3(0.0, 0.0, signf(value.z)) if value.z != 0.0 else Vector3.ZERO


static func _as_vector3(value: Variant) -> Vector3:
	if value is Vector3:
		return value
	if value is Array and (value as Array).size() == 3:
		return Vector3(float((value as Array)[0]), float((value as Array)[1]),
			float((value as Array)[2]))
	return Vector3.INF

static func undock(mobile_inst) -> Dictionary:
	if mobile_inst == null:
		return {"success": false, "reason": "dock_failed"}
	var host = mobile_inst.parent_ship
	if host == null:
		return {"success": true, "reason": "not_docked"}
	if host.docked_ships.has(mobile_inst):
		host.docked_ships.erase(mobile_inst)
	mobile_inst.parent_ship = null
	mobile_inst.docking_ports = []
	return {"success": true, "reason": "ok"}
