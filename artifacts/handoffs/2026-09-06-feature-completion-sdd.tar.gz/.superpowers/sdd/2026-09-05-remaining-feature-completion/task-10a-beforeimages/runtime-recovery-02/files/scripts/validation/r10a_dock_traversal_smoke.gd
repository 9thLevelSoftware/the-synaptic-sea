extends SceneTree

const DockPortsScript := preload("res://scripts/systems/dock_ports.gd")
const DockingManagerScript := preload("res://scripts/systems/docking_manager.gd")
const LifeBoatBuilderScript := preload("res://scripts/procgen/life_boat.gd")
const DockPortBarrierScript := preload("res://scripts/tools/dock_port_barrier.gd")

func _initialize() -> void:
    var home: Variant = JSON.parse_string(FileAccess.get_file_as_string(
        "res://data/procgen/golden/coherent_ship_001/layout.json"))
    var lifeboat: Dictionary = LifeBoatBuilderScript.build_layout()
    if not home is Dictionary:
        _fail("home layout missing")
        return
    var host_port: Dictionary = DockPortsScript.for_derelict(home as Dictionary)
    var mobile_port: Dictionary = DockPortsScript.for_lifeboat(lifeboat)
    var preflight: Dictionary = DockingManagerScript.preflight_registered_pair(
        home as Dictionary, lifeboat, Transform3D.IDENTITY, host_port, mobile_port)
    if not bool(preflight.get("ok", false)):
        _fail("registered pair preflight failed: %s" % JSON.stringify(preflight))
        return
    if int(preflight.get("non_join_overlap_count", -1)) != 0 \
            or not bool(preflight.get("open_capsule_clear", false)):
        _fail("pair is not collision/traversal clear")
        return

    var barrier: Area3D = DockPortBarrierScript.new()
    get_root().add_child(barrier)
    barrier.configure_endpoint("home/lifeboat", "intact", null, host_port, 6.0)
    var shape_node: CollisionShape3D = barrier.get_node_or_null(
        "DockPortBarrierCollisionShape3D") as CollisionShape3D
    if shape_node == null or not shape_node.shape is BoxShape3D:
        barrier.free()
        _fail("closed barrier is not an aperture box")
        return
    if shape_node.disabled:
        barrier.free()
        _fail("closed barrier collision disabled")
        return
    barrier.set_opened(true)
    if not shape_node.disabled:
        barrier.free()
        _fail("open barrier collision remained enabled")
        return
    barrier.free()
    print("R10A DOCK TRAVERSAL PASS")
    quit(0)

func _fail(reason: String) -> void:
    push_error("R10A DOCK TRAVERSAL FAIL reason=%s" % reason)
    quit(1)
