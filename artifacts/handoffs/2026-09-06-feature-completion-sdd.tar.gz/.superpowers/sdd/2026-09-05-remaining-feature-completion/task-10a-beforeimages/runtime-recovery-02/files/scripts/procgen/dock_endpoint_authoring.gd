extends RefCounted
class_name DockEndpointAuthoring

## Deterministic compiler/validator for the one structural boarding endpoint
## every production ship layout exposes. Endpoints name already-compiled
## structural records; consumers never derive them from a room center.

const ENDPOINT_KEYS := [
    "endpoint_id", "port_id", "portal_id", "type", "size_class", "room_id",
    "deck", "edge_cell", "edge_direction", "structural_edge_key",
    "target_module_id", "structural_module_id", "local_position", "outward_normal",
    "threshold_nav_node_id", "interior_nav_node_id",
    "threshold_clearance_point_local", "interior_clearance_point_local",
    "join_piece_placement_ids", "join_collision_fingerprint",
]
const DIRECTIONS: Dictionary = {
    "north": Vector2i(0, -1),
    "east": Vector2i(1, 0),
    "south": Vector2i(0, 1),
    "west": Vector2i(-1, 0),
}
const OUTWARD_NORMALS: Dictionary = {
    "north": Vector3(0.0, 0.0, -1.0),
    "east": Vector3(1.0, 0.0, 0.0),
    "south": Vector3(0.0, 0.0, 1.0),
    "west": Vector3(-1.0, 0.0, 0.0),
}
const PORTAL_MODULE: String = "doorway_frame_open_1x1"
const CELL_SIZE: float = 4.0
const PLAYER_CLEARANCE_Y: float = 0.55
const PORTAL_COLLISION_BOXES := [
    {"name": "CollisionShape3D_PostWest", "center": [-1.3, 1.6, 0.0], "size": [1.4, 3.2, 0.2]},
    {"name": "CollisionShape3D_PostEast", "center": [1.3, 1.6, 0.0], "size": [1.4, 3.2, 0.2]},
    {"name": "CollisionShape3D_Header", "center": [0.0, 2.7, 0.0], "size": [4.0, 1.0, 0.2]},
]


static func author_layout(layout: Dictionary, fixed_lifeboat: bool = false) -> Dictionary:
    var plan_variant: Variant = layout.get("structural_plan", null)
    if not plan_variant is Dictionary:
        return {"ok": false, "reason": "missing_structural_plan"}
    var plan: Dictionary = plan_variant
    var edges_variant: Variant = plan.get("edges", null)
    var placements_variant: Variant = plan.get("placements", null)
    var floors_variant: Variant = plan.get("floor_placements", null)
    if not edges_variant is Dictionary or not placements_variant is Array \
            or not floors_variant is Array:
        return {"ok": false, "reason": "malformed_structural_plan"}
    var existing: Variant = layout.get("boarding_endpoints_v1", null)
    if existing is Array and not (existing as Array).is_empty():
        return validate_layout(layout)

    var room_roles: Dictionary = {}
    for room_variant in layout.get("rooms", []):
        if room_variant is Dictionary:
            var room: Dictionary = room_variant
            room_roles[str(room.get("id", ""))] = str(
                room.get("room_role", room.get("role", "")))
    var candidates: Array[Dictionary] = []
    for edge_variant in (edges_variant as Dictionary).values():
        if not edge_variant is Dictionary:
            continue
        var edge: Dictionary = edge_variant
        if not bool(edge.get("exterior", false)) \
                or str(edge.get("kind", "")) != "SOLID" \
                or not str(edge.get("other_room", "")).is_empty():
            continue
        var direction: String = str(edge.get("direction", ""))
        if not DIRECTIONS.has(direction):
            continue
        var room_id: String = str(edge.get("owner_room", ""))
        var role: String = str(room_roles.get(room_id, ""))
        var role_rank: int = 0 if role == "dock" else (1 if role == "airlock" else 2)
        var direction_rank: int = _direction_rank(direction, fixed_lifeboat)
        var candidate: Dictionary = edge.duplicate(true)
        candidate["_sort_key"] = "%d|%d|%s|%s" % [
            role_rank, direction_rank, room_id, str(edge.get("edge_key", ""))]
        candidates.append(candidate)
    if candidates.is_empty():
        return {"ok": false, "reason": "no_clear_exterior_edge"}
    candidates.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
        return str(a.get("_sort_key", "")) < str(b.get("_sort_key", "")))
    var selected: Dictionary = candidates[0]
    var edge_key: String = str(selected.get("edge_key", selected.get("key", "")))
    var edge: Dictionary = (edges_variant as Dictionary).get(edge_key, {})
    if edge.is_empty():
        return {"ok": false, "reason": "selected_edge_missing"}
    var edge_placement: Dictionary = {}
    for placement_variant in (placements_variant as Array):
        if placement_variant is Dictionary and str((placement_variant as Dictionary).get(
                "edge_key", (placement_variant as Dictionary).get("key", ""))) == edge_key:
            edge_placement = placement_variant
            break
    if edge_placement.is_empty():
        return {"ok": false, "reason": "selected_edge_placement_missing"}
    var cell: Vector2i = _as_cell(edge.get("cell", Vector2i.ZERO))
    var deck: int = int(edge.get("deck", 0))
    var cell_key: String = "%d|%d|%d" % [deck, cell.x, cell.y]
    var floor_placement: Dictionary = {}
    for floor_variant in (floors_variant as Array):
        if floor_variant is Dictionary and str((floor_variant as Dictionary).get(
                "cell_key", "")) == cell_key:
            floor_placement = floor_variant
            break
    if floor_placement.is_empty():
        return {"ok": false, "reason": "incident_floor_missing"}

    var portal_id: String = "boarding_portal:%s" % edge_key
    for target in [edge, edge_placement]:
        target["kind"] = "DOOR"
        target["state"] = "DOOR"
        target["module_id"] = PORTAL_MODULE
        target["portal"] = true
        target["exterior"] = true
        target["wrapper_required"] = true
        target["placement_required"] = true
        target["portal_id"] = portal_id
    var direction: String = str(edge.get("direction", ""))
    var outward: Vector3 = OUTWARD_NORMALS[direction]
    var edge_position: Vector3 = _as_vector3(edge.get("position", Vector3.ZERO))
    # The registered threshold is the actual outer collision face. Mating the
    # two cell-center planes would overlap both frames and their adjacent walls.
    var port_position: Vector3 = edge_position + outward * _portal_outward_extent()
    var threshold_point: Vector3 = port_position - outward * 0.35 + Vector3.UP * PLAYER_CLEARANCE_Y
    var interior_point: Vector3 = port_position - outward * 1.0 + Vector3.UP * PLAYER_CLEARANCE_Y
    var edge_placement_id: String = str(edge_placement.get("placement_id", "edge:%s" % edge_key))
    var floor_placement_id: String = str(floor_placement.get("placement_id", "floor:%s" % cell_key))
    var endpoint: Dictionary = {
        "endpoint_id": "boarding:%s" % edge_key,
        "port_id": "airlock:%s" % edge_key,
        "portal_id": portal_id,
        "type": "airlock",
        "size_class": 1,
        "room_id": str(edge.get("owner_room", "")),
        "deck": deck,
        "edge_cell": [cell.x, cell.y, deck],
        "edge_direction": direction,
        "structural_edge_key": edge_key,
        "target_module_id": PORTAL_MODULE,
        "structural_module_id": PORTAL_MODULE,
        "local_position": _vector_array(port_position),
        "outward_normal": _vector_array(outward),
        "threshold_nav_node_id": "dock-threshold:%s" % edge_key,
        "interior_nav_node_id": "dock-interior:%s" % cell_key,
        "threshold_clearance_point_local": _vector_array(threshold_point),
        "interior_clearance_point_local": _vector_array(interior_point),
        "join_piece_placement_ids": [edge_placement_id, floor_placement_id],
        "join_collision_fingerprint": join_collision_fingerprint(
            edge_placement_id, floor_placement_id,
            str(floor_placement.get("module_id", "floor_1x1"))),
    }
    layout["boarding_endpoints_v1"] = [endpoint]
    if fixed_lifeboat:
        layout["initial_player_spawn_v1"] = {
            "spawn_id": "lifeboat-initial-airlock",
            "owner_ship_id": "lifeboat",
            "room_id": str(edge.get("owner_room", "airlock_01")),
            "nav_node_id": "dock-interior:%s" % cell_key,
            "local_position": [float(cell.x) * CELL_SIZE, PLAYER_CLEARANCE_Y,
                float(cell.y) * CELL_SIZE],
        }
    return validate_layout(layout)


static func validate_layout(layout: Dictionary) -> Dictionary:
    var endpoints_variant: Variant = layout.get("boarding_endpoints_v1", null)
    if not endpoints_variant is Array or (endpoints_variant as Array).size() != 1:
        return {"ok": false, "reason": "endpoint_count"}
    var endpoint_variant: Variant = (endpoints_variant as Array)[0]
    if not endpoint_variant is Dictionary:
        return {"ok": false, "reason": "endpoint_type"}
    var endpoint: Dictionary = endpoint_variant
    if endpoint.keys().size() != ENDPOINT_KEYS.size():
        return {"ok": false, "reason": "endpoint_keys"}
    for key in ENDPOINT_KEYS:
        if not endpoint.has(key):
            return {"ok": false, "reason": "endpoint_missing_%s" % key}
    var edge_key: String = str(endpoint.get("structural_edge_key", ""))
    var plan_variant: Variant = layout.get("structural_plan", null)
    if not plan_variant is Dictionary:
        return {"ok": false, "reason": "missing_structural_plan"}
    var edge_variant: Variant = (plan_variant as Dictionary).get("edges", {}).get(edge_key, null)
    if not edge_variant is Dictionary:
        return {"ok": false, "reason": "endpoint_edge_missing"}
    var edge: Dictionary = edge_variant
    if not bool(edge.get("exterior", false)) or not str(edge.get("other_room", "")).is_empty() \
            or str(edge.get("kind", "")) != "DOOR" \
            or str(edge.get("module_id", "")) != PORTAL_MODULE:
        return {"ok": false, "reason": "endpoint_not_exterior_portal"}
    var direction: String = str(endpoint.get("edge_direction", ""))
    if not OUTWARD_NORMALS.has(direction) \
            or _as_vector3(endpoint.get("outward_normal", [])) != OUTWARD_NORMALS[direction]:
        return {"ok": false, "reason": "endpoint_normal"}
    var expected_position: Vector3 = _as_vector3(edge.get("position", [])) \
        + (OUTWARD_NORMALS[direction] as Vector3) * _portal_outward_extent()
    if _as_vector3(endpoint.get("local_position", [])) != expected_position:
        return {"ok": false, "reason": "endpoint_position"}
    var join_ids: Variant = endpoint.get("join_piece_placement_ids", null)
    if not join_ids is Array or (join_ids as Array).size() != 2 \
            or str((join_ids as Array)[0]).is_empty() or str((join_ids as Array)[1]).is_empty():
        return {"ok": false, "reason": "endpoint_join_ids"}
    var expected_fingerprint: String = join_collision_fingerprint(
        str((join_ids as Array)[0]), str((join_ids as Array)[1]),
        _placement_module(plan_variant, str((join_ids as Array)[1])))
    if str(endpoint.get("join_collision_fingerprint", "")) != expected_fingerprint:
        return {"ok": false, "reason": "endpoint_join_fingerprint"}
    if _as_vector3(endpoint.get("threshold_clearance_point_local", [])) \
            == _as_vector3(endpoint.get("interior_clearance_point_local", [])):
        return {"ok": false, "reason": "endpoint_clearance_points"}
    return {"ok": true, "reason": "ok", "endpoint": endpoint}


static func endpoint(layout: Dictionary) -> Dictionary:
    var verdict: Dictionary = validate_layout(layout)
    return (verdict.get("endpoint", {}) as Dictionary).duplicate(true) \
        if bool(verdict.get("ok", false)) else {}


static func join_collision_fingerprint(
        edge_placement_id: String, floor_placement_id: String,
        floor_module_id: String) -> String:
    var canonical: Dictionary = {
        "schema": "dock-join-collision-v1",
        "records": [
            {"placement_id": edge_placement_id, "module_id": PORTAL_MODULE,
                "boxes": PORTAL_COLLISION_BOXES},
            {"placement_id": floor_placement_id, "module_id": floor_module_id,
                "boxes": [{"name": "CollisionShape3D", "center": [0.0, 0.0, 0.0],
                    "size": [4.0, 0.25, 4.0]}]},
        ],
    }
    return JSON.stringify(canonical, "", true).sha256_text()


static func _placement_module(plan_variant: Variant, placement_id: String) -> String:
    if not plan_variant is Dictionary:
        return ""
    for group in ["placements", "floor_placements"]:
        for placement_variant in (plan_variant as Dictionary).get(group, []):
            if placement_variant is Dictionary and str((placement_variant as Dictionary).get(
                    "placement_id", "")) == placement_id:
                return str((placement_variant as Dictionary).get("module_id", ""))
    return ""


static func _direction_rank(direction: String, fixed_lifeboat: bool) -> int:
    var order: Array = ["north", "south", "west", "east"] \
        if fixed_lifeboat else ["west", "east", "north", "south"]
    return order.find(direction)


static func _as_vector3(value: Variant) -> Vector3:
    if value is Vector3:
        return value
    if value is Array and (value as Array).size() == 3:
        return Vector3(float((value as Array)[0]), float((value as Array)[1]),
            float((value as Array)[2]))
    return Vector3.INF


static func _vector_array(value: Vector3) -> Array:
    return [value.x, value.y, value.z]


static func _portal_outward_extent() -> float:
    var extent: float = 0.0
    for box_variant in PORTAL_COLLISION_BOXES:
        var box: Dictionary = box_variant
        var center: Array = box.get("center", []) as Array
        var size: Array = box.get("size", []) as Array
        extent = maxf(extent, absf(float(center[2])) + float(size[2]) * 0.5)
    return extent


static func _as_cell(value: Variant) -> Vector2i:
    if value is Vector2i:
        return value
    if value is Array and (value as Array).size() >= 2:
        return Vector2i(int((value as Array)[0]), int((value as Array)[1]))
    return Vector2i(2147483647, 2147483647)
