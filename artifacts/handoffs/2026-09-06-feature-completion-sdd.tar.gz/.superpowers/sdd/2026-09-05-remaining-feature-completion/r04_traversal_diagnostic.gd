extends SceneTree

## Plan-local R04 diagnostic only. This starts through the real Title New Game
## input and drives PlayerController's production physics. After retaining a
## blocked baseline, it temporarily removes only the docked lifeboat's static
## collision layers to test component causality, then restores every value.

const TITLE_SCENE: PackedScene = preload("res://scenes/title_main.tscn")
const WAIT_TIMEOUT_FRAMES: int = 900
const BASELINE_MOVE_FRAMES: int = 240
const RESUME_TIMEOUT_FRAMES: int = 300
const REQUIRED_RESUME_DISTANCE: float = 2.0

enum Phase { WAITING, OPEN_BARRIER, BASELINE_MOVE, CONTROLLED_MOVE }

var title: Node
var playable
var player: CharacterBody3D
var phase: Phase = Phase.WAITING
var total_frames: int = 0
var phase_frames: int = 0
var baseline_start: Vector3 = Vector3.ZERO
var blocked_position: Vector3 = Vector3.ZERO
var controlled_start: Vector3 = Vector3.ZERO
var lifeboat_collision_records: Array[Dictionary] = []
var portal_interactions: int = 0
var portal_open_seen: bool = false
var completed: bool = false
var barrier_ref
var barrier_requested: bool = false
var waypoint_index: int = 0
var route: Array[Vector3] = [
    Vector3(4.0, 0.0, 2.0),
    Vector3(4.0, 0.0, 0.4),
    Vector3(6.0, 0.0, 0.4),
    Vector3(12.0, 0.0, 0.4),
    Vector3(18.0, 4.0, 0.4),
    Vector3(22.0, 4.0, 0.4),
]


func _initialize() -> void:
    title = TITLE_SCENE.instantiate()
    if title == null:
        _fail("title scene could not instantiate")
        return
    get_root().add_child(title)
    physics_frame.connect(_on_physics_frame)


func _on_physics_frame() -> void:
    if completed:
        return
    total_frames += 1
    if total_frames > WAIT_TIMEOUT_FRAMES:
        _fail("global timeout phase=%s" % Phase.keys()[phase])
        return
    if phase == Phase.WAITING:
        _wait_for_title_start()
    elif phase == Phase.OPEN_BARRIER:
        _open_home_barrier()
    elif phase == Phase.BASELINE_MOVE:
        _run_baseline_move()
    elif phase == Phase.CONTROLLED_MOVE:
        _run_controlled_move()


func _wait_for_title_start() -> void:
    if title == null or not is_instance_valid(title):
        _fail("title disappeared")
        return
    if playable == null:
        if title.get("playable_instance") == null:
            var accept := InputEventAction.new()
            accept.action = &"ui_accept"
            accept.pressed = true
            title.call("_unhandled_input", accept)
            return
        playable = title.get("playable_instance")
    if playable == null or not playable.get("playable_started"):
        return
    player = playable.get("player") as CharacterBody3D
    if player == null:
        _fail("playable started without CharacterBody3D player")
        return
    if playable.has_signal("playable_slice_completed"):
        playable.playable_slice_completed.connect(_on_slice_completed)
    _print_initial_contract()
    phase = Phase.OPEN_BARRIER
    phase_frames = 0


func _open_home_barrier() -> void:
    phase_frames += 1
    if phase_frames == 1:
        barrier_ref = _closed_barrier()
        if barrier_ref == null:
            _fail("no closed boot dock barrier")
            return
        print("R04 DIAG BARRIER BEFORE path=%s position=%s opened=%s player=%s distance=%.6f" % [
            str(barrier_ref.get_path()), str(barrier_ref.global_position), str(barrier_ref.get("opened")),
            str(player.global_position), barrier_ref.global_position.distance_to(player.global_position)])
    if not is_instance_valid(barrier_ref):
        _fail("boot dock barrier disappeared")
        return
    if not barrier_requested:
        var delta: Vector3 = barrier_ref.global_position - player.global_position
        delta.y = 0.0
        if delta.length() > 2.0:
            player.set_scripted_move_direction(delta.normalized())
            if phase_frames <= 8 or phase_frames % 15 == 0:
                _print_motion("dock_approach", phase_frames)
            return
        player.clear_scripted_move_direction()
        barrier_requested = true
        player.request_interact()
        print("R04 DIAG BARRIER INTERACT position=%s distance=%.6f" % [
            str(player.global_position), delta.length()])
        return
    if not barrier_ref.get("opened"):
        _fail("ordinary request_interact did not open boot barrier")
        return
    print("R04 DIAG BARRIER AFTER opened=true player=%s" % str(player.global_position))
    phase = Phase.BASELINE_MOVE
    phase_frames = 0
    baseline_start = player.global_position
    _drive_natural_route()


func _run_baseline_move() -> void:
    phase_frames += 1
    var portal_claimed: bool = _try_open_colliding_authored_portal()
    if not portal_claimed:
        _drive_natural_route()
    if phase_frames <= 8 or phase_frames % 15 == 0:
        _print_motion("baseline", phase_frames)
        _print_survival("baseline", phase_frames)
    # Reaching the fourth authored waypoint places the player beyond the airlock
    # portal and proves the corrected all-slide diagnostic traversed naturally.
    if waypoint_index >= 4 and portal_open_seen:
        player.clear_scripted_move_direction()
        _print_motion("natural_complete", phase_frames)
        _print_survival("natural_complete", phase_frames)
        print("R04 TRAVERSAL DIAGNOSTIC PASS all_slide_blocker_selection=true natural_route_resumed=true lifeboat_toggle_used=false portal_open_seen=true interaction_preemptions=%d" % [
            maxi(0, portal_interactions - 1)])
        completed = true
        quit(0)
        return
    if phase_frames < BASELINE_MOVE_FRAMES:
        return
    blocked_position = player.global_position
    var moved: float = blocked_position.x - baseline_start.x
    var horizontal: KinematicCollision3D = _horizontal_collision()
    var support: KinematicCollision3D = _support_collision()
    var collider_path: String = _collision_path(horizontal)
    print("R04 DIAG BASELINE RESULT start=%s end=%s delta_x=%.6f horizontal_collider=%s horizontal_normal=%s support_collider=%s support_normal=%s" % [
        str(baseline_start), str(blocked_position), moved, collider_path,
        str(horizontal.get_normal()) if horizontal != null else "none",
        _collision_path(support), str(support.get_normal()) if support != null else "none"])
    if moved <= 0.1:
        _fail("baseline never moved toward overlap")
        return
    if not collider_path.contains("/LifeBoat/"):
        _fail("baseline horizontal stop was not caused by lifeboat collider=%s" % collider_path)
        return
    _capture_and_disable_lifeboat_collisions()
    if lifeboat_collision_records.is_empty():
        _fail("no lifeboat StaticBody3D collisions captured")
        return
    phase = Phase.CONTROLLED_MOVE
    phase_frames = 0
    controlled_start = player.global_position
    _drive_natural_route()


func _run_controlled_move() -> void:
    phase_frames += 1
    var portal_claimed: bool = _try_open_colliding_authored_portal()
    if not portal_claimed:
        _drive_natural_route()
    if phase_frames <= 8 or phase_frames % 15 == 0:
        _print_motion("controlled", phase_frames)
        _print_survival("controlled", phase_frames)
    var controlled_delta: Vector3 = player.global_position - controlled_start
    controlled_delta.y = 0.0
    var resumed: float = controlled_delta.length()
    if resumed >= REQUIRED_RESUME_DISTANCE and portal_open_seen:
        player.clear_scripted_move_direction()
        _restore_lifeboat_collisions()
        _print_motion("restored", phase_frames)
        _print_survival("restored", phase_frames)
        print("R04 TRAVERSAL DIAGNOSTIC PASS all_slide_blocker_selection=true baseline_lifeboat_blocker=true resumed_without_lifeboat_collision=true delta_x=%.6f portal_open_seen=%s collision_values_restored=true interaction_preemptions=%d" % [
            resumed, str(portal_open_seen), maxi(0, portal_interactions - 1)])
        completed = true
        quit(0)
        return
    if phase_frames >= RESUME_TIMEOUT_FRAMES:
        _fail("movement did not resume after lifeboat collision toggle delta_x=%.6f" % resumed)


func _print_initial_contract() -> void:
    print("R04 DIAG PLAYER path=%s position=%s transform=%s velocity=%s on_floor=%s motion_mode=%s up=%s floor_snap=%.6f floor_angle=%.6f safe_margin=%.6f max_slides=%d" % [
        str(player.get_path()), str(player.global_position), str(player.global_transform),
        str(player.velocity), str(player.is_on_floor()), str(player.motion_mode),
        str(player.up_direction), player.floor_snap_length, player.floor_max_angle,
        player.safe_margin, player.max_slides])
    var shape_node = player.get("collision_shape")
    if shape_node is CollisionShape3D:
        var shape: Shape3D = (shape_node as CollisionShape3D).shape
        var shape_text: String = str(shape)
        if shape is CapsuleShape3D:
            shape_text = "CapsuleShape3D(radius=%.6f,height=%.6f)" % [shape.radius, shape.height]
        print("R04 DIAG CAPSULE local=%s global=%s shape=%s" % [
            str((shape_node as CollisionShape3D).transform),
            str((shape_node as CollisionShape3D).global_transform), shape_text])
    var home = playable.get("home_ship")
    var lifeboat = playable.get("lifeboat_ship")
    print("R04 DIAG SHIPS home_root=%s lifeboat_root=%s lifeboat_parent_home=%s occupancy=%s away=%s" % [
        str(home.scene_root.global_transform) if home != null else "none",
        str(lifeboat.scene_root.global_transform) if lifeboat != null else "none",
        str(lifeboat != null and lifeboat.parent_ship == home), _occupancy_id(),
        str(playable.get("away_from_start"))])
    _print_nearby_floor_shapes()
    _print_portals("initial")
    _print_survival("initial", 0)


func _print_nearby_floor_shapes() -> void:
    var stack: Array[Node] = [playable]
    while not stack.is_empty():
        var node: Node = stack.pop_back()
        for child in node.get_children():
            stack.append(child)
        if not (node is CollisionShape3D):
            continue
        var cs := node as CollisionShape3D
        if not (cs.shape is BoxShape3D):
            continue
        if cs.global_position.distance_to(player.global_position) > 10.0:
            continue
        if not str(cs.get_path()).to_lower().contains("floor_"):
            continue
        var box := cs.shape as BoxShape3D
        var bounds: Dictionary = _box_world_bounds(cs.global_transform, box.size)
        print("R04 DIAG FLOOR path=%s body=%s body_layer=%d body_mask=%d shape_size=%s transform=%s aabb_min=%s aabb_max=%s" % [
            str(cs.get_path()), str(cs.get_parent().get_path()),
            int(cs.get_parent().collision_layer) if cs.get_parent() is CollisionObject3D else -1,
            int(cs.get_parent().collision_mask) if cs.get_parent() is CollisionObject3D else -1,
            str(box.size), str(cs.global_transform), str(bounds["min"]), str(bounds["max"])])


func _box_world_bounds(xform: Transform3D, size: Vector3) -> Dictionary:
    var half := size * 0.5
    var extents := Vector3(
        absf(xform.basis.x.x) * half.x + absf(xform.basis.y.x) * half.y + absf(xform.basis.z.x) * half.z,
        absf(xform.basis.x.y) * half.x + absf(xform.basis.y.y) * half.y + absf(xform.basis.z.y) * half.z,
        absf(xform.basis.x.z) * half.x + absf(xform.basis.y.z) * half.y + absf(xform.basis.z.z) * half.z)
    return {"min": xform.origin - extents, "max": xform.origin + extents}


func _print_motion(label: String, local_frame: int) -> void:
    print("R04 DIAG MOTION label=%s frame=%d total=%d position=%s velocity=%s on_floor=%s floor_normal=%s floor_angle=%.6f slide_count=%d input=%s effective_speed=%.6f waypoint_index=%d waypoint=%s" % [
        label, local_frame, total_frames, str(player.global_position), str(player.velocity),
        str(player.is_on_floor()), str(player.get_floor_normal()), player.get_floor_angle(),
        player.get_slide_collision_count(), str(player.get("scripted_move_direction")),
        float(player.call("get_effective_move_speed")), waypoint_index,
        str(route[waypoint_index]) if waypoint_index < route.size() else "done"])
    for index in range(player.get_slide_collision_count()):
        var collision: KinematicCollision3D = player.get_slide_collision(index)
        var collider = collision.get_collider()
        var depth: float = float(collision.call("get_depth")) if collision.has_method("get_depth") else -1.0
        print("R04 DIAG COLLISION label=%s frame=%d index=%d collider=%s collider_path=%s collider_transform=%s normal=%s position=%s travel=%s remainder=%s depth=%.9f collider_velocity=%s" % [
            label, local_frame, index, str(collider),
            str(collider.get_path()) if collider is Node else "none",
            str(collider.global_transform) if collider is Node3D else "none",
            str(collision.get_normal()), str(collision.get_position()),
            str(collision.get_travel()), str(collision.get_remainder()), depth,
            str(collision.get_collider_velocity())])


func _print_survival(label: String, local_frame: int) -> void:
    var vitals = playable.get("vitals_state")
    var oxygen = playable.get("oxygen_state")
    var radiation = playable.get("radiation_state")
    var temperature = playable.get("body_temperature_state")
    var life_support = playable.get("life_support_expanded_state")
    print("R04 DIAG SURVIVAL label=%s frame=%d occupancy=%s away=%s vitals=%s oxygen=%s radiation=%s temperature=%s life_support_health_drain=%.6f player_in_breach=%s field_pressure=%s fire_intensity=%.6f slice_complete=%s" % [
        label, local_frame, _occupancy_id(), str(playable.get("away_from_start")),
        JSON.stringify(vitals.get_summary()) if vitals != null else "{}",
        JSON.stringify(oxygen.get_summary()) if oxygen != null else "{}",
        JSON.stringify(radiation.get_summary()) if radiation != null else "{}",
        JSON.stringify(temperature.get_summary()) if temperature != null else "{}",
        float(life_support.get_health_drain_per_second()) if life_support != null and life_support.has_method("get_health_drain_per_second") else 0.0,
        str(playable.call("is_player_in_breach_zone")),
        str(playable.call("_is_field_suit_pressure_active")),
        float(playable.call("_player_fire_intensity")), str(playable.get("slice_complete"))])


func _print_portals(label: String) -> void:
    var loader = playable.get("loader")
    if loader == null or not loader.has_method("get_authored_portal_nodes"):
        print("R04 DIAG PORTALS label=%s unavailable=true" % label)
        return
    for portal in loader.get_authored_portal_nodes() as Array:
        if not is_instance_valid(portal):
            continue
        print("R04 DIAG PORTAL label=%s id=%s path=%s position=%s is_open=%s state=%s" % [
            label, str(portal.get("portal_id")), str(portal.get_path()),
            str(portal.global_position), str(portal.get("is_open")), str(portal.get("portal_state"))])


func _try_open_colliding_authored_portal() -> bool:
    var collision: KinematicCollision3D = null
    for index in range(player.get_slide_collision_count()):
        var candidate: KinematicCollision3D = player.get_slide_collision(index)
        var candidate_collider = candidate.get_collider()
        if candidate_collider != null and str(candidate_collider.name) == "PortalBlocker":
            collision = candidate
            break
    if collision == null:
        return false
    var collider = collision.get_collider()
    player.clear_scripted_move_direction()
    portal_interactions += 1
    var inventory = playable.get("inventory_state")
    var pump_before: bool = inventory != null and inventory.has_tool("portable_oxygen_pump")
    var calibrator_before: bool = inventory != null and inventory.has_tool("junction_calibrator")
    print("R04 DIAG PORTAL INTERACT attempt=%d collider=%s normal=%s portal_before=%s pump_before=%s calibrator_before=%s" % [
        portal_interactions, str(collider.get_path()), str(collision.get_normal()),
        str(collider.get_parent().get("is_open")), str(pump_before), str(calibrator_before)])
    player.request_interact()
    portal_open_seen = collider.get_parent().get("is_open") == true
    var pump_after: bool = inventory != null and inventory.has_tool("portable_oxygen_pump")
    var calibrator_after: bool = inventory != null and inventory.has_tool("junction_calibrator")
    var claimed_by: String = "portal" if portal_open_seen else (
        "portable_oxygen_pump" if not pump_before and pump_after else (
        "junction_calibrator" if not calibrator_before and calibrator_after else "other_or_soft_deny"))
    print("R04 DIAG PORTAL INTERACT RESULT attempt=%d claimed_by=%s portal_after=%s pump_after=%s calibrator_after=%s" % [
        portal_interactions, claimed_by, str(portal_open_seen), str(pump_after), str(calibrator_after)])
    _print_portals("after_interact_%d" % portal_interactions)
    if portal_interactions > 4 and not portal_open_seen:
        _fail("ordinary portal dispatch did not open blocker")
    return true


func _horizontal_collision() -> KinematicCollision3D:
    for index in range(player.get_slide_collision_count()):
        var collision: KinematicCollision3D = player.get_slide_collision(index)
        if absf(collision.get_normal().y) < 0.5:
            return collision
    return null


func _support_collision() -> KinematicCollision3D:
    for index in range(player.get_slide_collision_count()):
        var collision: KinematicCollision3D = player.get_slide_collision(index)
        if collision.get_normal().y > 0.5:
            return collision
    return null


func _drive_natural_route() -> void:
    while waypoint_index < route.size():
        var delta: Vector3 = route[waypoint_index] - player.global_position
        delta.y = 0.0
        if delta.length() > 0.75:
            player.set_scripted_move_direction(delta.normalized())
            return
        waypoint_index += 1
    player.clear_scripted_move_direction()


func _capture_and_disable_lifeboat_collisions() -> void:
    var lifeboat = playable.get("lifeboat_ship")
    if lifeboat == null or not is_instance_valid(lifeboat.scene_root):
        return
    var stack: Array[Node] = [lifeboat.scene_root]
    while not stack.is_empty():
        var node: Node = stack.pop_back()
        for child in node.get_children():
            stack.append(child)
        if node is StaticBody3D:
            var body := node as StaticBody3D
            lifeboat_collision_records.append({
                "body": body,
                "layer": body.collision_layer,
                "mask": body.collision_mask,
            })
            print("R04 DIAG TOGGLE disable path=%s original_layer=%d original_mask=%d" % [
                str(body.get_path()), body.collision_layer, body.collision_mask])
            body.collision_layer = 0
            body.collision_mask = 0


func _restore_lifeboat_collisions() -> void:
    for record in lifeboat_collision_records:
        var body = record.get("body")
        if not is_instance_valid(body):
            continue
        body.collision_layer = int(record.get("layer", 0))
        body.collision_mask = int(record.get("mask", 0))
        print("R04 DIAG TOGGLE restore path=%s layer=%d mask=%d" % [
            str(body.get_path()), body.collision_layer, body.collision_mask])


func _closed_barrier():
    for barrier in playable.get("dock_barriers") as Array:
        if is_instance_valid(barrier) and not barrier.get("opened"):
            return barrier
    return null


func _collision_path(collision) -> String:
    if collision == null:
        return "none"
    var collider = collision.get_collider()
    return str(collider.get_path()) if collider is Node else "none"


func _occupancy_id() -> String:
    var occupancy = playable.get("current_occupancy")
    if occupancy == null:
        return "none"
    return str(occupancy.ship_id) if "ship_id" in occupancy else str(occupancy)


func _on_slice_completed(summary: Dictionary) -> void:
    print("R04 DIAG RUN COMPLETED summary=%s" % JSON.stringify(summary))


func _fail(reason: String) -> void:
    if completed:
        return
    if player != null and is_instance_valid(player):
        player.clear_scripted_move_direction()
    _restore_lifeboat_collisions()
    if playable != null:
        _print_survival("failure", phase_frames)
    completed = true
    print("FAIL: R04 TRAVERSAL DIAGNOSTIC %s" % reason)
    quit(1)
