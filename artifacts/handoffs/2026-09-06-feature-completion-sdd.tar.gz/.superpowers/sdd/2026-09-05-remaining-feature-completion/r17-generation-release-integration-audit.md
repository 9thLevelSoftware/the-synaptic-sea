# R17 preliminary audit: generation, release, integration, documentation

Read-only snapshot: `2026-09-05T20:10:38.1044344-04:00`; repository HEAD at read time: `aeba535e45a3b66d8ff87824892513add5109e0b`. R02 was changing source concurrently, so these observations are provisional. No Godot, export, test, network, provider, or Git mutation was performed.

## Checked registry scope

The current `docs/game/inventory/feature_acceptance.json` contains 37 active leaves in these domains: `pg` 11, `rl` 3, `int` 10, and `doc` 12. Every one has `evidence.state=not_verified`, empty `evidence.refs`, and false evidence booleans, regardless of its historical `declared_status` (`Validated` or `Implemented`). No leaf in these four domains is marked deferred.

The exact active IDs are:

* `pg`: `REQ-PG-001::acceptance-cbd90a75a499`, `REQ-PG-007::acceptance-e5a054ca075c`, `REQ-PG-012::acceptance-ac34a1612c25`, all three `REQ-PG-DRESS-001` leaves (`e9d541c88ac0`, `883e72dbd31b`, `c1dc1137feb6`), and all five `REQ-PG-PACING-001` leaves (`b610b37d12c6`, `9f954925da6f`, `7c33f186806b`, `c3bb2538538b`, `ad28f8997ea4`).
* `rl`: `REQ-RL-001::acceptance-955afa335800`, `REQ-RL-003::acceptance-174b6c9f5b4c`, `REQ-RL-008::acceptance-8f194f5a15bb`.
* `int`: `REQ-INT-001::acceptance-0d28bf17cd7b`, `REQ-INT-002::acceptance-6406c5eaaf0e`, `REQ-INT-003::acceptance-8c0618ec3143`, `REQ-INT-004::acceptance-e59d870a26f5`, `REQ-INT-005::acceptance-b710808b025d`, `REQ-INT-006::acceptance-34e174c62831`, `REQ-INT-007::acceptance-0de52808f02d`, `REQ-INT-008::acceptance-5ebe0f4b5c65`, `REQ-INT-009::acceptance-59dc98a20f24`, `REQ-INT-010::acceptance-dd6345b0c1de`.
* `doc`: `REQ-DOC-001::acceptance-58d5ed7cdbbc`, `REQ-DOC-002::acceptance-69d2a7d58ff3`, `REQ-DOC-003::acceptance-878ac9d23144`, `REQ-DOC-004::acceptance-9e872d2b8c60`, `REQ-DOC-005::acceptance-241b7673827d`, `REQ-DOC-006::acceptance-fd4761eb1694`, `REQ-DOC-007::acceptance-dba509af8f41`, `REQ-DOC-008::acceptance-13dcb811fdcd`, and four `REQ-DOC-009` leaves (`04aaed86d9fa`, `c1a22a36d9b8`, `1741bf6f177e`, `e66a18b59d99`).

## Generation (`pg`)

The production chain is present: `scripts/procgen/ship_generator.gd:11-22,53-72,102-119` preloads the layout, biome, difficulty, room-variant, encounter, and loader components; `generate()` forwards biome/difficulty and extended-template selection; `generate_from_seed()` selects the native worldgen extension when available and falls back to the normal pipeline. Native layout export is converted to gameplay documents and loaded at `ship_generator.gd:122-220`. `scripts/procgen/encounter_injector.gd:122-139` injects deterministic markers and `:410` exposes validation. These are implementation observations only: all 11 active `pg` leaves remain unverified because the registry has no smoke refs or fresh evidence.

The canonical checks named by plan 12 exist (`template_c_traversal_smoke.gd`, `room_variant_selector_smoke.gd`, `kit_catalog_smoke.gd`, `biome_profile_smoke.gd`, `difficulty_profile_smoke.gd`, `encounter_injector_smoke.gd`, `seed_determinism_smoke.gd`). Their existence does not prove the active dressing/pacing leaves, player reachability, or native-extension path. The feature source `docs/game/features/procedural_generation_expansion.md` still says “In progress for Gate 2 content-complete target,” so that prose is not a completion claim.

## Release/distribution/offline (`rl` and related active obligation)

The release seams are implemented in source: `achievement_state.gd:27-49,60-89,104-185` has catalog-trigger lookup, per-run unlock/reset, and disk round-trip; `build_metadata_state.gd:33-60` validates `dev/demo/release`; `demo_scope_gate.gd:29-79` consumes build kind and manifest; and `release_readiness_ledger.gd:27-88` enforces known checks, valid status/source, and evidence paths for external rows. `playable_generated_ship.gd:1786-1802,12389-12395` wires metadata, demo gate, localization, and achievement trigger calls into the live generated ship. The three active `rl` leaves (`RL-001`, `RL-003`, `RL-008`) nevertheless remain `not_verified` with no refs.

The active offline/native export obligation remains outside these explicit deferrals: `docs/game/05_requirements.md` lists FC-24 as approved/unimplemented. Current execution authority is Godot `4.7.2` on Windows, accepted by ADR-0060 and the Task 17 Global Constraints; older prose mentioning 4.7.1 is superseded. `scripts/export/build_release.sh:11,18,77-79` and its companion docs still hard-code Godot `4.6.2`, which is a potential R19 release-tool compatibility defect to resolve or explicitly supersede; no export was run.

## Integration (`int`)

The five canonical plan-14 checks exist and are structurally wired: `cross_system_dependency_smoke.gd:14-53` reads the matrix and validation plan; the three E2E smokes load rubric/balance data and emit their respective markers; `product_audit_smoke.gd:6-35` loads the audit and known-issue manifests. The feature source claims Task14 validation and a completed live-path follow-up, but the ten current `int` leaves have no registry evidence refs and are therefore unverified in this audit. The feature explicitly excludes fresh human/controller acceptance, so that remains a separate acceptance gap rather than a defect inferred from old boxes.

## Documentation validators (`doc`)

The canonical implementation is Python, not GDScript: `scripts/validation/doc_currency_validators.py:118-220,224-274` provides systems-map, requirement-trace, and Kanban validators; `scripts/validation/kanban_manifest_smoke.py:1-3` is a wrapper; and `scripts/validation/doc_currency_validators.py:277-314` emits the required markers (or a distinct `KANBAN MANIFEST SKIP` when the board DB is absent). This is documented in `docs/game/features/systems_map_task_graph_currency.md`, so the old plan wording “`.gd` or docs validator script” should resolve to these Python paths, not be treated as a missing runtime check. All 12 active `doc` leaves remain unverified with empty refs.

The documented Task15 claim is host-side validator evidence only and explicitly excludes external store/platform/signed-release evidence. Therefore it cannot promote release or integration leaves. The Kanban validator’s intentional board-DB absence path is `SKIP`, not `PASS`; whether that is acceptable for the current gate needs a fresh validator run and board-state decision. No such run was performed here.

## Bounded conclusion and remaining leaves

No checked source establishes a current defect in procedural generation, achievement/localization/demo seams, integration models, or documentation validators. The concrete compatibility concern is the release script/docs Godot 4.6.2 assumption versus the ADR-0060-authorized 4.7.2 execution engine; it is a potential R19 issue, not evidence that 4.7.1 is current authority. Everything else above is unverified because the frozen registry has no refs/fresh evidence. Remaining work is a coordinator-owned audit partition: run the canonical checks under the current engine, capture marker/output refs per exact leaf, separately audit FC-24 native export/offline behavior, and resolve the 4.6.2/4.7.2 release-tooling decision. Do not count the explicit external deferrals as local missing features.

Read-source hashes at snapshot: `ship_generator.gd` `10F91C78F9C2D101BA976B3F6BD37AADDFF5A0A8020CD19DE6F18E8178407D3B`; `encounter_injector.gd` `F908338A37A422CAA6279D6C7F926F1B409F9B7A8AE6E0325493502B2A7D54B7`; `achievement_state.gd` `DC32BFE2C87709CDFAABD79709DB14A105247B2CB2CE422733715B200198C243`; `build_metadata_state.gd` `D6CD16FD4A752F92FE71BAE38CFBF14E0154F1D99D1905D676A829238E3BC16A`; `release_readiness_ledger.gd` `D8CC7A3CA5F25683A3080ED0A8CD987A077EC674401ED71AE74AD4472777EFCA`; `build_release.sh` `E1CCAC14985963BF8DFCC062770BED965BA1C00A35085E9ADE20E422C3F64F68`; `doc_currency_validators.py` `D900F1FFB8EC16F3C5169AB4CA741E4BA345789D6CD95AE0F4C635C287352BE8`.
