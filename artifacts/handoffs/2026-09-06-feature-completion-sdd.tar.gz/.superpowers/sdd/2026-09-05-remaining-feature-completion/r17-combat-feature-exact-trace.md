# R17 Combat Feature Exact Trace

- Generated/hash-checked: `2026-09-06T00:26:44.8489776-04:00`
- Source revision at hash check: `17d9d3b11177b8c7d70d07d113ce5e9c038a513b`
- Bounded input hash drift during audit: `0 / 37`
- Moving WIP: `true`
- Scope: source-only audit; no Godot/runtime/test execution, evidence promotion, registry/index/governance/runtime/git change, or whole-game acceptance
- Selection: `domain == "feature_spec" && feature == "combat_threat_ai" && deferred == false`, excluding exact keys in `r17-source-trace-index.json.semantic_trace_reports`
- Frozen inventory: `668 recorded`, `657 active`, `622 canonical metric leaves`
- Exact selection: `6 feature rows`, `0 already semantically indexed`, `6 selected`, expected `6`, mismatch `0`
- Result: `3 traced`, `3 source_mapped_validation_gap`, `0 confirmed_runtime_contract_mismatch for these exact leaves`, `0 unresolved`, `0 fresh executions`, `0 evidence promotions`

The companion JSON pins SHA-256 hashes for the inventory, index, feature spec, bounded combat runtime sources, authored data, substantive tests, current ADRs, and R02/R03 reports. The coordinator identified moving R04 work as home interaction/probe only. This audit did not inspect or depend on that work.

Accepted ADR-0037 owns the pure combat-model and `PlayableGeneratedShip` coordinator boundary. Accepted ADR-0049 owns pure graph pathfinding, state targets, dynamic overlays, placeholder sync and repath-after-restore; its statement that INVESTIGATE/FLEE were missing is historical problem context, because both branches exist in current source. Accepted ADR-0054 amends graph construction to compiler standing edges. ADR-0059 decisions 33-38 are the current accepted R02 persistence amendment for strict outer v6 and nested `threat-manager-2` owner state. R02 is approved in `task-2-fix1-review.md`. R03's independent scoped review is complete PASS in `task-3-review.md` (SHA-256 `fc3bc147...`), with its documentation-only outcome recorded at revision `4590a405`; human/player G1+ acceptance and the complete post-integration regression remain outside that scoped PASS.

`traced` means the exact production route and full leaf are covered by substantive assertions, possibly combined across focused tests, or direct static architecture evidence. `source_mapped_validation_gap` means production source is connected but existing predicates omit an exact dynamic conjunct. These statuses do not promote inventory evidence or claim fresh execution/player acceptance.

## Key findings

- The live main-scene smoke requires at least five threats and five distinct archetype IDs. The builder and hydration paths statically prove every row uses `ThreatAIState` and receives a placeholder.
- Noise, light and sight all participate in both detection and per-threat awareness formulas. Existing tests isolate noise for DetectionState and sight for relative threat awareness, but never isolate light and prove both state and awareness effects.
- The production weapon path spends a magazine round, raises manager awareness and always refreshes the weapon hotbar. The main combat smoke proves spend/awareness/damage but never inspects the post-attack HUD; UI tests only check generic HOTBAR text.
- Position, phase, memory and attack state have combined persistence coverage: the main combat smoke checks position/memory/attack, and the process source compares complete home, away and active combat summaries after a JSON wire round-trip, which includes phase fields and exact owner travel identity.
- Compiler-edge graph construction, solid-edge exclusion and corridor waypoint movement combine to cover the generic no-solid-tunneling feature leaf. Narrower D-019 state-specific assertion gaps and the confirmed `farthest_point` distance/selection defect remain recorded in the separate combat-navigation report.
- Dynamic fire/hatch overlays flow into A*, but no existing smoke applies either overlay and compares route cost/connectivity before and after.

## Exact leaf traces

### `FEATURE::docs/game/features/combat_threat_ai.md::8148156b3f6a`

**Criterion:** At least five threat archetypes spawn through one shared `ThreatAIState` contract.

- Route: current layout/markers enter `ThreatManager.configure_for_layout`; `ThreatInitialStateBuilder` creates every entry with `ThreatAIStateScript.new`; manager hydration reconstructs every row with that same class and spawns a placeholder (`playable_generated_ship.gd:9735-9748`; `threat_initial_state_builder.gd:20-52`; `threat_manager.gd:264-294,402-408`).
- Predicate: `main_playable_slice_combat_encounter_smoke.gd:52-70` requires at least five live manager rows and five distinct `archetype_id` values. Static construction evidence supplies shared class and scene spawn identity.
- Data/save: `threat_archetypes.json` has six definitions; the no-marker fallback authors five distinct kinds (`threat_initial_state_builder.gd:95-117`). Complete rows persist under `threat-manager-2`.
- Status: `traced`.

### `FEATURE::docs/game/features/combat_threat_ai.md::d338fcdb9eb9`

**Criterion:** Noise, light, and sight all change detection state and threat awareness.

- Route: the live coordinator supplies movement noise, powered-room light and visibility; DetectionState emits/sums all three, and ThreatManager passes them with LOS/proximity changes into each ThreatAIState (`playable_generated_ship.gd:9855-9875`; `detection_state.gd:36-76`; `threat_manager.gd:125-177`).
- Predicate gap: `detection_state_smoke.gd:6-40` proves noise-driven detection plus exact three-value emission. `threat_detection_source_smoke.gd:16-60` proves combined signal raises awareness and sight-only proximity changes awareness. No test isolates light and requires both a detection transition and per-threat/manager awareness change; noise and sight also split those two outcome types across tests.
- Data/save: authored archetype sensitivities tune all three; raw signals, detection, awareness and memory persist.
- Status: `source_mapped_validation_gap`.

### `FEATURE::docs/game/features/combat_threat_ai.md::17bc130487cc`

**Criterion:** Player weapon use consumes ammo/resources, raises threat awareness, and updates HUD feedback.

- Route: `attack_primary` reaches `_attack_with_equipped_weapon`; the manager spends one magazine round, applies damage, raises noise/awareness, and records the receipt; the coordinator always calls `_refresh_weapon_hotbar`, which publishes weapon, reserve, threat awareness and combat state (`playable_generated_ship.gd:9750-9810,14609-14611`; `threat_manager.gd:198-239`).
- Predicate gap: `main_playable_slice_combat_encounter_smoke.gd:72-124` proves flare-pistol equip, one-round decrement, target, damage, awareness `>=0.95`, and detection. It never reads the post-attack hotbar. UI-shell smokes only require generic text containing `HOTBAR`; P10 tests inject and preserve a cache rather than verify live weapon feedback.
- Data/save: weapon/ammo JSON links three ranged weapons to their resources; magazine spend and inventory reserve reload are separate current models. Awareness/last attack/hotbar cache persist.
- Status: `source_mapped_validation_gap`.

### `FEATURE::docs/game/features/combat_threat_ai.md::070b5fea84e8`

**Criterion:** Threat positions, phases, memory, and last attack state survive save/load and ship travel.

- Route: travel departure syncs the current owner summary and destination activation restores its summary; world capture synchronizes active combat, while restore validates/hydrates models/placeholders and rebuilds transient paths (`playable_generated_ship.gd:8593-8695,9735-9748,12688-12697,13218-13223,13473-13478,13654-13661`).
- Predicate: the main combat smoke executes production save/load and checks weapon/target receipt, health, memory and exact position (`:126-160`). `fc_p10_process_smoke.gd:239-286,440-500` seeds distinct home/away summaries and compares complete JSON-wire `home_combat`, `away_combat` and `active_combat` from a new process, covering `state`, `previous_state`, position, memory and attack receipt together with exact traveled owner/route. Combined focused predicates satisfy the leaf; no umbrella assertion is required.
- Data/save: strict `threat-manager-2` validates the full manager/threat/detection/damage shape. ADR-0059 decisions 33-38 govern separate current home/visited owner authority.
- Status: `traced`.

### `FEATURE::docs/game/features/combat_threat_ai.md::68a82246f041`

**Criterion:** Threats path along layout floor graphs without tunneling through solid geometry (REQ-D-019).

- Route: every moving state goes through graph A*, ordered adjacent waypoints, model position/room update, then placeholder synchronization (`threat_manager.gd:132-196,443-526`; `ship_nav_graph.gd:206-221`; `threat_pathfinder.gd:12-56,97-123`). ADR-0054 makes compiler standing edges the current topology.
- Combined predicates: `ship_nav_graph_smoke` covers authored corridor/blocked shortcut/vertical/portal topology; `nav_solid_edges_smoke.gd:39-89` requires checked SOLID/LOCKED edges blocked and passable edges open with actual coverage; `threat_path_follow_smoke.gd:34-60` requires corridor movement; the main path smoke requires the live layout graph, distance closure and graph proximity.
- Boundary: narrower D-019 ATTACK/INVESTIGATE/FLEE destination assertions remain incomplete, and `farthest_point` has a separate confirmed defect. Those do not contradict this generic graph-versus-solid route constraint.
- Status: `traced`.

### `FEATURE::docs/game/features/combat_threat_ai.md::2053183b13ee`

**Criterion:** Fire / sealed hatch bulkheads affect path cost or connectivity (REQ-D-020).

- Route: the coordinator gathers burning room intensities and only unbypassed hatch pairs before every threat tick, then the manager resets/applies dynamic overlays. Fire multiplies matching edges, hatches set `BLOCKED_COST`, `neighbors` emits the changed graph, and A* consumes it (`playable_generated_ship.gd:9855-9896`; `threat_manager.gd:96-108`; `ship_nav_graph.gd:206-221,294-340`; `threat_pathfinder.gd:43-55`).
- Predicate gap: no validation script calls any of `apply_fire_costs`, `block_bulkhead`, `update_nav_dynamic_costs`, or `_refresh_threat_nav_costs`. Current nav smokes test static topology or an unmodified unique corridor. None proves a fire-cost detour, hatch disconnection, or resulting repath on matching authored rooms.
- Classification: connected source with missing dynamic assertion; this is not proof runtime is broken.
- Status: `source_mapped_validation_gap`.
