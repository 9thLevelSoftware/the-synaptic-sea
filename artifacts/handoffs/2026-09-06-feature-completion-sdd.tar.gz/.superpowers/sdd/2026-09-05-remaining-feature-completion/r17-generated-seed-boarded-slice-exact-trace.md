# R17 generated-seed-boarded-slice exact source trace (moving WIP)

Read-only source-audit draft pending root review. Generated 2026-09-05T21:58:59.6312341-04:00 from d850c26ab596b8130be57c8ba4024ef92617f61d. No tests were run. Full IDs and criterion strings were checked against `docs/game/inventory/feature_acceptance.json` and `docs/game/features/generated_seed_boarded_slice.md`.

## FEATURE::docs/game/features/generated_seed_boarded_slice.md::f57342dd120c

Criterion: Given the main scene hub, when the smoke boards via `travel_to_marker_id`, then `away_from_start` is true from `_attach_derelict_active` and the boarded layout is a generated wreck, not `coherent_ship_001`.

Status: `traced`.

Production trace: `PlayableGeneratedShip.travel_to_marker_id` delegates to `travel_to` (`scripts/procgen/playable_generated_ship.gd:2585-2594`). First travel selects an accepted preferred native seed through `_apply_first_run_contract_to_marker` (`:1821-1852`); `travel_to` runs the production TravelController/ShipGenerator path (`:8512-8569`), then `_attach_derelict_active` assigns the new scene root/current ship and sets `away_from_start=true` (`:2603-2612`).

Exact assertion: `scripts/validation/generated_seed_boarded_slice_smoke.gd:89-112` requires successful marker-id travel, away state, a new active ShipInstance/root, selected-marker identity, and the returned scene root. Lines `:121-157` require a loaded GeneratedShipLoader, built-layout/loader-layout equality, worldgen-v2 seed/archetype/program identity, and explicit rejection of a `coherent-proof-ship-001` identity.

## FEATURE::docs/game/features/generated_seed_boarded_slice.md::35e34f893efc

Criterion: Given that boarded layout, when nav/slots/wreck/objectives are read, then standing start→goal exists, at least one loot spec sits on an interior slot, wreck overlay is present for DAMAGED/WRECKED, and at least one objective spec exists.

Status: `traced`.

Production trace: the attached GeneratedShipLoader builds objective and loot specs in `load_from_documents` (`scripts/procgen/generated_ship_loader.gd:144-191`) and exposes the loaded layout and portal nodes. The live smoke evaluates the boarded structural plan through ShipNavGraph/ThreatPathfinder and the loader's actual specs/nodes.

Exact assertion: `scripts/validation/generated_seed_boarded_slice_smoke.gd:159-196` requires schema 1.2.0, structural plan, enclosure verdict, standing route, objective specs, loot on an interior slot, a DAMAGED/WRECKED condition, and native loaded breach evidence or fallback wreck evidence. The precise predicates are `_standing_start_to_goal` (`:286-330`), `_loot_on_interior_slot` (`:383-396`), and `_wreck_evidence_present` plus its native/fallback branches (`:399-513`).

## FEATURE::docs/game/features/generated_seed_boarded_slice.md::25685802fbc3

Criterion: Given 30 away `_process` ticks, when HUD/objective surface is queried, then `get_combined_system_status_lines()` is non-empty or `complete_objective_sequence_for_validation(1)` succeeds.

Status: `traced`.

Production trace: `PlayableGeneratedShip._process` (`scripts/procgen/playable_generated_ship.gd:11035`) advances away simulation through `_tick_present_ships` (`:11094`) and exposes the queried status/objective surfaces through `_combined_system_status_lines`/`get_combined_system_status_lines` (`:10877-10943`) and `complete_objective_sequence_for_validation` (`:1179`).

Exact assertion: `scripts/validation/generated_seed_boarded_slice_smoke.gd:198-218` performs exactly 30 `_process(0.1)` calls, proves away state remains active, proves run time and the present-ships cooldown advanced by 3.0 seconds, and then applies the criterion's exact OR predicate.

Counts: 3 registry leaves; 3 traced; 0 unresolved; 0 fresh executions.
