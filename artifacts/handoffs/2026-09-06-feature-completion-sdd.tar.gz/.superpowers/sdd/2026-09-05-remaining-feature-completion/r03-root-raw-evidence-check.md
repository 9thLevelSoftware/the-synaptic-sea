# R03 raw evidence verification

Checked frozen artifacts only; no Godot, test, runtime, Git, or index command
was run. The source and artifact hashes below were recomputed from disk.

## Focused suite

Artifact root:
`artifacts/feature-completion/R03-final-focused-suite-20260905-01`

* `summary.json` SHA-256 matches task-3-report.md:
  `31a279d803af565879e5bf8d9d44e4a777885f5249bc99cf73f30e8d686764d9`.
* The summary has 16 result entries, all `passed=true`; all 16 retained body
  stdout logs contain exactly one declared marker and all 16 body exits are 0.
  Independently counted raw body markers: **16**.
* All 16 body stderr logs are empty. Body Godot logs contain no diagnostics for
  15 cases. `title-failure` contains the two intentional diagnostic messages,
  each duplicated in stderr and the Godot log (four raw occurrences, two
  unique first-line diagnostics):

  ```text
  ERROR: PLAYABLE SHIP FAIL reason=smoke_forced_failure
  WARNING: TitleMain: gameplay boot failed (smoke_forced_failure) — returning to title
  ```

  The retained summary classifies exactly those two as
  `expected loader-failure injection only`; no other diagnostic was found.
* Every case has one passing probe marker in raw probe stdout, zero probe
  stderr bytes, and zero probe diagnostics. Every case has four environment
  values equal to its own case `home`; the 16 homes are distinct. Each probe's
  `resolved_user` marker contains its expected owned root.
* The title-failure raw stderr is 761 bytes and its body Godot log is 1,062
  bytes; this is expected diagnostic duplication, not an additional error.
  Other focused body stderr files are 0 bytes.

The focused summary flags `fresh_distinct_homes=true`,
`all_four_environment_exact=true`, and `passed=true`, matching the raw checks.

## Three-process proof

Artifact root:
`artifacts/feature-completion/R03-process-proof-final-20260905-03`

* `summary.json` SHA-256 matches the report:
  `1265cf735dfb4dae19be3c407c218d7c7ca47a69fd90ee14bac634fbac6518f0`.
* Producer, consumer1, and consumer2 each have exit 0, one process marker,
  zero diagnostics, empty body stderr, and empty probe stderr. Raw body marker
  count is 3; raw probe marker count is 3.
* Their probe stdout/logs contain one `FC P10 USER DATA PROBE PASS` each. The
  resolved user paths are inside the distinct producer, consumer1, and
  consumer2 roots recorded in `mode_user_data_dirs`; normalized slash/case
  comparison confirms containment.
* `source_drift_detected=false` and `passed=true` agree with the raw process
  rows. The retained producer/consumer stdout contains only expected Godot
  bootstrap plus the mode marker; all `unexpected_stdout` and
  `unexpected_stderr` arrays are empty.
* Recomputed artifact hashes match the report and summary:
  `baseline.world.json` =
  `c63fbd45c6ff7b68460a18e09e4d47b42fca7b9143d0590a8d09b4c32a07e6d1`,
  `expected-observations.json` =
  `20110f97de1581a4e58acaccb1a88bd6c65ac176b02b9cf4f52e16cdfcc4c3a9`,
  and `post-collection.world.json` /
  `post-collection-manifest.json` exist with the hashes recorded by the
  process summary.

## Hash verification

The final source manifest table in task-3-report.md contains **20** rows. Every
listed current file exists and its recomputed SHA-256 equals the declared
Frozen final SHA-256. The four evidence hashes cited above also match. No
source-hash mismatch was found.

## Disposition

Raw evidence is internally consistent with the report: 16 focused cases and 3
process modes, one marker per body, one probe per case/mode, and no unexpected
diagnostics. The only accepted diagnostic is the title-failure injection's two
unique first lines. This report verifies artifacts; it does not independently
re-accept the feature or replace the coordinator's frozen-source review.
