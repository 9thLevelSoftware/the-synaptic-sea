# R10-A runner independent review

**SpecPASS. QualityNeedsWork.**

Reviewed full current source for `tools/run_r10a_docking_smokes.py` and
`tests/test_r10a_docking_runner.py`, the complete
`run_feature_completion.execute_isolated_case` contract, and the R10-A report
and its cited before/after manifests. No runtime or Godot command was run.

The adapter defines exactly the fifteen mandatory docking/save/ceiling
prerequisites and excludes `fc_p09_natural_route_smoke.gd`; that R04 case is
therefore not promoted by this aggregate. Each case is sent through the
hardened `execute_isolated_case` seam with a distinct `user-data/<case-id>`
home. The inherited seam creates and verifies the separate containment probe
and supplies APPDATA, LOCALAPPDATA, GODOT_USER_PATH, and XDG_DATA_HOME.

The adapter requires a brand-new evidence root, retains per-case result JSON,
raw stdout/stderr on successful claims, the inherited probe evidence, summary,
and byte/SHA-256 records. A failed hardened result is returned unchanged;
specifically, a missing planned script remains failed with its `missing script`
reason and cannot become a pass. A successful claim is independently rejected
when retained output is absent, the exact marker is absent, or it occurs more
than once. Aggregate PASS is emitted only when all 15 results pass.

For the two `%`-formatted smokes, the explicit complete all-true lines are
correctly used. The remaining cases use the shared
`build_feature_acceptance._smoke_marker` helper. The tests cover the 15-case
order and distinct homes, planned-missing failure, duplicate marker, the two
formatted expected markers, false/truncated/prefix marker output, no promotion
of a hardened failure, missing-output handling, and fresh-root rejection.

Quality finding requiring correction: the report cites
`task-10a-runner-fix-afterimages/manifest.json` as the afterimage for these
files, but its recorded hashes and byte counts do not match the current files:

| File | Manifest (bytes / SHA-256) | Current (bytes / SHA-256) |
| --- | --- | --- |
| `tools/run_r10a_docking_smokes.py` | 7113 / `c47363c2968e0aee49755827605c747bebe5f2fd92440d3c38d867e339e8338b` | 6664 / `3c768a07c8505715662dffe382a8fd6813e3f4ef672c3102a065cd71a978a5ac` |
| `tests/test_r10a_docking_runner.py` | 6432 / `3296de9b026873c134c26d6de00ce51642759deac82a9481e72659db974ce9de` | 8012 / `50409a97970c2c201c1d32092bf0ae249d7bed8f993bb873c0acb105e90dfe3b` |

Regenerate or add a new immutable afterimage manifest for the exact current
files and update `task-10a-runner-report.md` before treating the report as
complete evidence. This is an evidence-integrity/documentation defect; it does
not change the current runner's spec disposition above.
