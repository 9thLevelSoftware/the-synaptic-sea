# R19 Godot 4.7.2 Mono export-template acquisition

Acquisition was authorized as a bounded prerequisite step for R19. No Godot
binary, editor, export, project configuration, preset, test, or network setting
was run or changed.

## Source and acquisition

- Official release listing: <https://github.com/godotengine/godot-builds/releases/expanded_assets/4.7.2-stable>
- Direct official asset URL:
  `https://github.com/godotengine/godot-builds/releases/download/4.7.2-stable/Godot_v4.7.2-stable_mono_export_templates.tpz`
- Asset: `Godot_v4.7.2-stable_mono_export_templates.tpz`
- Download command: PowerShell `Invoke-WebRequest -Uri <official-direct-url> -OutFile <unique-cache-partial> -UseBasicParsing`, followed by an atomic same-cache `Move-Item` to the final archive name.
- Destination archive (outside the plan SDD directory):
  `D:/the-synaptic-sea-feature-completion/.superpowers/toolchains/godot-4.7.2-mono/Godot_v4.7.2-stable_mono_export_templates.tpz`
- Existing-cache check: cache directory and final archive were absent before acquisition; the unique partial path was also absent. No existing file was overwritten.
- Disk check: D: free bytes before download `1,863,894,728,704`; after extraction `1,862,410,338,304`.
- Observed archive completion timestamp: `2026-09-06T16:07:14.3111945Z` (filesystem UTC).
- Archive size: `1,202,598,411` bytes.
- Expected SHA-256: `92f8681e349ef1f90891b792da95e3b2b0bd1ed610b78018c58feb2d87e15a9d`.
- Verified SHA-256: `92f8681e349ef1f90891b792da95e3b2b0bd1ed610b78018c58feb2d87e15a9d`.

The exact official checksum matches. No mirror, substitute version, or TLS
override was used.

## Safe archive inspection

The archive was inspected with the scoped Python runtime’s standard-library
`zipfile` reader; it was not broadly extracted. It contains 27 entries under
`templates/`. `templates/version.txt` reads exactly:

```text
4.7.2.stable.mono
```

Windows entries present:

```text
templates/windows_debug_arm64_console.exe
templates/windows_debug_arm64.exe
templates/windows_debug_x86_32_console.exe
templates/windows_debug_x86_32.exe
templates/windows_debug_x86_64_console.exe
templates/windows_debug_x86_64.exe
templates/windows_release_arm64_console.exe
templates/windows_release_arm64.exe
templates/windows_release_x86_32_console.exe
templates/windows_release_x86_32.exe
templates/windows_release_x86_64_console.exe
templates/windows_release_x86_64.exe
```

Native platform entries are available for Android, iOS, Linux arm32/arm64/x86_32/x86_64,
macOS, and Windows arm64/x86_32/x86_64, including Windows debug and release
variants. The Windows x86_64 release template required by the supported Windows
target was extracted through an absolute, traversal-safe destination check to:

`D:/the-synaptic-sea-feature-completion/.superpowers/toolchains/godot-4.7.2-mono/extracted/windows_release_x86_64.exe`

The original archive remains preserved. Extracted release template size is
`109,513,728` bytes and SHA-256 is
`16e0ec3cfd398b938f514de95ff2474b532b5061ada78f92226dba3f7584d55d`.

This acquisition removes the previously confirmed absence of the official
4.7.2 Mono template asset from the bounded readiness inventory. It does not
install templates into a default user profile, prove Godot’s template discovery
path, prove native extension loading in an exported executable, or satisfy R19
export and offline-playthrough acceptance. Official Godot 4.7 Windows guidance
supports either the standard `%APPDATA%\\Godot\\export_templates\\<version>`
layout or a Windows preset `custom_template/release` path; see the [Windows
export platform reference](https://docs.godotengine.org/en/4.7/classes/class_editorexportplatformwindows.html)
and [Windows template installation guidance](https://docs.godotengine.org/en/4.7/engine_details/development/compiling/compiling_for_windows.html).
An isolated-profile or custom-template arrangement may use this owned cache
without implying default-profile installation or additional user approval.
