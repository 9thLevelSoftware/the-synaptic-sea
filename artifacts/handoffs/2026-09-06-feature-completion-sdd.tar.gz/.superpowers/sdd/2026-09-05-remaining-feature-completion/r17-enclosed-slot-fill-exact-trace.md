# R17 enclosed-slot-fill exact source trace (moving WIP)

Read-only source-audit draft pending root review. Generated 2026-09-05T21:58:59.6312341-04:00 from d850c26ab596b8130be57c8ba4024ef92617f61d. No tests were run. Full IDs and criterion strings were checked against `docs/game/inventory/feature_acceptance.json` and `docs/game/features/enclosed_slot_fill.md`.

## FEATURE::docs/game/features/enclosed_slot_fill.md::043117554d29

Criterion: Given a generated room with `interior_zones`, when the slice builds, then loot `approach_cell` equals a center or wall slot and is not the first `floor_cell_*` unless that cell is the chosen slot.

Status: `traced`.

Production trace: `GameplaySliceBuilder.build` (`scripts/procgen/gameplay_slice_builder.gd:50-165`) calls `_pick_slot_cell` for each loot row. `_pick_slot_cell` (`:368-408`) calls `_pick_loot_slot`, which selects an unblocked, unreserved center slot before a wall slot (`:411-437`); only an empty slot result reaches the serialized first-eligible-floor fallback (`:392-405`).

Exact assertion: `scripts/validation/enclosed_slot_fill_smoke.gd:193-205` rejects a synthetic loot row on the first floor or outside center/wall slots. The generated-layout check at `:515-538` requires slot loot and rejects a non-slot first-floor dump.

## FEATURE::docs/game/features/enclosed_slot_fill.md::e0b84db22a11

Criterion: Given `interior_zones` present, when components populate, then placements store parsed slot cells and markers sit on those cells.

Status: `partially_traced_unresolved`.

Production trace: `PlayableGeneratedShip._restore_or_populate_component_placement_for_current_ship` (`scripts/procgen/playable_generated_ship.gd:9600-9659`) calls `ComponentPlacementState.populate` (`scripts/systems/component_placement_state.gd:38-65`). `_fill_slots` parses `slot_info.cell` and stores the parsed value in `entry.cell` (`:112-193`). `_rebuild_component_markers` resolves that entry through `_component_marker_world` and assigns `marker.position` (`scripts/procgen/playable_generated_ship.gd:4856-4912,5864-5884`).

Exact assertion and gap: `scripts/validation/enclosed_slot_fill_smoke.gd:225-243,557-574` proves populated placement cells are parseable room slots and avoid occupied loot/objective cells. `scripts/validation/component_markers_smoke.gd:63-89` checks marker count, imported visual presence, and dismount rebuild, but never compares a marker position with its stored slot cell. The marker-position half remains unresolved.

## FEATURE::docs/game/features/enclosed_slot_fill.md::13fe5a5526f2

Criterion: Given a dressed room, when the loader applies visuals, then `DressingProp_<room>_<index>` instances exist and lights/fog remain at room center.

Status: `partially_traced_unresolved`.

Production trace: `GeneratedShipLoader.load_from_documents` invokes `_apply_dressing_visuals` (`scripts/procgen/generated_ship_loader.gd:144-229`). That method creates `DressingVisuals`, derives the room center, places `DressingLight_<room>` at center plus the vertical light offset, places `DressingFog_<room>` at center plus the vertical fog offset, and delegates wall-slot prop creation (`:1568-1645`).

Exact assertion and gap: `scripts/validation/enclosed_slot_fill_smoke.gd:605-663` requires `DressingVisuals`, `DressingLight_cargo_01`, and at least one `DressingProp_cargo_01_*` with visual-only collision policy. It does not assert light position, require a fog node, or compare fog position with the room center. Prop existence is covered; light/fog center placement remains source-mapped only.

Counts: 3 registry leaves; 1 traced; 2 unresolved; 0 fresh executions.
