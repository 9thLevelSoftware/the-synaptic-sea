# R17 hallucination save remediation design

## Audit scope and snapshot

- Purpose: architecture preparation for `REQ-SV-002::acceptance-a75c0ceb86c3`, the confirmed conflict between ADR-0042 and the current save path.
- Repository: `D:/the-synaptic-sea-feature-completion`
- Snapshot time: `2026-09-06T04:25:42.6546336Z`
- Snapshot HEAD: `17d9d3b11177b8c7d70d07d113ce5e9c038a513b` (`refs/heads/codex/feature-completion`)
- Source state: moving WIP under R02/R03; this document is source review and a proposed transition, not implementation or fresh runtime evidence.
- Files changed by this audit: this design report only.

## Decision requested

Allocate `gate2-current-run-7` and `world-7`. Remove `hallucination_summary` from the new run format, stop copying `HallucinationDirector.get_summary()` into a run snapshot, and stop applying that summary during load. The version-6-to-version-7 migration must explicitly validate the recognized legacy value and remove it on a detached copy. A run-7 payload that contains the key—including an empty dictionary—must reject rather than silently ignore it.

This is the smallest authority-consistent implementation. It restores both parts of ADR-0042's contract: no transient `RunSnapshot` field and no event, timer, RNG-step, tier, or cosmetic state crossing a save/load boundary. The current count deliberately moves from 32 to 31. The migration and current decoder keep staged recapture exact; they do not add a second comparison exception beside the one ADR-0059 permits for derived oxygen context.

Do not reinterpret version 6 in place. Existing version-6 saves need the explicit paired migration even though the destination carries one fewer field.

## Binding architecture found

ADR-0042 is accepted authority. Its lines 21–25 say hallucination events are ephemeral, rederive from persisted sanity on load, and that `HallucinationDirector.get_summary()` / `apply_summary()` exist for pure round-trip testing rather than autosave. Lines 121–123 require a load during an episode to start clean. Durable sanity remains in `RunSnapshot.sanity_summary`; durable vitals, radiation, temperature, and status effects remain separate run summaries.

No later accepted ADR found by this audit explicitly supersedes ADR-0042's persistence decision. `docs/game/audits/2026-07-06-e2e-foundation-audit.md` later requested and records implementation of `hallucination_summary` persistence, but it is an audit/remediation record, not an ADR, and it does not declare ADR-0042 superseded. The current registry criterion repeats the ADR rule verbatim: “Hallucination events are not persisted; they re-derive from the already-saved sanity value on load.” The newer audit explains how the drift entered the code; it does not supply authority to retain it.

The current implementation violates that boundary in two paired places:

- `scripts/systems/run_snapshot.gd` declares `hallucination_summary`, includes it in `SUMMARY_FIELDS`, emits it from `to_dict()`, and reads it in `from_dict()`.
- `scripts/procgen/playable_generated_ship.gd` captures `hallucination_director.get_summary()` while building a run snapshot and calls `apply_summary()` during restore.

The persisted value contains `seed`, `step`, direct-teeth tuning, `active_events`, `spawn_timers`, `current_tier`, and `pool_loaded` (`scripts/systems/hallucination_director.gd:220`). The director's existing `apply_summary()` is intentionally permissive: it supplies defaults and skips malformed event/timer entries. It is therefore suitable for the ADR-authorized pure-model round-trip, but it is not a strict legacy-save validator.

The current save family is run 6/world 6:

- `SaveLoadService.CURRENT_SLICE_VERSION` is `gate2-current-run-6`.
- `WorldSnapshot.WORLD_SLICE_VERSION` is `world-6`.
- `SaveMigrationService` targets that pair, recognizes ordered run 1–6 and world 1–6 chains, and pins `world-6` to an embedded run 6.
- `WorldSnapshot.from_dict()` and `SaveRestoreCandidate.build()` independently pin the embedded current run to run 6.

ADR-0059 decision 33 makes the v5-to-v6 migration detached and one-way. A payload already declaring run 6 receives no v5 defaults or downgrade. The world v5-to-v6 step is the only step that may migrate its embedded home run, and world 6 requires run 6. These rules mean that tightening or changing the meaning of version 6 would either reject formerly accepted version-6 saves or normalize a current payload without an explicit migration. A new paired version is required.

ADR-0059 decision 29 also requires restore to apply and recapture all persisted authoritative summaries before publication. The canonical comparison in `scripts/procgen/playable_generated_ship.gd:755` removes metadata and only the exact derived path `home_ship.oxygen_summary.player_in_breach_zone`. All other values are compared exactly, with mismatch reported as `staged_world_authority_mismatch`. Hallucination remediation must continue to pass through that exact comparison; it must not add a hallucination exclusion.

## Options compared

| Option | Compatibility and strictness | Churn and accounting | Disposition |
|---|---|---|---|
| Run 7/world 7 with the field removed | Version 6 is explicitly validated and migrated; version 7 explicitly forbids the key. The migrated expected world and recaptured world both omit it, so comparison stays exact. | Removes one `SUMMARY_FIELDS` entry and changes current count 32→31, including exact markers and documentation. | **Recommended.** It follows accepted ADR-0042 without a compatibility exception. |
| Run 7/world 7 with required-empty `hallucination_summary` | Version 6 can migrate to `{}`, and version 7 can validate exact emptiness without a comparison exception. | Keeps count 32 but retains a RunSnapshot field that ADR-0042 explicitly rejected. | Technically safe, but reject absent a later accepted ADR that authorizes the tombstone. No such authority was found. |
| Change run 6 capture to empty or omit the field on load | Existing run-6 payloads have no migration boundary. A nonempty old expected world would recapture differently and fail unless code silently normalized or excluded the field. | Appears small but breaks current-version semantics or exact comparison. | Reject. |
| Keep persisting nonempty director state but start clean after load | Leaves forbidden transient content on disk. Exact recapture fails unless a broad exception hides the difference. | Retains the conflict and weakens validation. | Reject. |
| Make run 6 require empty immediately | Previously accepted run-6 saves become invalid with no recognized legacy transition. | Compatibility break disguised as validation. | Reject. |

## Recommended run-7 contract

`hallucination_summary` is absent from the run-7 model, `RunSnapshot.SUMMARY_FIELDS`, and serialized output. `get_summary_count()` becomes 31 under the current counting rule. ADR-0042's historical count of 26 described the format at that ADR's time; it does not freeze the later aggregate count at 32.

For a payload declaring `gate2-current-run-7`:

1. Absence of the key is the only valid current representation.
2. Presence of the key fails with a specific reason such as `hallucination_summary_forbidden`, regardless of its value.
3. The explicit forbidden-key check is required because the broader decoder currently tolerates unknown keys. Removing only the property/read/write sites would silently ignore a saved current episode.
4. The current-version decoder performs no legacy normalization or key removal.
5. `to_dict()` cannot emit the key because no run-7 property or summary entry exists.

Run 7 otherwise carries forward the complete run-6 contract. The R02 combat structure and the R03 system-condition/component-placement authority remain exact. The transition changes only hallucination persistence semantics.

## Explicit legacy migration

Append, rather than replace, these migration nodes:

- run: `gate2-current-run-6` → `gate2-current-run-7`
- world: `world-6` → `world-7`
- pair map: retain `world-6` → run 6 and add `world-7` → run 7

The run step operates on a detached deep copy and does the following:

1. Confirm the source declares run 6.
2. If `hallucination_summary` is absent, accept that recognized historical additive omission and leave it absent. Version 6 currently decodes absence as the empty default, so rejecting this historical shape would be a new incompatibility.
3. If the key is present, require a dictionary. Validate it against the known version-6 legacy envelope before discarding it. Accept `{}` and every historically emitted version-6 shape; reject malformed present content with a specific reason.
4. Erase the validated legacy key explicitly.
5. Stamp run 7. Leave all other fields byte-equivalent in the detached logical value.
6. Let the final run-7 decoder enforce the complete current structure.

The legacy validator should be a small pure migration helper, not a call to `HallucinationDirector.apply_summary()`. At minimum it must check the emitted top-level types (`seed`, `step`, the two numeric tuning values, `active_events`, `spawn_timers`, `current_tier`, and `pool_loaded`) and the event/timer value shapes that the repository actually emitted under version 6. Known optional narrative event keys may be accepted where history shows they were additive. It must not skip malformed members, coerce arbitrary strings to numbers, or convert an unknown envelope to `{}`. Before implementation, enumerate existing version-6 fixtures and source history to encode all legitimate historical variants explicitly.

The world step must validate a world-6/home-run-6 pair, migrate only its embedded home run through the run-6-to-run-7 step, stamp world 7, and preserve every visited-ship and world field. A declared world 7 must require embedded home run 7 exactly. Source dictionaries and source bytes remain unchanged; backup/sidecar behavior remains limited to the existing explicit save/load actions.

### Intermediate-version ordering hazard

The migration chain must finish the v6→v7 hallucination removal before any current run-7 decoder sees the payload. A legitimate v5 or v6 legacy payload may contain `hallucination_summary`; routing that intermediate dictionary through `RunSnapshot.from_dict(..., gate2-current-run-7, ...)` would trigger the new forbidden-key check before the authorized migration can remove it.

One current concrete trap is `SaveMigrationService._migrate_world_v5_to_v6_result()`: it calls `_migrate_world_home_ship(dict, TARGET_VERSION)`. When `TARGET_VERSION` changes to run 7, leaving that call symbolic would make the nominal world-5→world-6 step migrate its home directly to run 7, breaking the world-6/run-6 intermediate pair and bypassing the intended step boundary. Pin that helper to literal run 6. Add a separate world-6→world-7 step that invokes the run target 7 migration. Likewise, any R02/R03 helper added around v5→v6 that decodes an intermediate run must use the literal source/intermediate version and its version-specific validation, not the new current constant.

The ordered path must be:

1. v5→v6 preserves a legitimate hallucination key while applying only its existing crafting/combat/condition work;
2. v6→v7 validates and removes that key;
3. only then does the final run-7 decoder enforce `hallucination_summary_forbidden` and all carried-forward R02/R03 constraints;
4. world migration performs the analogous world5/home5 → world6/home6 → world7/home7 sequence before `WorldSnapshot.from_dict()` and `SaveRestoreCandidate.build()` decode the current pair.

This ordering needs a chained v5 fixture containing a legitimate legacy hallucination envelope, in addition to direct v6→v7 coverage. It should prove the key survives the v5→v6 intermediate step, is removed only by v6→v7, and never reaches current decode.

## Capture, restore, and rederivation

Current capture must stop assigning `hallucination_director.get_summary()` to the run snapshot. The run-7 model and encoder no longer have a destination for it. The current decoder's forbidden-key check catches serialized input that attempts to reintroduce the episode.

Current restore must not call `hallucination_director.apply_summary()`. It restores durable `sanity_summary` and the other survival summaries as it does today.

Construction alone is not a sufficient cleanliness guarantee. A staged or newly built gameplay instance can execute tick-like helpers before publication, and a reused renderer can retain projections. Restore therefore needs an explicit late publication-boundary reset after the durable sanity value is applied and before recapture/readiness/activation:

- reset the director episode to `step = 0`, no active events, no spawn timers, `_next_id = 1`, and tier 0;
- preserve its configured ship seed, direct-teeth tuning, manifestation pool, and kind schedule rather than replacing them with generic defaults;
- clear every phantom node and false-HUD projection, set hallucination FX intensity to zero, and reset renderer edge/cooldown state (`_prev_hud_active` and `_ambient_cooldown`), not only the phantom dictionary;
- refresh or clear the coordinator's rendered hallucination status lines before the instance is marked staged-ready or published; and
- keep processing fenced until that reset is complete, so tier-3 health drain or stamina suppression cannot affect vitals before the first tick using restored sanity.

The current `_build_hallucination_runtime()` creates/configures a fresh director and manager, and `_reset_runtime_for_reload()` calls `hallucination_manager.clear_all()`. Those are useful defenses, but neither proves the late boundary: `clear_all()` currently clears phantom nodes and FX intensity but not the manager's ambient cooldown or prior-HUD edge flag. Prefer explicit pure `reset_episode()` / projection-reset operations whose postconditions can be asserted. On the next normal simulation tick after publication, the director may derive tier and start a new schedule from restored sanity and the preserved seed/configuration. A safe-zone tick continues to force tier zero and clear events.

The pure director API and `hallucination_director_smoke.gd` round-trip coverage remain. That API is useful for deterministic model tests; removing it would exceed the problem and contradict ADR-0042's explicit allowance.

## Exact staged restore remains intact

The expected world passed to staged restore is already the migrated world-7 value and therefore omits `hallucination_summary`. Recapture from the staged gameplay instance omits it as well. The existing canonical comparison should compare the complete worlds normally.

Do not:

- erase `hallucination_summary` inside `_canonical_restore_world()` (it must already be rejected or migrated before comparison);
- add hallucination fields to a generic “derived” allowlist;
- compare only selected survival summaries;
- accept any current payload containing the forbidden key and clear it after decoding; or
- suppress `staged_world_authority_mismatch` for this path.

The ADR-0059 oxygen projection remains the sole comparison exception. Any run-7 hallucination key should fail before staged application. Drift in sanity, vitals, combat, system condition, inventory, or any other authoritative field must remain visible to the full comparison.

## Validation transition required for implementation

Fresh execution is outside this source-only design. The implementation scope should update meaningful predicates in this order:

1. **Run migration purity and rejection.** Prove a valid run-6 payload with nonempty events/timers becomes run 7 with the key absent; a historically valid run-6 payload with the key absent remains absent; malformed present legacy content rejects; the source object/bytes remain unchanged; an already-current run-7 payload receives no legacy normalization.
2. **Current run strictness.** Prove absence accepts and any presence—including `{}`, wrong-type, or nonempty content—rejects with `hallucination_summary_forbidden`. Keep existing run-6 combat and R03 condition/placement values unchanged through migration.
3. **World pairing.** Prove world 6/home run 6 migrates to world 7/home run 7, world 7 requires run 7, mismatched pairs reject, and visited/world data remains exact.
4. **Behavioral save/load and publication reset.** Begin with nondefault durable sanity/vitals and live hallucination events/timers. Prove the disk home snapshot omits the field and the restored durable summaries are exact. Deliberately contaminate or advance the staged director/manager before the late restore reset, then prove staged recapture and the publication boundary have step 0, tier 0, no events/timers/phantom nodes/false-HUD lines, zero FX, reset render edge/cooldown state, preserved seed/config, and neutral direct teeth. Only the first normal post-publication tick may derive a new tier/schedule from restored sanity; it must not recover old IDs, timers, or RNG step. Keep the pure-director round-trip test as a separate model test.
5. **Full recapture.** Prove no new canonical exception exists, a current payload containing the forbidden key rejects before publication, and unrelated authoritative drift still yields `staged_world_authority_mismatch`. Retain the existing predicates that only `player_in_breach_zone` is normalized and that unrelated oxygen drift and sub-ULP differences remain visible.
6. **Version/future fixtures.** Preserve `p10_run_v6_future.json`, `p10_world_v6_future.json`, `p10_run_v7_future.json`, and `p10_world_v7_future.json` as historical artifacts. Add run-8/world-8 future-rejection fixtures for the new current pair. Do not overwrite the old v7-future files into valid current examples; add explicit valid run-7/world-7 fixtures where needed.
7. **Count and markers.** Deliberately change `get_summary_count()` from 32 to 31 and update `save_load_service_smoke.gd`, `ship_mod_run_snapshot_smoke.gd`, `pillar_persistence_smoke.gd`, and any validation text that treats 32 as current. Replace the existing nonempty hallucination round-trip assertions with the absence/clean-load predicates above.

Version literals and pair constraints appear in `save_load_service.gd`, `save_migration_service.gd`, `world_snapshot.gd`, `save_restore_candidate.gd`, production coordinator checks, and multiple persistence smokes. They must move atomically. Avoid introducing a dependency cycle merely to centralize constants; if the current layering cannot share one constant safely, update the exact pins together and retain cross-check predicates.

## Empty-projection alternative

An explicitly empty run-7 compatibility field is technically workable: validate it as required and exactly `{}`, migrate old data to `{}`, and compare it exactly during staged recapture. It reduces count-marker churn. It is not recommended because the accepted ADR rejects a transient `RunSnapshot` field and no later accepted ADR was found to authorize a tombstone. Adopting it would require a deliberate ADR supersession or amendment; a test or audit record alone is insufficient authority.

## Authority and implementation gate

Existing accepted ADR-0042 authorizes literal field removal and the registry repeats that behavior. No newer accepted authority found here intentionally overrides it. Before implementation, governance still needs to allocate/document the new run-7/world-7 format and its explicit migrations under the repository's Stage-Gate process; that record should cite ADR-0042 rather than create a persistence exception.

The implementation must preserve durable sanity/vitals, the pure director round-trip API, explicit detached v6→v7 and world6→world7 migrations, current-version forbidden-key validation, exact staged recapture, and ADR-0059's sole derived oxygen exception. No save-schema change should begin by changing version-6 meaning or weakening the comparison.
