# R17 ENC exact source trace

Snapshot: `2026-09-05T23:10:50.8254653-04:00` at source revision `ed70d37198000529cb8baa5217414f74a0372090`. The source is moving WIP under R03. This was a read-only source audit: no tests ran, and no Git, registry, semantic-index, governance, runtime, or evidence state changed.

## Selection

`docs/game/inventory/feature_acceptance.json` contains exactly **16** rows where `domain == "enc"` and `deferred == false`, matching the expected count. All 16 have no `canonical_id` or `alias_of`, are their own metric-equivalence representative, and count as one. None appears in `r17-source-trace-index.json.semantic_trace_reports`; all 16 appear only as group-retrieval anchors, so semantic exclusion removes zero.

The status totals are: **7 traced**, **3 static-constraint traced**, **4 source-mapped validation gaps**, **1 accepted-ADR pending**, and **1 process-history partial**. “Traced” means an exact current source path plus a substantive existing predicate, without a fresh run. Static schema and negative architecture constraints may be established by direct review; dynamic claims are not promoted from source mapping or PASS strings.

## Exact leaves

### 1. `REQ-ENC-001::acceptance-1e4fddecc61e`

> Every generated room is a non-empty 4-connected integer cell set on the 4 m grid.

**Trace — traced.** `ShipLayoutGenerator._generate_once` calls `CellLayoutEngine.layout` (`ship_layout_generator.gd:96-130`). The engine grows and commits `Vector2i` cells and stores exact cells plus bounding footprint (`cell_layout_engine.gd:624-725,779-807`); its grid constant is 4 m. `cell_layout_engine_smoke.gd:101-110,296-312` requires each room to be nonempty and 4-connected. `procgen_structural_compiler_smoke.gd:102-131` rejects non-integer cells and duplicate occupancy across production seeds. ADR-0064 permits nonrectangular rooms, so rectangular cell-count equality is not treated as the general invariant.

### 2. `REQ-ENC-001::acceptance-4ffa0b5ebe6b`

> Template-declared connections become shared cardinal edges or vertical connections.

**Trace — traced.** `CellLayoutEngine.layout` builds its connector graph from `template.connections`, grows same-deck rooms to touch, and emits same-deck/vertical adjacencies (`cell_layout_engine.gd:46-93,120-195,810-874`). The exact predicates in `cell_layout_engine_smoke.gd:112-177` require owned Manhattan-cardinal endpoints and every declared entry/spine/side/destination connector. Its stacked-v2 case at `:186-260` requires the elevator-to-upper-hub declaration and full-pipeline vertical connection.

### 3. `REQ-ENC-001::acceptance-7312666ee245`

> No live path spaces rooms by `CELL_SIZE + ROOM_GAP`.

**Trace — static-constraint traced.** The production path is `ShipLayoutGenerator -> CellLayoutEngine -> LayoutSerializer -> StructuralEdgeCompiler`; it uses cardinal integer growth and 4 m coordinate conversion. Direct review finds no `ROOM_GAP` in that path, `LifeBoatBuilder`, or `GeneratedShipLoader`. `socketed_enclosure_smoke.gd:123-130` also rejects the symbol in the three named generation/hub files. This negative architecture constraint does not need a test that mirrors every call name.

### 4. `REQ-ENC-001::acceptance-b0e21d188f38`

> `CellLayoutEngine.layout()` output shape (`rooms`, `adjacencies`, footprints) remains the input to serialization.

**Trace — static-constraint traced.** `ship_layout_generator.gd:126-139` assigns `cell_grid` from `CellLayoutEngine.layout` and passes that same value to `LayoutSerializer.serialize`. The engine returns `rooms` and `adjacencies`, with each room carrying cells and footprint (`cell_layout_engine.gd:87-93,779-807`); serializer reads those exact collections (`layout_serializer.gd:30-35,47-79,102-166`). `layout_serializer_smoke.gd:7-27,63-124` exercises the same input shape and output schema.

### 5. `REQ-ENC-002::acceptance-5bd2ebbd4f1e`

> The compiler loads `ModularAssetSpec` contracts for the layout `kit_id` and chooses `module_id` by socket match.

**Trace — source-mapped validation gap.** Both generated ships and the lifeboat call `StructuralEdgeCompiler.compile`. It reads `layout.kit_id`, loads `ModularSocketCatalog`, and requests module kinds (`structural_edge_compiler.gd:55-94,528-542`). The catalog reads `*_contract.json` under the requested kit and uses accepted ADR-0056’s v0 fallback (`modular_socket_catalog.gd:35-41,75-103,139-180`). The loader then resolves emitted module IDs into wrappers.

The exact universal socket-match conjunct is unverified. `socketed_enclosure_smoke.gd:112-120` only scans source strings. `choose_module` can return an existing preferred ID after no match (`modular_socket_catalog.gd:101-102`), and the t-junction branch selects by `has_module` rather than required socket kinds (`structural_edge_compiler.gd:94`). This is not source-only proof of a bad runtime layout, but no current predicate establishes that every emitted module was selected by socket match.

### 6. `REQ-ENC-002::acceptance-a41b8b3dcc91`

> Every occupied cell has a floor and a ceiling unless it is an authored vertical opening.

**Trace — traced.** Compiler emission is one floor per occupancy cell and one ceiling except at authored vertical-opening keys (`structural_edge_compiler.gd:144-182`). `StructuralPlanValidator` enforces exact floor coverage (`structural_plan_validator.gd:101-185`) and ceiling coverage for occupancy minus openings (`:188-261`). `procgen_structural_compiler_smoke.gd:47-85` requires that exact verdict on five production layouts. `main_playable_lifeboat_biome_skin_smoke.gd:99-117` separately requires the three-cell hub’s floors and ceilings to equal its occupancy.

### 7. `REQ-ENC-002::acceptance-355d5e79ea8a`

> Every exterior non-OPEN edge is a wall or portal with `socket_bindings`.

**Trace — source-mapped validation gap.** Compiler classification omits same-room OPEN boundaries, emits walls/portal states for materialized boundaries, computes socket pairs, and attaches a binding array to every record (`structural_edge_compiler.gd:184-297,447-525`). Validator rejects OPEN placements and missing required non-OPEN placements (`structural_plan_validator.gd:338-385`). `procgen_structural_compiler_smoke.gd:134-176` requires exactly one placement for every SOLID/DOOR/LOCKED/HATCH edge and none for OPEN.

The binding portion is not exact: `StructuralPlanValidator:264-294` and `socketed_enclosure_smoke.gd:216-230` require only a nonzero plan-wide/nested total. No predicate requires each exterior non-OPEN placement’s own `socket_bindings` to be nonempty, and compiler source permits an empty per-record array when no pair is found. This remains unverified rather than a declared runtime defect.

### 8. `REQ-ENC-002::acceptance-2c33d94d4db9`

> Vertices use corner / junction modules when those contracts match.

**Trace — source-mapped validation gap.** `_apply_vertex_modules` enumerates occupied-cell vertices and selects t-junction, inner-corner, or outer-corner IDs from incident solid edges and occupied quadrants (`structural_edge_compiler.gd:375-430`). The v0 contract catalog contains all three families. `socketed_enclosure_smoke.gd:231-241` only requires at least one such stem somewhere in each audited plan. No predicate enumerates every eligible vertex and checks the matching module, and no predicate covers the junction case specifically.

### 9. `REQ-ENC-002::acceptance-4391f6e631cf`

> Floor cardinal sockets are XZ cell-edge positions (north = −Z), and `floor_edge` is compatible with `wall_base`.

**Trace — traced.** The v0 floor contract authors north `[0,0,-2]`, south `[0,0,2]`, east `[2,0,0]`, west `[-2,0,0]`, with `floor_edge -> wall_base` compatibility. Wall/portal contracts expose reciprocal `wall_base`. `socketed_enclosure_smoke.gd:62-109` loads the actual contracts and asserts those exact coordinate arrays and compatibility entries. The compiler consumes those positions and compatibility rules at `structural_edge_compiler.gd:447-495`.

### 10. `REQ-ENC-002::acceptance-8a6a2f377a6b`

> New plan fields live inside `structural_plan`; `layout.json` schema_version stays `1.2.0`.

**Trace — static-constraint traced.** `LayoutSerializer` emits schema `1.2.0` and one nested `structural_plan` object (`layout_serializer.gd:143-166`). Compiler keys such as occupancy, edges, floors, ceilings, placements, and bindings remain within that object (`structural_edge_compiler.gd:299-307`), and the loader reads them there. `layout_serializer_smoke.gd:66-80` requires the canonical top-level schema/version, while `layout_schema_coherence_smoke.gd:28-59` requires all goldens to match the serializer shape.

### 11. `REQ-ENC-003::acceptance-8790cc5effa0`

> `LifeBoatBuilder.build_layout()` emits schema `1.2.0` with a validated `structural_plan` and portals on the two real shared edges.

**Trace — traced.** `LifeBoatBuilder.build_layout` authors cells at x=`-1,0,1`, two airlock-to-neighbor portal pairs, schema `1.2.0`, and then compiles and validates before attaching the plan (`life_boat.gd:93-184`). The validator requires named ownership, same-deck cardinal adjacency, a canonical portal edge, and a non-SOLID portal result (`structural_plan_validator.gd:412-474`). `main_playable_lifeboat_biome_skin_smoke.gd:66-117` requires identical occupancy/portal records across all three biome inputs and an ok validator result with exact floor/ceiling coverage.

### 12. `REQ-ENC-003::acceptance-f57615b5b76d`

> `LifeBoatBuilder.build()` instances that plan and does not call `StructuralPlacer.place_structure`.

**Trace — traced.** The actual main path calls `LifeBoatBuilder.build` with the resolved run biome (`playable_generated_ship.gd:10282-10297`). `build` instances all floor, edge, and ceiling plan groups through `_instance_plan_records` (`life_boat.gd:49-90,263-300`). `main_playable_lifeboat_biome_skin_smoke.gd:99-159` requires a one-to-one live wrapper for every compiled record, including module ID, wrapper path, position, and yaw. `life_boat.gd` has no `StructuralPlacer` preload or `place_structure` call, as required by accepted ADR-0053.

### 13. `REQ-ENC-003::acceptance-1db947f6dbf8`

> Enclosure rules in REQ-ENC-002 apply to the hub craft.

**Trace — source-mapped validation gap.** The live hub path is `PlayableGeneratedShip._build_lifeboat_at_home -> LifeBoatBuilder.build/build_layout`; it uses the same `StructuralEdgeCompiler`, `StructuralPlanValidator`, and record instancing contract as generated ships. `main_playable_lifeboat_biome_skin_smoke.gd:53-159` reaches the actual main-scene craft, validates its plan, and compares every compiled record to a live wrapper. `socketed_enclosure_smoke.gd:133-164` also audits the hub plan.

Because this leaf incorporates all REQ-ENC-002 rules, it inherits the exact gaps from leaves 5, 7, and 8: universal socket-matched choice, a nonempty binding on every exterior non-OPEN placement, and matching corner/junction use at every eligible vertex. Common-path source mapping does not by itself establish those dynamic conjuncts.

### 14. `REQ-ENC-004::acceptance-f7eb7a80329d`

> `kit_id` follows `KitCatalog` biome preference (`breach_field` → hazard kit, `dead_fleet` → industrial kit, default → `ship_structural_v0`) without changing occupancy.

**Trace — traced.** The main path resolves one run biome and passes it to both the live lifeboat build and retained layout (`playable_generated_ship.gd:10282-10297`). `LifeBoatBuilder._kit_id_for_biome` returns the three exact IDs (`life_boat.gd:211-218`). `KitCatalog` independently selects the highest affinity (`kit_catalog.gd:93-106,274-292`); the builder currently duplicates that outcome rather than invoking the catalog. `main_playable_lifeboat_biome_skin_smoke.gd:66-117` asserts all three IDs and exact occupancy/portal equality across them, and first checks the main-scene resolved biome at `:53-64`.

### 15. `REQ-ENC-004::acceptance-ade9bfe58154`

> No new hive / wreck meshes are required; kits remap existing stems.

**Trace — accepted-ADR pending.** Accepted ADR-0053 establishes the no-new-mesh non-goal, and the hazard/industrial kit files name existing role-module stems. Accepted ADR-0063 is controlling current authority for the rest: only `ship_structural_v0` currently provides the modular contract directory and wrapper map used by the compiler/builder, so hazard and industrial selections intentionally resolve v0 contracts/wrappers. `main_playable_lifeboat_biome_skin_smoke.gd:131-174` asserts compiled-record/live-wrapper identity and the v0 fallback.

The criterion is stale if “kits remap existing stems” means a completed live visual remap. ADR-0063 explicitly leaves that visual work pending. This audit preserves the static no-new-mesh constraint and the accepted pending disposition; it does not invent a requirement for new meshes.

### 16. `REQ-ENC-004::acceptance-8344c31c47cf`

> `socketed_enclosure_smoke.gd` is RED (`SOCKETED ENCLOSURE FAIL`) until REQ-ENC-001..003 pass, then prints `SOCKETED ENCLOSURE PASS` and is added to the regression bundle. It is not in the bundle while RED.

**Trace — process-history partial.** `socketed_enclosure_smoke.gd:41-59` accumulates concrete issues, emits FAIL and exits 1 when any remain, and emits PASS only when none remain. Its meaningful checks cover floor axes/contracts (`:62-109`), the ROOM_GAP constraint (`:123-130`), compiled lifeboat/generated plans (`:133-188`), and floor/ceiling/binding/corner presence (`:200-243`). `docs/game/06_validation_plan.md:652` currently registers its exact PASS marker.

The source snapshot cannot prove the historical RED/out-of-bundle chronology, and this audit did not run the smoke to establish a fresh PASS. Those are preserved as process/history uncertainty. The smoke’s source-string and aggregate checks also do not close the separate universal gaps above.

## Material findings

- Exact active ENC count is 16; semantic exclusion is zero.
- Exact existing predicates support seven dynamic leaves, while three architecture/schema leaves are established by static review.
- Universal socket-match selection, per-exterior-edge binding coverage, and every-eligible-vertex corner/junction coverage remain explicit validation gaps; no runtime defect is inferred from the absence of those tests.
- The hub uses the common compiler/validator/live-wrapper path and inherits those exact universal gaps.
- ADR-0063 records the current biome state: selected kit IDs and unchanged occupancy are implemented, while hazard/industrial visual remap remains v0 fallback and pending.
- The enclosure smoke is currently registered and conditionally emits PASS only after its checks, but historical RED sequencing and a fresh run are outside this source-only audit.
