# R17 Core First-12 Exact Trace

- Generated: `2026-09-05T22:13:39.2967092-04:00`
- Source revision: `d850c26ab596b8130be57c8ba4024ef92617f61d`
- Moving WIP: `true`
- Scope: source-only trace; no runtime/test execution, evidence promotion, Git, registry/index writes, or complete-game acceptance
- Registry filter: `domain == "core" && deferred == false`
- Active core rows: `49`
- Active core rows already present in `r17-source-trace-index.json` semantic mappings: `0`
- Selection: first 12 remaining rows in registry order, zero-based registry indices `365..376`, core orders `1..12`
- Result: `10 traced`, `2 source_mapped_authority_scope_partial`, `0 runtime defects found`, `0 fresh executions`

Selected IDs, in exact order:

1. `REQ-001::acceptance-a35dc8b62528`
2. `REQ-001::acceptance-abdcf1c155d3`
3. `REQ-001::acceptance-407899d3a48f`
4. `REQ-001::acceptance-ecbea31d3acf`
5. `REQ-002::acceptance-17a456e83d17`
6. `REQ-002::acceptance-ba74ffcf3f3e`
7. `REQ-002::acceptance-0362bb95e57b`
8. `REQ-002::acceptance-8db36b1d36d0`
9. `REQ-003::acceptance-0d344559690d`
10. `REQ-003::acceptance-f7221141b6f7`
11. `REQ-004::acceptance-b50b8ae1a4d1`
12. `REQ-004::acceptance-c3c36e7427af`

REQ-001 through REQ-003 and `docs/game/features/route_control.md` remain aligned; no later ADR found in the bounded search retires their behavior. REQ-004 names `docs/game/08_milestone_gates.md`, which is absent. ADR-0001 supplies current high-level validation governance and `docs/game/06_validation_plan.md` is the live smoke contract, but neither defines the full population meant by “new gameplay systems” or supplies the named review-card checklist. The two REQ-004 partials are authority/scope limits, not runtime defects.

Static source review establishes construction types, metadata presence, and validation/process wiring. Dynamic collision, objective, and completion behavior is credited only where existing smokes contain meaningful predicates. No fresh PASS is claimed.

## Exact leaf traces

### `REQ-001::acceptance-a35dc8b62528`

**Criterion:** A route gate exists as a runtime `StaticBody3D` node.

- Entry: `_on_ship_loaded` calls `_build_route_control_gates` at `scripts/procgen/playable_generated_ship.gd:10127,10188-10191`.
- Implementation: `_build_route_control_gates` converts loader blockers to parented route gates at `:1444-1468`; `_create_route_gate` constructs a `StaticBody3D` at `:1470-1499`.
- Predicate: `scripts/validation/main_playable_slice_route_control_smoke.gd:48-68` asserts the loaded main scene reports at least one gate and returns a runtime gate node. Static review of the sole builder establishes its class.
- Status: `traced`.

### `REQ-001::acceptance-abdcf1c155d3`

**Criterion:** It has a `CollisionShape3D` while closed.

- Entry: `_build_route_control_gates` installs the gate and applies initial scene state at `scripts/procgen/playable_generated_ship.gd:1457-1468`.
- Implementation: `_create_route_gate` adds a `CollisionShape3D` with `BoxShape3D` at `:1479-1488`; `_apply_route_gate_scene_state` keeps it enabled while closed at `:10845-10863`.
- Predicate: `main_playable_slice_route_control_smoke.gd:48-64` asserts no gate is initially open and at least one route-gate collision is enabled. The queried count at `playable_generated_ship.gd:11016-11025` counts enabled `CollisionShape3D` children only.
- Status: `traced`.

### `REQ-001::acceptance-407899d3a48f`

**Criterion:** It starts with collision enabled.

- Entry: `_build_route_control_gates` configures initially closed records and immediately applies them at `scripts/procgen/playable_generated_ship.gd:1466-1468`.
- Implementation: `RouteControlState.configure_from_blocked_routes` sets `open=false` at `scripts/systems/route_control_state.gd:11-22`; the scene applier enables collision for closed gates at `playable_generated_ship.gd:10845-10863`.
- Predicate: `main_playable_slice_route_control_smoke.gd:48-64` asserts zero initially open gates and at least one enabled gate collision; `:71-75` confirms the returned gate is closed and power-gated.
- Status: `traced`.

### `REQ-001::acceptance-ecbea31d3acf`

**Criterion:** It exposes inspectable metadata including route id and open state.

- Entry: `_build_route_control_gates` calls `_create_route_gate` with the generated route ID at `scripts/procgen/playable_generated_ship.gd:1461-1464`.
- Implementation: `_create_route_gate` sets `route_gate_id`, kind, required system, open, and cleared metadata at `:1476-1480`; the scene applier updates open/cleared on the retained node at `:10845-10858`.
- Predicate: `main_playable_slice_route_control_smoke.gd:66-75` inspects the live node's initial open/required-system metadata; `:112-118` inspects its open/cleared metadata after objective 2. Static review establishes the route-ID metadata field.
- Status: `traced`.

### `REQ-002::acceptance-17a456e83d17`

**Criterion:** Completing objective 1 does not open the route gate.

- Entry: completed interaction reaches `_on_interactable_completed` at `scripts/procgen/playable_generated_ship.gd:10683-10763`, then refreshes route control at `:10734-10749`.
- Implementation: objective 1 `recover_supplies` has no power repair in `OBJECTIVE_REPAIR_MAP` at `:199-207`; `_manager_compat_summary` therefore leaves power/routes false at `:10966-10980`. `RouteControlState` requires both true at `scripts/systems/route_control_state.gd:24-37`.
- Predicate: `main_playable_slice_route_control_smoke.gd:78-90` completes objective 1 and asserts zero opened gates, extraction still locked, and collision still enabled.
- Status: `traced`.

### `REQ-002::acceptance-ba74ffcf3f3e`

**Criterion:** Completing objective 2 restores main power and opens powered gates.

- Entry: objective 2 completion force-repairs `restore_systems` mappings and refreshes route control at `scripts/procgen/playable_generated_ship.gd:10734-10749`.
- Implementation: `OBJECTIVE_REPAIR_MAP` maps restore_systems to power distribution and batteries at `:199-207`; `_manager_compat_summary` derives restored power/cleared routes at `:10966-10980`; `RouteControlState` opens all gates at `scripts/systems/route_control_state.gd:24-37`.
- Predicate: `main_playable_slice_route_control_smoke.gd:92-108` completes objective 2 and asserts `main_power_restored`, `powered_gates_open`, zero blockers, and at least one open gate.
- Status: `traced`.

### `REQ-002::acceptance-0362bb95e57b`

**Criterion:** Active blocker count becomes zero.

- Entry: `_refresh_route_control_from_ship_systems` applies the live manager summary at `scripts/procgen/playable_generated_ship.gd:10837-10843`.
- Implementation: `RouteControlState.apply_ship_systems_summary` opens every gate at `scripts/systems/route_control_state.gd:24-37`; `get_summary` derives blockers from closed records at `:39-62,121-127`.
- Predicate: `main_playable_slice_route_control_smoke.gd:99-107` asserts zero blockers after objective 2; `:124-126,135-146` asserts they remain zero through objectives 3 and 4.
- Status: `traced`.

### `REQ-002::acceptance-8db36b1d36d0`

**Criterion:** Gate collision is disabled rather than the node being deleted.

- Entry: the objective refresh calls `_apply_route_gate_scene_state` at `scripts/procgen/playable_generated_ship.gd:10837-10843`.
- Implementation: `_apply_route_gate_scene_state` retains the array entry, updates metadata, and disables child collision at `:10845-10863`; it does not remove/free the gate.
- Predicate: `main_playable_slice_route_control_smoke.gd:109-118` asserts enabled collision count becomes zero, then re-reads `gate_nodes[0]` and inspects its open/cleared metadata, proving the node remains present.
- Status: `traced`.

### `REQ-003::acceptance-0d344559690d`

**Criterion:** Completing objective 4 unlocks extraction in route-control summary.

- Entry: objective 4 `stabilize_reactor` reaches `_on_interactable_completed` and route refresh at `scripts/procgen/playable_generated_ship.gd:10683,10730-10749`.
- Implementation: `OBJECTIVE_REPAIR_MAP` restores `power.reactor_core` at `:203-207`; `_manager_compat_summary` derives extraction from full reactor health at `:10966-10980`; RouteControlState latches/exposes it at `scripts/systems/route_control_state.gd:34-36,54-62`.
- Predicate: `main_playable_slice_route_control_smoke.gd:132-147` completes objective 4 and asserts route-control extraction is unlocked while gates stay open and blockers remain zero.
- Status: `traced`.

### `REQ-003::acceptance-f7221141b6f7`

**Criterion:** Slice completion remains intact.

- Entry: final `_on_interactable_completed` marks completion at `scripts/procgen/playable_generated_ship.gd:10764-10776`; `get_slice_completion_summary` exposes it at `:1077-1088`.
- Implementation: when the completed-objective count reaches the sequence count, the coordinator sets `slice_complete=true`, advances the sequence, and marks the tracker complete at `:10764-10773`.
- Predicate: `main_playable_slice_route_control_smoke.gd:132-140` asserts objective 4 unlock plus `run_complete=true`. `main_playable_slice_completion_smoke.gd:32-56` independently asserts four completed objectives, sequence 5, run/tracker completion, and the HUD completion banner.
- Status: `traced`.

### `REQ-004::acceptance-b50b8ae1a4d1`

**Criterion:** Pure state logic has a direct model smoke when practical.

- Entry: this is a process rule, not runtime behavior. The adjacent route-control pure model is `scripts/systems/route_control_state.gd`; its direct smoke is `scripts/validation/route_control_state_smoke.gd`.
- Static implementation: `docs/game/features/route_control.md:55-60` pairs the pure model with direct/main smokes. `docs/game/06_validation_plan.md:184-196,427` documents and registers the model smoke; `tools/synaptic_sea_gate4_regression.sh:39` registers its exact marker.
- Predicate: `route_control_state_smoke.gd:3-94` directly asserts initial closure, power-only no-open, powered opening, blocker counts, idempotence, extraction, and status lines.
- Gap: this proves compliance for route control. The named owner `docs/game/08_milestone_gates.md` is absent, `when practical` leaves exceptions undefined, and no referenced review-card checklist was identified, so the repository-wide population cannot be determined. This is an authority/scope gap, not a runtime defect or fabricated test obligation.
- Status: `source_mapped_authority_scope_partial`.

### `REQ-004::acceptance-c3c36e7427af`

**Criterion:** Scene consequences have a main-scene smoke.

- Entry: this is validation governance. Route-control scene consequences enter through gate construction at `scripts/procgen/playable_generated_ship.gd:10127,10188-10191` and objective application at `:10734-10749`.
- Static implementation: `docs/game/features/route_control.md:55-60` designates `main_playable_slice_route_control_smoke.gd`; `docs/game/06_validation_plan.md:184-196,428` and `tools/synaptic_sea_gate4_regression.sh:40` register it.
- Predicate: `main_playable_slice_route_control_smoke.gd:11-32` instantiates `scenes/main.tscn`; `:48-147` asserts live gate, collision, objective, and extraction consequences.
- Gap: this is a concrete compliant example, but the absent owner document and undefined “new gameplay systems” set prevent a repository-wide claim. No runtime failure is inferred.
- Status: `source_mapped_authority_scope_partial`.

## Review disposition

- The first ten route-control leaves have exact production routes and meaningful existing predicates; no fresh execution is represented.
- The two REQ-004 leaves are partially traced because their named authority file and checklist scope are unavailable, even though route control itself has the required model/main-scene pair.
- No runtime implementation change or additional mirror test is proposed by this source audit.
