# R04 low-repair opening source table

This is a read-only source inventory for `coherent_ship_001`. It records authored edges and arithmetic only; it does not establish a playable route. No Godot process, smoke, test, or balancing change was run for this report.

## Starting classes and threshold arithmetic

`data/player/classes.json:3-36` defines the base classes and their starting repair values. `scripts/procgen/playable_generated_ship.gd:1856-1895` loads the selected class, accepts an unlockable class only when meta progression says it is unlocked, and otherwise uses the configured/default class. The exported default is Engineer (`scripts/procgen/playable_generated_ship.gd:209-214`). The table below covers the low-repair base classes; Salvage Captain is included as a conditional unlockable row.

`PlayerProgressionState.xp_for_next_level()` is `(level + 1) * 100` (`scripts/systems/player_progression_state.gd:78-92`), and `grant_xp()` levels while accumulated XP meets that threshold (`:136-165`). Therefore level 1 requires 200 effective XP to reach level 2; level 0 requires 100 + 200 = 300 effective XP.

| class | start repair | technical multiplier | effective XP to repair 2 | ordinary completed repairs needed* |
|---|---:|---:|---:|---:|
| medic | 1 | 0.7 | 200 | 4 (60 each) |
| pilot | 1 | 1.0 | 200 | 3 (75 each) |
| security | 1 | 0.9 | 200 | 3 (70 each) |
| cook | 0 | 0.8 | 300 | 5 (65 each) |
| communications | 0 | 0.9 | 300 | 5 (70 each) |
| salvage captain (unlockable) | 1 | 1.1 | 200 | 3 (80 each) |

`*` A production `RepairPoint` completion directly grants 25 repair XP (`scripts/tools/repair_point.gd:370-375`) and the production completion handler emits `repair_subcomponent` (`scripts/procgen/playable_generated_ship.gd:7548-7564`). `data/player/training_actions.json:4` gives that event base 50 technical XP; `scripts/systems/training_event_bus.gd:90-159` applies the class multiplier. Thus the projected per-repair values are `25 + 50 * technical multiplier`, rounded as the integer progression code does. These counts assume the required target, parts, tool, time, and skill gate are all available for every repetition; they are not a reachability proof.

## Opening damage, parts, and skill gates

The golden blueprint is DAMAGED with seed 17 (`data/procgen/golden/coherent_ship_001/blueprint.json`). `ShipSystemsManager` uses `DAMAGED_HEALTH = 0.2` and a 0.4 break chance for DAMAGED condition (`scripts/systems/ship_systems_manager.gd:18,75-96`). After system construction, `_apply_lifeboat_opening_damage()` resets propulsion subcomponents to full health and sets only `propulsion.nav_linkage` to 0.2 (`scripts/procgen/playable_generated_ship.gd:1604-1609,8073-8083`). Its authored repair gate is `circuit_board`, no tool, minimum repair 2 (`data/ship_systems/systems.json:44-46`). This is the known departure blocker for repair-0/1 classes.

The coherent slice places `start_supply_a` in `maintenance_01` with guaranteed `repair_parts_starter` and `start_supply_b` in `medbay_01` with weighted `salvage_engineering` (`data/procgen/golden/coherent_ship_001/gameplay_slice.json:80-81`). `repair_parts_starter` guarantees a circuit board (`data/items/loot_tables.json:86-91`); `salvage_engineering` is weighted and does not guarantee a particular tool or repair part (`:33-57`). These facts establish an authored part source for nav_linkage, but do not establish that another repairable target is damaged and reachable before departure.

## Candidate pre-navigation progression edges

| edge | authored prerequisite | XP and threshold relevance | status before a playthrough |
|---|---|---|---|
| `RepairPoint` / `repair_subcomponent` | A damaged subcomponent whose BOM and tool are in inventory, and current repair level meets its min skill (`scripts/tools/repair_point.gd:100-105,108+`; `scripts/systems/ship_subcomponent.gd:35-63`) | Direct 25 + `repair_subcomponent` base 50 technical, as calculated above | **Conditional.** Systems data has level-1 no-tool candidates (`power.battery_cells`, `life_support.co2_scrubber`, `navigation.star_charts`, and `scanners.power_coupling` in `data/ship_systems/systems.json:8-10,17-19,35-37,53-55`), but source inspection does not prove which are broken under seed 17 or that their BOMs are available before nav. No listed ordinary component has min skill 0. |
| `patch_breach` / `BreachSealPoint` | Actual breach plus hull sealant; work catalog permits repair level 0 (`data/work_actions/work_action_catalog.json:43-54`; `scripts/tools/breach_seal_point.gd:90-160`) | `patch_breach` routes a `repair` event (base 45 technical); breach seal point directly grants 15 repair XP | **Not an opening fact.** Home construction calls `_build_breach_zone(false,...)`, while seeded breach content is explicitly derelict-side (`scripts/procgen/playable_generated_ship.gd:2652-2674,11389+`). No home opening breach is authored by the inspected sources. |
| fire suppression | Burning compartment and extinguisher/charge (`scripts/tools/fire_suppression_point.gd:120-170`) | Direct 10 repair XP | **Away-only by source.** `_seed_derelict_fire()` is documented as not called on home/lifeboat (`scripts/procgen/playable_generated_ship.gd:3862-3866`). |
| objective full repair | Reach the derelict objective sequence; `restore_systems`/`stabilize_reactor` map to repair pairs (`scripts/procgen/playable_generated_ship.gd:199-207,10715-10747`) | `repair_full_system`, base 120 technical (`data/player/training_actions.json:4-5`) | **Post-navigation.** The coherent gameplay slice lists these objectives (`data/procgen/golden/coherent_ship_001/gameplay_slice.json:20-78`); it is not evidence that a low-repair starter can reach them before fixing nav_linkage. |

## Unresolved reachability facts

1. For repair-1 starters, a static route exists only if at least one level-1 target is actually damaged, its required part/tool is obtainable from the two opening containers, and the target is interactable before nav repair. The DAMAGED RNG and generated runtime state were deliberately not executed here, so this remains an explicit assumption.
2. For repair-0 starters, `systems.json` exposes no ordinary subcomponent with minimum repair 0. The conditional breach/work-action edges do not supply an opening route because no home breach is authored in the inspected source. Therefore the source inventory cannot show a pre-navigation level-0-to-2 route; it records the gap for R04 validation rather than calling it a proven softlock.
3. Repair books do not provide a fallback repair edge: `scripts/systems/player_progression_state.gd:171-192` supports book XP, but `data/player/skill_books.json` contains no repair-target book.
4. Base class definitions are present, while unlockable classes require meta progression. Whether the current Title UI exposes every base class is an independent UI/default-selection fact and is not re-proven by this table.

## Useful later verification target

A fresh R04 playthrough or focused smoke should record, before nav repair, the actual damaged subcomponents, each opening container's realized inventory, and any successful `RepairPoint` completion. It should separately distinguish the direct 25 XP grant from the `repair_subcomponent` event, then verify the repair-0 and repair-1 starter classes rather than inferring them from the Engineer/default path.
