# R01 evidence reconciliation report

Base reviewed: `eca5de3c5b97916094ff2b5e17daf644bf8be08f` with pre-existing runtime and documentation WIP preserved. No Git index operation, commit, product runtime edit, Godot execution, or external-board mutation occurred.

## Changes

- Regenerated `docs/game/inventory/feature_acceptance.json` and `data/validation/feature_completion_cards.json` from the frozen current source tree. The P17 candidate-navigation smoke is now present in the generated allowlist. The P10 process smoke was already present in the P10 allowlist.
- Classified `fc_p10_process_smoke` and `structural_rebuild_candidate_nav_smoke` as `standalone-feature-completion` in the orphan classifier and validation-plan table. This classification conveys neither fresh validation nor criterion acceptance.
- Changed aggregate accounting so the completion dimensions are `null`/unknown until a reviewed criterion-level evidence mapping exists. The register publishes the exact mapping coverage: `0` mapped, `622` unknown, `0.0%` coverage. Separate `promoted_evidence_counts` preserves the raw zero values without presenting them as product-completion counts.
- Updated `STATUS.md` to distinguish P10’s partial scene and retained three-process wire proof from full P10 qualification, and P17’s pure candidate-navigation helper proof from live authorization/acceptance.
- Copied the latest `.tmp` P10 authority-matrix and P13 integration logs and their world manifests into `artifacts/feature-completion/R01-evidence-20260905/`. The P10 source manifest is paired with its matching process run. The separately retained older P13 summary is historical context only, not a manifest for run8.

## Evidence review

`P10-process-wire-direct-20260905-184856` reports producer, consumer1, and consumer2 exit `0`, exactly one expected marker each, no diagnostics, no unexpected stdout/stderr, valid baseline and post digests, and `source_drift_detected=false`. The smoke compares expected and actual values only after both take the same full-precision JSON stringify/parse roundtrip; it uses exact Variant equality. Its observations include serialized lot IDs, quantity, quality, condition, origin, jobs, receipts, and component origins. No numeric tolerance or relaxed lot-identity matcher is present in this comparison.

The copied P10 authority-matrix log ends in `FC P10 PASS`; it also contains the expected negative-path line `P10 RESTORE AUTHORITY DIFF ... motion_reduce type expected=4 actual=1`. It has no `ERROR:`, `WARNING:`, or `SCRIPT ERROR:` line. The copied P13 run8 integration log ends in `FC P13 PASS` with no conventional engine diagnostic, but its exact source snapshot is unavailable: no matching source-hash manifest was found. These retained artifacts are focused historical evidence only; neither was promoted to an FC row.

## Durable additions

All files were absent before this task and were copied byte-for-byte from the named source; their SHA-256 values are the exact after-state identifiers.

| Added file | Source | Bytes | SHA-256 |
|---|---|---:|---|
| `p10-authority-matrix-fc_p10_smoke.log` | `.tmp/p10-authority-matrix-09/fc_p10_smoke.log` | 5443 | `bce7a995093c8b40e2e9c0f53ba479bef88b0d475fe97d7e782fd5e67ab2d5c4` |
| `p10-authority-matrix-world.manifest.json` | `.tmp/p10-authority-matrix-09/.../saves/.cloud/world.manifest.json` | 351 | `a200f6ddc1d07463ba4d5d890ba86064917b177e18d435d2be7af92f4bb0bcd1` |
| `p10-process-wire-direct-source-manifest.json` | `artifacts/feature-completion/P10-process-wire-direct-20260905-184856/summary.json` | 347504 | `236d64e9bef2c7defbd619eca86e5b055249e13a3f6ffaf004b31fcd78a235ff` |
| `p13-integration-fc_p13_smoke.log` | `.tmp/p13-p10-pointer-run8/fc_p13_smoke.log` | 894 | `7c99d3bd1789fdee25521678ad44056765adac5094163310a98f29ba903fe561` |
| `p13-integration-world.manifest.json` | `.tmp/p13-p10-pointer-run8/.../saves/.cloud/world.manifest.json` | 351 | `bdcfd62ad8731be9ad9bc9d079c44c7731619ba282643432399e2419fa7cb4d5` |
| `p13-integration-source-manifest.json` | older `p13-final-837adcc1-20260905/summary.json`; unrelated historical context, not run8 provenance | 295884 | `cd538984c0f6067d6fbb757a26c366991a6495dbec15a703e5d89ff9ac9daca7` |

`task-1-review.patch` is the root-generated canonical review diff. `task-1-diff.patch` is superseded and must not be used as an exact ledger.

## Verification

- `Blender 5.2 Python` `tools/build_feature_acceptance.py --write` — `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0`.
- `Blender 5.2 Python` `tools/build_feature_acceptance.py --check` — passed with the same count.
- `.superpowers/test-runtime/Scripts/python.exe -m unittest tests.test_feature_acceptance_registry` — 22 tests passed, including partial and complete evidence-mapping transitions.
- `bash tools/classify_orphan_smokes.sh --check` — `ORPHAN CLASSIFICATION CHECK PASS orphans=209`.

The validator now independently recomputes mapping coverage and all five promoted evidence counts from criteria. It rejects a tampered aggregate; the complete-mapping test changes `promoted_evidence_counts.implemented` and asserts `promoted evidence count mismatch`.

Final rerun after this invariant:

- `.superpowers/test-runtime/Scripts/python.exe -m unittest tests.test_feature_acceptance_registry.FeatureAcceptanceRegistryTests.test_complete_evidence_mapping_publishes_derived_counts` — `Ran 1 test in 0.067s`, `OK`.
- `.superpowers/test-runtime/Scripts/python.exe -m unittest tests.test_feature_acceptance_registry` — `Ran 22 tests in 0.792s`, `OK`.
- `.superpowers/test-runtime/Scripts/python.exe tools/build_feature_acceptance.py --write` and `--check` — each `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0`.
- `bash tools/classify_orphan_smokes.sh --check` — `ORPHAN CLASSIFICATION CHECK PASS orphans=209`.

Final source SHA-256:

- `tests/test_feature_acceptance_registry.py` — `70a786a9763eef942023d73bb3a379b0a1299dcc613a1f980d5f24d7216b6d8f`.
- `tools/build_feature_acceptance.py` — `031641c2d10c5530cb9e8c269e5d2aa96ee1079999182ad1c1d5f6ab6d801082`.
- `git diff --check` — no patch errors. The generator emits an existing Python 3.14 deprecation warning for positional `maxsplit`; it does not affect either gate.

## Concerns left open

- Evidence mapping is intentionally incomplete: all 622 active metric criteria remain unknown, not zero implemented. R17 owns the full criterion mapping and plan-alias audit.
- The P13 run8 source snapshot is unknown; its copied old summary is accurately labeled unrelated historical context. It is not source-pinned evidence.
- External `synaptic-sea-stage-gate` synchronization remains pending because no board connector is available.

## Fix round 3

The complete-mapping synthetic case now writes the tracked plan into its temporary root and calls `validate(rebuilt, build_card_manifest(self.root), self.root)` immediately after the frozen rebuild. It asserts all five derived headline dimensions and the matching `promoted_evidence_counts`; a separately rebuilt unfrozen registry retains null percentages.

Commands and actual output:

- `.superpowers/test-runtime/Scripts/python.exe -m unittest tests.test_feature_acceptance_registry.FeatureAcceptanceRegistryTests.test_complete_evidence_mapping_publishes_derived_counts` — `Ran 1 test in 0.057s`, `OK`.
- `.superpowers/test-runtime/Scripts/python.exe -m unittest tests.test_feature_acceptance_registry` — `Ran 22 tests in 0.745s`, `OK`.
- `.superpowers/test-runtime/Scripts/python.exe tools/build_feature_acceptance.py --write` — `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0`.
- `.superpowers/test-runtime/Scripts/python.exe tools/build_feature_acceptance.py --check` — `FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0`.
- `bash tools/classify_orphan_smokes.sh --check` — `ORPHAN CLASSIFICATION CHECK PASS orphans=209`.
