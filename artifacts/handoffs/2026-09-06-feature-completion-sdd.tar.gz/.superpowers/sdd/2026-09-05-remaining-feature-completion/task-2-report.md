# Task 2 / R02 runtime implementation report

> **Supersession notice (2026-09-05):** The focused-isolation claim in this
> report is invalid. Those original focused runs did not bind Windows
> `APPDATA`/`LOCALAPPDATA` and touched the default Godot profile; the retained
> default-profile copy is an observed after-state, not a recovery backup. This
> report also incorrectly classified `save_load_service_smoke.gd` as unrelated
> R03 work; its failure was an R02 current-version fixture regression. Both
> issues were corrected and revalidated in
> [`task-2-fix1-report.md`](task-2-fix1-report.md), which supersedes the affected
> claims while retaining this file as historical evidence.

Date: 2026-09-05  
Workspace: `D:/the-synaptic-sea-feature-completion`  
Task base authority: `a12d3eed` plus the preserved accepted runtime WIP  
Governance commits reviewed by root before runtime: `aeba535e`, `4fc54eea`  
Runtime owner: `/root/r02_persistence`  
Index/commit status: no files staged or committed by the runtime owner

## Outcome

R02 now persists combat under outer `gate2-current-run-6` / `world-6` envelopes and nested `threat-manager-2`. Every current threat row carries finite, nonnegative `structure_damage`, including explicit zero. Recognized pre-v6 combat is migrated through a frozen historical map (`hull_tendril=0.4`; `biomatter_swarm`, `puppet_corpse`, `stalker`, `mimic`, and `drone_swarm=0.0`). Unknown archetypes, ambiguous mixed shapes, malformed current summaries, and future versions fail before live mutation or sidecar publication.

The codec and initializer are pure helpers. `ThreatManager` validates a complete detached summary before clearing or hydrating live threats. `SaveMigrationService` traverses home combat and every visited owner, including inactive owners. `SaveRestoreCandidate` retains and reattaches home combat after inventory canonicalization and preserves the optional exact-String `combat_hotbar_text`. Capturing while away writes the retained home owner combat and the live current visited-owner combat separately.

Recognized pre-v6 missing/empty required combat is deterministically bootstrapped before current decoding, candidate construction, sealing, or migrated-sidecar publication. Home uses the saved layout at the origin. Active-away uses the saved blueprint/context through the same `ShipGenerator.generate_documents_from_seed` document pipeline as first-use scene generation. Native/fallback selection, seed/size/condition, errors, and generated documents remain shared; the pure return contains no `Node` or `RID` values and a selected native failure is never replaced silently by fallback output.

## Implementation details

- `ThreatSaveContract` centralizes strict current validation and detached legacy migration. It validates complete manager, threat, detection, damage, armor, finite numeric, and duplicate-ID contracts. Boolean, string, negative, missing, NaN, infinity, and legacy/current mixed values reject.
- `ThreatInitialStateBuilder.build_initial_v2` shares marker aliases, encounter normalization, spawn placement, and authored definitions with `ThreatManager.configure_for_layout`. An initialized empty owner is a complete v2 manager with zero threats; absent legacy ownership remains absent unless the outer bootstrap contract requires initialization.
- `ThreatAIState.get_summary` and `ThreatManager.get_summary` emit structural damage and the v2 schema. Manager application derives the last-attack weapon cache from the persisted attack result and preserves clear-before-hydrate ordering after validation.
- `RunSnapshot`, `WorldSnapshot`, `ShipInstance`, and `SaveRestoreCandidate` enforce the same codec at their boundaries. Current run-v6 receives no v5 crafting adaptation, embedded world-v6 requires run-v6 exactly, and earlier outer versions move through explicit migration steps.
- `SaveLoadService` performs legacy combat bootstrap before current decode and uses strict integral JSON blueprint validation. Integer-valued finite floats are accepted; booleans, fractions, NaN, and infinity reject.
- `PlayableGeneratedShip` restores the validated arbitrary hotbar cache after owner activation/docking has completed, then publishes it. Live combat may subsequently replace it legitimately. No combat comparison exclusion was added.
- The process proof seeds deliberately different home and active-away threat IDs, health, awareness, weapon identity, and structure damage. Consumer 1 invokes the production structure-attack path after restore and observes a real module integrity reduction; consumer 2 verifies the resulting saved world.

## Active-away anchor ruling and proof

Production creates the first active derelict at `PlayableGeneratedShip.DERELICT_DOCK_OFFSET = Vector3(100, 0, 0)` before configuring its threat runtime. Legacy active-away bootstrap therefore pins `SaveLoadService.ACTIVE_DERELICT_COMBAT_ANCHOR` to the same historical `(100, 0, 0)` anchor. The focused active-away case builds the expected summary through the shared initializer at that anchor and compares the complete prepared summary exactly.

This does not constrain the initializer to one location. The focused factory/initializer case also injects the independently relocated anchor `(8, 2, -5)` and verifies the local marker is transformed to world position `[9.25, 2.5, -7]`. Persisted relocated or already-docked owners retain their own current v2 combat positions; deterministic bootstrap is only for recognized pre-v6 owners whose combat authority was absent/empty.

## Hotbar-cache debug history

- `R02-process-evidence-20260905-01` exposed a real ordering defect: the valid arbitrary cache `Weapon: Flare Pistol | R02 process authority` decoded successfully but owner activation replaced it with an unarmed cache. The implementation now retains the validated string before rebuilding owners, then reinstates and publishes it after the docking transaction.
- `R02-process-evidence-20260905-02` then showed that consumer 1's real live attack legitimately changes the cache. The proof was corrected to capture the new live cache in its post-attack expected state. This was not made into an exemption: the deliberately stale but valid producer cache must still cross the producer-to-consumer-1 restore exactly.
- `R02-process-evidence-20260905-03` passed before subsequent source changes; `-04` passed after the cache-order repair; `-05` is the final frozen source-closure authority and includes the active-away anchor/numeric validation changes. The failed `-01` and `-02` directories are retained as debug evidence.

## Verification

Godot executable used for every runtime smoke and process:

`C:/Users/dasbl/Downloads/Godot_v4.7.2-stable_mono_win64/Godot_v4.7.2-stable_mono_win64/Godot_v4.7.2-stable_mono_win64_console.exe`

Each focused smoke used fresh task-specific `GODOT_USER_PATH` and `XDG_DATA_HOME` directories under `artifacts/feature-completion/R02-final-evidence-20260905`:

| Script | Required marker | Evidence log SHA-256 |
|---|---|---|
| `threat_ai_state_smoke.gd` | `THREAT AI STATE PASS final_state=dead previous=hunt awareness=0.00` | `3e1be0e7df1ec7e8120cc3afd0a49c59e7c09c498ec3dd678656e74a0e0fe8a0` |
| `tendril_structure_damage_smoke.gd` | `TENDRIL STRUCTURE DAMAGE PASS archetype=true hit=true damaged=true` | `d9114e0ecab9a09830a05e94218366de1137c65774b0bbe4d22984e0a3f0be98` |
| `save_migration_service_smoke.gd` | `SAVE MIGRATION SERVICE PASS` | `d62dd8afd2e35ccfae7a603bb3d98099dcf7635fe0e5584654fc62bc84b9c777` |
| `ship_generator_smoke.gd` | `SHIP GENERATOR PASS life_boat=true small=true deterministic=true documents=true life_rooms=9 small_rooms=24` | `4f9f74d46fd7f1805bfae29998de84d8c4a2ce7d7dcde3f56997a552e2b37122` |
| `world_snapshot_smoke.gd` | `WORLD SNAPSHOT PASS round_trip=true version_gated=true` | `4bac304194072777d56932b4160385b49fe4493f61f9bc39ebd53279c2fc16bb` |
| `combat_persistence_smoke.gd` | `COMBAT PERSISTENCE PASS schema=threat-manager-2 hull=0.4 callback=true owners=home+away` | `916a1c88635a6ebb1d491d1e5fb57559a34331fcef4c456c4b418e1da3e7cf93` |
| `fc_p10_smoke.gd` | `FC P10 PASS` | `bce7a995093c8b40e2e9c0f53ba479bef88b0d475fe97d7e782fd5e67ab2d5c4` |

The final log scan found zero lines beginning `ERROR:` or `WARNING:` across all 11 files in the focused evidence directory. `fc_p10_smoke.log` contains the expected informational malformed-candidate comparison line `P10 RESTORE AUTHORITY DIFF ... expected=4 actual=1`; it is part of the rejection proof and is not an engine diagnostic.

Final true three-process command:

```powershell
.superpowers/test-runtime/Scripts/python.exe tools/run_p10_process_smoke.py --godot "C:/Users/dasbl/Downloads/Godot_v4.7.2-stable_mono_win64/Godot_v4.7.2-stable_mono_win64/Godot_v4.7.2-stable_mono_win64_console.exe" --root . --evidence-dir artifacts/feature-completion/R02-process-evidence-20260905-05 --timeout 180
```

Result: `FC P10 PROCESS PASS`. `summary.json` SHA-256 is `a3d6f1f8b8ae31f259493ad13b3f75c73ed40d0cdc06c4c24e3ee71fa44f9502`; it reports `passed=true`, `source_drift_detected=false`, and producer/consumer1/consumer2 each with exit 0, exactly one marker, empty diagnostics, empty unexpected output, and distinct fresh user homes.

The process artifacts prove:

- baseline world SHA-256 `9760fbc1a2f8ebe79e53dc5f2a4bd4bd26ec4616de49c81e76e09afbd50221f7`
- expected observations SHA-256 `56a2d5069fb9e5b04d9e041ccf07050df6cfe8eb77ad874cb6ae750ea0b6759d`
- post-collection world SHA-256 `25e19c14ad9328f098dd466f5d355f1ea705f72cc1f3516d07103c59995ccd0f`
- post-collection manifest SHA-256 `1c0c8129ae565cfd8751efdff539521fb98afca547606fa231ef46219945ed28`
- home `fallback_0_0`: health `20.75`, awareness `0.1875`
- away `validation_0_0`: health `31.25`, awareness `0.8375`, `structure_damage=0.4`, last weapon `flare_pistol`
- persisted arbitrary initial cache `Weapon: Flare Pistol | R02 process authority`
- post-restore production callback with an actual module integrity change to `0.6` / `damaged`

Fresh non-Godot checks after source freeze:

```text
.superpowers/test-runtime/Scripts/python.exe -m pytest -q tests/test_p10_process_runner.py tests/test_feature_acceptance_registry.py
38 passed in 1.04s

.superpowers/test-runtime/Scripts/python.exe tools/build_feature_acceptance.py --root . --check
FEATURE ACCEPTANCE REGISTRY PASS criteria=668 unassessed_sources=0

bash tools/classify_orphan_smokes.sh --check
ORPHAN CLASSIFICATION CHECK PASS orphans=210
```

Their logs are in the focused evidence directory with SHA-256 values `605fab51f1fcbdd6335b2ba156839736c3221b23aa0911195599410176015145`, `13d4e6336be1e33a7fadde4436eaf222cb70956f66a57097a21f4235cf316b1f`, and `fd466cf219b46fbde4dbd2e8d58e7120f899e6fd9e2b661a2824ebaad37e2328` respectively.

## Exact R02 review scope

Tracked runtime files reconstructed from `.superpowers/sdd/2026-09-05-remaining-feature-completion/r02-review-baseline`:

- `scripts/procgen/playable_generated_ship.gd`
- `scripts/systems/run_snapshot.gd`
- `scripts/systems/save_load_service.gd`
- `scripts/systems/save_migration_service.gd`
- `scripts/systems/ship_instance.gd`
- `scripts/systems/threat_manager.gd`
- `scripts/systems/world_snapshot.gd`

Tracked files compared to governance revision `4fc54eea`:

- `docs/game/06_validation_plan.md`
- `docs/game/inventory/feature_acceptance.json`
- `scripts/procgen/ship_generator.gd`
- `scripts/systems/threat_ai_state.gd`
- `scripts/validation/save_migration_service_smoke.gd`
- `scripts/validation/ship_generator_smoke.gd`
- `scripts/validation/world_snapshot_smoke.gd`
- `tools/build_feature_acceptance.py`
- `tools/classify_orphan_smokes.sh`

Preexisting untracked files with exact pre-edit backups in `.superpowers/sdd/2026-09-05-remaining-feature-completion/task-2-before-untracked`:

- `scripts/validation/fc_p10_process_smoke.gd`
- `tests/fixtures/feature_completion/p10_run_v4_legacy_active_paid.json`
- `tests/fixtures/feature_completion/p10_run_v5_transactional.json`
- `tests/fixtures/feature_completion/p10_world_v4_legacy_active_paid.json`
- `tests/fixtures/feature_completion/p10_world_v5_transactional.json`

New R02 files:

- `scripts/systems/threat_initial_state_builder.gd`
- `scripts/systems/threat_save_contract.gd`
- `scripts/validation/combat_persistence_smoke.gd`
- `tests/fixtures/feature_completion/p10_run_v7_future.json`
- `tests/fixtures/feature_completion/p10_world_v7_future.json`

Preexisting untracked files whose exact pre-edit bytes could not be reconstructed after bounded searches:

- `scripts/systems/save_restore_candidate.gd`
- `scripts/validation/fc_p10_smoke.gd`

These two files are included as full afterimages under explicit `/unavailable-preimage/` labels in the review patch. That presentation is not an exact incremental diff and does not attribute all existing lines to R02. Review the complete files, focusing on the R02 intent described above. Their frozen afterimage SHA-256 values are `bcf7327eb8b681dad14d75bff339f4840928d3e41276cf1767696ff7bb1d52a4` and `f6c427a23fda67aa3b986653daee5d6b335e75790c25515262312602dadc6983`.

The unchanged preexisting v6 future fixtures, malformed fixtures, process runner, and Python runner test remain byte-identical to the exact backup copies and are excluded from the R02 patch.

Review artifacts:

- `.superpowers/sdd/2026-09-05-remaining-feature-completion/task-2-before-runtime.patch` — SHA-256 `38c814423de05aa0ac2529c3fe95758ccdd7722e1fdb905861d8a488d9e639b9`
- `.superpowers/sdd/2026-09-05-remaining-feature-completion/task-2-runtime-review.patch` — SHA-256 `a9d2739cb37ee7d4adc57df38f3a51594456cca902580f47d865d3aa64fdfa2a`, 3,253,804 bytes
- `.superpowers/sdd/2026-09-05-remaining-feature-completion/task-2-afterimages.json` — SHA-256 `522f4646549febbc0d39de8f883ba0400f966ab9dadac6ff96c4ecde571f6a0c`, 28 scoped files with before/after provenance and hashes

## Review concerns and boundary

The main review risks are the version transition, all-owner traversal, bootstrap ordering, active-away anchor, arbitrary cache restoration order, and manager atomicity. Each has a named focused assertion and the integrated/process proof above.

Exploratory broad runs of `save_load_service_smoke.gd`, `world_save_service_smoke.gd`, and `ship_mod_run_snapshot_smoke.gd` encountered older broad-fixture expectations (`invalid_world_snapshot`, `invalid_visited_ship`, and placement restore respectively). R02 did not edit those files or absorb those unrelated full-persistence regressions; root assigned remaining full persistence closure to R03. All explicit R02 codec, legacy/current version, home/away/inactive owner, bootstrap, current-invalid rollback, integrated P10, and process obligations are covered by the passing matrix above.
