# R17 player progression exact source trace (moving WIP)

Nine exact registry FEATURE IDs and verbatim criteria are recorded with source functions, concrete callers where found, and exact smoke line references. Source-only: no execution or evidence promotion.

The audit explicitly leaves three rows partial/unresolved: live book-read caller, live skill-tree unlock caller, and HubUpgrade purchase function/caller. It does not infer acceptance from their model smokes.
