# R17 reviewed survival, food, consumables, and hazards source trace (moving WIP)

This replaces the unaccepted Luna draft while preserving it as provenance. It is a source-only preparation artifact: no runtime or smoke was executed, no Git or registry mutation occurred, and no evidence is promoted.

The JSON maps all 35 exact active FEATURE IDs and verbatim registry criteria across the bounded six-feature scope. Each leaf records the source specification section, concrete current implementation/caller, player consequence, persistence boundary, and matching existing assertion or a gap.

Identity check run from the feature-completion workspace:

```powershell
# Compare exact full IDs and ordinal criterion text in the reviewed JSON
# with feature_acceptance.json; fail for duplicate, missing, extra, or mismatch.
```

Result: `trace_count=35 registry_count=35 missing=0 extra=0 criterion_mismatch=0`. The JSON records current HEAD as its `source_revision`, actual generation time, and `moving_wip: true`.

Counts: 35 source-traced, 0 source-unresolved, 0 fresh execution scenarios, 2 root causes, 0 evidence promotions.

Root causes:

- `hallucination_persistence_conflict` affects the two survival-vitals leaves that touch hallucination state. Current R02 moving code captures/restores `hallucination_summary`, while ADR-0042 and REQ-SV-002 require hallucination events to remain ephemeral. This is cross-referenced only, with no second review.
- `fire_state_retired_by_ADR0041` affects all five historical `hazard_variety.md` leaves. Current persistent `FireSuppressionState` intentionally replaces cyclic `FireState`; this is not a missing feature.

`CookingState` retirement is likewise intentional: current station crafting is the implementation for food production. The report records no fresh test evidence for any leaf because this bounded task was static source audit only.
