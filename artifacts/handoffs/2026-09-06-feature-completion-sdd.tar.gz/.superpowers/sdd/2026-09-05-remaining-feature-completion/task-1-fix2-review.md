# Task 1 fix round 2 review — R01

## Verdicts

- **Spec compliance: PASS.** Current R01 output remains conservative, with incomplete evidence mapping reported as unknown and no standalone evidence promoted to acceptance.
- **Code quality: NEEDS CHANGES.** The accounting invariant is repaired and aggregate assertions are materially improved, but the complete-mapping test still does not invoke `validate()` as required by the prior remediation and this fix-round acceptance check.

## Remaining finding status

### MEDIUM — Frozen/complete aggregation and validation coverage: PARTIALLY ADDRESSED

The implementation now publishes percentages only when both conditions hold: `scope_frozen is not None` and evidence mapping is complete. The complete-mapping test supplies a frozen contract, asserts all five headline dimensions (`implemented`, `production_reachable`, `freshly_validated`, `player_accepted`, and `accepted`), and asserts every published percentage. It also rebuilds without a frozen contract and verifies all percentages remain `null`. These changes address the generator behavior and the unfrozen regression from fix round 1.

The test still stops after `build()` and never calls `validate(rebuilt, ...)`. Consequently, it does not prove the stated frozen-and-complete result satisfies the registry validator, and a future generator/validator disagreement of the kind found in fix round 1 could recur while this test continues to pass. It also does not directly assert the complete mapping's `promoted_evidence_counts`, although the five equal headline totals indirectly exercise the same aggregation values.

**Concrete remediation:** Call `validate()` on the frozen, complete rebuilt registry using the fixture's card manifest/root as appropriate. Add a direct equality assertion for `promoted_evidence_counts` against the five-value expected dictionary. Keep the existing unfrozen-null assertion.

## Verification

- Inspected `task-1-fix2-review.patch` only for the scoped remaining finding.
- Confirmed the percentage guard requires both frozen scope and complete evidence mapping.
- Confirmed exact assertions cover all five headline totals and all three percentage fields.
- Confirmed the test explicitly checks that an unfrozen complete mapping leaves percentages `null`.
- Confirmed no `validate()` call or direct complete-map `promoted_evidence_counts` assertion appears in the new transition test.
- Accepted the coordinator's fresh evidence: 22 tests passed in 0.77 seconds and the 668-criterion registry check passed. No runtime or Git command was run during this review.

