# R17 source trace: core and architecture families

Read-only snapshot: `2026-09-05T20:21:59.5893599-04:00`; HEAD `4fc54eeacaabc7cde321b7dc26b4daf19a4bf21b`; engine authority Godot 4.7.2 Windows (ADR-0060). No runtime, Godot, tests, Git, or evidence mutation. The exact IDs remain in `r17-r17-coverage.json`; this report does not add core/arch rows to its checked union.

## Scope

The registry has 49 active `core` rows and 16 active `arch` rows, all sourced from `docs/game/05_requirements.md`, all currently `evidence.state=not_verified`. The 337 active `feature_spec` rows are explicitly excluded. Core and architecture are source-anchor retrieval only; no historical `Implemented`/`Validated` text is promoted.
For the next decomposition pass, `r17-feature-spec-source-groups.json` groups all 337 excluded `feature_spec` rows into 47 source files with exact leaf IDs. This is an inventory artifact only; it does not mark any feature-spec row checked.

## Core anchors

The 49 core rows cover REQ-001..007 and REQ-010..014. Requirement anchors are `docs/game/05_requirements.md:74-314`: route gates and restoration (`REQ-001..003`), model/scene validation and no proof-only substitution (`REQ-004..005`), hazard pressure/variety (`REQ-006`, `REQ-010`, `REQ-013`), inventory/tool loop (`REQ-007`, `REQ-014`), objective variation (`REQ-011`), and save/load persistence (`REQ-012`). The live source candidates are `scripts/systems/route_control_state.gd`, `ship_systems_manager.gd`, hazard models under `scripts/systems/`, `inventory_state.gd`, `objective_progress_state.gd`, and save/coordinator paths owned by R02. These anchors establish where fresh checks must attach; they do not prove the 49 leaves.

The requirements table separately marks FC-24 native offline export approved/unimplemented (`docs/game/05_requirements.md:20-51`), so “core loop source exists” must not be read as offline-release acceptance. Current execution authority is 4.7.2; any 4.7.1 prose is stale/superseded.

## Architecture anchors

The 16 architecture rows are REQ-ARCH-001..006 at `docs/game/05_requirements.md:1233-1424`. They anchor to `sim_keys.gd`/tick context, `tuning_catalog.gd`, `ship_runtime.gd` per-ship advance and catch-up, runtime snapshot composition, shared home/away helpers, and FRAME/SLOW/LAZY tick bands. The architecture source `docs/game/architecture/05-runtime-component-dependencies.md:148` identifies `PlayableGeneratedShip` as a large integration hotspot and notes deferred ambient/spatial audio inputs. The threat architecture source `docs/game/architecture/04-threat-ai-state-machine.md:1-12` explicitly says reachable FLEE and INVESTIGATE states lack distinct matching scene behavior; this is a documented limitation requiring focused acceptance evidence, not proof of a new code defect.

## Concrete source contradictions and limits

The historical inventory classification `hangar_bay_control -> hangar_bay` as `health=broken` (`docs/game/inventory/system_inventory.json:8175-8192`) is stale against the current source path: `hangar_bay_control.gd:40-45` emits `bay_dock_requested` after the direct-range condition; `playable_generated_ship.gd:2892-2897` connects it; `_try_hangar_interact():10647-10667` calls `try_dock`/`try_launch` only when a valid control, bay, and candidate/occupied slot exist; handlers are at `:3209-3272`; and the validation seam directly routes `:14902-14907`. This establishes a production caller/condition path, but source presence is still not player/runtime evidence. Keep the hangar acceptance leaves as unmapped until fresh execution.

The same inventory records retired cooking/synthesizer state as broken/dead (`docs/game/inventory/system_inventory.json:560-585`) while the canonical meal path is CraftingState. This is a documented retirement/supersession, not an active core defect; do not count it as a missing current feature.

## Exact hangar/nested source leaves

The registry has no criterion whose text explicitly says `hangar`, `nested ship`, or `ship-in-ship`. The closest exact source anchors are the `crafting_derelict` acceptance IDs `FC-13`, `FC-15`, and `FC-18` through `FC-22` (physical compatibility, selected-ship isolation, replacement, readiness, and revisit/docking/save persistence). Separate `feature_spec` leaves exist for the related ship-modification/runtime/save behavior and are preserved verbatim in `r17-r17-coverage.json` under `nested_hangar_feature_spec_leaf_ids` (14 IDs). These IDs are unmapped source anchors, not members of the checked union and not evidence of complete nested-ship coverage.

Remaining work is fresh model/scene/player validation for the exact 49 core and 16 architecture IDs, plus explicit mapping or reviewed disposition for the hangar acceptance leaves. Persistence/coordinator conclusions remain R02-owned.

