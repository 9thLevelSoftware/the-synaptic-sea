# R05 / G1 natural crafting validation inventory

Read-only preparation for G1. No runtime, tests, Git, registry, governance, or
source mutations were performed.

## Contract to prove

The plan's G1 exit at
`docs/superpowers/plans/2026-09-04-crafting-derelict-feature-completion.md:877-878`
requires FC-04..12 evidence and normal-control proof that the player can obtain,
craft, queue, interrupt, collect, and use differentiated output. The P09 block
at `:680-693` specifically requires a graph of authored recipes/deconstruction/
repair BOMs/learning sources/station tiers, starter/donor/advanced acquisition
paths, the economy checker plus resource/picker tests, and traversal “without
injected stock.” G1 is the crafting gate (`:54`): P03-P10 and FC-04..12 pass
through real interactions and saves.

## Existing source-backed evidence

### Title and authored loot entry

- `scripts/title_main.gd:122-128,137` routes New Game into `scenes/main.tscn`;
  `scripts/main.gd:5` selects `scenes/procgen/playable_coherent_ship.tscn`, whose
  paths at `:6-9` select coherent_ship_001 layout/gameplay data.
- `scripts/procgen/playable_generated_ship.gd:10127-10248` builds the home,
  lifeboat, loot containers, and owner-bound stations. `_build_loot_containers`
  at `:3431-3468` uses loader-authored IDs/tables and the current ship's
  `looted_container_ids`; `_on_loot_container_searched` at `:8090-8104` records
  the container and emits scavenging training.
- `data/procgen/golden/coherent_ship_001/gameplay_slice.json:80-81` defines
  `start_supply_a` / `repair_parts_starter` and `start_supply_b` /
  `salvage_engineering`. `data/items/loot_tables.json:86-100` defines the
  starter circuit-board roll and engineering salvage sources including rare
  `thruster_nozzle` and `fabrication_schematic_basic`. This establishes authored
  acquisition sources, not a proof that every random roll contains a desired
  item.

### Recipe knowledge, station and paid-job controls

- The live knowledge route is `_on_inventory_use_requested` -> `_read_recipe_book`
  at `scripts/procgen/playable_generated_ship.gd:9338-9368`; it requires the
  book in inventory, grants book XP, and calls `receive_book_read`. The live
  station picker is `:8980-9091`: owner/binding preflight, exact station, and
  explicit picker confirmation. `scripts/tools/crafting_station.gd:137-171`
  rejects unknown knowledge, wrong tier/skill, and missing ingredients before
  beginning paid work; `:256-289` routes salvage targets through the resolver.
- `scripts/validation/fc_p09_smoke.gd:20-196` is the closest existing scene
  journey. It checks the cold propulsion block, searches authored containers,
  verifies a circuit board, starts and completes nav-linkage repair, proves
  owner-scoped home stations, confirms a book-gated nozzle is
  `missing_recipe_knowledge`, exposes station-tier denial, and drives the picker
  into a paid queued job. Later in the file (`:199-299`) it checks progress,
  power pause, queue/cancel/refund, and pending output; the rest checks crafted
  tool consumers and away-owner lifetime.
- `scripts/validation/main_playable_slice_recipe_picker_smoke.gd:58-196`
  proves picker selection, non-first choice, confirmation-before-start, output
  deposit, and field picker behavior. `main_playable_slice_station_craft_smoke.gd`
  proves live coordinator ownership, station craft, salvage, field craft, and
  coordinator snapshot population, but seeds all inputs and fabrication skill.
- `scripts/validation/main_playable_slice_progression_smoke.gd:14-85` proves
  default Engineer, objective-driven repair XP, HUD display, and save/load XP,
  but completes objectives through validation seams and does not acquire recipe
  knowledge or craft a natural output.
- `scripts/validation/main_playable_slice_crafting_smoke.gd:50-130` is an
  explicitly injected model/save fixture: it seeds inventory, creates separate
  `CraftingState`/`MaterialState`, manually writes snapshot summaries, then
  resumes a paid job. It is useful for persistence assertions, not natural
  Title->loot->crafting acceptance.
- `scripts/validation/e2e_combat_loot_craft_smoke.gd:50-58` similarly seeds
  crafting inputs after a combat setup. It composes systems but is not a cold
  authored-loot acquisition proof.

## Natural-path distinction and concrete gap rows

| Required G1 edge | Existing evidence | Why it is not yet a natural-path proof |
|---|---|---|
| Title New Game -> authored starter loot | `fc_p09_smoke.gd:150-170` searches real loader containers and checks `circuit_board` | Same function force-repairs power/navigation before the opening and its later `_ensure_quantity` helper (`:735-738`) injects missing materials. |
| Loot -> recipe-book learning | `_read_recipe_book` live implementation; P09 only checks `missing_recipe_knowledge` for `craft_thruster_nozzle` | No existing scene smoke starts from the authored `fabrication_schematic_basic` roll, uses inventory Use, and asserts the learned recipe unlocks the picker. |
| Knowledge -> station craft | P09 and recipe-picker smokes use owner-scoped picker and paid jobs | P09 grants fabrication skill and ensures ingredients; picker smoke adds a large stock and sets skill 6 (`main_playable_slice_recipe_picker_smoke.gd:58-74`). |
| Paid job -> interrupt/save/reload/collect | P07/P08 and `main_playable_slice_station_craft_smoke.gd` cover scheduler/pending output | Existing coverage uses seeded fixtures; no single Title-origin inventory lot is traced through payment, queued work, interruption, pending receipt, and collection. |
| Crafted output -> ordinary use/consumer | P09 `_validate_crafted_tool_consumers` and craft completion handlers | The source shows consumer callbacks, but the existing positive setup chooses/injects a ready tool path rather than proving the complete cold acquisition route. |
| Advanced recipe / plating path | `recipe_resource_smoke.gd`, economy tests, recipe catalog | Static/model checks do not prove normal control acquisition of plating, knowledge, tier, and advanced output from a fresh run. |

## Suggested fresh G1 evidence shape

Use the coherent Title scene and a task-owned user home. Capture IDs/origins and
quantities immediately after each ordinary interaction: container ID/table and
lot origin, book ID/read receipt, learned recipe, station owner/instance,
escrowed lots, job/receipt, pending output, collection, and final consumer
effect. The positive path must search the authored containers and use their
actual roll; it must not call `force_repair_all_for_validation`, direct
`inventory_state.add_item`, `_ensure_quantity`, skill dictionary mutation, or
snapshot field injection. Existing validation seams remain appropriate for
negative blocker and scheduler unit cases, but cannot substitute for this G1
journey. No conclusion about current gameplay success or failure is made here;
these are coverage distinctions for the next implementer.

