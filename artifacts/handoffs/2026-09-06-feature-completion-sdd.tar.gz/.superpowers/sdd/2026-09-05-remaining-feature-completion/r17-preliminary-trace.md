# R17 preliminary coverage trace

Read-only trace against the R17 task and Global constraints in
`docs/superpowers/plans/2026-09-05-remaining-feature-completion.md`.
No gameplay, governance, Godot, or Git changes were made.

## Registry evidence contract

`docs/game/inventory/feature_acceptance.json` is schema
`feature-acceptance-v5`. The frozen scope is 668 source rows, 657 active rows,
11 deferred rows, and a 622-row active metric denominator. The registry's
`criteria[]` records expose these fields:

* identity/source: `id`, `criterion`, `criterion_fingerprint`, `source`,
  `verification_source`, `domain`, `feature`, `owner_card`,
  `metric_equivalence`;
* provenance: `declared_status`, `acceptance_kind`, `deferred`;
* executable evidence: `evidence.implemented`,
  `evidence.production_reachable`, `evidence.fresh_validation`,
  `evidence.player_accepted`, `evidence.state`, and `evidence.refs`.

The allowed evidence states in `tools/build_feature_acceptance.py` are
`not_verified`, `blocked`, `unbuilt`, `failed`, `verified_model`,
`verified_scene`, `verified_player`, and `accepted`. The registry currently
has no promoted evidence (`implemented`, `production_reachable`,
`fresh_validation`, and `player_accepted` all account to zero); declared
statuses such as `Validated`, `Implemented`, and `Approved` are historical
provenance and cannot be promoted without refs and current checks.

The registry's active rows are overwhelmingly owned by P23 (634 of 657), so
R17 must trace source leaves rather than use card ownership as domain proof.
Active registry domain counts are: `feature_spec` 337, `core` 49, `aiap` 35,
`avb` 27, `crafting_derelict` 24, `cs` 17, `arch` 16, `enc` 16, `doc` 12,
`sv` 12, `pg` 11, `decay` 11, `int` 10, `d` 8, `mi` 7, `smod` 6,
`walk` 6, `hive` 6, `wa` 5, `cmp` 4, `fill` 4, `slice` 4, `fc` 3,
`le` 3, `cn` 3, `ss` 3, `pm` 3, `ui` 3, `au` 3, `sl` 3, `rl` 3, and
`pcg` 3. These are source-domain labels, not the fifteen plan numbers.

The read-only registry check currently fails before tests:

```text
python tools/build_feature_acceptance.py --check
AssertionError: card manifest is stale; run build_feature_acceptance.py --write
```

This is an R01/R17 source-consistency blocker. Do not run `--write` in this
trace; the coordinator must reconcile the card manifest in its own bounded
window. `tests/test_feature_acceptance_registry.py` was therefore not run.

## Existing executable checks by domain plan

All fifteen plans require deterministic ASCII markers, focused checks, and the
current validation bundle; their embedded standard command still points at a
historical macOS checkout and Godot 4.6.2. It is not a valid Windows command
for this worktree. The plan-level check inventory is:

| Plan | Required executable checks named by the plan | File gaps found by read-only existence check |
|---|---|---|
| 01 survival | `vitals_state_smoke`, `sanity_state_smoke`, `radiation_state_smoke`, `body_temperature_state_smoke`, `main_playable_slice_vitals_full_smoke`, `vitals_state_save_load_smoke` | none |
| 02 food | `food_state_smoke`, `spoilage_state_smoke`, `cooking_state_smoke`, `hydroponics_state_smoke`, `main_playable_slice_cooking_smoke`, `food_save_load_smoke` | `cooking_state_smoke.gd`, `main_playable_slice_cooking_smoke.gd` absent |
| 03 crafting | `material_state_smoke`, `crafting_state_smoke`, `station_state_smoke`, `recipe_resource_smoke`, `quality_tier_smoke`, `field_crafting_state_smoke`, `main_playable_slice_crafting_smoke` | none |
| 04 loot | rarity, distribution, biome table, unique item, junk, container variety, and main playable loot smokes | none |
| 05 consumables | effect dispatcher, consumable, medicine, stimulant, addiction, save/load, and main playable consumables smokes | `main_playable_slice_consumables_smoke.gd` absent |
| 06 combat | damage pipeline, status effects, armor, detection, threat AI, and main playable combat encounter smokes | none |
| 07 ship systems | Plan records delivered markers: `POWER GRID STATE PASS`, `LIFE SUPPORT STATE PASS`, `SUSTENANCE STATE PASS`, `MAIN PLAYABLE SHIP SYSTEMS EXPANDED PASS` | no `Required smoke/validation files` section to enumerate; must derive checks from plan and validation plan |
| 08 progression | progression full, cross-training, training-by-item, meta state/snapshot, skill tree panel | none |
| 09 UI | menu, settings, tooltip, tutorial, map fog, and main playable UI shell smokes | `map_fog_state_smoke.gd` absent |
| 10 audio | audio bus, SFX router, ambient zone, dynamic music, spatial resolver, and main playable audio smokes | none |
| 11 save/load | save slot, save index, migration service, autosave, permadeath, and main playable multislot smokes | `save_index_state_smoke.gd`, `permadeath_resolver_smoke.gd` absent |
| 12 procgen | template C traversal, room variant, kit catalog, biome, difficulty, encounter injector, seed determinism | none |
| 13 distribution | export presets, achievement, localization, demo scope, release readiness ledger | none |
| 14 integration | dependency, survival loop, combat/loot/craft, ship/meta loop, product audit | none |
| 15 systems map | systems-map currency, requirement trace, Kanban manifest | `systems_map_currency_smoke.gd`, `requirement_trace_smoke.gd`, and `kanban_manifest_smoke.py` absent at the paths implied by the plan |

The existence result is only a bounded inventory. It does not classify a
criterion as failed: each missing named check needs source/plan reconciliation
and an owner before implementation.

## Active coverage mapping and special systems

The fifteen plan sources name one primary requirement family each:
`REQ-SV-001`, `REQ-FC-001`, `REQ-CS-001`, `REQ-LE-001`, `REQ-CN-001`,
`REQ-D-001`, (ship systems plan has no REQ token in its source section),
`REQ-PM-001`, `REQ-UI-001`, `REQ-AU-001`, `REQ-SL-001`, `REQ-PG-001`,
`REQ-RL-001`, `REQ-INT-001`, and `REQ-DOC-001`. Registry leaves also live in
cross-cutting feature specs and `docs/game/05_requirements.md`, so this mapping
must be joined by stable criterion IDs/source headings, not filename guesses.

Special R17 areas are present in active leaves but do not have a dedicated one
of the fifteen plan files:

* Travel/route candidates: 71 active keyword candidates across
  `05_requirements.md`, `route_control.md`, `layout_template_b.md`,
  `objective_variation.md`, `layout_template_c.md`,
  `generated_seed_boarded_slice.md`, `save_load.md`, and
  `asset_metadata_pipeline.md`.
* Docking/access/ownership candidates: 25 active keyword candidates, mostly
  `ui_ux_accessibility.md` (14), `05_requirements.md` (6), and
  `crafting_derelict_feature_completion.md` (2). These must be split into
  physical docking, access authorization, ownership, and player-visible UX.
* Objectives: 48 active keyword candidates, led by `05_requirements.md` (22),
  `objective_variation.md` (5), `layout_template_b.md` (4),
  `layout_template_c.md` (3), `route_control.md` (3), and generated/save/asset
  specs. Objective type is not a sufficient identity key; use authored
  `placement_id`/objective sequence contracts.
* Extraction: 8 active keyword candidates across requirements, route control,
  demo scope, save/load, and vertical-slice specs. `generated_seed_boarded_slice`
  explicitly has no extraction requirement, so its PASS cannot close extraction.
* Hangars/nested ships: no active registry rows were found by the literal
  `hangar`/`nested` keyword search. This is an unmapped-source warning, not
  evidence that the system is absent; inspect the docking/ship modification
  specs and requirement headings directly for aliases.

## Recommended bounded audit partitions

1. **Survival and resource loop:** plans 01–05; include home/away, powered
   facilities, loot origins, consumable effects, and save-facing state.
2. **Threat, ship, and persistence:** plans 06–07 and 11; include structural
   damage, power/air/hull, machinery condition, ownership isolation, and
   corruption/migration.
3. **Progression and presentation:** plans 08–10; include action XP/unlocks,
   controller/UI feedback, captions/settings, and player-observable cues.
4. **Generation, release, and integration:** plans 12–15; include native
   generation, deterministic IDs/topology, export disposition, whole-loop
   checks, and registry/card currency.
5. **Cross-cutting travel slice:** audit travel, docking, access/ownership,
   hangars/nested ships, objectives, and extraction as an explicit partition
   spanning 06/07/09/11/12/14, with stable criterion IDs and source headings
   recorded before assigning fixes.

## Concrete unmapped-source blockers

* Card manifest is stale, so the registry cannot currently be accepted by its
  own `--check` gate.
* Fourteen of fifteen plans use requirement-family IDs that do not appear as a
  direct one-to-one registry `domain`; plan-to-registry joins need a reviewed
  mapping table.
* Travel, docking, ownership, hangars/nested ships, objectives, and extraction
  are distributed across multiple feature specs and requirements rather than a
  dedicated plan source. The literal hangar/nested search found no leaves and
  must be resolved by heading/alias review.
* The earlier nine-name absence list is mostly stale naming/path drift, not
  nine proven uncovered behaviors. Canonical replacements are documented
  below; only the replacement checks' current evidence remains to be audited.

## Resolution of the absent check names

The canonical bundle in `docs/game/06_validation_plan.md`, plus the current
runtime validation directory, resolves the plan names as follows:

| Plan name reported absent | Current canonical check/source | Classification |
|---|---|---|
| `cooking_state_smoke.gd` | `cooking_work_xp_away_smoke.gd`, `food_closure_smoke.gd`, and `main_playable_food_production_smoke.gd`/`main_playable_food_consumption_smoke.gd`; the old name remains in REQ-FC-004 verification prose | renamed/split; source wording still stale |
| `main_playable_slice_cooking_smoke.gd` | `main_playable_food_production_smoke.gd` and `main_playable_food_consumption_smoke.gd`; canonical bundle includes cooking work-XP away coverage | renamed/split; no evidence of an uncovered cooking behavior from absence alone |
| `main_playable_slice_consumables_smoke.gd` | `scripts/validation/main_playable_consumables_smoke.gd` exists; bundle also runs `consumables_away_tick_smoke.gd` and `consumable_save_load_smoke.gd` | stale `slice_` prefix |
| `map_fog_state_smoke.gd` | No replacement: `MapFogState`/`MinimapPanel` were explicitly deleted by ADR-0045. `slice_atmosphere_smoke.gd` only checks `WorldEnvironment` volumetric fog density (`fog_enabled`, density, away density); it is not map exploration UI. The live replacement is item-gated `ChartPanel`/`ui_open_map`, documented in `ui_ux_accessibility.md`. | stale retired design reference; old smoke remains uncovered as a behavior because the behavior is intentionally out of scope. Verify ChartPanel acceptance separately |
| `save_index_state_smoke.gd` | `scripts/systems/save_index_state.gd` exists. `save_slot_state_smoke.gd` directly preloads and tests `SaveIndexState` listing manual/autosave/quicksave/world rows, corruption backup, collision rules, and UI row ordering. | stale missing smoke name; semantic model coverage exists in the canonical save-slot smoke, but its current evidence still needs status audit |
| `permadeath_resolver_smoke.gd` | `permadeath_freeze_smoke.gd` is canonical and explicitly exercises `PermadeathResolver`, death freeze, reload denial, epitaph, and reclaim-on-write | renamed |
| `systems_map_currency_smoke.gd` | `scripts/validation/systems_map_currency_smoke.py` exists; bundle invokes `doc_currency_validators.py systems-map` | `.gd` suffix/path in plan is stale |
| `requirement_trace_smoke.gd` | `scripts/validation/requirement_trace_smoke.py` exists; bundle invokes `doc_currency_validators.py requirement-trace` | `.gd` suffix/path in plan is stale |
| `kanban_manifest_smoke.py` | `scripts/validation/kanban_manifest_smoke.py` exists; bundle invokes `doc_currency_validators.py kanban-manifest` | plan path is stale; current file is present |

Thus the prior report's “nine absent files” blocker should be replaced with a
“nine stale plan references requiring source-to-check reconciliation” blocker.
The canonical validation plan is the executable authority; old verification
bullets in `docs/game/05_requirements.md` and plan files need reconciliation by
R01/R17, without changing criterion identities or denominator.

## Docking, hangar, ownership, and nested-ship source trace

The literal keyword search undercounted these areas. Stable source anchors are:

* `REQ-SMOD-001..003` in `docs/game/05_requirements.md` and
  `docs/game/features/ship_modification.md`: physical hub growth, component
  ownership/lifecycle, power-budget installs, and ship-system linkage.
  Verification names include `ship_modification_smoke.gd`,
  `ship_mod_install_key_smoke.gd`, `ship_mod_system_effect_smoke.gd`, and
  `hub_explorable_verify_smoke.gd` (the latter is documented as implemented).
* `FC-13`, `FC-15`, `FC-18..FC-22` in
  `docs/game/features/crafting_derelict_feature_completion.md`: compatible
  physical slots, selected-ship isolation, destroyed-module replacement,
  footprint/sockets/occupancy/egress, visible/collision/nav/atmosphere restore,
  claim→pilot→undock→travel readiness, and persistence across revisit/docking/
  save-load. This is the explicit R17 cross-cutting acceptance chain.
* `REQ-SLICE-001` in `docs/game/05_requirements.md` and
  `docs/game/features/generated_seed_boarded_slice.md`: production
  `travel_to_marker_id` → `_attach_derelict_active`, away branch, standing nav,
  slot loot, wreck overlay, objectives, and 30 away ticks. Its acceptance
  explicitly says “No extract requirement”; it must not close extraction.
* `REQ-001` and `REQ-003` in `docs/game/05_requirements.md`, plus
  `docs/game/features/route_control.md`: route blockers, objective progression,
  reactor stabilization, and extraction unlock. `REQ-006`/`REQ-010` keep hazard
  state parallel to route/extraction semantics.
* The canonical validation plan has executable docking/hangar checks beyond
  the fifteen plan lists: `dock_ports_smoke.gd`, `dock_port_types_smoke.gd`,
  `dock_copresence_smoke.gd`, `docking_loop_smoke.gd`,
  `docking_persistence_smoke.gd`, `hangar_bay_smoke.gd`,
  `hangar_control_smoke.gd`, `hangar_port_smoke.gd`,
  `hangar_persistence_smoke.gd`, and live SFX/away variants. It also runs
  `main_playable_reachability_smoke.gd` with `hangar_interact=true` and
  `derelict_generator_smoke.gd` with `hangar_seeds=80`.

These sources establish several explicit anchors, but they do not prove that
every historical nested-ship design obligation is accounted for. In
particular, no active registry leaf was found whose criterion/source heading
explicitly names `hangar`, `nested ship`, or `ship-in-ship`; broad FC-22/SMOD
language and existing smokes are insufficient to infer complete coverage.
R17 must inspect the requirement register and archived/current feature specs
for the exact original nested-ship obligation and either (a) map it to a
stable active criterion ID, (b) record a reviewed deferral/supersession, or
(c) create a concrete unmapped-source blocker. The same rule applies to
ownership/access semantics beyond the explicit SMOD and FC rows.

## Correction to earlier equivalence conclusions

The earlier report incorrectly called `slice_atmosphere_smoke.gd` a map-fog
replacement. Its lines 45–73 prove only volumetric atmosphere fog. The UI
plan's `map_fog_state_smoke.gd` name has no runtime file, and the UI feature
spec explicitly retires `MapFogState`/`MinimapPanel`; therefore this is not a
renamed or merged smoke. The active UI design to trace is the web-chart
`ChartPanel` contract, while the old interior-map behavior is a retired
source reference.

Likewise, save-index coverage is stronger than the filename inventory showed:
`save_index_state.gd` is a live model and `save_slot_state_smoke.gd` documents
direct `SaveIndexState` checks. Similar UI smokes should not be treated as
model replacements, but this specific model coverage is direct and should be
mapped to the `REQ-SL-001` verification row.
* The fifteen plan command snippets reference obsolete macOS paths/engine
  versions; use the current Windows regression protocol in the remaining-work
  plan and retain raw output/diagnostic classification.
