# R17 survival exact source trace

Snapshot: `2026-09-05T23:54:30.5453627-04:00` at source revision `a8f7d9653bd00c3d6b7b3221dc577277d0a46aec`. R04 had exclusive runtime ownership and the source was moving during this read-only audit. No tests ran, and no Git, runtime, registry, semantic-index, governance, evidence, or schema state changed.

## Selection and authority

`feature_acceptance.json` contains exactly **12** active rows with `domain == "sv"`, matching the expected count. None was already semantically indexed at the recorded snapshot. The exact selection is registry indices **433–444**: one `REQ-SV-001` package leaf, nine distinct `REQ-SV-002` hallucination leaves, one `REQ-SV-007` main-scene package leaf, and one `REQ-SV-008` persistence package leaf.

The three identically worded package rows share reviewed metric group `reviewed-package-68f0294324ff`; `REQ-SV-001` is its denominator representative, while `REQ-SV-007` and `REQ-SV-008` remain active non-counting members. Their mappings below follow their own requirement rationale and verification: core model, main-scene HUD, and persistence respectively.

Accepted ADR-0042 is explicit that hallucination **events** are ephemeral and absent from autosave, while sanity is durable. Its `HallucinationDirector.get_summary/apply_summary` surface is authorized only for pure-model round-trip tests. This audit finds **11 traced leaves and 1 source-confirmed authority conflict**: current `RunSnapshot` capture/restore persists the director episode itself. Existing predicates are evaluated for source trace without claiming fresh execution.

## Exact leaves

### 1. `REQ-SV-001::acceptance-47fbc16a74d2`

> The "Survival vitals" package is implemented and smoke-validated.

**Trace — traced for the requirement’s core-model rationale.** `PlayableGeneratedShip._tick_survival_attrition` builds live cascade/hazard context and calls `VitalsState.tick`; the pure authority implements bounded health/stamina/hunger/thirst, drain/recovery and cascade curves (`vitals_state.gd:41-200`) plus durable summary restoration (`:229-278`).

`vitals_state_smoke.gd:11-33` asserts defaults, movement drain and idle recovery; `:35-69` asserts hunger/stamina, thirst warning, temperature/thirst and radiation/health coupling; `:72-100` asserts summary round-trip and status lines; `:103-164` asserts fire/sanity drain, sanity stamina penalty, incapacitation and movement gating. This is the exact pure-model verification named by `REQ-SV-001:427-438`, rather than a generic package-template mapping.

### 2. `REQ-SV-002::acceptance-d8aa6fd27025`

> Sanity below 40 activates tier-1 ambient hallucination cues (no HUD or phantom events).

**Trace — traced.** `_tick_sanity_and_hallucinations` (`playable_generated_ship.gd:11146-11161`) passes live sanity, safe-zone state and room anchors into the director and manager. Tier 1 begins below 40; only ambient has `min_tier=1`, while HUD/phantom require tier 2. `HallucinationManager.render` routes ambient events to audio (`hallucination_manager.gd:75-82`).

`hallucination_director_smoke.gd:12-24` puts sanity at 35 and requires tier 1, a nonempty ambient stream, and empty HUD/phantom streams. `sanity_hallucination_sfx_smoke.gd:51-72` sends a real catalog ambient event through the live manager/router and requires its routed count to increase. The threshold/channel and cue-routing predicates together cover the leaf.

### 3. `REQ-SV-002::acceptance-7240577f81c5`

> Sanity below 25 activates tier-2 phantom threats and false HUD contact blips.

**Trace — traced.** The director maps sanity 20 to tier 2. `HallucinationManager.render` builds phantom children at `:42-68`, while `get_hallucinated_status_lines` generates `CONTACT? bearing` lines at `:32-40`. `hallucination_director_smoke.gd:15-17,38-42` requires both event kinds at sanity 20. `main_playable_hallucination_smoke.gd:51-69,104-118` proves live phantom rendering and hallucinated HUD lines; the SFX smoke’s `:51-70` exercises the manager/router with real catalog entries.

### 4. `REQ-SV-002::acceptance-e69f90b9b036`

> Sanity below 15 activates tier-3 direct vitals teeth: health drain per second and reduced stamina recovery multiplier fed into the vitals tick via `sanity_health_drain` and `sanity_stamina_recovery_mult` context keys.

**Trace — traced.** `HallucinationDirector.get_direct_teeth` returns nonzero health drain and reduced recovery only at tier 3 (`hallucination_director.gd:210-213`). The production coordinator copies those exact values into `VitalsState.tick` as `sanity_health_drain` and `sanity_stamina_recovery_mult` (`playable_generated_ship.gd:11309-11323`).

`hallucination_director_smoke.gd:73-80` compares neutral tier 2 with tier-3 teeth. `vitals_state_smoke.gd:111-133` independently requires each exact context key to alter health/recovery. `main_playable_hallucination_smoke.gd:97-102,120-139` proves live health teeth on home and boarded/away branches. Combined predicates cover both named inputs and their production consequence.

### 5. `REQ-SV-002::acceptance-077c7a551679`

> Phantoms are rendered by `HallucinationManager`, never registered in `ThreatManager`; real combat math is untouched.

**Trace — traced.** The manager builds its own `Node3D` children using `ThreatPlaceholderRenderer` and has no ThreatManager registration call (`hallucination_manager.gd:4-15,42-68`). Weapon attacks enter normal `ThreatManager.attack_with_weapon` before a separate phantom check. `main_playable_hallucination_smoke.gd:38-69` clears real threats, waits for a manager phantom, requires the ThreatManager list to remain empty, and rejects a combat-sized health loss while the phantom exists. Static owner separation plus that behavior covers this architectural constraint without a brittle method-name test.

### 6. `REQ-SV-002::acceptance-4a05236876d7`

> Swinging at a phantom in melee range dissipates it and spends the attack action (wasted ammo if an ammo weapon is equipped); the attack result carries `phantom_dissipated: true`.

**Trace — traced.** `_attack_with_equipped_weapon` (`playable_generated_ship.gd:9777-9804`) runs normal weapon/ammo expenditure, calls `HallucinationManager.dissipate_phantom_in_range`, and annotates the result. The manager removes both rendered node and director event (`hallucination_manager.gd:94-109,134-144`). `main_playable_hallucination_smoke.gd:78-87` requires fewer phantoms, lower loaded ammo, and `phantom_dissipated=true`; `:89-95` asserts the event does not respawn on subsequent frames.

### 7. `REQ-SV-002::acceptance-70ad5a12cc98`

> Entering a safe zone or returning sanity to tier 0 clears all active hallucination events.

**Trace — traced.** `HallucinationDirector.tick` forces tier 0 in a safe zone and clears events/timers when either safe or sanity-derived tier 0 (`hallucination_director.gd:69-81`). The manager removes nodes missing from the event set. `hallucination_director_smoke.gd:19-33` creates events and enters a safe zone at sanity 10, requiring events/teeth/FX clear. `:62-71` creates events and then ticks sanity 90, requiring an empty event set. The live smoke’s `:141-150` restores sanity/seals the breach and requires zero rendered phantoms.

### 8. `REQ-SV-002::acceptance-d61509f20435`

> The hallucination schedule is deterministic from seed and sanity history (no `randi()`/`randf()`).

**Trace — traced.** `HallucinationDirector` contains no RNG object or `randi`/`randf` call. Its selection uses integer formulas over `rng_seed`, `step` and kind (`hallucination_director.gd:103-113,306-311`), with deterministic timers and input history. `hallucination_director_smoke.gd:44-60` feeds two seed-42 directors the same 200-step sanity history and requires identical event streams on every step; a seed-99 director must diverge.

### 9. `REQ-SV-002::acceptance-a75c0ceb86c3`

> Hallucination events are not persisted; they re-derive from the already-saved sanity value on load.

**Trace — source-confirmed authority conflict.** Durable sanity is correctly captured in `snapshot.sanity_summary` at `playable_generated_ship.gd:12715-12716` and restored at `:13249-13250`; `vitals_state_save_load_smoke.gd:69-72,98-115,128-150` asserts that value.

The director episode is also persisted, contrary to ADR-0042. `RunSnapshot` defines `hallucination_summary` and labels it active events/RNG step/tier state (`run_snapshot.gd:87-97`), includes it in `SUMMARY_FIELDS` (`:147-176`), emits it (`:219-224`) and parses it (`:316-321`). The coordinator captures `HallucinationDirector.get_summary` at `playable_generated_ship.gd:12724-12727` and applies it at `:13261-13262`. That summary serializes/restores `step`, `active_events`, `spawn_timers` and `current_tier` (`hallucination_director.gd:220-285`). `save_load_service_smoke.gd:135-148,275-300` explicitly requires those events, positions, tier and timers to survive disk.

ADR-0042:21-25 says this model summary is test-only and must not enter autosave; `:121-123` says load starts the episode clean. The leaf is therefore unresolved by a precise current-authority contradiction, without inferring or planning a schema change.

Compatible future constraints: preserve durable `sanity_summary` and all other survival summaries. If ADR-0042 remains authority, load should start a clean director and let the normal next tick derive tier from restored sanity, safe-zone context and run seed; legacy transient payloads may be tolerated/ignored without this audit prescribing field deletion. `get_summary/apply_summary` can remain for the explicitly authorized pure-model test. Persisting episodes instead requires an authority decision first.

### 10. `REQ-SV-002::acceptance-43be0d6405f8`

> A pure-model smoke and a main-scene live-loop smoke both pass.

**Trace — traced from substantive existing predicates, with no fresh-run claim.** `hallucination_director_smoke.gd:12-106` asserts thresholds, channel gating, safe clear, deterministic scheduling, TTL, direct teeth, FX, and its ADR-permitted model-only round trip before the marker. `main_playable_hallucination_smoke.gd:33-150` instantiates the main scene and requires live ownership, manifested phantom, ThreatManager separation, normal attack/ammo dissipation, no respawn, home/away teeth, false HUD/FX and clear before its marker. Those predicates trace the exact two required validation surfaces; their marker text alone is not used.

### 11. `REQ-SV-007::acceptance-a04b65ef20ce`

> The "Survival vitals" package is implemented and smoke-validated.

**Trace — traced for the requirement’s main-scene/HUD rationale.** `PlayableGeneratedShip` owns the five survival state models, `PlayerVitalsModel`, and `PlayerVitalsPanel` under the HUD layer and refreshes the model from live summaries. `main_playable_slice_vitals_full_smoke.gd:42-73` requires the actual layer/panel/model and all state owners. `:77-86` requires Health, Stamina, Hunger, Thirst, Sanity, Radiation and Temp lines. `:87-109` sets non-default states and requires HUNGER LOW, THIRST LOW, PERCEPTION PRESSURE, RADIATION SICKNESS, DANGER and Status output. This active metric-group member does not add a denominator unit but has its own exact main-scene trace.

### 12. `REQ-SV-008::acceptance-5cab021c4812`

> The "Survival vitals" package is implemented and smoke-validated.

**Trace — traced for the requirement’s durable-persistence rationale.** `_build_run_snapshot` captures vitals, sanity, radiation, temperature and status-effect summaries (`playable_generated_ship.gd:12712-12722`); `_apply_run_snapshot` restores those same durable values (`:13247-13256`).

`vitals_state_save_load_smoke.gd:45-83` sets non-default health/stamina/hunger/thirst, sanity, radiation, temperature and a stacked effect. `:90-125` requires nonempty snapshot fields and exact values; `:127-160` resets/applies and requires exact restoration. `save_load_service_smoke.gd:149-175,302-332` additionally asserts the non-default durable values through disk. This mapping is specific to `REQ-SV-008`; it preserves the distinction between valid sanity persistence and the invalid transient event persistence reported above.

## Material finding

The only exact source gap is `REQ-SV-002::acceptance-a75c0ceb86c3`. Current source and current save/load assertions deliberately persist the `HallucinationDirector` episode, while accepted ADR-0042 requires only sanity to persist and the episode to start clean/re-derive. Any compatible correction must retain durable survival state, preserve model-only round-trip utility, and reconcile legacy transient payloads without silently changing authority.
