# R02 generation-authority source map

Read-only source map for the R02 fix owner. This records existing generation
and docking authority before `WorldSnapshot` decode. It does not address
codec/version/reward policy and does not propose a new architecture.

## Starting ship: authoritative inputs

`PlayableGeneratedShip` exports the starting document paths at
`scripts/procgen/playable_generated_ship.gd:156-212`:

- `DEFAULT_LAYOUT_PATH` = `res://data/procgen/smoke/seed_000017/layout.json`
- `DEFAULT_KIT_PATH` = `res://data/kits/ship_structural_v0.json`
- `DEFAULT_GAMEPLAY_SLICE_PATH` = `res://data/procgen/smoke/seed_000017/gameplay_slice.json`
- `blueprint_path` defaults to `res://data/procgen/golden/coherent_ship_001/blueprint.json`.

`_ready()` calls `loader.load_from_paths(layout_path, kit_path,
gameplay_slice_path)` at `playable_generated_ship.gd:560-570`. On the initial
`playable_ready` path, `_on_ship_loaded()` wraps that loaded scene as
`ShipInstance.create("ship_start", "", _load_blueprint_for_systems(),
ship_systems_manager, loader)` and stores `home_ship.built_layout =
loader.get_layout_copy()` at approximately lines 10146-10175. The same method
builds the lifeboat with `LifeBoatBuilderScript.build(_resolve_current_loot_biome_id())`
and assigns its layout from `LifeBoatBuilderScript.build_layout()` at
`playable_generated_ship.gd:10293-10305`.

`_load_blueprint_for_systems()` at `playable_generated_ship.gd:1897-1913`
reads `blueprint_path` and falls back to `ShipBlueprint(MEDIUM, DAMAGED, 17)`
when absent or malformed. This blueprint sidecar drives the initial systems
condition/seed; the three loaded document paths drive the actual initial scene.

## Native generation pipeline and supported variants

The pure generation entry points are:

- `ShipGenerator.generate_from_seed(seed, size, condition)` and
  `generate_documents_from_seed(...)` at `scripts/procgen/ship_generator.gd:99-124`.
- `_generate_documents_via_worldgen()` at `ship_generator.gd:144-240` uses
  `WORLDGEN_KIT_ID`, exports native layout/gameplay JSON, stamps `kit_id`,
  biome and difficulty, then returns layout/kit/gameplay documents.
- `_generate_documents_for_blueprint()` at `ship_generator.gd:127-142` calls
  `ShipLayoutGenerator.generate_with_options()` and `_prepare_layout_documents()`.
- `PlayableGeneratedShip.load_from_blueprint()` at
  `playable_generated_ship.gd:1054-1070` uses `ShipGenerator.generate(blueprint)`.

`ShipLayoutGenerator.generate_with_options()` at
`ship_layout_generator.gd:54-92` is the canonical layout route. Its stages in
`_generate_once()` (`ship_layout_generator.gd:96-189`) are
`TemplateSelector -> RoomAssigner -> CellLayoutEngine -> WallDoorResolver ->
LayoutSerializer`, followed by biome/difficulty encounter injection, kit ID
stamping, structural plan compilation/validation, condition mutators, and
wreck plan mutation.

Template selection is explicit and seed-deterministic:

- `TemplateSelector.AVAILABLE_TEMPLATES` is `spine`, `bifurcated`, `stacked`
  (`scripts/procgen/template_selector.gd:18-20`).
- `EXTENDED_TEMPLATES` adds `stacked_v2`, `compact`, `dispersed`, `hive`, and
  `vault` (`template_selector.gd:20-27`).
- `DERELICT_TEMPLATES` is `derelict_a`, `derelict_b` (`template_selector.gd:28`).
- `select()` honors `archetype["template"]`; otherwise it chooses from the
  legacy three using `blueprint.seed_value` (`template_selector.gd:32-42`).
- `select_with_options()` honors an explicit template, otherwise starts with the
  three legacy templates and conditionally adds extended and derelict pools
  (`template_selector.gd:49-71`).
- `generate_with_options(..., extended_templates)` only selects the extended
  route when that argument is true; default `generate()` uses the legacy three
  (`ship_layout_generator.gd:43-45`, `104-108`).

Room dressing variants are selected by `RoomVariantSelector.pick(role,
room_index, seed, biome)` at `scripts/procgen/room_variant_selector.gd:231-240`.
`ShipLayoutGenerator` stamps each room's `variant`, `template_id`, `biome_id`,
`difficulty_id`, and `kit_id` into the layout at
`ship_layout_generator.gd:161-176`. `LayoutSerializer.serialize()` emits
`schema_version`, `program_id`, `design_intent`, `kit_id`, rooms, links,
portals, structural plan and `prototype` start/goal at
`scripts/procgen/layout_serializer.gd:145-167`.

The persisted `ShipBlueprint` authority is exact seed/size/condition plus
optional validated `{biome, difficulty}` generation context:
`ship_blueprint.gd:20-45`, `92-150`, and `152-205`. It does not persist a
template ID, layout document bytes, kit document bytes, gameplay slice bytes,
or a selected room variant in the blueprint itself. Those are in the layout and
the three document paths when a `RunSnapshot` is captured.

## What RunSnapshot records

`RunSnapshot` fields at `scripts/systems/run_snapshot.gd:30-32` persist
`layout_path`, `kit_path`, and `gameplay_slice_path`. `_build_run_snapshot()`
copies those live path values at `playable_generated_ship.gd:12649-12653`, and
`RunSnapshot.to_dict()`/`from_dict()` carry them at
`run_snapshot.gd:189-193` and `248-287`.

It also records current player position, objective sequence, all model
summaries, and current-run metadata. `SUMMARY_FIELDS` includes systems,
oxygen, inventory, crafting, knowledge, module integrity, component placement,
work action, and ship modification summaries (`run_snapshot.gd:147-180`).
The saved blueprint for a visited ship is nested in that ship's `ShipInstance`
summary; the home RunSnapshot itself has no standalone `blueprint` field.

On reload, `_apply_run_snapshot()` resets the runtime, assigns the three saved
paths, synchronously calls `loader.load_from_paths()` and applies summaries to
the rebuilt scene (`playable_generated_ship.gd:13100-13135`). Thus the starting
layout authority available before world decoding is the path triple from the
embedded home `RunSnapshot`, plus the existing blueprint sidecar used during
`_on_ship_loaded`; the save does not carry an independent starting template
selection unless it is present in the saved layout document at that path.

## Visited-ship identity and generation context

`ShipInstance.get_summary()` at `scripts/systems/ship_instance.gd:235-305`
persists `ship_id`, `marker_id`, `blueprint.to_dict()`, systems and mutable
ship state. The blueprint dictionary includes `seed_value`, `size`,
`condition`, room-count range, and valid/invalid generation context. It does
not include a scene root transform. `ShipInstance.apply_summary()` at
`ship_instance.gd:306-452` reconstructs the blueprint and model summaries,
but leaves `scene_root` unset until geometry is regenerated.

First travel creates a `ShipBlueprint(size_class, condition, seed_value)` and
sets marker generation context before registering
`ShipInstance.create("ship_%s" % marker_id, marker_id, blueprint, ...)` at
`playable_generated_ship.gd:8620-8637`. Revisit reuses the retained
`visited_ships[marker_id]` instance and its mutable summaries.

World capture stores every retained instance summary keyed by marker ID at
`playable_generated_ship.gd:13502-13505`. World preparation reconstructs each
summary into a detached `ShipInstance` in `_prepare_world_holder_restore()` at
`playable_generated_ship.gd:13780-13808`, before scene application.

## Persisted docking and transform information

`WorldSnapshot` fields at `scripts/systems/world_snapshot.gd:33-42` persist:

- `visited_ships`: marker ID -> `ShipInstance.get_summary()`;
- `current_location`;
- `player_position_in_ship` (one player position array);
- `dock_edges`: `{host, mobile, port_type, slot_index}` dictionaries;
- `piloted_ship_id`, `aboard_ship_id`, and `opened_ports`.

`_build_world_snapshot()` fills those fields at
`playable_generated_ship.gd:13502-13517`; `WorldSnapshot.to_dict()` and
`from_dict()` copy them at `world_snapshot.gd:55-75` and `94-170`.

The saved dock edge is a logical owner relationship, not a transform. The
canonical live edge producer is `_current_dock_edges()` at
`playable_generated_ship.gd:13565-13612`; its host key is the host marker ID
(`""` for home), and its mobile key is the mobile ship ID. It stores port type
and hangar slot index, but no position, rotation, or basis.

On world apply, `_activate_derelict_from_instance()` regenerates the active
derelict from its own blueprint seed/size/condition via `generate_from_seed()`
and then `_attach_derelict_active()` at `playable_generated_ship.gd:13635-13653`.
`_attach_derelict_active()` places a new root at fixed
`DERELICT_DOCK_OFFSET` (`Vector3(100,0,0)`) and derives the final physical
relationship through docking (`playable_generated_ship.gd:164` and `2597-2645`).
Endpoint-only geometry is similarly regenerated at that offset by
`_ensure_derelict_geometry()` (`playable_generated_ship.gd:13656-13684`).

`_apply_docking_snapshot()` at `playable_generated_ship.gd:13880-13931`
resolves `piloted_ship_id`, re-establishes airlock edges through
`_dock_piloted_to(host)` or hangar edges through `_redock_bayed(mobile, host,
slot_index)`, and restores `aboard_ship_id`. Opened barriers are restored just
before this step in `_apply_world_snapshot()` at `playable_generated_ship.gd:13844-13870`.

## Production placement restore authority

For the active ship, `_apply_run_snapshot()` restores component placement by
calling `component_placement_state.restore_from_layout(active_layout,
component_catalog, component_seed, snapshot.component_placement_summary,
_slot_occupancy_from_loader())` at `playable_generated_ship.gd:13280-13318`.
The layout/catalog supply current fit policy; the saved component summary
supplies persisted installed lots/origins. It then links systems and mirrors
the resulting summary back to `current_ship`.

For retained visited ships, `ShipInstance.apply_summary()` validates and stores
`component_placement` in `component_placement_summary` at
`ship_instance.gd:320-333` and `447-452`. When that ship's geometry is
materialized, `_restore_or_populate_component_placement_for_current_ship()`
rebuilds/uses the live owner (called after home load around
`playable_generated_ship.gd:10180-10190`, and on derelict activation near
`2645-2686`). Staged validation compares each expected ship placement against
the live owner in `_validate_staged_component_placements()` at
`playable_generated_ship.gd:799-824`.

## Persisted versus unavailable context

Available before `WorldSnapshot.from_dict()`/scene rebuild:

- raw embedded home `RunSnapshot` path triple and serialized model fields;
- each visited summary's marker ID, ship ID, blueprint seed/size/condition,
  generation context, and mutable owner summaries;
- current marker, player position, opened ports, piloted/aboard IDs, and logical
  dock edges with host/mobile/port/slot ownership;
- persisted component-placement summaries and lot origins;
- source layout/kit/gameplay documents addressed by the saved path triple, if
  present and unchanged.

Unavailable from the current save contract:

- a per-ship `scene_root` transform (position, rotation, or basis);
- per-ship dock-port world transforms or serialized socket choice;
- a per-ship layout/kit/gameplay path triple in `ShipInstance` summaries;
- blueprint-level persisted template ID or selected room-variant map;
- runtime Node/RID identity, live parent pointers, or scene-tree order.

Current production restore authority is therefore: regenerate each ship from
its persisted blueprint context and current generation documents, place generated
derelicts at the canonical offset, then reconstruct physical placement from
logical dock edges and current layout-derived port/bay descriptors. The exact
per-ship transform is not persisted and cannot be recovered from current
`WorldSnapshot` fields alone.
