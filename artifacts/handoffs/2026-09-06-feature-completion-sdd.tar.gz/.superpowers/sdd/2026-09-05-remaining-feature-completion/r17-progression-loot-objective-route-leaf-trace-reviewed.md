# R17 reviewed progression, loot, objective, and route source trace (moving WIP)

Source-only trace for 37 exact active FEATURE leaves. No runtime/test/Git/registry edits and no evidence promotion.

Exact full-ID and verbatim-criterion validation result: `trace_count=37 registry_count=37 missing=0 extra=0 criterion_mismatch=0`.

The JSON has actual generation time, current HEAD, and moving-WIP provenance. Counts: 37 traced, 0 unresolved, 0 fresh execution scenarios, 2 root causes, 0 evidence promotions.

It separates source seams from proof: injected fixtures and controlled routes do not establish natural XP/acquisition, and master-asset criteria still require human visual approval plus independent artifact review. Retired APIs are mapped to their current ADR-backed replacement where applicable. This is mapping only; root source-index accounting remains 95 semantic rows and 562 pending-active rows.
