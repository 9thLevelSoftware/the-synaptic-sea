# R17 ship-modification exact source trace (moving WIP)

Read-only source-audit draft pending root review. Generated 2026-09-05T21:58:59.6312341-04:00 from d850c26ab596b8130be57c8ba4024ef92617f61d. No tests were run. Full IDs and criterion strings were checked against `docs/game/inventory/feature_acceptance.json` and `docs/game/features/ship_modification.md`; ADR-0066 governs the plating-policy conflict.

## FEATURE::docs/game/features/ship_modification.md::d3fd287beaca

Criterion: Given a scavenged fabricator head and an empty home station slot, when install completes, then station tier/capacity rises and power draw increases.

Status: `partially_traced_unresolved`.

Production trace: `_on_ship_mod_install_requested` preflights the selected ship/slot/lot and starts a transactional `mount_component` WorkAction (`scripts/procgen/playable_generated_ship.gd:5223-5259`). Staging and commit validate the selected owner, resolve the paid lot into ComponentPlacementState, sync ShipModificationState, apply system effects, and refresh that ship's station tiers (`:4481-4507,4528-4557`). `ShipModificationState.sync_from_placement` derives installed power draw (`scripts/systems/ship_modification_state.gd:91-122`), while `_refresh_station_tiers_from_ship_mod` projects `station_tier_bonus` onto explicitly owned station nodes (`scripts/procgen/playable_generated_ship.gd:5407-5441`).

Exact assertion and gap: `scripts/validation/ship_mod_station_tier_smoke.gd:38-58` adds a local reactor console and checks fabricator tier, but does not establish scavenged provenance, an explicitly home-owned station slot, timed WorkAction completion, capacity, or power draw. `scripts/validation/ship_mod_system_effect_smoke.gd:45-66` completes timed installation of an air recycler and proves +10 power draw, but does not assert fabricator tier/capacity or cross-ship provenance. No station-capacity implementation/assertion was found, and these isolated scenarios do not prove the cross-ship leaf.

## FEATURE::docs/game/features/ship_modification.md::a6dcfe7197a0

Criterion: Given over-budget power, when player attempts install, then install is rejected or systems degrade per authored rules.

Status: `traced`.

Production trace: `ShipModificationState.can_install` returns `power_budget` when prospective draw exceeds supply (`scripts/systems/ship_modification_state.gd:166-175`); `preflight_install` derives catalog/quality-adjusted draw and applies that gate before mutation (`:196-248`). The live coordinator checks it before reservation/work start and repeats it at transaction staging (`scripts/procgen/playable_generated_ship.gd:5187-5192,5223-5234,4481-4507`).

Exact assertion: `scripts/validation/ship_mod_power_budget_scene_smoke.gd:43-79` frees two real slots, sets supply so one reactor console fits and the second does not, completes the first timed install, requires the second panel attempt to be rejected, and proves the blocked item remains in inventory. `scripts/validation/ship_modification_smoke.gd:44-50` separately requires the pure-model reason `power_budget`.

## FEATURE::docs/game/features/ship_modification.md::6bd8e50b3903

Criterion: Given a damaged home hull module and salvaged plating, when patch/replace WorkAction completes, then integrity improves and is visible/persistent.

Status: `source_mapped_pending_policy_replacement`.

Production trace: the legacy `_apply_ship_mod_plating_repair` helper repairs the first damaged/breached module by 0.15 and reapplies its scene state (`scripts/procgen/playable_generated_ship.gd:5341-5369`); install commit invokes it at `:4556-4557`. ADR-0066 retires literal `.15` plating-repair markers and states that plating never repairs or resurrects structure (`docs/game/adr/0066-durable-machinery-condition-and-effective-system-health.md:251-265,275-276`). The approved replacement is condition-weighted plating/resilience behavior.

Exact assertion and gap: `scripts/validation/ship_mod_plating_repair_smoke.gd:36-49` checks the legacy numeric increase after panel install. It does not assert patch/replace WorkAction semantics, a visible module state, or persistence, and ADR-0066 explicitly retires that marker. The leaf remains pending the ADR-0066 runtime and validation-marker replacement.

Counts: 3 registry leaves; 1 traced; 2 unresolved, including 1 pending policy replacement; 0 fresh executions.
