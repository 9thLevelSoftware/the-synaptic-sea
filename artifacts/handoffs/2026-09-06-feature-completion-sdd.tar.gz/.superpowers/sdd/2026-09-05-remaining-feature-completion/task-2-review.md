# Task 2 / R02 Independent Review

## Spec compliance

**Verdict: FAIL.** The patch implements most of the new combat persistence contract, but it does not meet the accepted requirements for source-version-pinned migration, authoritative relocated/docked bootstrap inputs, explicit migration failures, a complete strict current schema, or isolated fresh validation. One R02-induced save/load regression is also still present.

The review distinguishes the states required by the project policy: the R02 machinery is substantially **implemented** and the main save/load path is **production reachable**; the three-process P10 proof is **freshly validated** in properly isolated homes; the seven focused Godot results are not acceptable as fresh isolated evidence because they ran against the default Windows Godot profile; and **player acceptance is unassessed**. No helper PASS or `r02_implemented` metadata flag establishes whole-feature or human acceptance.

## Strengths

- `scripts/systems/threat_save_contract.gd` centralizes the new `threat-manager-2` codec and rejects malformed threat rows, duplicate instance IDs, non-finite values, negative structure damage, and ambiguous legacy mixtures. The fixed legacy damage mapping is explicit rather than inferred.
- `scripts/systems/threat_manager.gd:257-269` validates before clearing or mutating the live manager, and the task adds negative atomicity coverage for authoritative state, children, and restored weapon attribution.
- The migration traverses both home and visited owners, and the save/restore candidate carries the threat summary and arbitrary String hotbar text through detached prepare/resolve/apply flow.
- Home and active-away runtime ownership are kept separate. The implementation does not reuse home combat as the away manager's authority.
- `tools/run_p10_process_smoke.py:87-92` correctly sets `APPDATA`, `LOCALAPPDATA`, `GODOT_USER_PATH`, and `XDG_DATA_HOME` for each process. Its retained process-05 evidence supports exit 0, one expected marker, clean diagnostics, distinct data homes, and no source drift.
- The focused smokes cover many valuable cases: exact current round trip, legacy migration, absent versus initialized-empty combat, owner traversal, finite/integral generator inputs, detached resolve, and native generation document parity.

## Material findings

### HIGH — A world version does not pin the embedded run version

**Affected:** `scripts/systems/save_migration_service.gd:722-725`, `scripts/systems/save_migration_service.gd:825-841`; missing coverage near `scripts/validation/combat_persistence_smoke.gd:222-236`.

**Problem:** `_migrate_world_v5_to_v6()` asks `_migrate_world_home_ship()` to migrate the embedded home run directly to v6. `_migrate_world_home_ship()` then starts from whatever `home_ship.slice_version` claims and walks that independent chain. Consequently, an outer `world-5` payload can contain an older run (for example run-v4) and be upgraded through extra mandatory boundaries, or already contain run-v6 and be accepted. The outer source version therefore does not pin the expected inner source version.

**Why it matters:** This is the prohibited mixed/downgrade shape. It lets a new outer migration bypass the exact historical boundary that owns mandatory crafting, field, knowledge, component, and combat checks. It also makes the declared world version cease to describe the payload being migrated.

**Remediation:** Make each world step require the exact embedded run version allowed at that step before invoking the corresponding single run migration. Reject older, newer, missing, empty, and wrong-typed inner versions without mutating the candidate. Add negative mutants for at least `world-v5/run-v4` and `world-v5/run-v6`, plus equivalent earlier boundaries, and assert the intended denial reason, unchanged source/protected live state, and no success marker.

### HIGH — Active-away bootstrap hard-codes one anchor and does not restore relocated or docked ownership

**Affected:** `scripts/systems/save_load_service.gd:52-56`, `scripts/systems/save_load_service.gd:267-289`; circular expectation in `scripts/validation/combat_persistence_smoke.gd:307-363`.

**Problem:** Every recognized pre-v6 active-away owner whose combat is absent is initialized at the constant `(100, 0, 0)`. The test computes its expected result with the same implementation constant. The independent relocated-anchor check at `combat_persistence_smoke.gd:27-45` exercises only the pure initializer, not `SaveLoadService` bootstrap and not a relocated/docked owner context.

**Why it matters:** The accepted requirement explicitly calls for bootstrap from the original validated owner anchor and for relocated/docked cases. A legacy active ship that moved or docked before saving will receive threat world positions for the historical first spawn instead of its authoritative current owner position. The current test cannot detect drift because it duplicates the implementation choice.

**Remediation:** Resolve or persist the per-owner anchor through the authoritative location/docking owner and inject that value into bootstrap. If the required historical owner context cannot be reconstructed, reject the load with an explicit reason rather than synthesizing at a guessed position. Add service-level legacy active-away cases for default, relocated, and docked anchors; derive expected coordinates independently from the fixture's owner context.

### HIGH — Home bootstrap treats a saved path as the authoritative generation source

**Affected:** `scripts/systems/save_load_service.gd:246-263`.

**Problem:** When home combat is absent, the service reads `home.layout_path` directly from the candidate and uses that document and its markers to create and seal combat authority. The path is caller-controlled save data; it is not resolved or cross-checked by a canonical layout/generation service owner.

**Why it matters:** The accepted amendment requires the pre-seal bootstrap to use the original validated context and requires definitions and source inputs to come from canonical service owners. A corrupt or edited legacy save can select a different existing layout and have threats from that substitute layout accepted as restored authority.

**Remediation:** Resolve the home layout and markers through an authoritative owner using validated identity/context (or an immutable canonical starting-layout reference), and cross-check the saved reference before bootstrap. Reject unreconstructable or mismatched context explicitly. Add a forged-but-existing `layout_path` mutant and prove denial with unchanged source, slot/index, and live state.

### HIGH — The R02 version bump leaves `save_load_service_smoke` failing

**Affected:** `scripts/validation/save_load_service_smoke.gd:156-178` and the R02 validation report.

**Problem:** The smoke stamps a default `RunSnapshot` with `CURRENT_SLICE_VERSION` at line 165 without building the mandatory current-v6 `threat_summary`. The retained exploratory output reports `invalid_world_snapshot` because the default fixture has no combat authority. This failure was introduced by the R02 current-version bump; it is not an R03-only failure.

**Why it matters:** A repository smoke for the production save/load service is broken by this task. That is a blocking regression in the same persistence boundary, even though the new focused smokes pass.

**Remediation:** Build a schema-valid current-v6 snapshot in `save_load_service_smoke` using complete owner summaries, including `threat-manager-2`, then retain a clean rerun with exit 0, exactly one expected marker, no unexpected diagnostics, and no timeout. Keep the failure attribution separate from `world_save_service_smoke` (pre-existing missing `ship_id`) and `ship_mod_run_snapshot_smoke` (pre-existing condition-lot WIP).

### HIGH — The focused validation isolation claim is false and the runs touched the default Godot profile

**Affected:** `.superpowers/sdd/2026-09-05-remaining-feature-completion/task-2-report.md:42-58`; destructive fixture setup in `scripts/validation/save_migration_service_smoke.gd:52-55`, `scripts/validation/save_migration_service_smoke.gd:198-218`, and `scripts/validation/fc_p10_smoke.gd:2156-2168`.

**Problem:** The report says the seven focused smokes used fresh task-specific homes, but those commands set only `GODOT_USER_PATH` and `XDG_DATA_HOME` (plus an unsupported `--user-data-dir`). On Windows, the requested directories remained empty and matching Godot logs and save timestamps appeared under the default `APPDATA` profile. Several smokes delete and overwrite shared slot names such as world, quicksave, autosaves, and current-run files. There is no pre-test snapshot from which the prior profile can be restored. The later process-05 runner does set all four variables correctly and is not affected by this finding.

**Why it matters:** The seven logs show behavioral passes, but they do not prove clean, independent fresh runs. More seriously, validation operated on user-profile save state while cleanup code assumed an isolated fixture home. The requirement to retain trustworthy raw evidence is unmet for these focused gates.

**Remediation:** Correct the report to remove the false fresh-home claim and disclose the observed default-profile side effect. Do not delete, rewrite, or guess a restoration for the default profile; the read-only `R02-default-profile-observed-20260905` copy is an afterimage, not a recovery snapshot. Update the repeatable Windows command/runner to set all four home variables to a newly empty directory and assert that `ProjectSettings.globalize_path("user://")` is under that directory before any cleanup. Rerun the seven focused gates only through that isolated path and retain raw stdout/stderr, command, environment/root proof, exit status, marker count, diagnostic scan, and timeout status.

### MEDIUM — Codec failure reasons are discarded by outer migration

**Affected:** `scripts/systems/save_migration_service.gd:80-93`, `scripts/systems/save_migration_service.gd:308-330`, `scripts/systems/save_migration_service.gd:736-745`; weak assertions at `scripts/validation/combat_persistence_smoke.gd:127-134` and `scripts/validation/combat_persistence_smoke.gd:214-218`.

**Problem:** `ThreatSaveContract.migrate_legacy()` produces explicit failures such as `legacy_combat_unknown_archetype:<id>`, but the run and world migration steps collapse failures to `{}`. The migration walker then reports the generic `malformed_legacy_payload`. Tests assert only that migration returned no dictionary and never assert the reason.

**Why it matters:** Unknown or ambiguous archetypes are safely rejected, but the accepted contract also requires an explicit recoverable reason. Losing the reason makes operator diagnosis and user-facing recovery indistinguishable from unrelated malformed data.

**Remediation:** Return a structured step result or otherwise propagate the codec reason through the migration walker. Assert exact reasons for unknown and mixed home combat and for an invalid inactive visited owner, alongside unchanged-state and no-success-marker checks.

### MEDIUM — `last_attack_result` is JSON-valid but not a strict current contract, and the reward assertion stops before production behavior

**Affected:** `scripts/systems/threat_save_contract.gd:78-86`, `scripts/systems/threat_manager.gd:277-282`, `scripts/validation/fc_p10_smoke.gd:90-129`, production consumer `scripts/procgen/playable_generated_ship.gd:8300-8307`.

**Problem:** Current-v2 validation accepts any JSON-compatible dictionary as `last_attack_result`. Restore then coerces `weapon_id` with `str()`, so wrong-typed identity fields can be silently converted. The P10 test proves that `_sweep_dead_threats()` emits a flare-pistol receipt, but it does not connect that receipt to the production `_on_threat_killed()` progression path or assert that `intimidate_threat` remains unchanged.

**Why it matters:** The requested current contract is complete and strict, exact weapon attribution controls rewards, and the acceptance criterion specifically requires a lethal restored ranged hit without an unintended intimidation reward. A local manager signal is insufficient to prove that whole production consequence.

**Remediation:** Define and validate the permitted `last_attack_result` shape and exact field types (including String identity fields and finite numeric fields); do not coerce invalid saved identifiers. Add a production-connected restored ranged-kill test that observes the progression/training owner before and after the callback, expects the exact ranged receipt, and proves no intimidation event or reward.

### MEDIUM — Apply clears most derived manager state but retains LOS cache entries

**Affected:** `scripts/systems/threat_manager.gd:47`, `scripts/systems/threat_manager.gd:159-160`, `scripts/systems/threat_manager.gd:257-269`, `scripts/systems/threat_manager.gd:527-536`.

**Problem:** `_clear_runtime_nodes()` clears nodes, threats, paths, reward bookkeeping, and awareness, but not `engaged_los`. A valid `apply_summary()` can therefore retain derived LOS decisions from the prior manager state. The atomicity smoke checks invalid-apply preservation but does not check that a successful apply removes stale derived cache entries.

**Why it matters:** The binding requirement says to clear derived state before hydration. Reused deterministic instance IDs can inherit stale LOS and alter attack behavior before or outside the scene coordinator's next perception refresh.

**Remediation:** Clear `engaged_los` in the successful apply reset path. Add a test that seeds stale LOS for a reused ID, applies a valid summary, and proves it is absent afterward, while separately proving a rejected summary preserves the pre-call cache.

## Unresolved requirements and covering tests

| Requirement | Current evidence | Review status / required coverage |
|---|---|---|
| Exact `threat-manager-2` round trip, damage mapping, finite checks, initialized-empty semantics | `threat_ai_state_smoke`, `tendril_structure_damage_smoke`, `combat_persistence_smoke`, `fc_p10_smoke` reported PASS | Implementation coverage is strong; focused evidence must be rerun in a verified isolated Windows home. |
| Source-version-pinned run/world migration with no mixed downgrade bypass | Current-boundary tests cover some world-v6/home-v5-or-v7 cases | **Unresolved:** add outer world-v5/inner run-v4 and run-v6 mutants, then extend to earlier exact pairings. |
| Bootstrap from original authoritative layout, markers, definitions, and owner anchor, including relocated/docked | Pure initializer relocation test; service active-away test at shared fixed constant | **Unresolved:** service-level relocated/docked owner proof and forged-layout-source denial are missing. |
| Explicit unknown/ambiguous migration reason and atomic rollback | Codec rejects; owner traversal rejects | **Partially covered:** outer migration discards the explicit reason; assert exact reason and protected-state invariants. |
| Per-owner home/away state and native generation seam | `combat_persistence_smoke` and process-05 P10 evidence | Covered for tested default placement; relocation/docking remains unresolved. |
| Detached restore, exact arbitrary String cache, slot/index integrity | `fc_p10_smoke` plus correctly isolated three-process runner | Fresh process evidence is credible; this does not repair the seven focused evidence runs. |
| Lethal restored ranged attribution with no intimidation reward | `fc_p10_smoke:90-129` checks manager receipt only | **Unresolved:** exercise and observe the production progression callback. |
| Production save/load regression set | Exploratory failures retained in session output | **R02 blocker:** fix and rerun `save_load_service_smoke`. `world_save_service_smoke` and `ship_mod_run_snapshot_smoke` remain downstream/pre-existing follow-up and must not be presented as R02-caused. |
| Player acceptance | No human/player acceptance evidence, and none is claimed | Unassessed. Do not promote a helper/process PASS or `r02_implemented` flag to player or whole-feature acceptance. |

## Task quality

**Verdict: Needs fixes.** The design direction and much of the implementation are sound, but the three HIGH correctness defects, the R02-induced smoke regression, and the invalid focused-isolation evidence block approval. Resolve the findings above and obtain the specified isolated evidence before requesting another Task 2 review.
