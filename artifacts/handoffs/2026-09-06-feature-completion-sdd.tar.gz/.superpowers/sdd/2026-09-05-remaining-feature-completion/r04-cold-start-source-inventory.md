# R04 cold-start acquisition source inventory

Read-only source inventory for P09 / FC-10. This records what the current source
authoritatively creates and gates; it does not establish that a fresh run is
playable end-to-end. No Godot or test process was run for this inventory.

## Title -> New Game and the fresh runtime

- `scripts/title_main.gd:122-128` maps `start` to `_on_title_start()` and
  `continue` to `_on_title_continue()`. `_on_title_start()` calls
  `_instantiate_gameplay(false)`; Continue passes `true`.
- `scripts/procgen/playable_generated_ship.gd:1602-1609` creates the ship
  systems manager, loads the blueprint, applies opening damage, and creates
  player progression. `:1677-1685` creates a new empty
  `InventoryStateScript` namespace `player:<run_id>`; the ordinary fresh-start
  path contains no authored `inventory_state.add_item` calls. `add_item` calls
  at `:4791-4792`, `:4821-4822`, and `:14959-14963` are validation seams, not
  New Game bootstrap.
- `_on_ship_loaded` at `:10127-10260` wraps the generated home as `ship_start`,
  claims local home access, spawns the lifeboat, then builds loot containers,
  repair points, and crafting/production stations. The production station
  creation is explicit at `:10238-10248`.
- The authored golden gameplay slice contains the only identified fresh home
  starter sources: `data/procgen/golden/coherent_ship_001/gameplay_slice.json:80-81`
  declares `start_supply_a` (`repair_parts_starter`) and `start_supply_b`
  (`salvage_engineering`). These are container origins, not carried inventory.
  `scripts/procgen/playable_generated_ship.gd:3431-3468` instantiates each
  loader-provided container with `seed_source = <marker_id>:<container_id>` and
  records searched IDs on the owning ship. `data/items/loot_tables.json:86-100`
  defines the starter table as one `circuit_board`; the engineering table
  includes `circuit_board`, `fuel_line`, `power_cell`, rare `thruster_nozzle`,
  and rare `fabrication_schematic_basic` among its rolls. This is sampled loot,
  so the source inventory does not prove a particular roll occurred.

## Opening operational blockers and normal controls

- `_apply_lifeboat_opening_damage` at
  `scripts/procgen/playable_generated_ship.gd:8068-8083` sets every propulsion
  subcomponent healthy, then damages only `propulsion/nav_linkage` with the
  documented requirement of `circuit_board`, skill 2, and no tool. The source
  comment explicitly says propulsion is offline until that repair and that
  repairing the lifeboat is the opening to travel.
- `travel_to` at `:8510-8585` requires the player aboard the piloted ship and
  passes the current systems operation map to `TravelController.attempt_travel`;
  the propulsion operation bit comes from `_current_systems_ops`. Thus an
  ordinary route must obtain the opening repair part from an authored container
  and complete the repair before travel. The code does not establish that a
  particular deterministic loot roll supplies every later BOM item.
- Ordinary walk-up interaction is ordered in
  `scripts/procgen/playable_generated_ship.gd:10521-10641`: repairs first,
  then work-yield drops, nearest crafting station picker, persistent production
  stations, home loot containers, and tool pickups. The station interaction
  helper `:7098-7102` creates one owner-bound station per configured kind; the
  nearest helper `:10538-10567` only accepts an in-range station with the
  current occupancy ship ID. This is the real control path to open the picker,
  rather than an arbitrary validation seam.

## Recipe-book learning

- The actual inventory Use signal routes through
  `scripts/procgen/playable_generated_ship.gd:9338-9351`. An item definition
  whose `use_kind` is `read_skill_book` calls `_read_recipe_book`.
- `_read_recipe_book` at `:9353-9368` requires the book quantity in the
  player's inventory, then calls `PlayerProgressionState.grant_xp_from_book`
  and `RecipeKnowledgeState.receive_book_read` with the catalog. The ordinary
  entry is opening the inventory panel (`_open_inventory_self` immediately
  following this handler) and choosing Use; no forced knowledge grant is part
  of this route.
- `data/items/item_definitions.json:3` identifies
  `fabrication_schematic_basic` as a readable book. Its authored source is the
  rare `salvage_engineering` entry above. A fresh run therefore needs that
  container roll (or another explicitly authored book source) before recipes
  whose `knowledge_source` is `book` can be claimed reachable.

## Workbench deconstruction and the preserved titanium route

- `scripts/procgen/playable_generated_ship.gd:8980-9050` lists station picker
  entries. For `station_kind == "salvage"`, it delegates to
  `DeconstructionResolver.list_salvage_entries`; normal crafting entries are
  filtered through station ownership, power, skill, tier, and recipe knowledge.
  `:9080-9091` confirms an explicit picker selection calls the exact station's
  `try_salvage_target` and reports `salvaged` or `salvage_failed`.
- `scripts/tools/crafting_station.gd:6-11` defines the physical distinction:
  the salvage station opens the picker and runs deconstruction/junk targets;
  `:256-289` executes the chosen target through the resolver while preserving
  owner/station context. `scripts/systems/deconstruction_resolver.gd:138-225`
  lists all catalog deconstruction recipes plus only junk targets for items
  actually in inventory. This prevents arbitrary loot recommendations.
- `data/recipes/recipe_definitions.json:704-738` is the exact preserved route:
  `deconstruct_thruster` consumes one `thruster_nozzle`, produces one
  `titanium_ingot`, requires workbench and salvage skill 1; and
  `deconstruct_plasma_cutter` does the same for one `plasma_cutter`. Both have
  zero power cost. The item IDs are authored at
  `data/items/item_definitions.json:34-38`.
- The source provides possible origins, not a guaranteed fresh roll:
  `data/items/loot_tables.json:22` places `plasma_cutter` in
  `generic_locker`; `:39` places `thruster_nozzle` and
  `fabrication_schematic_basic` in `salvage_engineering`; `:98` also permits a
  plasma cutter in `repair_tools`. The R04 validation must use the existing
  authored container/objective route and report which sampled origin was used.

## Additional authored economy facts and cold-start gaps

- `data/recipes/recipe_definitions.json:29-34` defines
  `form_plating_plate`: one `plating` -> one `plating_plate`, skill 0, and the
  recipe is a workbench/fabrication edge. `data/items/loot_tables.json:61-75`
  places raw `plating` in `salvage_cargo`; source inspection alone does not
  prove a fresh route reaches that cargo table.
- `data/recipes/recipe_definitions.json:89-100` makes manufacturing a thruster
  nozzle a separate skill-4, tier-2, book-gated fabrication path, so it must
  not replace the documented skill-1 deconstruction route in cold-start proof.
- The current source clearly persists container identity and inventory lot
  provenance after searching (`_on_loot_container_searched` and the home
  snapshot handling at `:13485-13493`), but this inventory found no fresh-start
  carried-item seed. R04 still needs a fresh normal-control capture proving:
  (1) the opening repair succeeds from `start_supply_a`, (2) a normal container
  or objective grants the chosen nozzle/cutter with its origin, (3) inventory
  Use learns the schematic, and (4) the physical workbench/salvage picker
  deconstructs it into titanium. Controlled setup may be used only for negative
  cases, per the brief; it must not inject items or force-repair the positive
  route.

## Class prerequisite audit and actual title profile

- `_configure_player_progression` at
  `scripts/procgen/playable_generated_ship.gd:1854-1885` starts from the
  exported `starting_class_id` and lets a valid, unlocked meta selection
  override it. `playable_generated_ship.gd:213` defaults that export to
  `engineer`; unknown IDs fall back to the engineer class definition.
  `scripts/systems/player_progression_state.gd:81-106` initializes every
  catalog skill to zero, then copies the selected class's `starting_skills`.
- `data/player/classes.json` has these repair starts: engineer 3, mechanic 4,
  scientist 2; medic 1, pilot 1, security 1, salvage_captain 1; cook 0,
  communications 0, and field_medic/signal_specialist omit repair and therefore
  receive catalog default 0. The class catalog marks the unlockable classes;
  the base selectable classes still include repair-0/1 cases.
- The actual blocker is not merely a comment: `data/ship_systems/systems.json:46`
  declares `propulsion/nav_linkage` with `required_parts=[circuit_board]`, no
  tools, `min_skill=2`, and an eight-second repair. `_build_repair_points` at
  `scripts/procgen/playable_generated_ship.gd:3545-3585` passes that
  `sub.min_skill` into `RepairPoint.configure`; `scripts/tools/repair_point.gd:101-137`
  checks the player's `repair` skill and rejects below-minimum starts.
  Therefore the ordinary opening repair is directly satisfiable by engineer,
  mechanic, and scientist; it is blocked for the other classes until an
  authored progression route raises repair. The current source inventory found
  no fresh-start repair XP/book edge that raises a class from 0/1 to 2 before
  this repair, so “every selectable class can cold-start” remains an R04
  coverage gap rather than an established fact.
- Title production does select the coherent profile: `scripts/title_main.gd:9`
  loads `scenes/main.tscn`; `scripts/main.gd:5` preloads
  `scenes/procgen/playable_coherent_ship.tscn`; and that scene's exported paths
  at `scenes/procgen/playable_coherent_ship.tscn:6-9` point to
  `data/procgen/golden/coherent_ship_001/layout.json`, the structural kit, and
  `coherent_ship_001/gameplay_slice.json`. The generic
  `playable_generated_ship.gd` defaults at `:156-158` remain fallback/export
  defaults for the generic scene and are not the Title New Game production
  selection.

## Can a low-repair class train before the opening repair?

- The training catalog has only two events whose target skill is `repair`:
  `data/player/training_actions.json:4` (`repair_subcomponent`, 50 XP) and
  `:5` (`repair_full_system`, 120 XP); the legacy `repair` event at `:34`
  also targets repair. Production emits `repair_subcomponent` only after a
  successful repair (`scripts/procgen/playable_generated_ship.gd:7559-7564`),
  while salvage/container events train scavenging (`:7743-7746`, `:8101-8102`)
  and workbench/fabricator completion trains fabrication (`:7641-7648`). Those
  ordinary home actions do not raise repair.
- `scripts/tools/repair_point.gd:125-138` checks minimum skill before starting
  the channel. Thus `nav_linkage` cannot itself be the first repair-XP source
  for a class below repair 2. The source does create points for every
  nonfunctional subcomponent (`playable_generated_ship.gd:3538-3585`), so a
  deterministic home blueprint damage entry with `min_skill <= 1` could provide
  a pre-opening repair edge. This inventory did not run the loader or assert
  the coherent profile's resulting damaged subcomponents; that possible edge
  remains unresolved, not evidence of a softlock. R04 needs source-backed or
  fresh normal-control proof for each low-repair selectable class.
- Recipe books do not directly grant repair XP: `_read_recipe_book` only calls
  progression/book-knowledge methods (`playable_generated_ship.gd:9353-9368`),
  and the identified starter book is fabrication knowledge. No home container
  source inspected here declares a repair-specific book.
- Class UI availability is explicit in `scripts/ui/class_panel.gd:26-34`:
  every `unlockable=false` class is available; unlockable classes require
  `MetaProgressionState.is_class_unlocked`. Selection is persisted by
  `scripts/ui/menu_coordinator.gd:838-851`. Fresh meta state starts with empty
  `selected_class_id` (`scripts/systems/meta_progression_state.gd:24,179`), so
  production falls back to engineer, while the UI still exposes all base
  classes, including repair-0/1 classes.
