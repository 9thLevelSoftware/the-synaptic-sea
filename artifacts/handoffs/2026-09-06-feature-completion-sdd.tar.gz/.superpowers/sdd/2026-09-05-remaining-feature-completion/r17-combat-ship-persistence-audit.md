# R17 preliminary audit: combat, ship systems, and persistence

Read-only snapshot: `2026-09-05T20:13:00.1433489-04:00`; HEAD `aeba535e45a3b66d8ff87824892513add5109e0b`. Current execution authority is Godot 4.7.2 on Windows, accepted by ADR-0060 and Task 17 Global Constraints. No Godot, tests, runtime, Git mutation, or source edits were performed. R02 owns the active persistence/coordinator changes; this report records source paths and defers R02-owned defect conclusions.

## Coverage boundary

The machine-readable coverage companion is `r17-combat-ship-persistence-coverage.json`. Its checked leaf set is bounded to registry domains `d`, `ss`, `smod`, `mi`, `cmp`, and `sl`: 31 active IDs, all currently `evidence.state=not_verified` with empty refs. It explicitly lists every other active registry ID as `remaining_unmapped_leaf_ids`; this audit does not claim coverage of the 337 `feature_spec` rows or broad `core`/`arch` families.

The exact checked IDs are 8 combat leaves (`REQ-D-001`, `REQ-D-006`, three `REQ-D-019` and two `REQ-D-020` acceptance IDs), 3 ship-system leaves (`REQ-SS-001/002/006`), 6 ship-modification leaves, 7 module-integrity leaves, 4 component leaves, and 3 save/load leaves (`REQ-SL-001/007/012`). No checked ID is deferred.

## Combat (`d`)

The production path is present in `scripts/systems/threat_manager.gd:49-105,127-189,193-232`: it loads archetypes/weapons/ammo, configures LOS/nav inputs, ticks detection and attacks, routes damage through `DamagePipeline`, applies optional structure damage, emits one `threat_killed` reward event, and removes dead threats at `:398-423`. `threat_ai_state.gd:61-100,119-224,291-304` owns configured detection/attack state, damage, status, and summary restore. `damage_pipeline.gd:29-45,49-60` resolves armor damage and round-trips aggregate state.

The active combat leaves remain unverified despite the validation plan registering focused smokes such as `threat_detection_source_smoke.gd`, `threat_kill_removal_smoke.gd`, `combat_reward_data_smoke.gd`, `combat_closure_smoke.gd`, and `combat_corpse_position_smoke.gd` (plan lines 1272-1277). Historical registration is not current evidence. R02 owns the combat save version boundary and independent-process proof in Task 02 (`remaining-feature-completion.md:108-130`); this audit does not reclassify those pending items.

## Ship systems, damage, modification, and special owners (`ss`, `smod`, `mi`, `cmp`)

The live ship owner paths are explicit. `ship_instance.gd:52-54,97-100,136-146,259-302,402-441` stores optional hangar state, combat summary, module-integrity summary, and component placement, and applies them back to a ship. `ship_instance.gd:457-464` lazily creates the hangar owner. `ship_runtime.gd:67-74,204-263,326` attaches live module/component owners and serializes/restores per-ship runtime bundles. `module_integrity_map.gd:17-24,63-89,134-158` binds structural rebuild authority and persists sparse integrity deltas. `pillar_persistence.gd:13-110` provides the pack/unpack boundary for integrity, component placement, and WorkAction state.

Nested and hangar ownership is source-backed but not player-accepted here: `world_snapshot.gd:33,39,145-170,203-249` retains `visited_ships` and dock edges, validates detached nested state and owner IDs; `save_restore_candidate.gd:29,130-147,256-406` materializes home and visited ship owners and performs conservation checks; `playable_generated_ship.gd:672-709,799-824` compares staged nested/component state before commit and `:2642` creates hangar controls. These paths justify an exact-owner audit partition; broad hangar/nested text alone is not evidence that every nested-ship acceptance criterion passed.

All 20 active ship/system/modification/integrity/component leaves listed in the coverage JSON remain `not_verified` with no refs. The relevant validation plan entries exist for ship damage, closure, ship instance models, catch-up, and component/structural behavior, but no command was run. R02 owns any current persistence/coordinator failures; no independent defect is asserted from source inspection alone.

## Persistence (`sl`)

`run_snapshot.gd:243-326` validates and reconstructs the current-run state, including combat, integrity, component, ship modification, and player/system summaries. `world_snapshot.gd:55-170` serializes the home ship, visited ships, dock edges, version, and ownership-sensitive world state. `save_restore_candidate.gd:39-180,318-554` stages restore, validates owner identity, materializes nested ships, and checks physical-lot/job/store conservation before coordinator commit. `save_load_service.gd:623-696` normalizes visited ships and owner defaults; `save_migration_service.gd:613-669` migrates visited component payloads.

The three active save leaves (`REQ-SL-001`, `REQ-SL-007`, `REQ-SL-012`) are unverified in the registry. The validation plan registers save service, migration, autosave, world-save, slot UI, and world-migration smokes (for example lines 452-455, 601-626), but historical `[x]` entries do not promote current evidence. R02 owns the current save/coordinator work and must supply fresh process and migration evidence.

## Findings

No new concrete runtime defect was established within this bounded read. The concrete authority correction is that 4.7.2 is the accepted current engine; earlier 4.7.1 baseline prose is superseded. The previously reported 4.6.2 export-script assumption should remain classified as a potential R19 tooling-compatibility issue only. All checked leaves remain unverified, and all unmapped families remain outside this audit. Next bounded work should capture fresh evidence for exact IDs, especially combat save version boundaries, nested/hangar owner restoration, atomic ship replacement, and process-level persistence; R02 should be cross-referenced rather than duplicated for its owned changes.

Read-source SHA256 provenance at snapshot (not test evidence): `threat_manager.gd` `061CD49BA7E31C9B0FE18AB23E9ED57D886290AEFF924EA2D32DCE122CC850B0`; `threat_ai_state.gd` `36D6B85396B6940445FB9A8A5F8B9164F1F96D03DCD3B8B5A53BB4FBE58C62B1`; `module_integrity_map.gd` `F1B6CD1EB2C35332FC3D47E0A0FC94B9D59690B490D09D88F18B786A3F07D45B`; `ship_instance.gd` `77BF9C8F227D956F0FCD872190883100F9CCDB0A4FEA6FEF9EAE8F9CF0B5ADFA`; `ship_runtime.gd` `33A193C43E03BDF862046B3E831B26209BFE4F7B0B5FC454B1CB6067E368AA7B`; `save_load_service.gd` `D65A81F23E021C0CFB847EDB8CBABEE859C1187B9CF8DB86B91506D5B8E8622A`; `save_migration_service.gd` `B163802DB0F850C265C26E0F01E16BFBF9BE0BD271D6A399CC06488D97576EA7`; `world_snapshot.gd` `C35B246E5AD25E19345C6476190CA34262A6C158313D159108DB1FA42446ABA1`; `save_restore_candidate.gd` `01C44043DA4BAC276E1D83C9AAB3AEB754EB1BB313C8CE3958B87E335C222EFE`.

