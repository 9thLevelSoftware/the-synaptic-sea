extends SceneTree

const MAIN_SCENE: PackedScene = preload("res://scenes/main.tscn")
const CompilerScript := preload("res://scripts/procgen/structural_edge_compiler.gd")
const AuthoringScript := preload("res://scripts/procgen/dock_endpoint_authoring.gd")
const LifeBoatBuilderScript := preload("res://scripts/procgen/life_boat.gd")
const ShipGeneratorScript := preload("res://scripts/procgen/ship_generator.gd")
const KIT_PATH := "res://data/kits/ship_structural_v0.json"
const MARKER := "R10A PAIR SELECTION DIAGNOSTIC PASS"

var main_node: Node
var frame: int = 0
var done: bool = false

func _initialize() -> void:
    main_node = MAIN_SCENE.instantiate()
    get_root().add_child(main_node)
    process_frame.connect(_on_frame)

func _on_frame() -> void:
    if done:
        return
    frame += 1
    var playable = _find_playable(main_node)
    if playable == null or playable.loader == null or not playable.loader.has_loaded_ship():
        if frame > 600:
            _fail("no playable")
        return
    _run(playable)

func _run(playable) -> void:
    playable.force_repair_all_for_validation()
    playable.board_piloted_ship_for_validation()
    playable.recompute_occupancy()
    var marker_ids: Array = playable.scannable_marker_ids_for_validation()
    if marker_ids.is_empty():
        _fail("no marker")
        return
    var travel: Dictionary = playable.travel_to_marker_id(str(marker_ids[0]))
    if not bool(travel.get("success", false)):
        _fail("travel failed: %s" % JSON.stringify(travel))
        return
    var host = playable.get_current_host_for_validation()
    if host == null:
        _fail("no host")
        return
    var selected_layout: Dictionary = host.built_layout.duplicate(true)
    var selected_endpoint: Dictionary = selected_layout.get(
        "boarding_endpoints_v1", [])[0]
    var unauthored: Dictionary = selected_layout.duplicate(true)
    unauthored.erase("boarding_endpoints_v1")
    unauthored.erase("initial_player_spawn_v1")
    var compiler: RefCounted = CompilerScript.new()
    unauthored["structural_plan"] = compiler.compile(unauthored)
    unauthored["structural_plan_validated"] = true
    var kit_variant: Variant = JSON.parse_string(
        FileAccess.get_file_as_string(KIT_PATH))
    var projection: Dictionary = (kit_variant as Dictionary).get(
        "dock_collision_projection_v1", {})
    var lifeboat: Dictionary = LifeBoatBuilderScript.build_layout()
    var author_result: Dictionary = AuthoringScript.author_layout(
        unauthored, false, projection, lifeboat)
    if not bool(author_result.get("ok", false)):
        _fail("reauthor failed: %s" % JSON.stringify(author_result))
        return
    var reauth_endpoint: Dictionary = unauthored.get(
        "boarding_endpoints_v1", [])[0]
    if reauth_endpoint != selected_endpoint:
        _fail("reauth selection differs from production endpoint")
        return
    var enriched_rejections: Array[Dictionary] = []
    for rejection_variant in author_result.get("candidate_pair_rejections", []):
        var rejection: Dictionary = (rejection_variant as Dictionary).duplicate(true)
        var mobile_shapes: Array[Dictionary] = []
        for overlap_variant in rejection.get("overlaps", []):
            var overlap: Dictionary = overlap_variant
            var mobile_path: String = str(overlap.get("mobile", ""))
            var delimiter: int = mobile_path.find("/")
            if delimiter < 0:
                continue
            var placement_id: String = mobile_path.substr(0, delimiter)
            var shape_path: String = mobile_path.substr(delimiter + 1)
            var placement: Dictionary = _placement_by_id(
                lifeboat.structural_plan, placement_id)
            var module_id: String = str(placement.get("module_id", ""))
            var projected_module: Dictionary = projection.get(
                "modules", {}).get(module_id, {})
            for box_variant in projected_module.get("boxes", []):
                var box: Dictionary = box_variant
                if str(box.get("shape_path", "")) == shape_path:
                    mobile_shapes.append({
                        "placement_id": placement_id,
                        "module_id": module_id,
                        "placement_position": placement.get("position", []),
                        "placement_yaw_degrees": placement.get("yaw_degrees", 0),
                        "shape": box.duplicate(true),
                    })
        rejection["mobile_projected_shapes"] = mobile_shapes
        enriched_rejections.append(rejection)
    var output: Dictionary = {
        "marker_id": str(marker_ids[0]),
        "selected_endpoint": selected_endpoint,
        "candidate_count": int(author_result.get("candidate_count", -1)),
        "supporting_candidate_count": int(
            author_result.get("supporting_candidate_count", -1)),
        "selected_pair": author_result.get("selected_pair", {}),
        "rejected_pairs": enriched_rejections,
        "lifeboat_endpoint": lifeboat.boarding_endpoints_v1[0],
        "selected_blueprint": {
            "seed": int(host.blueprint.seed_value),
            "size": int(host.blueprint.size),
            "condition": int(host.blueprint.condition),
        },
        "preferred_seed_authoring": [
            _raw_authoring(42, int(host.blueprint.size),
                int(host.blueprint.condition), projection, lifeboat),
            _raw_authoring(777, int(host.blueprint.size),
                int(host.blueprint.condition), projection, lifeboat),
        ],
    }
    print("R10A_PAIR_SELECTION_DIAGNOSTIC=%s" % JSON.stringify(output))
    done = true
    print(MARKER)
    _teardown(0)

func _raw_authoring(
        seed_value: int, size_class: int, condition_class: int,
        projection: Dictionary, lifeboat: Dictionary) -> Dictionary:
    var native = ClassDB.instantiate("DerelictGenerator")
    if native == null:
        return {"seed": seed_value, "ok": false, "reason": "native_missing"}
    var archetypes: Dictionary = {0: "shuttle", 1: "corvette", 2: "freighter"}
    var intactness: Dictionary = {0: 9500, 1: 6000, 2: 2000}
    var parameters: Dictionary = {
        "archetype_id": str(archetypes.get(size_class, "")),
        "intactness_override": int(intactness.get(condition_class, -1)),
    }
    var raw_variant: Variant = JSON.parse_string(str(native.export_layout_json(
        seed_value, parameters, "ship_structural_v0")))
    if not raw_variant is Dictionary:
        return {"seed": seed_value, "ok": false, "reason": "raw_invalid"}
    var raw: Dictionary = (raw_variant as Dictionary).duplicate(true)
    if not ShipGeneratorScript.stamp_native_component_slot_contracts(raw):
        return {"seed": seed_value, "ok": false, "reason": "slot_stamp_failed"}
    var old_layout: Dictionary = raw.duplicate(true)
    var old_result: Dictionary = AuthoringScript.author_layout(
        old_layout, false, projection)
    var paired_layout: Dictionary = raw.duplicate(true)
    var paired_result: Dictionary = AuthoringScript.author_layout(
        paired_layout, false, projection, lifeboat)
    return {
        "seed": seed_value,
        "old_first_supporting_result": old_result,
        "old_first_supporting_endpoint": old_layout.get(
            "boarding_endpoints_v1", []),
        "paired_result": paired_result,
        "paired_endpoint": paired_layout.get("boarding_endpoints_v1", []),
        "paired_rejections": _enrich_rejections(
            paired_result.get("candidate_pair_rejections", []),
            lifeboat, projection),
    }

func _enrich_rejections(
        rejection_values: Array, lifeboat: Dictionary,
        projection: Dictionary) -> Array[Dictionary]:
    var result: Array[Dictionary] = []
    for rejection_variant in rejection_values:
        var rejection: Dictionary = (rejection_variant as Dictionary).duplicate(true)
        var mobile_shapes: Array[Dictionary] = []
        for overlap_variant in rejection.get("overlaps", []):
            var overlap: Dictionary = overlap_variant
            var mobile_path: String = str(overlap.get("mobile", ""))
            var delimiter: int = mobile_path.find("/")
            if delimiter < 0:
                continue
            var placement_id: String = mobile_path.substr(0, delimiter)
            var shape_path: String = mobile_path.substr(delimiter + 1)
            var placement: Dictionary = _placement_by_id(
                lifeboat.structural_plan, placement_id)
            var module_id: String = str(placement.get("module_id", ""))
            var projected_module: Dictionary = projection.get(
                "modules", {}).get(module_id, {})
            for box_variant in projected_module.get("boxes", []):
                var box: Dictionary = box_variant
                if str(box.get("shape_path", "")) == shape_path:
                    mobile_shapes.append({
                        "placement_id": placement_id,
                        "module_id": module_id,
                        "placement_position": placement.get("position", []),
                        "placement_yaw_degrees": placement.get("yaw_degrees", 0),
                        "shape": box.duplicate(true),
                    })
        rejection["mobile_projected_shapes"] = mobile_shapes
        result.append(rejection)
    return result

func _placement_by_id(plan: Dictionary, placement_id: String) -> Dictionary:
    for group in ["floor_placements", "placements", "ceiling_placements"]:
        for record_variant in plan.get(group, []):
            if record_variant is Dictionary and str(
                    (record_variant as Dictionary).get(
                        "placement_id", (record_variant as Dictionary).get(
                            "id", ""))) == placement_id:
                return (record_variant as Dictionary).duplicate(true)
    return {}

func _find_playable(node: Node):
    if node is PlayableGeneratedShip:
        return node
    for child in node.get_children():
        var found = _find_playable(child)
        if found != null:
            return found
    return null

func _fail(reason: String) -> void:
    if done:
        return
    done = true
    push_error("R10A PAIR SELECTION DIAGNOSTIC FAIL reason=%s" % reason)
    _teardown(1)

func _teardown(code: int) -> void:
    if main_node != null and is_instance_valid(main_node):
        main_node.free()
        main_node = null
    call_deferred("_quit", code)

func _quit(code: int) -> void:
    quit(code)
