extends SceneTree

const LifeBoatBuilderScript := preload("res://scripts/procgen/life_boat.gd")
const DockingManagerScript := preload("res://scripts/systems/docking_manager.gd")

func _initialize() -> void:
    var layout: Dictionary = LifeBoatBuilderScript.build_layout()
    var position_value: Array = layout.initial_player_spawn_v1.local_position
    var local_position := Vector3(float(position_value[0]), float(position_value[1]),
        float(position_value[2]))
    var verdict: Dictionary = DockingManagerScript.validate_registered_spawn_clear(
        layout, Transform3D.IDENTITY, local_position)
    print("R10A_SPAWN_CLEARANCE_DIAGNOSTIC=%s" % JSON.stringify(verdict))
    var candidates: Array[Dictionary] = []
    var endpoint: Dictionary = layout.boarding_endpoints_v1[0]
    var endpoint_point: Array = endpoint.interior_clearance_point_local
    var measured_points: Array[Vector3] = [Vector3(float(endpoint_point[0]),
        float(endpoint_point[1]), float(endpoint_point[2]))]
    for x_step in range(7):
        for z_step in range(7):
            measured_points.append(Vector3(2.5 + 0.5 * x_step, 0.55,
                -1.5 + 0.5 * z_step))
    for point in measured_points:
        var candidate: Dictionary = DockingManagerScript.validate_registered_spawn_clear(
            layout, Transform3D.IDENTITY, point)
        if bool(candidate.get("ok", false)):
            candidates.append({"local_position": point, "verdict": candidate})
    print("R10A_SPAWN_CLEAR_POINTS=%s" % JSON.stringify(candidates))
    print("R10A SPAWN CLEARANCE DIAGNOSTIC PASS")
    quit(0)
