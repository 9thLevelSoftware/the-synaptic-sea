extends SceneTree

const LifeBoatBuilderScript := preload("res://scripts/procgen/life_boat.gd")
const DockingManagerScript := preload("res://scripts/systems/docking_manager.gd")

func _initialize() -> void:
    var layout: Dictionary = LifeBoatBuilderScript.build_layout()
    var position_value: Array = layout.initial_player_spawn_v1.local_position
    var local_position := Vector3(float(position_value[0]), float(position_value[1]),
        float(position_value[2]))
    var verdict: Dictionary = DockingManagerScript.validate_registered_spawn_clear(
        layout, Transform3D.IDENTITY, local_position)
    print("R10A_SPAWN_CLEARANCE_DIAGNOSTIC=%s" % JSON.stringify(verdict))
    print("R10A SPAWN CLEARANCE DIAGNOSTIC PASS")
    quit(0)
