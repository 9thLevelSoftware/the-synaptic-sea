# R17 bounded audit: survival, food, and consumables

Read-only trace of plans 01, 02, and 05 against the active registry leaves and
current runtime sources. No Godot run, code edit, registry edit, or governance
change was performed.

## Active leaves in scope

The registry currently marks every in-scope leaf `state=not_verified`, with all
four evidence booleans false and `refs=[]`:

* Survival (`domain=sv`): `REQ-SV-001::acceptance-47fbc16a74d2`, all eight
  `REQ-SV-002` leaves (`d8aa6fd27025`, `7240577f81c5`, `e69f90b9b036`,
  `077c7a551679`, `4a05236876d7`, `70ad5a12cc98`, `d61509f20435`,
  `a75c0ceb86c3`, `43be0d6405f8`), `REQ-SV-007::acceptance-a04b65ef20ce`,
  and `REQ-SV-008::acceptance-5cab021c4812`.
* Food (`domain=fc`): `REQ-FC-001::acceptance-9b9251649ac4`,
  `REQ-FC-004::acceptance-41ac5998a30a`, and
  `REQ-FC-008::acceptance-c25f70862438`.
* Consumables (`domain=cn`): `REQ-CN-001::acceptance-e96391835861`,
  `REQ-CN-004::acceptance-a86e801fefa0`, and
  `REQ-CN-009::acceptance-84ffad824395`.

The package-level leaves are reviewed exact-text representatives; the detailed
REQ-SV-002 hallucination leaves are distinct active behavior criteria. No
historical `declared_status` is treated as current execution evidence.

## Survival runtime trace

The production coordinator instantiates survival models at
`scripts/procgen/playable_generated_ship.gd:1702-1704,1709-1717` and runs one
survival attrition path from both home and away process branches. The live path
at `playable_generated_ship.gd:11244` assembles temperature, radiation,
life-support/oxygen, fire, status, sanity teeth, and encumbrance inputs, passes
them to `VitalsState.tick`, then applies movement gating and terminal death.
`playable_generated_ship.gd:11356-11357` advances status effects; the model
implementations are `scripts/systems/vitals_state.gd:140-254`,
`sanity_state.gd:28-66`, `radiation_state.gd:28-84`,
`body_temperature_state.gd:29-115`, and `status_effects_state.gd:40-135`.

The player-facing downstream path is present: `_refresh_player_vitals` applies
the live summaries to `PlayerVitalsModel` at
`playable_generated_ship.gd:11632-11660`; the panel/model formatting is in
`scripts/systems/player_vitals_model.gd:84-225` and
`scripts/ui/player_vitals_panel.gd`. Death is a scene consequence through
`_check_vitals_death` at `playable_generated_ship.gd:11380-11389`, which calls
`end_run("death")` when the model is incapacitated.

The survival save boundary is explicit. `_build_run_snapshot` captures vitals,
sanity, radiation, temperature, status effects, and hallucination summaries at
`playable_generated_ship.gd:12638-12720`; `_apply_run_snapshot` restores them at
`playable_generated_ship.gd:13099-13256`. This establishes model/scene wiring,
but the registry has no fresh refs or player acceptance for any SV leaf.

### Concrete discrepancy requiring bounded follow-up

`REQ-SV-002::acceptance-a75c0ceb86c3` says hallucination events are not
persisted and must re-derive from saved sanity. Current production code does
the opposite: `_build_run_snapshot` stores `hallucination_director.get_summary()`
at `playable_generated_ship.gd:12717-12720`, and `_apply_run_snapshot` calls
`hallucination_director.apply_summary()` at `playable_generated_ship.gd:13250-13256`.
`scripts/systems/hallucination_director.gd:220-290` serializes/restores
`active_events`, timers, seed, and step. The adjacent comment identifies this
as intentional mid-episode persistence. This is a concrete source/spec
contradiction, not an inference from an unchecked old box; it needs a reviewed
decision and a focused positive/negative save test before the leaf can be
classified.

The other SV-002 leaves have executable model/scene candidates in the source:
threshold/tier scheduling is `hallucination_director.gd:9-20,65-145`, scene
rendering and false HUD/audio/FX are `hallucination_manager.gd:36-102`, and
phantom attack dissipation is wired through the manager. These are implementation
observations only; no fresh validation or player evidence is claimed.

## Food runtime trace

Food definitions are in `data/items/item_definitions.json:6-13,50`, including
spoilage durations, fresh/stale/rotten multipliers, restores, and sickness risk.
`SpoilageState` owns per-item `FoodState` instances in
`scripts/systems/spoilage_state.gd:4-34`, advances them from
`playable_generated_ship.gd:11372-11378` on both home and away branches, and
serializes/restores at `playable_generated_ship.gd:12723-12729` and
`13258-13264`. Newly acquired food is registered by
`_register_food_for_spoilage` (`playable_generated_ship.gd:7592-7605`) from
loot/craft/production call sites at lines 7629, 7707, 7782, and 8122.

The live consumption path is `ConsumableState.use_item` at
`scripts/systems/consumable_state.gd:46-205`, called by direct and hotbar
coordinator entry points at `playable_generated_ship.gd:9976-10024`. Food/drink
uses `_apply_food_restores` (`consumable_state.gd:220-270`) to read tracked
spoilage stage and apply hunger/thirst to `VitalsState` and sanity to
`SanityState`; the coordinator refreshes UI/vitals and emits training after a
successful use (`playable_generated_ship.gd:9986-9997,10008-10024`).

The old standalone `CookingState` file is explicitly retired in
`scripts/systems/cooking_state.gd:1-12`; the live producer is the kitchen/
synthesizer recipe path through `CraftingState`. This retirement is documented
by `scripts/validation/food_synthesizer_retirement_smoke.gd`, which checks that
the coordinator has no `synthesizer_state`, the crafting synthesizer still
produces `synthesized_paste`, and legacy snapshots load. Therefore absence of a
`cooking_state_smoke.gd` file is not by itself a food runtime defect, although
the old plan/spec verification names still need reconciliation.

Hydroponics and water recycling are production-owned models: construction is
at `playable_generated_ship.gd:7291-7302`, time advancement is
`11372-11378`, summaries are fed to `SustenanceState` at
`2078-2095`, and save/load is at `12726-12729`/`13261-13264`. Existing focused
files include `main_playable_food_production_smoke.gd`,
`main_playable_food_consumption_smoke.gd`, `food_away_tick_smoke.gd`,
`spoilage_eat_scaling_smoke.gd`, and `food_save_load_smoke.gd`.

No fresh evidence is attached to the three FC registry leaves. The bounded
runtime trace found no additional proven defect beyond stale references to the
retired cooking model and the need to reconcile the canonical replacement
checks.

## Consumables runtime trace

`EffectDispatcher` loads `data/items/effect_definitions.json` and dispatches
vitals, sanity, radiation, temperature, status-add, and status-cure effects at
`scripts/systems/effect_dispatcher.gd:8-90`. The coordinator injects all
consumable dependencies at `_consumable_pipeline_context`
(`playable_generated_ship.gd:9928-9943`). `ConsumableState` accepts food/drink,
medicine, stimulant, ammo, and utility categories at
`scripts/systems/consumable_state.gd:20-33,114-205`; failed consumption restores
the removed lot in the category branches.

Medicine, stimulant/addiction, ammo, and utility models are instantiated at
`playable_generated_ship.gd:1710-1717` and ticked from
`_tick_ammo_and_consumable_decay` at `playable_generated_ship.gd:11168-11177`.
Medicine/stimulant summaries and restoration are captured at
`12730-12736` and restored at `13265-13272`. Stimulant dose/tolerance and
withdrawal flow through `scripts/systems/stimulant_state.gd:18-73` and
`addiction_state.gd:29-92`; status effects are the downstream consumer.

Direct and hotbar player entry points are present at
`playable_generated_ship.gd:9976-10024`, including SFX, hotbar reassignment,
encumbrance, oxygen/vitals refresh, UI refresh, and training-event emission.
Existing focused checks include `consumable_state_smoke.gd`,
`medicine_state_smoke.gd`, `stimulant_state_smoke.gd`,
`addiction_state_smoke.gd`, `consumable_save_load_smoke.gd`,
`consumables_away_tick_smoke.gd`, and `main_playable_consumables_smoke.gd`.

No fresh evidence is attached to CN leaves. The bounded trace found no
additional concrete runtime defect, but player/controller acceptance and the
full status-cure/ammo/utility path remain unverified until those checks are
run on the frozen source and promoted with exact refs.

## Remaining bounded leaves and disposition

All 11 SV leaves, 3 FC leaves, and 3 CN leaves listed above remain
`not_verified` in the registry. The trace establishes implementation and
production-call candidates, not `verified_model`, `verified_scene`,
`verified_player`, or `accepted` status. Required follow-up is:

1. Resolve the hallucination persistence contradiction against the exact
   REQ-SV-002 leaf.
2. Reconcile retired CookingState and stale smoke names with canonical food
   checks; do not resurrect the retired model solely to satisfy old plan text.
3. Run/pin focused model and live-scene checks, then separately obtain player
   evidence for HUD, food freshness/use, and consumable/hotbar/controller paths.

