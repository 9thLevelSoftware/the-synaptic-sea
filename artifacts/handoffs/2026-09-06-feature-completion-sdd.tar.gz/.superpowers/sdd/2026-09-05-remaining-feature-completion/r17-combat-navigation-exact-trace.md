# R17 Combat / Threat Navigation Exact Trace

- Generated: `2026-09-05T23:54:51.6023776-04:00`
- Source revision: `ed70d37198000529cb8baa5217414f74a0372090`
- Moving WIP: `true`
- Scope: source-only audit; no Godot/runtime/test execution, evidence promotion, registry/index/governance/source/git change, or whole-game acceptance
- Selection: `domain == "d" && deferred == false`, excluding exact keys in `r17-source-trace-index.json.semantic_trace_reports`
- Frozen inventory: `668 recorded`, `657 active`, `622 canonical metric leaves`
- Exact selection: `8 domain rows`, `0 already semantically indexed`, `8 selected`, expected `8`, mismatch `0`
- Result: `4 traced`, `3 source_mapped_validation_gap`, `1 confirmed_runtime_contract_mismatch`, `0 unresolved`, `0 fresh executions`, `0 evidence promotions`

The three repeated package criteria are scoped by their distinct registered verification seams: D-001 is damage/armor/status, D-006 is the shared threat-state model, and D-010 is the main playable combat/save-load encounter. None is used as a generic label-only proof for the other two.

The production movement chain is live in both home and away branches: `PlayableGeneratedShip._process` calls `_tick_threat_runtime` (`scripts/procgen/playable_generated_ship.gd:11035-11087`), which refreshes dynamic nav costs and calls `ThreatManager.tick_threats` (`:9855-9896`). The manager ticks the pure `ThreatAIState`, advances through `ThreatPathfinder` waypoints, writes model position/room, and then copies position to the placeholder `Node3D` (`scripts/systems/threat_manager.gd:132-196,443-526`). This establishes that current production has INVESTIGATE and FLEE paths. ADR-0049's statement that they were missing is historical context for the accepted decision, not a current-source finding.

Current authority is Accepted ADR-0037 for the pure combat-model and scene-coordinator boundary; Accepted ADR-0049 for graph pathfinding, state targets, dynamic costs, placeholder sync, and repath-after-restore; and Accepted ADR-0054 for the amended compiler-edge standing graph. ADR-0059 decisions 33-38 are the accepted R02 persistence amendment: current outer v6 envelopes, strict nested `threat-manager-2`, shared initializer, and separate owner combat authority. R02 combat is accepted in `task-2-fix1-review.md`. R03 is frozen at this revision for independent review, and `task-3-report.md` expressly leaves acceptance pending. No historical marker or task report is presented as a fresh run here.

`traced` means the current route and the full leaf are directly covered by substantive assertions or an exact static architecture review. `source_mapped_validation_gap` means production source is mapped but existing predicates omit a required dynamic conjunct. `confirmed_runtime_contract_mismatch` is reserved for a source-level contradiction with the current exact contract; it is not inferred from a missing test.

## Key findings

- HUNT movement is implemented and directly helper-tested in a pure and a main-scene script. ATTACK shares the production target branch but is never moved by either test; neither test invokes the production `tick_threats` caller or checks placeholder synchronization.
- INVESTIGATE does target stored `last_known_position` in production. No smoke supplies and asserts that destination. The state smoke allows either HUNT or INVESTIGATE and does not check movement.
- FLEE is implemented, but `farthest_point` violates both phases of its stated Dijkstra/maximum-distance-then-tie-break rule. Its FIFO `pop_front` traversal can settle weighted nodes before their minimum tentative distance, and its final `d_path * 0.35 + d_avoid` score can choose a node that is not farthest by either measure. Its only smoke assertion is that the returned point is not `Vector3.INF`.
- Dynamic fire and unbypassed hatch pairs are pushed into the manager before each threat tick in both process branches. Fire/hatch overlays feed `neighbors`, and A* consumes those costs. No smoke calls the dynamic overlay methods or asserts a before/after fire detour or hatch disconnection, despite the requirement's claim that pathfinder unit tests cover this.
- Waypoints and dynamic edge overlays are derived and not saved. Position, state, memory, last-known position, and movement tuning are persisted under strict `threat-manager-2`; the active layout graph is rebuilt after restore and threats repath.

## Exact leaf traces

### `REQ-D-001::acceptance-b6d1b8dc002b`

**Criterion:** The "Combat, threat AI, damage, armor, status" package is implemented and smoke-validated.

- Inherited scope: D-001's registered `damage_pipeline_smoke.gd` slice.
- Route/consequence: threat attacks call `DamagePipeline.apply_to_vitals`; player weapons call `apply_to_threat`. The pipeline resolves armor, mutates vitals/threat state, applies authored status, and records damage/noise (`threat_manager.gd:178-239`; `damage_pipeline.gd:29-52,72-96`). The scene coordinator refreshes vitals/inventory/hotbar and captures combat state (`playable_generated_ship.gd:9777-9810`).
- Predicate: `damage_pipeline_smoke.gd:14-54` requires player health `65` after a 20 physical/25%-resisted hit, bleed present, threat health `19` after a 10 physical/50%-resisted hit, STUN state, and exactly two processed hits. The PASS marker follows these predicates at `:55-60`.
- Data/save: weapon/ammo/status JSON feeds the live models. Damage receipts, armor and threat state are nested in strict `threat-manager-2` (`threat_manager.gd:241-260`; `threat_save_contract.gd:4,53-100`).
- Status: `traced`.

### `REQ-D-006::acceptance-6ecf253508ec`

**Criterion:** The "Combat, threat AI, damage, armor, status" package is implemented and smoke-validated.

- Inherited scope: D-006's registered `threat_ai_state_smoke.gd` shared FSM slice.
- Route/consequence: live player signals flow through `PlayableGeneratedShip._tick_threat_runtime` to `ThreatManager.tick_threats`, which supplies perception/player position to `ThreatAIState.tick`, consumes attacks, advances motion, syncs placeholders and sweeps dead threats (`playable_generated_ship.gd:9855-9875`; `threat_manager.gd:132-196`).
- Predicate: `threat_ai_state_smoke.gd:18-52` requires ATTACK, attack readiness, cooldown after consume, HUNT-or-INVESTIGATE memory behavior, and DEAD after lethal damage. That disjunction is not reused as proof of D-019's exact destination.
- Data/save: six authored archetypes define state/movement tuning. State, cooldown, memory, position and last-known position persist and are strictly validated (`threat_ai_state.gd:224-267`; `threat_save_contract.gd:135-177`).
- Status: `traced`.

### `REQ-D-010::acceptance-55a4624ec516`

**Criterion:** The "Combat, threat AI, damage, armor, status" package is implemented and smoke-validated.

- Inherited scope: D-010's main playable encounter, weapon/ammo, detection/damage, and persistence seam.
- Route/consequence: current layout/markers configure the manager, attacks route through the equipped weapon method, and both process branches tick combat (`playable_generated_ship.gd:9493-9507,9735-9748,9777-9810,11035-11087`). Placeholder nodes are spawned and updated from model state (`threat_manager.gd:284-293,402-408,443-526`).
- Predicate: `main_playable_slice_combat_encounter_smoke.gd:52-166` requires five threats/five archetypes, flare-pistol equip, exactly one flare round spent, a target, awareness `>=0.95`, detection, reduced health, production save/load, and restored weapon, target, health, memory tolerance and exact position.
- Data/save: the manager reads threat, weapon and ammo JSON; the damage pipeline reads status JSON. Restore validates `threat-manager-2`, applies it, rebuilds the graph, and repaths (`playable_generated_ship.gd:9735-9746`).
- Status: `traced`.

### `REQ-D-019::acceptance-a18a8bf12653`

**Criterion:** Threats in HUNT/ATTACK advance along `ShipNavGraph` waypoints without leaving the graph corridor.

- Route/consequence: `_motion_target_for` maps both states to player position; `_advance_threat_motion` obtains A* waypoints, calls `step_along_path`, updates model position/room, and `_update_placeholder` copies it to the scene (`threat_manager.gd:443-526`). Compiler standing edges are current graph authority under ADR-0054; blocked edges are omitted from neighbors (`ship_nav_graph.gd:206-221`).
- Predicate gap: `threat_path_follow_smoke.gd:34-60` and `main_playable_threat_pathfinding_smoke.gd:48-85` inject only HUNT and directly call the private movement helper. They require advance plus corridor/node proximity, but never exercise ATTACK, `tick_threats`, or the placeholder node.
- Data/save: archetype movement tuning is authored; position/state persist, waypoint cache does not, and restore rebuilds the graph.
- Status: `source_mapped_validation_gap`.

### `REQ-D-019::acceptance-c402f145b3f5`

**Criterion:** INVESTIGATE targets last-known position; FLEE targets farthest reachable node.

- Route/consequence: detection records `last_known_position`; memory decay reaches INVESTIGATE and low health reaches FLEE (`threat_ai_state.gd:119-180`). Current manager source routes INVESTIGATE to `last_known_world_position` and FLEE through `farthest_point` then A* (`threat_manager.gd:443-519`). Both paths exist.
- Predicate gap: the AI smoke never supplies/asserts a last-known position. The pathfinder smoke only requires its flee point not equal `Vector3.INF` (`threat_pathfinder_smoke.gd:41-43`).
- Runtime contract mismatch, distance phase: `ThreatPathfinder.farthest_point` documents Dijkstra distances (`threat_pathfinder.gd:58-65`) but uses an unordered FIFO queue and permanently skips visited nodes at `:66-84`. Current graph costs are unequal: static standing costs include `1.0`, `1.15`, `1.25`, and `1.5`, and fire multiplies matching edges by `6 * max(1, intensity)` (`ship_nav_graph.gd:117-123,294-315`). FIFO settlement is therefore not Dijkstra.
- Cardinal-grid counterexample using the actual fire overlay: place `S(0,0)`, `A(1,0)`, `T(2,0)`, `B(0,1)`, `C(1,1)`, `D(2,1)`, `U(3,0)`, with only edges `S-A`, `A-T`, `S-B`, `B-C`, `C-D`, `D-T`, `T-U`; the cardinal `A-C` structural edge is closed. Assign only `A` to a burning room. The any-edge-touching-fire-room rule makes `S-A=A-T=6`, while every other edge remains `1` (`ship_nav_graph.gd:299-315`). With `S` neighbors enumerated `A` before `B`, FIFO settles `T=12` and `U=13`; the cheap lower corridor later lowers `T` to `4`, but requeued `T` is skipped as visited, leaving `U=13` instead of shortest `5`. This layout is embeddable in the compiler standing graph, and `neighbors` performs no cost sort (`ship_nav_graph.gd:206-221`).
- Runtime contract mismatch, selection phase: the same function ranks `d_path * 0.35 + d_avoid` at `threat_pathfinder.gd:85-95`, which does not guarantee maximum shortest-path distance or maximum player distance. A complete fix must first compute correct shortest-path distances with minimum-distance extraction or correct reopen/propagation, then select lexicographically by maximum shortest-path distance with `d_avoid` only as a true tie-break. Replacing only the weighted score is insufficient.
- Data/save: flee/investigate tuning and last-known position are authored/persisted; waypoints are derived and repathed.
- Status: `confirmed_runtime_contract_mismatch`.

### `REQ-D-019::acceptance-7636f2902c8f`

**Criterion:** Pure unit smokes + main-scene smoke pass headless.

- Registered set: `ship_nav_graph_smoke.gd`, `threat_pathfinder_smoke.gd`, `threat_path_follow_smoke.gd`, and `main_playable_threat_pathfinding_smoke.gd` (`05_requirements.md:756-760`; ADR-0049:43-48).
- Substantive predicates: graph size/topology/wall/blocked/vertical/portal checks; a multi-step A* path and positive step; HUNT-only corridor movement; HUNT-only main-scene graph proximity.
- Gap: the set omits ATTACK movement, exact INVESTIGATE last-known destination, strict farthest selection, production tick caller, and placeholder sync. This audit did not run Godot and claims no fresh PASS.
- Status: `source_mapped_validation_gap`.

### `REQ-D-020::acceptance-ffe88a55d2db`

**Criterion:** Coordinator pushes fire rooms + unbypassed hatch bulkheads into `ThreatManager.update_nav_dynamic_costs`.

- Route/consequence: both process branches call `_tick_threat_runtime`, which invokes `_refresh_threat_nav_costs` before movement. That method gathers every burning compartment/intensity and only valid `not h.bypassed` compartment pairs, then calls the named manager method (`playable_generated_ship.gd:9855-9896,11035-11087`). The manager resets base costs, applies fire, and blocks each hatch pair (`threat_manager.gd:96-108`).
- Data/save: fire state supplies ids/intensity; `FIRE_COMPARTMENT_SYSTEM` and `HATCH_BULKHEAD_LINKS` define compartment labels (`playable_generated_ship.gd:341-365`). Fire/hatch owner state persists elsewhere; graph overlays remain derived.
- Predicate: this is exact static live wiring and is directly source-reviewable. A dedicated spy would improve regression detection, but current wiring is not unknown.
- Status: `traced`.

### `REQ-D-020::acceptance-e4f171937209`

**Criterion:** Blocked/costed edges affect A* routes.

- Route/consequence: fire multiplies matching base edges; hatch pairs set `BLOCKED_COST` (`ship_nav_graph.gd:294-340`). `neighbors` omits blocked edges and emits current dynamic costs (`:206-221`); A* accumulates those costs (`threat_pathfinder.gd:43-55`); resulting waypoints drive model and placeholder movement.
- Predicate gap: no validation script calls `apply_fire_costs`, `block_bulkhead`, `update_nav_dynamic_costs`, or `_refresh_threat_nav_costs`. `ship_nav_graph_smoke` covers static compiler/blocked-links topology, while `threat_pathfinder_smoke` uses an unmodified unique corridor. No predicate compares routes before/after a fire cost or proves hatch disconnection/repath on matching authored rooms.
- Classification: production source is connected; the missing dynamic assertion is a validation gap, not proof runtime is broken.
- Status: `source_mapped_validation_gap`.
