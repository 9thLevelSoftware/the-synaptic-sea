# R04 beacon voice source inventory

Read-only source inventory for the fresh Title → New Game warning:

```text
WARNING: AudioManager: stream file missing, path='res://data/audio/voice/log_beacon_01.ogg'
```

No Godot run, test, Git operation, or asset edit was performed for this report.

## Exact catalog and trigger

`scripts/audio/audio_log.gd:14-25` registers `log.beacon_01` with:

- label: `Beacon — Distress 01`
- transcript: `Mayday. Repeat, mayday. Reactor is critical. Hull integrity failing.`
- clip path: `res://data/audio/voice/log_beacon_01.ogg`
- duration: 5.0 seconds
- volume: -3 dB

`scripts/systems/meta_event_state.gd:24-31` schedules `beacon_distress` at 12 seconds with `voice_log_id = log.beacon_01` and volume -3 dB. In the normal playable coordinator path, `scripts/procgen/playable_generated_ship.gd:11186-11201` ticks `AudioManager`; `scripts/audio/audio_manager.gd:299-320` advances `MetaEventState`, routes the scheduled beacon through the meta SFX catalog, then calls `play_voice_log("log.beacon_01")`. The Title → New Game path therefore reaches this warning after the run has elapsed to the scheduled 12-second event; it is not a malformed Title catalog lookup.

The associated SFX event is cataloged in `scripts/systems/sfx_event_router.gd:74-79` as `meta.beacon.distress`, on the `meta` bus, with caption `Distress signal received`. The voice log itself is separate: `AudioManager.play_voice_log()` at `scripts/audio/audio_manager.gd:423-440` looks up the AudioLog entry, routes its authored `clip_path`, sets `current_voice_log_id`, and emits `voice_log_played`.

## Asset and fallback findings

The exact path is structurally consistent with the authored catalog. A bounded filesystem inspection found no `data/audio/voice` directory and no `log_beacon_01.ogg` under the project’s `data` or `assets` trees. The other five authored voice paths in `audio_log.gd` are likewise absent:

`log_beacon_02.ogg`, `log_pulse_01.ogg`, `log_groan_01.ogg`, `log_tutorial_pickup.ogg`, and `log_tutorial_calibrator.ogg`.

`AudioManager._load_stream_cached()` at `scripts/audio/audio_manager.gd:468-502` checks `FileAccess.file_exists()`, emits one warning per missing path through `_warned_missing_paths`, and returns null. `_play_via_bus()` retains the bus-volume operation and streamless behavior when no stream is available (`scripts/audio/audio_manager.gd:507+`). Thus the evidence classifies this as a genuinely missing deferred voice asset at an intentional authored path, rather than a wrong path or a load/extension mismatch. The `.ogg` dispatch is already authored for future delivery (`audio_manager.gd` comment immediately above the decoder branch).

## Transcript/caption coverage

The voice-log transcript is present in the AudioLog registry and is available to the audio log panel. `scripts/ui/audio_log_panel.gd:80-121` lists entries and calls `play_voice_log()`; `scripts/procgen/playable_generated_ship.gd:12291-12318` pumps router captions into the HUD. The scheduled beacon’s visible caption is the independent SFX caption `Distress signal received`; the transcript is not automatically enqueued as a closed caption by `play_voice_log()`.

The accessibility feature explicitly requires a selected Codex/audio-log entry to show its transcript (`docs/game/features/ui_ux_accessibility.md:65-70`). The audio feature says voice-log entries are data-only transcript + placeholder clip path (`docs/game/features/audio-music-spatial.md:74-78, Non-goals`) and requires voice-log replay through the voice bus (`REQ-AU-006`, same file). These sources support caption/transcript availability while the voice clip is absent; they do not require synthesized speech or a transcript caption at the instant the scheduled voice clip is missing.

## Governing authority and current validation contract

ADR-0044 is accepted (`docs/game/adr/0044-audio-bus-layout-registration-and-caption-settings-unification.md`). Its retained-deferral section explicitly names all six `data/audio/voice/` paths as absent, calls the condition an “honest-deferred-assets” contract, and requires warn-once missing-file fallback. It also states that the full voice asset library is out of scope; only two non-voice placeholder clips are committed. The ADR therefore authorizes the present missing voice asset and warning behavior; it does not authorize changing the path or adding audio as part of this inventory.

`docs/game/06_validation_plan.md:363-371` independently codifies the same contract: the voice directory remains absent, voice-playing smokes emit one expected warning per distinct path, and the regression runner allowlists only warnings under `res://data/audio/voice/`. `scripts/validation/audio_log_panel_smoke.gd:107-123` deliberately asserts that the authored clip path is attempted, while `main_playable_slice_audio_smoke.gd:96-100` exercises `log.beacon_01`. This means the warning is expected evidence of the deferred asset contract, not an unclassified fresh-Title failure.

## Disposition for R04

Source evidence is consistent with **allowed caption/transcript plus deferred missing voice asset**:

1. The beacon ID, trigger, transcript, clip path, and volume are all authored and internally coherent.
2. The referenced path does not exist anywhere in the inspected project asset locations; it is not a misplaced existing file.
3. The runtime warning and streamless fallback are explicitly specified by ADR-0044 and the validation plan.
4. The player still receives the `Distress signal received` meta caption, and the AudioLog UI exposes the written transcript.

This report does not decide whether R04 should promote voice assets, alter the warning, or change transcript-caption semantics. Those are policy/content decisions outside this bounded source inventory.
